package androidx.versionedparcelable;

public abstract class CustomVersionedParcelable implements q10 {
}
