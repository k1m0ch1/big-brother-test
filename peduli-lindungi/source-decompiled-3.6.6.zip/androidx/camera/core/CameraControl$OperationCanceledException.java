package androidx.camera.core;

public final class CameraControl$OperationCanceledException extends Exception {
    public CameraControl$OperationCanceledException(String str) {
        super(str);
    }
}
