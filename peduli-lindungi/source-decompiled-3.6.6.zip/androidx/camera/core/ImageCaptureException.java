package androidx.camera.core;

public class ImageCaptureException extends Exception {
}
