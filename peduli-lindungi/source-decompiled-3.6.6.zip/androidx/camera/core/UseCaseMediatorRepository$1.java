package androidx.camera.core;

import defpackage.sr;
import java.util.Map;

public class UseCaseMediatorRepository$1 implements xr {
    public final /* synthetic */ eb g;

    public UseCaseMediatorRepository$1(eb ebVar) {
        this.g = ebVar;
    }

    @gs(sr.a.ON_DESTROY)
    public void onDestroy(yr yrVar) {
        synchronized (this.g.a) {
            this.g.b.remove(yrVar);
        }
        as asVar = (as) yrVar.getLifecycle();
        asVar.d("removeObserver");
        asVar.b.m(this);
    }

    @gs(sr.a.ON_START)
    public void onStart(yr yrVar) {
        synchronized (this.g.a) {
            for (Map.Entry<yr, UseCaseMediatorLifecycleController> entry : this.g.b.entrySet()) {
                if (entry.getKey() != yrVar) {
                    wd e = entry.getValue().e();
                    if (e.e) {
                        e.f();
                    }
                }
            }
            eb ebVar = this.g;
            ebVar.d = yrVar;
            ebVar.c.add(0, yrVar);
        }
    }

    @gs(sr.a.ON_STOP)
    public void onStop(yr yrVar) {
        synchronized (this.g.a) {
            this.g.c.remove(yrVar);
            eb ebVar = this.g;
            if (ebVar.d == yrVar) {
                if (ebVar.c.size() > 0) {
                    eb ebVar2 = this.g;
                    ebVar2.d = ebVar2.c.get(0);
                    eb ebVar3 = this.g;
                    ebVar3.b.get(ebVar3.d).e().e();
                } else {
                    this.g.d = null;
                }
            }
        }
    }
}
