package androidx.camera.core.internal.utils;

public final class ImageUtil$CodecFailedException extends Exception {
}
