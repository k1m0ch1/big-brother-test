package androidx.camera.core.internal;

public final class CameraUseCaseAdapter$CameraException extends Exception {
}
