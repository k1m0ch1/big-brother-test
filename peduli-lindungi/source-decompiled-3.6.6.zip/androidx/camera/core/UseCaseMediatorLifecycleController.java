package androidx.camera.core;

import defpackage.sr;

public final class UseCaseMediatorLifecycleController implements xr {
    public final Object g = new Object();
    public final wd h;
    public final sr i;

    public UseCaseMediatorLifecycleController(sr srVar) {
        wd wdVar = new wd();
        this.h = wdVar;
        this.i = srVar;
        srVar.a(this);
    }

    public wd e() {
        wd wdVar;
        synchronized (this.g) {
            wdVar = this.h;
        }
        return wdVar;
    }

    public void f() {
        synchronized (this.g) {
            if (((as) this.i).c.compareTo(sr.b.STARTED) >= 0) {
                this.h.e();
            }
            for (db dbVar : this.h.d()) {
                dbVar.m();
            }
        }
    }

    @gs(sr.a.ON_DESTROY)
    public void onDestroy(yr yrVar) {
        synchronized (this.g) {
            this.h.b();
        }
    }

    @gs(sr.a.ON_START)
    public void onStart(yr yrVar) {
        synchronized (this.g) {
            this.h.e();
        }
    }

    @gs(sr.a.ON_STOP)
    public void onStop(yr yrVar) {
        synchronized (this.g) {
            this.h.f();
        }
    }
}
