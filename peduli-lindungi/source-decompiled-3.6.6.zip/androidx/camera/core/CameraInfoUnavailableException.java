package androidx.camera.core;

public final class CameraInfoUnavailableException extends Exception {
}
