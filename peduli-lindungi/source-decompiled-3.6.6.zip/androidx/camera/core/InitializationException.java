package androidx.camera.core;

public class InitializationException extends Exception {
    public InitializationException(Throwable th) {
        super(th);
    }
}
