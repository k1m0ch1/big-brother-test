package androidx.camera.core.impl;

import android.util.Log;
import android.view.Surface;
import defpackage.me;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class DeferrableSurface {
    public static final boolean f = Log.isLoggable("DeferrableSurface", 3);
    public static AtomicInteger g = new AtomicInteger(0);
    public static AtomicInteger h = new AtomicInteger(0);
    public final Object a = new Object();
    public int b = 0;
    public boolean c = false;
    public wg<Void> d;
    public final g03<Void> e;

    public static final class SurfaceClosedException extends Exception {
        public DeferrableSurface g;

        public SurfaceClosedException(String str, DeferrableSurface deferrableSurface) {
            super(str);
            this.g = deferrableSurface;
        }
    }

    public static final class SurfaceUnavailableException extends Exception {
        public SurfaceUnavailableException(String str) {
            super(str);
        }
    }

    public DeferrableSurface() {
        g03<Void> d2 = fg.d(new kb(this));
        this.e = d2;
        if (f) {
            f("Surface created", h.incrementAndGet(), g.get());
            d2.a(new jb(this, Log.getStackTraceString(new Exception())), i0.e());
        }
    }

    public final void a() {
        wg<Void> wgVar;
        synchronized (this.a) {
            if (!this.c) {
                this.c = true;
                if (this.b == 0) {
                    wgVar = this.d;
                    this.d = null;
                } else {
                    wgVar = null;
                }
                if (f) {
                    Log.d("DeferrableSurface", "surface closed,  useCount=" + this.b + " closed=true " + this);
                }
            } else {
                wgVar = null;
            }
        }
        if (wgVar != null) {
            wgVar.a(null);
        }
    }

    public void b() {
        wg<Void> wgVar;
        synchronized (this.a) {
            int i = this.b;
            if (i != 0) {
                int i2 = i - 1;
                this.b = i2;
                if (i2 != 0 || !this.c) {
                    wgVar = null;
                } else {
                    wgVar = this.d;
                    this.d = null;
                }
                boolean z = f;
                if (z) {
                    Log.d("DeferrableSurface", "use count-1,  useCount=" + this.b + " closed=" + this.c + " " + this);
                    if (this.b == 0 && z) {
                        f("Surface no longer in use", h.get(), g.decrementAndGet());
                    }
                }
            } else {
                throw new IllegalStateException("Decrementing use count occurs more times than incrementing");
            }
        }
        if (wgVar != null) {
            wgVar.a(null);
        }
    }

    public final g03<Surface> c() {
        synchronized (this.a) {
            if (this.c) {
                return new me.a(new SurfaceClosedException("DeferrableSurface already closed.", this));
            }
            return g();
        }
    }

    public g03<Void> d() {
        return le.d(this.e);
    }

    public void e() {
        synchronized (this.a) {
            int i = this.b;
            if (i == 0) {
                if (this.c) {
                    throw new SurfaceClosedException("Cannot begin use on a closed surface.", this);
                }
            }
            int i2 = i + 1;
            this.b = i2;
            if (f) {
                if (i2 == 1) {
                    f("New surface in use", h.get(), g.incrementAndGet());
                }
                Log.d("DeferrableSurface", "use count+1, useCount=" + this.b + " " + this);
            }
        }
    }

    public final void f(String str, int i, int i2) {
        Log.d("DeferrableSurface", str + "[total_surfaces=" + i + ", used_surfaces=" + i2 + "](" + this + "}");
    }

    public abstract g03<Surface> g();
}
