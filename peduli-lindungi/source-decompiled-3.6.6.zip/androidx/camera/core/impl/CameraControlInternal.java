package androidx.camera.core.impl;

public interface CameraControlInternal {
    public static final CameraControlInternal a = new a();

    public static final class CameraControlException extends Exception {
    }

    public class a implements CameraControlInternal {
        @Override // androidx.camera.core.impl.CameraControlInternal
        public void a(int i) {
        }
    }

    public interface b {
    }

    void a(int i);
}
