package androidx.camera.core;

public class CameraUnavailableException extends Exception {
    public CameraUnavailableException(int i, Throwable th) {
        super(th);
    }
}
