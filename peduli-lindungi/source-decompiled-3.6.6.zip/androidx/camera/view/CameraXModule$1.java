package androidx.camera.view;

import defpackage.sr;

public class CameraXModule$1 implements xr {
    @gs(sr.a.ON_DESTROY)
    public void onDestroy(yr yrVar) {
        throw null;
    }
}
