package androidx.camera.view;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.util.AttributeSet;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import androidx.lifecycle.LiveData;
import defpackage.wa;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;

public class PreviewView extends FrameLayout {
    public b g = b.SURFACE_VIEW;
    public sf h;
    public zf i = new zf();
    public es<d> j = new es<>(d.IDLE);
    public AtomicReference<rf> k = new AtomicReference<>();
    public final View.OnLayoutChangeListener l = new a();

    public class a implements View.OnLayoutChangeListener {
        public a() {
        }

        public void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
            sf sfVar = PreviewView.this.h;
            if (sfVar != null) {
                sfVar.a();
            }
        }
    }

    public enum b {
        SURFACE_VIEW,
        TEXTURE_VIEW
    }

    public enum c {
        FILL_START(0),
        FILL_CENTER(1),
        FILL_END(2),
        FIT_START(3),
        FIT_CENTER(4),
        FIT_END(5);
        
        public final int g;

        /* access modifiers changed from: public */
        c(int i) {
            this.g = i;
        }
    }

    public enum d {
        IDLE,
        STREAMING
    }

    /* JADX INFO: finally extract failed */
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public PreviewView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0, 0);
        Resources.Theme theme = context.getTheme();
        int[] iArr = tf.a;
        TypedArray obtainStyledAttributes = theme.obtainStyledAttributes(attributeSet, iArr, 0, 0);
        if (Build.VERSION.SDK_INT >= 29) {
            saveAttributeDataForStyleable(context, iArr, attributeSet, obtainStyledAttributes, 0, 0);
        }
        try {
            int integer = obtainStyledAttributes.getInteger(0, this.i.a.g);
            c[] values = c.values();
            for (int i2 = 0; i2 < 6; i2++) {
                c cVar = values[i2];
                if (cVar.g == integer) {
                    setScaleType(cVar);
                    obtainStyledAttributes.recycle();
                    if (getBackground() == null) {
                        setBackgroundColor(wk.b(getContext(), 17170444));
                        return;
                    }
                    return;
                }
            }
            throw new IllegalArgumentException("Unknown scale type id " + integer);
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    public wa.e a() {
        i0.c();
        removeAllViews();
        return new ef(this);
    }

    public final boolean b() {
        Display defaultDisplay = ((WindowManager) getContext().getSystemService("window")).getDefaultDisplay();
        return (((DisplayManager) getContext().getSystemService("display")).getDisplays().length <= 1 || defaultDisplay == null || defaultDisplay.getDisplayId() == 0) ? false : true;
    }

    public Bitmap getBitmap() {
        int i2;
        sf sfVar = this.h;
        if (sfVar == null) {
            return null;
        }
        Bitmap c2 = sfVar.c();
        if (c2 != null) {
            Objects.requireNonNull(sfVar.c);
            dg dgVar = sfVar.c.b;
            if (dgVar != null) {
                Matrix matrix = new Matrix();
                matrix.setScale(dgVar.a, dgVar.b);
                matrix.postRotate(dgVar.e);
                c2 = Bitmap.createBitmap(c2, 0, 0, c2.getWidth(), c2.getHeight(), matrix, true);
                c cVar = sfVar.c.a;
                if (!(cVar == c.FIT_START || cVar == c.FIT_CENTER || cVar == c.FIT_END)) {
                    Objects.requireNonNull(sfVar.b);
                    int ordinal = cVar.ordinal();
                    int i3 = 0;
                    if (ordinal != 0) {
                        if (ordinal == 1) {
                            i3 = (c2.getWidth() - sfVar.b.getWidth()) / 2;
                            i2 = (c2.getHeight() - sfVar.b.getHeight()) / 2;
                        } else if (ordinal == 2) {
                            i3 = c2.getWidth() - sfVar.b.getWidth();
                            i2 = c2.getHeight() - sfVar.b.getHeight();
                        }
                        c2 = Bitmap.createBitmap(c2, i3, i2, sfVar.b.getWidth(), sfVar.b.getHeight());
                    }
                    i2 = 0;
                    c2 = Bitmap.createBitmap(c2, i3, i2, sfVar.b.getWidth(), sfVar.b.getHeight());
                }
            }
        }
        return c2;
    }

    public int getDeviceRotationForRemoteDisplayMode() {
        return this.i.d;
    }

    public b getPreferredImplementationMode() {
        return this.g;
    }

    public LiveData<d> getPreviewStreamState() {
        return this.j;
    }

    public c getScaleType() {
        return this.i.a;
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        addOnLayoutChangeListener(this.l);
        sf sfVar = this.h;
        if (sfVar != null) {
            sfVar.d();
        }
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeOnLayoutChangeListener(this.l);
        sf sfVar = this.h;
        if (sfVar != null) {
            sfVar.e();
        }
    }

    public void setDeviceRotationForRemoteDisplayMode(int i2) {
        if (i2 != this.i.d && b()) {
            this.i.d = i2;
            sf sfVar = this.h;
            if (sfVar != null) {
                sfVar.a();
            }
        }
    }

    public void setPreferredImplementationMode(b bVar) {
        this.g = bVar;
    }

    public void setScaleType(c cVar) {
        this.i.a = cVar;
        sf sfVar = this.h;
        if (sfVar != null) {
            sfVar.a();
        }
    }
}
