package androidx.camera.camera2;

import defpackage.cc;
import defpackage.ja;
import defpackage.mc;

public final class Camera2Config$DefaultProvider implements ja.b {
    @Override // defpackage.ja.b
    public ja getCameraXConfig() {
        v4 v4Var = v4.a;
        x4 x4Var = x4.a;
        w4 w4Var = w4.a;
        ja.a aVar = new ja.a();
        hd hdVar = aVar.a;
        mc.a<cc.a> aVar2 = ja.v;
        mc.c cVar = mc.c.OPTIONAL;
        hdVar.B(aVar2, cVar, v4Var);
        aVar.a.B(ja.w, cVar, x4Var);
        aVar.a.B(ja.x, cVar, w4Var);
        return new ja(jd.y(aVar.a));
    }
}
