package androidx.camera.camera2.internal.compat;

import android.hardware.camera2.CameraAccessException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class CameraAccessExceptionCompat extends Exception {
    public static final Set<Integer> h = Collections.unmodifiableSet(new HashSet(Arrays.asList(4, 5, 1, 2, 3)));
    public final int g;

    static {
        Collections.unmodifiableSet(new HashSet(Arrays.asList(10001)));
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public CameraAccessExceptionCompat(int i, Throwable th) {
        super(i != 1 ? i != 2 ? i != 3 ? i != 4 ? i != 5 ? i != 10001 ? null : "Some API 28 devices cannot access the camera when the device is in \"Do Not Disturb\" mode. The camera will not be accessible until \"Do Not Disturb\" mode is disabled." : "The system-wide limit for number of open cameras has been reached, and more camera devices cannot be opened until previous instances are closed." : "The camera device is in use already" : "The camera device is currently in the error state; no further calls to it will succeed." : "The camera device is removable and has been disconnected from the Android device, or the camera service has shut down the connection due to a higher-priority access request for the camera device." : "The camera is disabled due to a device policy, and cannot be opened.", th);
        this.g = i;
        if (h.contains(Integer.valueOf(i))) {
            new CameraAccessException(i, null, th);
        }
    }

    public CameraAccessExceptionCompat(CameraAccessException cameraAccessException) {
        super(cameraAccessException.getMessage(), cameraAccessException.getCause());
        this.g = cameraAccessException.getReason();
    }
}
