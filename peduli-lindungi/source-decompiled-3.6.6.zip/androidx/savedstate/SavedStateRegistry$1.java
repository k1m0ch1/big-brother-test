package androidx.savedstate;

import defpackage.sr;

public class SavedStateRegistry$1 implements wr {
    public final /* synthetic */ nz g;

    public SavedStateRegistry$1(nz nzVar) {
        this.g = nzVar;
    }

    @Override // defpackage.wr
    public void c(yr yrVar, sr.a aVar) {
        if (aVar == sr.a.ON_START) {
            this.g.e = true;
        } else if (aVar == sr.a.ON_STOP) {
            this.g.e = false;
        }
    }
}
