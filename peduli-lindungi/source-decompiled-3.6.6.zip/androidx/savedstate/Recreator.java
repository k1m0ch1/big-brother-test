package androidx.savedstate;

import android.annotation.SuppressLint;
import android.os.Bundle;
import defpackage.nz;
import defpackage.sr;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

@SuppressLint({"RestrictedApi"})
public final class Recreator implements wr {
    public final pz g;

    public static final class a implements nz.b {
        public final Set<String> a = new HashSet();

        public a(nz nzVar) {
            if (nzVar.a.g("androidx.savedstate.Restarter", this) != null) {
                throw new IllegalArgumentException("SavedStateProvider with the given key is already registered");
            }
        }

        @Override // defpackage.nz.b
        public Bundle a() {
            Bundle bundle = new Bundle();
            bundle.putStringArrayList("classes_to_restore", new ArrayList<>(this.a));
            return bundle;
        }
    }

    public Recreator(pz pzVar) {
        this.g = pzVar;
    }

    @Override // defpackage.wr
    public void c(yr yrVar, sr.a aVar) {
        Class cls;
        if (aVar == sr.a.ON_CREATE) {
            as asVar = (as) yrVar.getLifecycle();
            asVar.d("removeObserver");
            asVar.b.m(this);
            Bundle a2 = this.g.getSavedStateRegistry().a("androidx.savedstate.Restarter");
            if (a2 != null) {
                ArrayList<String> stringArrayList = a2.getStringArrayList("classes_to_restore");
                if (stringArrayList != null) {
                    Iterator<String> it = stringArrayList.iterator();
                    while (it.hasNext()) {
                        String next = it.next();
                        try {
                            try {
                                Constructor<? extends U> declaredConstructor = Class.forName(next, false, Recreator.class.getClassLoader()).asSubclass(nz.a.class).getDeclaredConstructor(new Class[0]);
                                declaredConstructor.setAccessible(true);
                                try {
                                    ((nz.a) declaredConstructor.newInstance(new Object[0])).a(this.g);
                                } catch (Exception e) {
                                    throw new RuntimeException(ze0.r0("Failed to instantiate ", next), e);
                                }
                            } catch (NoSuchMethodException e2) {
                                StringBuilder J0 = ze0.J0("Class");
                                J0.append(cls.getSimpleName());
                                J0.append(" must have default constructor in order to be automatically recreated");
                                throw new IllegalStateException(J0.toString(), e2);
                            }
                        } catch (ClassNotFoundException e3) {
                            throw new RuntimeException(ze0.s0("Class ", next, " wasn't found"), e3);
                        }
                    }
                    return;
                }
                throw new IllegalStateException("Bundle with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
            }
            return;
        }
        throw new AssertionError("Next event must be ON_CREATE");
    }
}
