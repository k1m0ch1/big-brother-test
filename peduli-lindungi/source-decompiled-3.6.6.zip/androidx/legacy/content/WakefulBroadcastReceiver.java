package androidx.legacy.content;

import android.content.BroadcastReceiver;
import android.os.PowerManager;
import android.util.SparseArray;

@Deprecated
public abstract class WakefulBroadcastReceiver extends BroadcastReceiver {
    public static final SparseArray<PowerManager.WakeLock> a = new SparseArray<>();
    public static int b = 1;
}
