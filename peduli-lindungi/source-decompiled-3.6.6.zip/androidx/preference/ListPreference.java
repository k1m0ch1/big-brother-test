package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import androidx.preference.Preference;
import com.telkom.tracencare.R;

public class ListPreference extends DialogPreference {
    public CharSequence[] v;
    public CharSequence[] w;
    public String x;
    public String y;

    public static final class a implements Preference.a<ListPreference> {
        public static a a;

        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [androidx.preference.Preference] */
        @Override // androidx.preference.Preference.a
        public CharSequence a(ListPreference listPreference) {
            ListPreference listPreference2 = listPreference;
            if (TextUtils.isEmpty(listPreference2.y())) {
                return listPreference2.g.getString(R.string.not_set);
            }
            return listPreference2.y();
        }
    }

    public ListPreference(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, vx.d, i, i2);
        this.v = ek.M(obtainStyledAttributes, 2, 0);
        CharSequence[] textArray = obtainStyledAttributes.getTextArray(3);
        this.w = textArray == null ? obtainStyledAttributes.getTextArray(1) : textArray;
        if (obtainStyledAttributes.getBoolean(4, obtainStyledAttributes.getBoolean(4, false))) {
            if (a.a == null) {
                a.a = new a();
            }
            this.t = a.a;
            d();
        }
        obtainStyledAttributes.recycle();
        TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, vx.f, i, i2);
        this.y = ek.K(obtainStyledAttributes2, 33, 7);
        obtainStyledAttributes2.recycle();
    }

    @Override // androidx.preference.Preference
    public CharSequence a() {
        Preference.a aVar = this.t;
        if (aVar != null) {
            return aVar.a(this);
        }
        CharSequence y2 = y();
        CharSequence a2 = super.a();
        String str = this.y;
        if (str == null) {
            return a2;
        }
        Object[] objArr = new Object[1];
        if (y2 == null) {
            y2 = "";
        }
        objArr[0] = y2;
        String format = String.format(str, objArr);
        if (TextUtils.equals(format, a2)) {
            return a2;
        }
        Log.w("ListPreference", "Setting a summary with a String formatting marker is no longer supported. You should use a SummaryProvider instead.");
        return format;
    }

    @Override // androidx.preference.Preference
    public Object m(TypedArray typedArray, int i) {
        return typedArray.getString(i);
    }

    public CharSequence y() {
        CharSequence[] charSequenceArr;
        CharSequence[] charSequenceArr2;
        String str = this.x;
        int i = -1;
        if (str != null && (charSequenceArr2 = this.w) != null) {
            int length = charSequenceArr2.length - 1;
            while (true) {
                if (length < 0) {
                    break;
                } else if (this.w[length].equals(str)) {
                    i = length;
                    break;
                } else {
                    length--;
                }
            }
        }
        if (i < 0 || (charSequenceArr = this.v) == null) {
            return null;
        }
        return charSequenceArr[i];
    }

    public ListPreference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ek.z(context, R.attr.dialogPreferenceStyle, 16842897), 0);
    }
}
