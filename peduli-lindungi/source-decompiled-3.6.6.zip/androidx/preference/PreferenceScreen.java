package androidx.preference;

import android.content.Context;
import android.util.AttributeSet;
import com.telkom.tracencare.R;

public final class PreferenceScreen extends PreferenceGroup {
    public PreferenceScreen(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, ek.z(context, R.attr.preferenceScreenStyle, 16842891), 0);
    }
}
