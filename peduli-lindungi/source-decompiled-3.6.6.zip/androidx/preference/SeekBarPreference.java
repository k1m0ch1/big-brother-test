package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import com.telkom.tracencare.R;

public class SeekBarPreference extends Preference {
    public int u;
    public int v;
    public int w;
    public boolean x;
    public boolean y;

    public SeekBarPreference(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.seekBarPreferenceStyle, 0);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, vx.i, R.attr.seekBarPreferenceStyle, 0);
        this.u = obtainStyledAttributes.getInt(3, 0);
        int i = obtainStyledAttributes.getInt(1, 100);
        int i2 = this.u;
        i = i < i2 ? i2 : i;
        if (i != this.v) {
            this.v = i;
        }
        int i3 = obtainStyledAttributes.getInt(4, 0);
        if (i3 != this.w) {
            this.w = Math.min(this.v - this.u, Math.abs(i3));
        }
        this.x = obtainStyledAttributes.getBoolean(2, true);
        obtainStyledAttributes.getBoolean(5, false);
        this.y = obtainStyledAttributes.getBoolean(6, false);
        obtainStyledAttributes.recycle();
    }

    @Override // androidx.preference.Preference
    public Object m(TypedArray typedArray, int i) {
        return Integer.valueOf(typedArray.getInt(i, 0));
    }
}
