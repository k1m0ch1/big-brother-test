package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.CompoundButton;
import com.telkom.tracencare.R;
import java.util.Objects;

public class SwitchPreference extends TwoStatePreference {
    public CharSequence A;
    public CharSequence B;
    public final a z = new a();

    public class a implements CompoundButton.OnCheckedChangeListener {
        public a() {
        }

        public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
            Objects.requireNonNull(SwitchPreference.this);
            SwitchPreference.this.y(z);
        }
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    public SwitchPreference(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, r0, 0);
        int z2 = ek.z(context, R.attr.switchPreferenceStyle, 16843629);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, vx.j, z2, 0);
        this.v = ek.K(obtainStyledAttributes, 7, 0);
        String string = obtainStyledAttributes.getString(6);
        this.w = string == null ? obtainStyledAttributes.getString(1) : string;
        String string2 = obtainStyledAttributes.getString(9);
        this.A = string2 == null ? obtainStyledAttributes.getString(3) : string2;
        String string3 = obtainStyledAttributes.getString(8);
        this.B = string3 == null ? obtainStyledAttributes.getString(4) : string3;
        this.y = obtainStyledAttributes.getBoolean(5, obtainStyledAttributes.getBoolean(2, false));
        obtainStyledAttributes.recycle();
    }
}
