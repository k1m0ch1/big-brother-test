package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import androidx.preference.Preference;
import com.telkom.tracencare.R;

public class EditTextPreference extends DialogPreference {

    public static final class a implements Preference.a<EditTextPreference> {
        public static a a;

        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [androidx.preference.Preference] */
        @Override // androidx.preference.Preference.a
        public CharSequence a(EditTextPreference editTextPreference) {
            EditTextPreference editTextPreference2 = editTextPreference;
            if (TextUtils.isEmpty(null)) {
                return editTextPreference2.g.getString(R.string.not_set);
            }
            return null;
        }
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    public EditTextPreference(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, r0, 0);
        int z = ek.z(context, R.attr.editTextPreferenceStyle, 16842898);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, vx.c, z, 0);
        if (ek.A(obtainStyledAttributes, 0, 0, false)) {
            if (a.a == null) {
                a.a = new a();
            }
            this.t = a.a;
        }
        obtainStyledAttributes.recycle();
    }

    @Override // androidx.preference.Preference
    public Object m(TypedArray typedArray, int i) {
        return typedArray.getString(i);
    }
}
