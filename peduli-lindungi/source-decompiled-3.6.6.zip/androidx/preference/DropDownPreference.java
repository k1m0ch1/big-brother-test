package androidx.preference;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ArrayAdapter;
import com.telkom.tracencare.R;

public class DropDownPreference extends ListPreference {
    public final ArrayAdapter A;
    public final Context z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DropDownPreference(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.dropdownPreferenceStyle, 0);
        this.z = context;
        ArrayAdapter arrayAdapter = new ArrayAdapter(context, 17367049);
        this.A = arrayAdapter;
        arrayAdapter.clear();
        CharSequence[] charSequenceArr = this.v;
        if (charSequenceArr != null) {
            for (CharSequence charSequence : charSequenceArr) {
                this.A.add(charSequence.toString());
            }
        }
    }

    @Override // androidx.preference.Preference
    public void d() {
        ArrayAdapter arrayAdapter = this.A;
        if (arrayAdapter != null) {
            arrayAdapter.notifyDataSetChanged();
        }
    }
}
