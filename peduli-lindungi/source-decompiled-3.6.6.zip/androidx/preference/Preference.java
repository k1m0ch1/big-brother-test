package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import com.telkom.tracencare.R;

public class Preference implements Comparable<Preference> {
    public Context g;
    public int h;
    public CharSequence i;
    public CharSequence j;
    public String k;
    public String l;
    public boolean m;
    public boolean n;
    public boolean o;
    public Object p;
    public boolean q;
    public boolean r;
    public boolean s;
    public a t;

    public interface a<T extends Preference> {
        CharSequence a(T t);
    }

    public Preference(Context context, AttributeSet attributeSet, int i2, int i3) {
        this.h = Integer.MAX_VALUE;
        this.m = true;
        this.n = true;
        this.o = true;
        this.q = true;
        this.r = true;
        this.g = context;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, vx.f, i2, i3);
        ek.J(obtainStyledAttributes, 23, 0, 0);
        String string = obtainStyledAttributes.getString(26);
        this.k = string == null ? obtainStyledAttributes.getString(6) : string;
        CharSequence text = obtainStyledAttributes.getText(34);
        this.i = text == null ? obtainStyledAttributes.getText(4) : text;
        CharSequence text2 = obtainStyledAttributes.getText(33);
        this.j = text2 == null ? obtainStyledAttributes.getText(7) : text2;
        this.h = obtainStyledAttributes.getInt(28, obtainStyledAttributes.getInt(8, Integer.MAX_VALUE));
        String string2 = obtainStyledAttributes.getString(22);
        this.l = string2 == null ? obtainStyledAttributes.getString(13) : string2;
        obtainStyledAttributes.getResourceId(27, obtainStyledAttributes.getResourceId(3, R.layout.preference));
        obtainStyledAttributes.getResourceId(35, obtainStyledAttributes.getResourceId(9, 0));
        this.m = obtainStyledAttributes.getBoolean(21, obtainStyledAttributes.getBoolean(2, true));
        this.n = obtainStyledAttributes.getBoolean(30, obtainStyledAttributes.getBoolean(5, true));
        this.o = obtainStyledAttributes.getBoolean(29, obtainStyledAttributes.getBoolean(1, true));
        if (obtainStyledAttributes.getString(19) == null) {
            obtainStyledAttributes.getString(10);
        }
        obtainStyledAttributes.getBoolean(16, obtainStyledAttributes.getBoolean(16, this.n));
        obtainStyledAttributes.getBoolean(17, obtainStyledAttributes.getBoolean(17, this.n));
        if (obtainStyledAttributes.hasValue(18)) {
            this.p = m(obtainStyledAttributes, 18);
        } else if (obtainStyledAttributes.hasValue(11)) {
            this.p = m(obtainStyledAttributes, 11);
        }
        obtainStyledAttributes.getBoolean(31, obtainStyledAttributes.getBoolean(12, true));
        boolean hasValue = obtainStyledAttributes.hasValue(32);
        this.s = hasValue;
        if (hasValue) {
            obtainStyledAttributes.getBoolean(32, obtainStyledAttributes.getBoolean(14, true));
        }
        obtainStyledAttributes.getBoolean(24, obtainStyledAttributes.getBoolean(15, false));
        obtainStyledAttributes.getBoolean(25, obtainStyledAttributes.getBoolean(25, true));
        obtainStyledAttributes.getBoolean(20, obtainStyledAttributes.getBoolean(20, false));
        obtainStyledAttributes.recycle();
    }

    public CharSequence a() {
        a aVar = this.t;
        if (aVar != null) {
            return aVar.a(this);
        }
        return this.j;
    }

    public boolean c() {
        return this.m && this.q && this.r;
    }

    /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object] */
    @Override // java.lang.Comparable
    public int compareTo(Preference preference) {
        Preference preference2 = preference;
        int i2 = this.h;
        int i3 = preference2.h;
        if (i2 != i3) {
            return i2 - i3;
        }
        CharSequence charSequence = this.i;
        CharSequence charSequence2 = preference2.i;
        if (charSequence == charSequence2) {
            return 0;
        }
        if (charSequence == null) {
            return 1;
        }
        if (charSequence2 == null) {
            return -1;
        }
        return charSequence.toString().compareToIgnoreCase(preference2.i.toString());
    }

    public void d() {
    }

    public Object m(TypedArray typedArray, int i2) {
        return null;
    }

    public boolean r() {
        return !c();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        CharSequence charSequence = this.i;
        if (!TextUtils.isEmpty(charSequence)) {
            sb.append(charSequence);
            sb.append(' ');
        }
        CharSequence a2 = a();
        if (!TextUtils.isEmpty(a2)) {
            sb.append(a2);
            sb.append(' ');
        }
        if (sb.length() > 0) {
            sb.setLength(sb.length() - 1);
        }
        return sb.toString();
    }

    public Preference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ek.z(context, R.attr.preferenceStyle, 16842894), 0);
    }
}
