package androidx.preference;

import android.content.Context;
import android.util.AttributeSet;
import com.telkom.tracencare.R;

public class PreferenceCategory extends PreferenceGroup {
    public PreferenceCategory(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, ek.z(context, R.attr.preferenceCategoryStyle, 16842892), 0);
    }

    @Override // androidx.preference.Preference
    public boolean c() {
        return false;
    }
}
