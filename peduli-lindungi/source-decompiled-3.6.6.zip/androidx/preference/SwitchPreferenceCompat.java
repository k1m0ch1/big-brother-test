package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.CompoundButton;
import com.telkom.tracencare.R;
import java.util.Objects;

public class SwitchPreferenceCompat extends TwoStatePreference {
    public CharSequence A;
    public CharSequence B;
    public final a z = new a();

    public class a implements CompoundButton.OnCheckedChangeListener {
        public a() {
        }

        public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
            Objects.requireNonNull(SwitchPreferenceCompat.this);
            SwitchPreferenceCompat.this.y(z);
        }
    }

    public SwitchPreferenceCompat(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.switchPreferenceCompatStyle, 0);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, vx.k, R.attr.switchPreferenceCompatStyle, 0);
        this.v = ek.K(obtainStyledAttributes, 7, 0);
        String string = obtainStyledAttributes.getString(6);
        this.w = string == null ? obtainStyledAttributes.getString(1) : string;
        String string2 = obtainStyledAttributes.getString(9);
        this.A = string2 == null ? obtainStyledAttributes.getString(3) : string2;
        String string3 = obtainStyledAttributes.getString(8);
        this.B = string3 == null ? obtainStyledAttributes.getString(4) : string3;
        this.y = obtainStyledAttributes.getBoolean(5, obtainStyledAttributes.getBoolean(2, false));
        obtainStyledAttributes.recycle();
    }
}
