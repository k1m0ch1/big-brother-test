package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.CompoundButton;
import com.telkom.tracencare.R;
import java.util.Objects;

public class CheckBoxPreference extends TwoStatePreference {
    public final a z = new a();

    public class a implements CompoundButton.OnCheckedChangeListener {
        public a() {
        }

        public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
            Objects.requireNonNull(CheckBoxPreference.this);
            CheckBoxPreference.this.y(z);
        }
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    public CheckBoxPreference(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, r0, 0);
        int z2 = ek.z(context, R.attr.checkBoxPreferenceStyle, 16842895);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, vx.a, z2, 0);
        this.v = ek.K(obtainStyledAttributes, 5, 0);
        String string = obtainStyledAttributes.getString(4);
        this.w = string == null ? obtainStyledAttributes.getString(1) : string;
        this.y = obtainStyledAttributes.getBoolean(3, obtainStyledAttributes.getBoolean(2, false));
        obtainStyledAttributes.recycle();
    }
}
