package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;

public abstract class TwoStatePreference extends Preference {
    public boolean u;
    public CharSequence v;
    public CharSequence w;
    public boolean x;
    public boolean y;

    public TwoStatePreference(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0, 0);
    }

    @Override // androidx.preference.Preference
    public Object m(TypedArray typedArray, int i) {
        return Boolean.valueOf(typedArray.getBoolean(i, false));
    }

    @Override // androidx.preference.Preference
    public boolean r() {
        if ((this.y ? this.u : !this.u) || super.r()) {
            return true;
        }
        return false;
    }

    public void y(boolean z) {
        boolean z2 = this.u != z;
        if (z2 || !this.x) {
            this.u = z;
            this.x = true;
            if (z2) {
                r();
            }
        }
    }

    public TwoStatePreference(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
    }
}
