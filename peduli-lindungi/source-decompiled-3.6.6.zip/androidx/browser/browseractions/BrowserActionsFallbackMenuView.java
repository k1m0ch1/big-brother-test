package androidx.browser.browseractions;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import com.telkom.tracencare.R;

public class BrowserActionsFallbackMenuView extends LinearLayout {
    public final int g = getResources().getDimensionPixelOffset(R.dimen.browser_actions_context_menu_min_padding);
    public final int h = getResources().getDimensionPixelOffset(R.dimen.browser_actions_context_menu_max_width);

    public BrowserActionsFallbackMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(Math.min(getResources().getDisplayMetrics().widthPixels - (this.g * 2), this.h), 1073741824), i2);
    }
}
