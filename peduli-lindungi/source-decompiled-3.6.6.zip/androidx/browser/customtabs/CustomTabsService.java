package androidx.browser.customtabs;

import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import java.util.List;
import java.util.Map;

public abstract class CustomTabsService extends Service {
    public final Map<IBinder, IBinder.DeathRecipient> g = new mg();
    public n h = new a();

    public class a extends n {
        public a() {
        }
    }

    public abstract Bundle a(String str, Bundle bundle);

    public abstract boolean b(u4 u4Var, Uri uri, Bundle bundle, List<Bundle> list);

    public abstract boolean c(u4 u4Var);

    public abstract int d(u4 u4Var, String str, Bundle bundle);

    public abstract boolean e(u4 u4Var, Uri uri);

    public abstract boolean f(u4 u4Var, Bundle bundle);

    public abstract boolean g(u4 u4Var, int i, Uri uri, Bundle bundle);

    public abstract boolean h(long j);

    public IBinder onBind(Intent intent) {
        return this.h;
    }
}
