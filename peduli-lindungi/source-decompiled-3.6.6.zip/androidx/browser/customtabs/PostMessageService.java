package androidx.browser.customtabs;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class PostMessageService extends Service {
    public o g = new a(this);

    public class a extends o {
        public a(PostMessageService postMessageService) {
        }
    }

    public IBinder onBind(Intent intent) {
        return this.g;
    }
}
