package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.github.mikephil.charting.utils.Utils;
import defpackage.hy;
import defpackage.lo;
import java.util.Arrays;
import java.util.Objects;

public class GridLayoutManager extends LinearLayoutManager {
    public boolean G = false;
    public int H = -1;
    public int[] I;
    public View[] J;
    public final SparseIntArray K = new SparseIntArray();
    public final SparseIntArray L = new SparseIntArray();
    public c M = new a();
    public final Rect N = new Rect();

    public static final class a extends c {
    }

    public static abstract class c {
        public final SparseIntArray a = new SparseIntArray();
        public final SparseIntArray b = new SparseIntArray();

        public int a(int i, int i2) {
            int i3 = 0;
            int i4 = 0;
            for (int i5 = 0; i5 < i; i5++) {
                i3++;
                if (i3 == i2) {
                    i4++;
                    i3 = 0;
                } else if (i3 > i2) {
                    i4++;
                    i3 = 1;
                }
            }
            return i3 + 1 > i2 ? i4 + 1 : i4;
        }
    }

    public GridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        P1(RecyclerView.m.R(context, attributeSet, i, i2).b);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int A(RecyclerView.t tVar, RecyclerView.y yVar) {
        if (this.r == 1) {
            return this.H;
        }
        if (yVar.b() < 1) {
            return 0;
        }
        return K1(tVar, yVar, yVar.b() - 1) + 1;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public void D1(boolean z) {
        if (!z) {
            d(null);
            if (this.x) {
                this.x = false;
                K0();
                return;
            }
            return;
        }
        throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
    }

    public final void H1(int i) {
        int i2;
        int[] iArr = this.I;
        int i3 = this.H;
        if (!(iArr != null && iArr.length == i3 + 1 && iArr[iArr.length - 1] == i)) {
            iArr = new int[(i3 + 1)];
        }
        int i4 = 0;
        iArr[0] = 0;
        int i5 = i / i3;
        int i6 = i % i3;
        int i7 = 0;
        for (int i8 = 1; i8 <= i3; i8++) {
            i4 += i6;
            if (i4 <= 0 || i3 - i4 >= i6) {
                i2 = i5;
            } else {
                i2 = i5 + 1;
                i4 -= i3;
            }
            i7 += i2;
            iArr[i8] = i7;
        }
        this.I = iArr;
    }

    public final void I1() {
        View[] viewArr = this.J;
        if (viewArr == null || viewArr.length != this.H) {
            this.J = new View[this.H];
        }
    }

    public int J1(int i, int i2) {
        if (this.r != 1 || !u1()) {
            int[] iArr = this.I;
            return iArr[i2 + i] - iArr[i];
        }
        int[] iArr2 = this.I;
        int i3 = this.H;
        return iArr2[i3 - i] - iArr2[(i3 - i) - i2];
    }

    public final int K1(RecyclerView.t tVar, RecyclerView.y yVar, int i) {
        if (!yVar.g) {
            return this.M.a(i, this.H);
        }
        int c2 = tVar.c(i);
        if (c2 != -1) {
            return this.M.a(c2, this.H);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. " + i);
        return 0;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m, androidx.recyclerview.widget.LinearLayoutManager
    public int L0(int i, RecyclerView.t tVar, RecyclerView.y yVar) {
        Q1();
        I1();
        if (this.r == 1) {
            return 0;
        }
        return B1(i, tVar, yVar);
    }

    public final int L1(RecyclerView.t tVar, RecyclerView.y yVar, int i) {
        if (!yVar.g) {
            c cVar = this.M;
            int i2 = this.H;
            Objects.requireNonNull(cVar);
            return i % i2;
        }
        int i3 = this.L.get(i, -1);
        if (i3 != -1) {
            return i3;
        }
        int c2 = tVar.c(i);
        if (c2 == -1) {
            Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i);
            return 0;
        }
        c cVar2 = this.M;
        int i4 = this.H;
        Objects.requireNonNull(cVar2);
        return c2 % i4;
    }

    public final int M1(RecyclerView.t tVar, RecyclerView.y yVar, int i) {
        if (!yVar.g) {
            Objects.requireNonNull(this.M);
            return 1;
        }
        int i2 = this.K.get(i, -1);
        if (i2 != -1) {
            return i2;
        }
        if (tVar.c(i) == -1) {
            Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i);
            return 1;
        }
        Objects.requireNonNull(this.M);
        return 1;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m, androidx.recyclerview.widget.LinearLayoutManager
    public int N0(int i, RecyclerView.t tVar, RecyclerView.y yVar) {
        Q1();
        I1();
        if (this.r == 0) {
            return 0;
        }
        return B1(i, tVar, yVar);
    }

    public final void N1(View view, int i, boolean z) {
        int i2;
        int i3;
        b bVar = (b) view.getLayoutParams();
        Rect rect = bVar.b;
        int i4 = rect.top + rect.bottom + ((ViewGroup.MarginLayoutParams) bVar).topMargin + ((ViewGroup.MarginLayoutParams) bVar).bottomMargin;
        int i5 = rect.left + rect.right + ((ViewGroup.MarginLayoutParams) bVar).leftMargin + ((ViewGroup.MarginLayoutParams) bVar).rightMargin;
        int J1 = J1(bVar.e, bVar.f);
        if (this.r == 1) {
            i2 = RecyclerView.m.z(J1, i, i5, ((ViewGroup.MarginLayoutParams) bVar).width, false);
            i3 = RecyclerView.m.z(this.t.l(), this.o, i4, ((ViewGroup.MarginLayoutParams) bVar).height, true);
        } else {
            int z2 = RecyclerView.m.z(J1, i, i4, ((ViewGroup.MarginLayoutParams) bVar).height, false);
            int z3 = RecyclerView.m.z(this.t.l(), this.n, i5, ((ViewGroup.MarginLayoutParams) bVar).width, true);
            i3 = z2;
            i2 = z3;
        }
        O1(view, i2, i3, z);
    }

    public final void O1(View view, int i, int i2, boolean z) {
        boolean z2;
        RecyclerView.n nVar = (RecyclerView.n) view.getLayoutParams();
        if (z) {
            z2 = V0(view, i, i2, nVar);
        } else {
            z2 = T0(view, i, i2, nVar);
        }
        if (z2) {
            view.measure(i, i2);
        }
    }

    public void P1(int i) {
        if (i != this.H) {
            this.G = true;
            if (i >= 1) {
                this.H = i;
                this.M.a.clear();
                K0();
                return;
            }
            throw new IllegalArgumentException(ze0.j0("Span count should be at least 1. Provided ", i));
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void Q0(Rect rect, int i, int i2) {
        int i3;
        int i4;
        if (this.I == null) {
            super.Q0(rect, i, i2);
        }
        int O = O() + N();
        int M2 = M() + P();
        if (this.r == 1) {
            i4 = RecyclerView.m.h(i2, rect.height() + M2, K());
            int[] iArr = this.I;
            i3 = RecyclerView.m.h(i, iArr[iArr.length - 1] + O, L());
        } else {
            i3 = RecyclerView.m.h(i, rect.width() + O, L());
            int[] iArr2 = this.I;
            i4 = RecyclerView.m.h(i2, iArr2[iArr2.length - 1] + M2, K());
        }
        this.b.setMeasuredDimension(i3, i4);
    }

    public final void Q1() {
        int i;
        int i2;
        if (this.r == 1) {
            i2 = this.p - O();
            i = N();
        } else {
            i2 = this.q - M();
            i = P();
        }
        H1(i2 - i);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int S(RecyclerView.t tVar, RecyclerView.y yVar) {
        if (this.r == 0) {
            return this.H;
        }
        if (yVar.b() < 1) {
            return 0;
        }
        return K1(tVar, yVar, yVar.b() - 1) + 1;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m, androidx.recyclerview.widget.LinearLayoutManager
    public boolean Y0() {
        return this.B == null && !this.G;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public void a1(RecyclerView.y yVar, LinearLayoutManager.c cVar, RecyclerView.m.c cVar2) {
        int i = this.H;
        for (int i2 = 0; i2 < this.H && cVar.b(yVar) && i > 0; i2++) {
            ((hy.b) cVar2).a(cVar.d, Math.max(0, cVar.g));
            Objects.requireNonNull(this.M);
            i--;
            cVar.d += cVar.e;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean g(RecyclerView.n nVar) {
        return nVar instanceof b;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:52:0x00ca, code lost:
        if (r13 == (r2 > r15)) goto L_0x00cc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:62:0x00e6, code lost:
        if (r13 == (r2 > r8)) goto L_0x00e8;
     */
    /* JADX WARNING: Removed duplicated region for block: B:67:0x00f0  */
    @Override // androidx.recyclerview.widget.RecyclerView.m, androidx.recyclerview.widget.LinearLayoutManager
    public View h0(View view, int i, RecyclerView.t tVar, RecyclerView.y yVar) {
        int i2;
        int i3;
        int i4;
        int i5;
        View view2;
        View view3;
        boolean z;
        RecyclerView.t tVar2 = tVar;
        RecyclerView.y yVar2 = yVar;
        View s = s(view);
        View view4 = null;
        if (s == null) {
            return null;
        }
        b bVar = (b) s.getLayoutParams();
        int i6 = bVar.e;
        int i7 = bVar.f + i6;
        if (super.h0(view, i, tVar, yVar) == null) {
            return null;
        }
        if ((e1(i) == 1) != this.w) {
            i4 = y() - 1;
            i3 = -1;
            i2 = -1;
        } else {
            i3 = y();
            i4 = 0;
            i2 = 1;
        }
        boolean z2 = this.r == 1 && u1();
        int K1 = K1(tVar2, yVar2, i4);
        int i8 = i4;
        int i9 = -1;
        int i10 = 0;
        int i11 = 0;
        int i12 = -1;
        View view5 = null;
        while (i8 != i3) {
            int K12 = K1(tVar2, yVar2, i8);
            View x = x(i8);
            if (x == s) {
                break;
            }
            if (!x.hasFocusable() || K12 == K1) {
                b bVar2 = (b) x.getLayoutParams();
                int i13 = bVar2.e;
                view2 = s;
                int i14 = bVar2.f + i13;
                if (x.hasFocusable() && i13 == i6 && i14 == i7) {
                    return x;
                }
                if ((!x.hasFocusable() || view4 != null) && (x.hasFocusable() || view5 != null)) {
                    view3 = view5;
                    int min = Math.min(i14, i7) - Math.max(i13, i6);
                    if (x.hasFocusable()) {
                        if (min <= i10) {
                            if (min == i10) {
                            }
                        }
                    } else if (view4 == null) {
                        i5 = i10;
                        if (Y(x, false)) {
                            if (min <= i11) {
                                if (min == i11) {
                                }
                            }
                            z = true;
                            if (z) {
                                if (x.hasFocusable()) {
                                    int i15 = bVar2.e;
                                    i5 = Math.min(i14, i7) - Math.max(i13, i6);
                                    i12 = i15;
                                    view5 = view3;
                                    view4 = x;
                                } else {
                                    int i16 = bVar2.e;
                                    i11 = Math.min(i14, i7) - Math.max(i13, i6);
                                    i9 = i16;
                                    view5 = x;
                                }
                                i8 += i2;
                                tVar2 = tVar;
                                yVar2 = yVar;
                                i3 = i3;
                                s = view2;
                                i10 = i5;
                            }
                        }
                        z = false;
                        if (z) {
                        }
                    }
                    i5 = i10;
                    z = false;
                    if (z) {
                    }
                } else {
                    view3 = view5;
                }
                i5 = i10;
                z = true;
                if (z) {
                }
            } else if (view4 != null) {
                break;
            } else {
                view2 = s;
                view3 = view5;
                i5 = i10;
            }
            view5 = view3;
            i8 += i2;
            tVar2 = tVar;
            yVar2 = yVar;
            i3 = i3;
            s = view2;
            i10 = i5;
        }
        return view4 != null ? view4 : view5;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m, androidx.recyclerview.widget.LinearLayoutManager
    public int l(RecyclerView.y yVar) {
        return c1(yVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m, androidx.recyclerview.widget.LinearLayoutManager
    public int m(RecyclerView.y yVar) {
        return d1(yVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void m0(RecyclerView.t tVar, RecyclerView.y yVar, View view, lo loVar) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof b)) {
            l0(view, loVar);
            return;
        }
        b bVar = (b) layoutParams;
        int K1 = K1(tVar, yVar, bVar.a());
        if (this.r == 0) {
            loVar.j(lo.c.a(bVar.e, bVar.f, K1, 1, false, false));
        } else {
            loVar.j(lo.c.a(K1, 1, bVar.e, bVar.f, false, false));
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m, androidx.recyclerview.widget.LinearLayoutManager
    public int o(RecyclerView.y yVar) {
        return c1(yVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void o0(RecyclerView recyclerView, int i, int i2) {
        this.M.a.clear();
        this.M.b.clear();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m, androidx.recyclerview.widget.LinearLayoutManager
    public int p(RecyclerView.y yVar) {
        return d1(yVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void p0(RecyclerView recyclerView) {
        this.M.a.clear();
        this.M.b.clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public View p1(RecyclerView.t tVar, RecyclerView.y yVar, boolean z, boolean z2) {
        int i;
        int y = y();
        int i2 = -1;
        int i3 = 1;
        if (z2) {
            i = y() - 1;
            i3 = -1;
        } else {
            i2 = y;
            i = 0;
        }
        int b2 = yVar.b();
        f1();
        int k = this.t.k();
        int g = this.t.g();
        View view = null;
        View view2 = null;
        while (i != i2) {
            View x = x(i);
            int Q = Q(x);
            if (Q >= 0 && Q < b2 && L1(tVar, yVar, Q) == 0) {
                if (((RecyclerView.n) x.getLayoutParams()).c()) {
                    if (view2 == null) {
                        view2 = x;
                    }
                } else if (this.t.e(x) < g && this.t.b(x) >= k) {
                    return x;
                } else {
                    if (view == null) {
                        view = x;
                    }
                }
            }
            i += i3;
        }
        return view != null ? view : view2;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void q0(RecyclerView recyclerView, int i, int i2, int i3) {
        this.M.a.clear();
        this.M.b.clear();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void r0(RecyclerView recyclerView, int i, int i2) {
        this.M.a.clear();
        this.M.b.clear();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void t0(RecyclerView recyclerView, int i, int i2, Object obj) {
        this.M.a.clear();
        this.M.b.clear();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m, androidx.recyclerview.widget.LinearLayoutManager
    public RecyclerView.n u() {
        if (this.r == 0) {
            return new b(-2, -1);
        }
        return new b(-1, -2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m, androidx.recyclerview.widget.LinearLayoutManager
    public void u0(RecyclerView.t tVar, RecyclerView.y yVar) {
        if (yVar.g) {
            int y = y();
            for (int i = 0; i < y; i++) {
                b bVar = (b) x(i).getLayoutParams();
                int a2 = bVar.a();
                this.K.put(a2, bVar.f);
                this.L.put(a2, bVar.e);
            }
        }
        super.u0(tVar, yVar);
        this.K.clear();
        this.L.clear();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public RecyclerView.n v(Context context, AttributeSet attributeSet) {
        return new b(context, attributeSet);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m, androidx.recyclerview.widget.LinearLayoutManager
    public void v0(RecyclerView.y yVar) {
        this.B = null;
        this.z = -1;
        this.A = Integer.MIN_VALUE;
        this.C.d();
        this.G = false;
    }

    /* JADX DEBUG: Multi-variable search result rejected for r17v0, resolved type: androidx.recyclerview.widget.GridLayoutManager */
    /* JADX DEBUG: Multi-variable search result rejected for r13v9, resolved type: android.graphics.Rect */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r11v9, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r11v17 */
    /* JADX WARN: Type inference failed for: r11v18 */
    /* JADX WARN: Type inference failed for: r11v19 */
    /* JADX WARN: Type inference failed for: r11v27 */
    /* JADX WARNING: Unknown variable types count: 1 */
    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public void v1(RecyclerView.t tVar, RecyclerView.y yVar, LinearLayoutManager.c cVar, LinearLayoutManager.b bVar) {
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        ?? r11;
        View c2;
        int j = this.t.j();
        boolean z = j != 1073741824;
        int i13 = y() > 0 ? this.I[this.H] : 0;
        if (z) {
            Q1();
        }
        boolean z2 = cVar.e == 1;
        int i14 = this.H;
        if (!z2) {
            i14 = L1(tVar, yVar, cVar.d) + M1(tVar, yVar, cVar.d);
        }
        int i15 = 0;
        while (i15 < this.H && cVar.b(yVar) && i14 > 0) {
            int i16 = cVar.d;
            int M1 = M1(tVar, yVar, i16);
            if (M1 <= this.H) {
                i14 -= M1;
                if (i14 < 0 || (c2 = cVar.c(tVar)) == null) {
                    break;
                }
                this.J[i15] = c2;
                i15++;
            } else {
                throw new IllegalArgumentException(ze0.w0(ze0.L0("Item at position ", i16, " requires ", M1, " spans but GridLayoutManager has only "), this.H, " spans."));
            }
        }
        if (i15 == 0) {
            bVar.b = true;
            return;
        }
        if (z2) {
            i4 = 0;
            i3 = i15;
            i2 = 0;
            i = 1;
        } else {
            i4 = i15 - 1;
            i3 = -1;
            i2 = 0;
            i = -1;
        }
        while (i4 != i3) {
            View view = this.J[i4];
            b bVar2 = (b) view.getLayoutParams();
            int M12 = M1(tVar, yVar, Q(view));
            bVar2.f = M12;
            bVar2.e = i2;
            i2 += M12;
            i4 += i;
        }
        float f = Utils.FLOAT_EPSILON;
        int i17 = 0;
        for (int i18 = 0; i18 < i15; i18++) {
            View view2 = this.J[i18];
            if (cVar.k != null) {
                r11 = 0;
                r11 = 0;
                if (z2) {
                    c(view2, -1, true);
                } else {
                    c(view2, 0, true);
                }
            } else if (z2) {
                b(view2);
                r11 = 0;
            } else {
                r11 = 0;
                c(view2, 0, false);
            }
            Rect rect = this.N;
            RecyclerView recyclerView = this.b;
            if (recyclerView == null) {
                int i19 = r11 == true ? 1 : 0;
                int i20 = r11 == true ? 1 : 0;
                int i21 = r11 == true ? 1 : 0;
                int i22 = r11 == true ? 1 : 0;
                int i23 = r11 == true ? 1 : 0;
                rect.set(i19, r11, r11, r11);
            } else {
                rect.set(recyclerView.M(view2));
            }
            N1(view2, j, r11);
            int c3 = this.t.c(view2);
            if (c3 > i17) {
                i17 = c3;
            }
            float d = (((float) this.t.d(view2)) * 1.0f) / ((float) ((b) view2.getLayoutParams()).f);
            if (d > f) {
                f = d;
            }
        }
        if (z) {
            H1(Math.max(Math.round(f * ((float) this.H)), i13));
            i17 = 0;
            for (int i24 = 0; i24 < i15; i24++) {
                View view3 = this.J[i24];
                N1(view3, 1073741824, true);
                int c4 = this.t.c(view3);
                if (c4 > i17) {
                    i17 = c4;
                }
            }
        }
        for (int i25 = 0; i25 < i15; i25++) {
            View view4 = this.J[i25];
            if (this.t.c(view4) != i17) {
                b bVar3 = (b) view4.getLayoutParams();
                Rect rect2 = bVar3.b;
                int i26 = rect2.top + rect2.bottom + ((ViewGroup.MarginLayoutParams) bVar3).topMargin + ((ViewGroup.MarginLayoutParams) bVar3).bottomMargin;
                int i27 = rect2.left + rect2.right + ((ViewGroup.MarginLayoutParams) bVar3).leftMargin + ((ViewGroup.MarginLayoutParams) bVar3).rightMargin;
                int J1 = J1(bVar3.e, bVar3.f);
                if (this.r == 1) {
                    i12 = RecyclerView.m.z(J1, 1073741824, i27, ((ViewGroup.MarginLayoutParams) bVar3).width, false);
                    i11 = View.MeasureSpec.makeMeasureSpec(i17 - i26, 1073741824);
                } else {
                    int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i17 - i27, 1073741824);
                    i11 = RecyclerView.m.z(J1, 1073741824, i26, ((ViewGroup.MarginLayoutParams) bVar3).height, false);
                    i12 = makeMeasureSpec;
                }
                O1(view4, i12, i11, true);
            }
        }
        bVar.a = i17;
        if (this.r == 1) {
            if (cVar.f == -1) {
                i8 = cVar.b;
                i7 = i8 - i17;
            } else {
                i7 = cVar.b;
                i8 = i17 + i7;
            }
            i6 = 0;
            i5 = 0;
        } else {
            if (cVar.f == -1) {
                int i28 = cVar.b;
                i6 = i28;
                i5 = i28 - i17;
            } else {
                int i29 = cVar.b;
                i5 = i29;
                i6 = i17 + i29;
            }
            i7 = 0;
            i8 = 0;
        }
        int i30 = 0;
        while (i30 < i15) {
            View view5 = this.J[i30];
            b bVar4 = (b) view5.getLayoutParams();
            if (this.r == 1) {
                if (u1()) {
                    i6 = N() + this.I[this.H - bVar4.e];
                    i5 = i6 - this.t.d(view5);
                } else {
                    i5 = this.I[bVar4.e] + N();
                    i6 = this.t.d(view5) + i5;
                }
                i10 = i8;
                i9 = i7;
            } else {
                int P = P() + this.I[bVar4.e];
                i9 = P;
                i10 = this.t.d(view5) + P;
            }
            Z(view5, i5, i9, i6, i10);
            if (bVar4.c() || bVar4.b()) {
                bVar.c = true;
            }
            bVar.d |= view5.hasFocusable();
            i30++;
            i8 = i10;
            i7 = i9;
            i6 = i6;
            i5 = i5;
        }
        Arrays.fill(this.J, (Object) null);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public RecyclerView.n w(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            return new b((ViewGroup.MarginLayoutParams) layoutParams);
        }
        return new b(layoutParams);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public void w1(RecyclerView.t tVar, RecyclerView.y yVar, LinearLayoutManager.a aVar, int i) {
        Q1();
        if (yVar.b() > 0 && !yVar.g) {
            boolean z = i == 1;
            int L1 = L1(tVar, yVar, aVar.b);
            if (z) {
                while (L1 > 0) {
                    int i2 = aVar.b;
                    if (i2 <= 0) {
                        break;
                    }
                    int i3 = i2 - 1;
                    aVar.b = i3;
                    L1 = L1(tVar, yVar, i3);
                }
            } else {
                int b2 = yVar.b() - 1;
                int i4 = aVar.b;
                while (i4 < b2) {
                    int i5 = i4 + 1;
                    int L12 = L1(tVar, yVar, i5);
                    if (L12 <= L1) {
                        break;
                    }
                    i4 = i5;
                    L1 = L12;
                }
                aVar.b = i4;
            }
        }
        I1();
    }

    public static class b extends RecyclerView.n {
        public int e = -1;
        public int f = 0;

        public b(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public b(int i, int i2) {
            super(i, i2);
        }

        public b(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public b(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    public GridLayoutManager(Context context, int i, int i2, boolean z) {
        super(i2, z);
        P1(i);
    }

    public GridLayoutManager(Context context, int i) {
        super(1, false);
        P1(i);
    }
}
