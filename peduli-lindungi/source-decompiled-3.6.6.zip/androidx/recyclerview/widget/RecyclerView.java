package androidx.recyclerview.widget;

import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Observable;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.os.Trace;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.FocusFinder;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import com.github.mikephil.charting.utils.Utils;
import com.telkom.tracencare.R;
import defpackage.co;
import defpackage.cy;
import defpackage.hy;
import defpackage.lo;
import defpackage.uy;
import defpackage.xx;
import defpackage.xy;
import defpackage.yy;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public class RecyclerView extends ViewGroup implements qn {
    public static final int[] I0 = {16843830};
    public static final boolean J0 = (Build.VERSION.SDK_INT >= 23);
    public static final boolean K0 = true;
    public static final boolean L0 = true;
    public static final Class<?>[] M0;
    public static final Interpolator N0 = new c();
    public boolean A;
    public final int[] A0;
    public boolean B;
    public final int[] B0;
    public int C;
    public final List<b0> C0;
    public boolean D;
    public Runnable D0;
    public boolean E;
    public boolean E0;
    public boolean F;
    public int F0;
    public int G;
    public int G0;
    public boolean H;
    public final yy.b H0;
    public final AccessibilityManager I;
    public List<o> J;
    public boolean K;
    public boolean L;
    public int M;
    public int N;
    public i O;
    public EdgeEffect P;
    public EdgeEffect Q;
    public EdgeEffect R;
    public EdgeEffect S;
    public j T;
    public int U;
    public int V;
    public VelocityTracker W;
    public int a0;
    public int b0;
    public int c0;
    public int d0;
    public int e0;
    public p f0;
    public final v g;
    public final int g0;
    public final t h;
    public final int h0;
    public w i;
    public float i0;
    public xx j;
    public float j0;
    public cy k;
    public boolean k0;
    public final yy l;
    public final a0 l0;
    public boolean m;
    public hy m0;
    public final Runnable n;
    public hy.b n0;
    public final Rect o;
    public final y o0;
    public final Rect p;
    public r p0;
    public final RectF q;
    public List<r> q0;
    public e r;
    public boolean r0;
    public m s;
    public boolean s0;
    public u t;
    public j.b t0;
    public final List<u> u;
    public boolean u0;
    public final ArrayList<l> v;
    public uy v0;
    public final ArrayList<q> w;
    public h w0;
    public q x;
    public final int[] x0;
    public boolean y;
    public rn y0;
    public boolean z;
    public final int[] z0;

    public class a implements Runnable {
        public a() {
        }

        public void run() {
            RecyclerView recyclerView = RecyclerView.this;
            if (recyclerView.B && !recyclerView.isLayoutRequested()) {
                RecyclerView recyclerView2 = RecyclerView.this;
                if (!recyclerView2.y) {
                    recyclerView2.requestLayout();
                } else if (recyclerView2.E) {
                    recyclerView2.D = true;
                } else {
                    recyclerView2.n();
                }
            }
        }
    }

    public class a0 implements Runnable {
        public int g;
        public int h;
        public OverScroller i;
        public Interpolator j;
        public boolean k = false;
        public boolean l = false;

        public a0() {
            Interpolator interpolator = RecyclerView.N0;
            this.j = interpolator;
            this.i = new OverScroller(RecyclerView.this.getContext(), interpolator);
        }

        public void a() {
            if (this.k) {
                this.l = true;
                return;
            }
            RecyclerView.this.removeCallbacks(this);
            RecyclerView recyclerView = RecyclerView.this;
            AtomicInteger atomicInteger = co.a;
            co.c.m(recyclerView, this);
        }

        public void b(int i2, int i3, int i4, Interpolator interpolator) {
            int i5;
            if (i4 == Integer.MIN_VALUE) {
                int abs = Math.abs(i2);
                int abs2 = Math.abs(i3);
                boolean z = abs > abs2;
                int sqrt = (int) Math.sqrt((double) 0);
                int sqrt2 = (int) Math.sqrt((double) ((i3 * i3) + (i2 * i2)));
                RecyclerView recyclerView = RecyclerView.this;
                int width = z ? recyclerView.getWidth() : recyclerView.getHeight();
                int i6 = width / 2;
                float f = (float) width;
                float f2 = (float) i6;
                float sin = (((float) Math.sin((double) ((Math.min(1.0f, (((float) sqrt2) * 1.0f) / f) - 0.5f) * 0.47123894f))) * f2) + f2;
                if (sqrt > 0) {
                    i5 = Math.round(Math.abs(sin / ((float) sqrt)) * 1000.0f) * 4;
                } else {
                    if (!z) {
                        abs = abs2;
                    }
                    i5 = (int) (((((float) abs) / f) + 1.0f) * 300.0f);
                }
                i4 = Math.min(i5, 2000);
            }
            if (interpolator == null) {
                interpolator = RecyclerView.N0;
            }
            if (this.j != interpolator) {
                this.j = interpolator;
                this.i = new OverScroller(RecyclerView.this.getContext(), interpolator);
            }
            this.h = 0;
            this.g = 0;
            RecyclerView.this.setScrollState(2);
            this.i.startScroll(0, 0, i2, i3, i4);
            if (Build.VERSION.SDK_INT < 23) {
                this.i.computeScrollOffset();
            }
            a();
        }

        public void c() {
            RecyclerView.this.removeCallbacks(this);
            this.i.abortAnimation();
        }

        public void run() {
            int i2;
            int i3;
            RecyclerView recyclerView = RecyclerView.this;
            if (recyclerView.s == null) {
                c();
                return;
            }
            this.l = false;
            this.k = true;
            recyclerView.n();
            OverScroller overScroller = this.i;
            if (overScroller.computeScrollOffset()) {
                int currX = overScroller.getCurrX();
                int currY = overScroller.getCurrY();
                int i4 = currX - this.g;
                int i5 = currY - this.h;
                this.g = currX;
                this.h = currY;
                RecyclerView recyclerView2 = RecyclerView.this;
                int[] iArr = recyclerView2.B0;
                iArr[0] = 0;
                iArr[1] = 0;
                if (recyclerView2.t(i4, i5, iArr, null, 1)) {
                    int[] iArr2 = RecyclerView.this.B0;
                    i4 -= iArr2[0];
                    i5 -= iArr2[1];
                }
                if (RecyclerView.this.getOverScrollMode() != 2) {
                    RecyclerView.this.m(i4, i5);
                }
                RecyclerView recyclerView3 = RecyclerView.this;
                if (recyclerView3.r != null) {
                    int[] iArr3 = recyclerView3.B0;
                    iArr3[0] = 0;
                    iArr3[1] = 0;
                    recyclerView3.j0(i4, i5, iArr3);
                    RecyclerView recyclerView4 = RecyclerView.this;
                    int[] iArr4 = recyclerView4.B0;
                    i2 = iArr4[0];
                    i3 = iArr4[1];
                    i4 -= i2;
                    i5 -= i3;
                    x xVar = recyclerView4.s.g;
                    if (xVar != null && !xVar.d && xVar.e) {
                        int b = recyclerView4.o0.b();
                        if (b == 0) {
                            xVar.f();
                        } else if (xVar.a >= b) {
                            xVar.a = b - 1;
                            xVar.b(i2, i3);
                        } else {
                            xVar.b(i2, i3);
                        }
                    }
                } else {
                    i3 = 0;
                    i2 = 0;
                }
                if (!RecyclerView.this.v.isEmpty()) {
                    RecyclerView.this.invalidate();
                }
                RecyclerView recyclerView5 = RecyclerView.this;
                int[] iArr5 = recyclerView5.B0;
                iArr5[0] = 0;
                iArr5[1] = 0;
                recyclerView5.u(i2, i3, i4, i5, null, 1, iArr5);
                RecyclerView recyclerView6 = RecyclerView.this;
                int[] iArr6 = recyclerView6.B0;
                int i6 = i4 - iArr6[0];
                int i7 = i5 - iArr6[1];
                if (!(i2 == 0 && i3 == 0)) {
                    recyclerView6.v(i2, i3);
                }
                if (!RecyclerView.this.awakenScrollBars()) {
                    RecyclerView.this.invalidate();
                }
                boolean z = overScroller.isFinished() || (((overScroller.getCurrX() == overScroller.getFinalX()) || i6 != 0) && ((overScroller.getCurrY() == overScroller.getFinalY()) || i7 != 0));
                RecyclerView recyclerView7 = RecyclerView.this;
                x xVar2 = recyclerView7.s.g;
                if ((xVar2 != null && xVar2.d) || !z) {
                    a();
                    RecyclerView recyclerView8 = RecyclerView.this;
                    hy hyVar = recyclerView8.m0;
                    if (hyVar != null) {
                        hyVar.a(recyclerView8, i2, i3);
                    }
                } else {
                    if (recyclerView7.getOverScrollMode() != 2) {
                        int currVelocity = (int) overScroller.getCurrVelocity();
                        int i8 = i6 < 0 ? -currVelocity : i6 > 0 ? currVelocity : 0;
                        if (i7 < 0) {
                            currVelocity = -currVelocity;
                        } else if (i7 <= 0) {
                            currVelocity = 0;
                        }
                        RecyclerView recyclerView9 = RecyclerView.this;
                        Objects.requireNonNull(recyclerView9);
                        if (i8 < 0) {
                            recyclerView9.x();
                            if (recyclerView9.P.isFinished()) {
                                recyclerView9.P.onAbsorb(-i8);
                            }
                        } else if (i8 > 0) {
                            recyclerView9.y();
                            if (recyclerView9.R.isFinished()) {
                                recyclerView9.R.onAbsorb(i8);
                            }
                        }
                        if (currVelocity < 0) {
                            recyclerView9.z();
                            if (recyclerView9.Q.isFinished()) {
                                recyclerView9.Q.onAbsorb(-currVelocity);
                            }
                        } else if (currVelocity > 0) {
                            recyclerView9.w();
                            if (recyclerView9.S.isFinished()) {
                                recyclerView9.S.onAbsorb(currVelocity);
                            }
                        }
                        if (!(i8 == 0 && currVelocity == 0)) {
                            AtomicInteger atomicInteger = co.a;
                            co.c.k(recyclerView9);
                        }
                    }
                    if (RecyclerView.L0) {
                        hy.b bVar = RecyclerView.this.n0;
                        int[] iArr7 = bVar.c;
                        if (iArr7 != null) {
                            Arrays.fill(iArr7, -1);
                        }
                        bVar.d = 0;
                    }
                }
            }
            x xVar3 = RecyclerView.this.s.g;
            if (xVar3 != null && xVar3.d) {
                xVar3.b(0, 0);
            }
            this.k = false;
            if (this.l) {
                RecyclerView.this.removeCallbacks(this);
                RecyclerView recyclerView10 = RecyclerView.this;
                AtomicInteger atomicInteger2 = co.a;
                co.c.m(recyclerView10, this);
                return;
            }
            RecyclerView.this.setScrollState(0);
            RecyclerView.this.r0(1);
        }
    }

    public class b implements Runnable {
        public b() {
        }

        public void run() {
            j jVar = RecyclerView.this.T;
            if (jVar != null) {
                jVar.runPendingAnimations();
            }
            RecyclerView.this.u0 = false;
        }
    }

    public static abstract class b0 {
        public static final int FLAG_ADAPTER_FULLUPDATE = 1024;
        public static final int FLAG_ADAPTER_POSITION_UNKNOWN = 512;
        public static final int FLAG_APPEARED_IN_PRE_LAYOUT = 4096;
        public static final int FLAG_BOUNCED_FROM_HIDDEN_LIST = 8192;
        public static final int FLAG_BOUND = 1;
        public static final int FLAG_IGNORE = 128;
        public static final int FLAG_INVALID = 4;
        public static final int FLAG_MOVED = 2048;
        public static final int FLAG_NOT_RECYCLABLE = 16;
        public static final int FLAG_REMOVED = 8;
        public static final int FLAG_RETURNED_FROM_SCRAP = 32;
        public static final int FLAG_TMP_DETACHED = 256;
        public static final int FLAG_UPDATE = 2;
        private static final List<Object> FULLUPDATE_PAYLOADS = Collections.emptyList();
        public static final int PENDING_ACCESSIBILITY_STATE_NOT_SET = -1;
        public final View itemView;
        public e<? extends b0> mBindingAdapter;
        public int mFlags;
        public boolean mInChangeScrap = false;
        private int mIsRecyclableCount = 0;
        public long mItemId = -1;
        public int mItemViewType = -1;
        public WeakReference<RecyclerView> mNestedRecyclerView;
        public int mOldPosition = -1;
        public RecyclerView mOwnerRecyclerView;
        public List<Object> mPayloads = null;
        public int mPendingAccessibilityState = -1;
        public int mPosition = -1;
        public int mPreLayoutPosition = -1;
        public t mScrapContainer = null;
        public b0 mShadowedHolder = null;
        public b0 mShadowingHolder = null;
        public List<Object> mUnmodifiedPayloads = null;
        private int mWasImportantForAccessibilityBeforeHidden = 0;

        public b0(View view) {
            if (view != null) {
                this.itemView = view;
                return;
            }
            throw new IllegalArgumentException("itemView may not be null");
        }

        private void createPayloadsIfNeeded() {
            if (this.mPayloads == null) {
                ArrayList arrayList = new ArrayList();
                this.mPayloads = arrayList;
                this.mUnmodifiedPayloads = Collections.unmodifiableList(arrayList);
            }
        }

        public void addChangePayload(Object obj) {
            if (obj == null) {
                addFlags(FLAG_ADAPTER_FULLUPDATE);
            } else if ((1024 & this.mFlags) == 0) {
                createPayloadsIfNeeded();
                this.mPayloads.add(obj);
            }
        }

        public void addFlags(int i) {
            this.mFlags = i | this.mFlags;
        }

        public void clearOldPosition() {
            this.mOldPosition = -1;
            this.mPreLayoutPosition = -1;
        }

        public void clearPayload() {
            List<Object> list = this.mPayloads;
            if (list != null) {
                list.clear();
            }
            this.mFlags &= -1025;
        }

        public void clearReturnedFromScrapFlag() {
            this.mFlags &= -33;
        }

        public void clearTmpDetachFlag() {
            this.mFlags &= -257;
        }

        public boolean doesTransientStatePreventRecycling() {
            if ((this.mFlags & 16) == 0) {
                View view = this.itemView;
                AtomicInteger atomicInteger = co.a;
                if (co.c.i(view)) {
                    return true;
                }
            }
            return false;
        }

        public void flagRemovedAndOffsetPosition(int i, int i2, boolean z) {
            addFlags(8);
            offsetPosition(i2, z);
            this.mPosition = i;
        }

        public final int getAbsoluteAdapterPosition() {
            RecyclerView recyclerView = this.mOwnerRecyclerView;
            if (recyclerView == null) {
                return -1;
            }
            return recyclerView.H(this);
        }

        @Deprecated
        public final int getAdapterPosition() {
            return getBindingAdapterPosition();
        }

        public final e<? extends b0> getBindingAdapter() {
            return this.mBindingAdapter;
        }

        public final int getBindingAdapterPosition() {
            RecyclerView recyclerView;
            e adapter;
            int H;
            if (this.mBindingAdapter == null || (recyclerView = this.mOwnerRecyclerView) == null || (adapter = recyclerView.getAdapter()) == null || (H = this.mOwnerRecyclerView.H(this)) == -1) {
                return -1;
            }
            return adapter.findRelativeAdapterPositionIn(this.mBindingAdapter, this, H);
        }

        public final long getItemId() {
            return this.mItemId;
        }

        public final int getItemViewType() {
            return this.mItemViewType;
        }

        public final int getLayoutPosition() {
            int i = this.mPreLayoutPosition;
            return i == -1 ? this.mPosition : i;
        }

        public final int getOldPosition() {
            return this.mOldPosition;
        }

        @Deprecated
        public final int getPosition() {
            int i = this.mPreLayoutPosition;
            return i == -1 ? this.mPosition : i;
        }

        public List<Object> getUnmodifiedPayloads() {
            if ((this.mFlags & FLAG_ADAPTER_FULLUPDATE) != 0) {
                return FULLUPDATE_PAYLOADS;
            }
            List<Object> list = this.mPayloads;
            if (list == null || list.size() == 0) {
                return FULLUPDATE_PAYLOADS;
            }
            return this.mUnmodifiedPayloads;
        }

        public boolean hasAnyOfTheFlags(int i) {
            return (i & this.mFlags) != 0;
        }

        public boolean isAdapterPositionUnknown() {
            return (this.mFlags & FLAG_ADAPTER_POSITION_UNKNOWN) != 0 || isInvalid();
        }

        public boolean isAttachedToTransitionOverlay() {
            return (this.itemView.getParent() == null || this.itemView.getParent() == this.mOwnerRecyclerView) ? false : true;
        }

        public boolean isBound() {
            return (this.mFlags & 1) != 0;
        }

        public boolean isInvalid() {
            return (this.mFlags & 4) != 0;
        }

        public final boolean isRecyclable() {
            if ((this.mFlags & 16) == 0) {
                View view = this.itemView;
                AtomicInteger atomicInteger = co.a;
                if (!co.c.i(view)) {
                    return true;
                }
            }
            return false;
        }

        public boolean isRemoved() {
            return (this.mFlags & 8) != 0;
        }

        public boolean isScrap() {
            return this.mScrapContainer != null;
        }

        public boolean isTmpDetached() {
            return (this.mFlags & FLAG_TMP_DETACHED) != 0;
        }

        public boolean isUpdated() {
            return (this.mFlags & 2) != 0;
        }

        public boolean needsUpdate() {
            return (this.mFlags & 2) != 0;
        }

        public void offsetPosition(int i, boolean z) {
            if (this.mOldPosition == -1) {
                this.mOldPosition = this.mPosition;
            }
            if (this.mPreLayoutPosition == -1) {
                this.mPreLayoutPosition = this.mPosition;
            }
            if (z) {
                this.mPreLayoutPosition += i;
            }
            this.mPosition += i;
            if (this.itemView.getLayoutParams() != null) {
                ((n) this.itemView.getLayoutParams()).c = true;
            }
        }

        public void onEnteredHiddenState(RecyclerView recyclerView) {
            int i = this.mPendingAccessibilityState;
            if (i != -1) {
                this.mWasImportantForAccessibilityBeforeHidden = i;
            } else {
                View view = this.itemView;
                AtomicInteger atomicInteger = co.a;
                this.mWasImportantForAccessibilityBeforeHidden = co.c.c(view);
            }
            recyclerView.l0(this, 4);
        }

        public void onLeftHiddenState(RecyclerView recyclerView) {
            recyclerView.l0(this, this.mWasImportantForAccessibilityBeforeHidden);
            this.mWasImportantForAccessibilityBeforeHidden = 0;
        }

        public void resetInternal() {
            this.mFlags = 0;
            this.mPosition = -1;
            this.mOldPosition = -1;
            this.mItemId = -1;
            this.mPreLayoutPosition = -1;
            this.mIsRecyclableCount = 0;
            this.mShadowedHolder = null;
            this.mShadowingHolder = null;
            clearPayload();
            this.mWasImportantForAccessibilityBeforeHidden = 0;
            this.mPendingAccessibilityState = -1;
            RecyclerView.k(this);
        }

        public void saveOldPosition() {
            if (this.mOldPosition == -1) {
                this.mOldPosition = this.mPosition;
            }
        }

        public void setFlags(int i, int i2) {
            this.mFlags = (i & i2) | (this.mFlags & (~i2));
        }

        public final void setIsRecyclable(boolean z) {
            int i = this.mIsRecyclableCount;
            int i2 = z ? i - 1 : i + 1;
            this.mIsRecyclableCount = i2;
            if (i2 < 0) {
                this.mIsRecyclableCount = 0;
                Log.e("View", "isRecyclable decremented below 0: unmatched pair of setIsRecyable() calls for " + this);
            } else if (!z && i2 == 1) {
                this.mFlags |= 16;
            } else if (z && i2 == 0) {
                this.mFlags &= -17;
            }
        }

        public void setScrapContainer(t tVar, boolean z) {
            this.mScrapContainer = tVar;
            this.mInChangeScrap = z;
        }

        public boolean shouldBeKeptAsChild() {
            return (this.mFlags & 16) != 0;
        }

        public boolean shouldIgnore() {
            return (this.mFlags & FLAG_IGNORE) != 0;
        }

        public void stopIgnoring() {
            this.mFlags &= -129;
        }

        public String toString() {
            StringBuilder N0 = ze0.N0(getClass().isAnonymousClass() ? "ViewHolder" : getClass().getSimpleName(), "{");
            N0.append(Integer.toHexString(hashCode()));
            N0.append(" position=");
            N0.append(this.mPosition);
            N0.append(" id=");
            N0.append(this.mItemId);
            N0.append(", oldPos=");
            N0.append(this.mOldPosition);
            N0.append(", pLpos:");
            N0.append(this.mPreLayoutPosition);
            StringBuilder sb = new StringBuilder(N0.toString());
            if (isScrap()) {
                sb.append(" scrap ");
                sb.append(this.mInChangeScrap ? "[changeScrap]" : "[attachedScrap]");
            }
            if (isInvalid()) {
                sb.append(" invalid");
            }
            if (!isBound()) {
                sb.append(" unbound");
            }
            if (needsUpdate()) {
                sb.append(" update");
            }
            if (isRemoved()) {
                sb.append(" removed");
            }
            if (shouldIgnore()) {
                sb.append(" ignored");
            }
            if (isTmpDetached()) {
                sb.append(" tmpDetached");
            }
            if (!isRecyclable()) {
                StringBuilder J0 = ze0.J0(" not recyclable(");
                J0.append(this.mIsRecyclableCount);
                J0.append(")");
                sb.append(J0.toString());
            }
            if (isAdapterPositionUnknown()) {
                sb.append(" undefined adapter position");
            }
            if (this.itemView.getParent() == null) {
                sb.append(" no parent");
            }
            sb.append("}");
            return sb.toString();
        }

        public void unScrap() {
            this.mScrapContainer.k(this);
        }

        public boolean wasReturnedFromScrap() {
            return (this.mFlags & 32) != 0;
        }
    }

    public class c implements Interpolator {
        public float getInterpolation(float f) {
            float f2 = f - 1.0f;
            return (f2 * f2 * f2 * f2 * f2) + 1.0f;
        }
    }

    public class d implements yy.b {
        public d() {
        }

        public void a(b0 b0Var, j.c cVar, j.c cVar2) {
            RecyclerView.this.h.k(b0Var);
            RecyclerView recyclerView = RecyclerView.this;
            recyclerView.f(b0Var);
            b0Var.setIsRecyclable(false);
            if (recyclerView.T.animateDisappearance(b0Var, cVar, cVar2)) {
                recyclerView.a0();
            }
        }
    }

    public static class f extends Observable<g> {
        public boolean a() {
            return !((Observable) this).mObservers.isEmpty();
        }

        public void b() {
            for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
                ((g) ((Observable) this).mObservers.get(size)).a();
            }
        }

        public void c(int i, int i2) {
            for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
                ((g) ((Observable) this).mObservers.get(size)).e(i, i2, 1);
            }
        }

        public void d(int i, int i2, Object obj) {
            for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
                ((g) ((Observable) this).mObservers.get(size)).c(i, i2, obj);
            }
        }

        public void e(int i, int i2) {
            for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
                ((g) ((Observable) this).mObservers.get(size)).d(i, i2);
            }
        }

        public void f(int i, int i2) {
            for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
                ((g) ((Observable) this).mObservers.get(size)).f(i, i2);
            }
        }

        public void g() {
            for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
                ((g) ((Observable) this).mObservers.get(size)).g();
            }
        }
    }

    public static abstract class g {
        public void a() {
        }

        public void b(int i, int i2) {
        }

        public void c(int i, int i2, Object obj) {
            b(i, i2);
        }

        public void d(int i, int i2) {
        }

        public void e(int i, int i2, int i3) {
        }

        public void f(int i, int i2) {
        }

        public void g() {
        }
    }

    public interface h {
        int a(int i, int i2);
    }

    public static class i {
        public EdgeEffect a(RecyclerView recyclerView) {
            return new EdgeEffect(recyclerView.getContext());
        }
    }

    public static abstract class j {
        public static final int FLAG_APPEARED_IN_PRE_LAYOUT = 4096;
        public static final int FLAG_CHANGED = 2;
        public static final int FLAG_INVALIDATED = 4;
        public static final int FLAG_MOVED = 2048;
        public static final int FLAG_REMOVED = 8;
        private long mAddDuration = 120;
        private long mChangeDuration = 250;
        private ArrayList<a> mFinishedListeners = new ArrayList<>();
        private b mListener = null;
        private long mMoveDuration = 250;
        private long mRemoveDuration = 120;

        public interface a {
            void a();
        }

        public interface b {
        }

        public static class c {
            public int a;
            public int b;
        }

        public static int buildAdapterChangeFlagsForAnimations(b0 b0Var) {
            int i = b0Var.mFlags & 14;
            if (b0Var.isInvalid()) {
                return 4;
            }
            if ((i & 4) != 0) {
                return i;
            }
            int oldPosition = b0Var.getOldPosition();
            int absoluteAdapterPosition = b0Var.getAbsoluteAdapterPosition();
            return (oldPosition == -1 || absoluteAdapterPosition == -1 || oldPosition == absoluteAdapterPosition) ? i : i | 2048;
        }

        public abstract boolean animateAppearance(b0 b0Var, c cVar, c cVar2);

        public abstract boolean animateChange(b0 b0Var, b0 b0Var2, c cVar, c cVar2);

        public abstract boolean animateDisappearance(b0 b0Var, c cVar, c cVar2);

        public abstract boolean animatePersistence(b0 b0Var, c cVar, c cVar2);

        public abstract boolean canReuseUpdatedViewHolder(b0 b0Var);

        public boolean canReuseUpdatedViewHolder(b0 b0Var, List<Object> list) {
            return canReuseUpdatedViewHolder(b0Var);
        }

        public final void dispatchAnimationFinished(b0 b0Var) {
            onAnimationFinished(b0Var);
            b bVar = this.mListener;
            if (bVar != null) {
                k kVar = (k) bVar;
                Objects.requireNonNull(kVar);
                boolean z = true;
                b0Var.setIsRecyclable(true);
                if (b0Var.mShadowedHolder != null && b0Var.mShadowingHolder == null) {
                    b0Var.mShadowedHolder = null;
                }
                b0Var.mShadowingHolder = null;
                if (!b0Var.shouldBeKeptAsChild()) {
                    RecyclerView recyclerView = RecyclerView.this;
                    View view = b0Var.itemView;
                    recyclerView.o0();
                    cy cyVar = recyclerView.k;
                    int indexOfChild = ((sy) cyVar.a).a.indexOfChild(view);
                    if (indexOfChild == -1) {
                        cyVar.l(view);
                    } else if (cyVar.b.d(indexOfChild)) {
                        cyVar.b.f(indexOfChild);
                        cyVar.l(view);
                        ((sy) cyVar.a).c(indexOfChild);
                    } else {
                        z = false;
                    }
                    if (z) {
                        b0 K = RecyclerView.K(view);
                        recyclerView.h.k(K);
                        recyclerView.h.h(K);
                    }
                    recyclerView.q0(!z);
                    if (!z && b0Var.isTmpDetached()) {
                        RecyclerView.this.removeDetachedView(b0Var.itemView, false);
                    }
                }
            }
        }

        public final void dispatchAnimationStarted(b0 b0Var) {
            onAnimationStarted(b0Var);
        }

        public final void dispatchAnimationsFinished() {
            int size = this.mFinishedListeners.size();
            for (int i = 0; i < size; i++) {
                this.mFinishedListeners.get(i).a();
            }
            this.mFinishedListeners.clear();
        }

        public abstract void endAnimation(b0 b0Var);

        public abstract void endAnimations();

        public long getAddDuration() {
            return this.mAddDuration;
        }

        public long getChangeDuration() {
            return this.mChangeDuration;
        }

        public long getMoveDuration() {
            return this.mMoveDuration;
        }

        public long getRemoveDuration() {
            return this.mRemoveDuration;
        }

        public abstract boolean isRunning();

        public final boolean isRunning(a aVar) {
            boolean isRunning = isRunning();
            if (aVar != null) {
                if (!isRunning) {
                    aVar.a();
                } else {
                    this.mFinishedListeners.add(aVar);
                }
            }
            return isRunning;
        }

        public c obtainHolderInfo() {
            return new c();
        }

        public void onAnimationFinished(b0 b0Var) {
        }

        public void onAnimationStarted(b0 b0Var) {
        }

        public c recordPostLayoutInformation(y yVar, b0 b0Var) {
            c obtainHolderInfo = obtainHolderInfo();
            Objects.requireNonNull(obtainHolderInfo);
            View view = b0Var.itemView;
            obtainHolderInfo.a = view.getLeft();
            obtainHolderInfo.b = view.getTop();
            view.getRight();
            view.getBottom();
            return obtainHolderInfo;
        }

        public c recordPreLayoutInformation(y yVar, b0 b0Var, int i, List<Object> list) {
            c obtainHolderInfo = obtainHolderInfo();
            Objects.requireNonNull(obtainHolderInfo);
            View view = b0Var.itemView;
            obtainHolderInfo.a = view.getLeft();
            obtainHolderInfo.b = view.getTop();
            view.getRight();
            view.getBottom();
            return obtainHolderInfo;
        }

        public abstract void runPendingAnimations();

        public void setAddDuration(long j) {
            this.mAddDuration = j;
        }

        public void setChangeDuration(long j) {
            this.mChangeDuration = j;
        }

        public void setListener(b bVar) {
            this.mListener = bVar;
        }

        public void setMoveDuration(long j) {
            this.mMoveDuration = j;
        }

        public void setRemoveDuration(long j) {
            this.mRemoveDuration = j;
        }
    }

    public class k implements j.b {
        public k() {
        }
    }

    public static abstract class l {
        public void d(Rect rect, View view, RecyclerView recyclerView, y yVar) {
            ((n) view.getLayoutParams()).a();
            rect.set(0, 0, 0, 0);
        }

        public void e(Canvas canvas, RecyclerView recyclerView, y yVar) {
        }

        public void f(Canvas canvas, RecyclerView recyclerView, y yVar) {
        }
    }

    public static abstract class m {
        public cy a;
        public RecyclerView b;
        public final xy.b c;
        public final xy.b d;
        public xy e;
        public xy f;
        public x g;
        public boolean h = false;
        public boolean i = false;
        public boolean j = true;
        public boolean k = true;
        public int l;
        public boolean m;
        public int n;
        public int o;
        public int p;
        public int q;

        public class a implements xy.b {
            public a() {
            }

            @Override // defpackage.xy.b
            public int a() {
                m mVar = m.this;
                return mVar.p - mVar.O();
            }

            @Override // defpackage.xy.b
            public int b(View view) {
                return m.this.C(view) - ((ViewGroup.MarginLayoutParams) ((n) view.getLayoutParams())).leftMargin;
            }

            @Override // defpackage.xy.b
            public View c(int i) {
                return m.this.x(i);
            }

            @Override // defpackage.xy.b
            public int d() {
                return m.this.N();
            }

            @Override // defpackage.xy.b
            public int e(View view) {
                return m.this.F(view) + ((ViewGroup.MarginLayoutParams) ((n) view.getLayoutParams())).rightMargin;
            }
        }

        public class b implements xy.b {
            public b() {
            }

            @Override // defpackage.xy.b
            public int a() {
                m mVar = m.this;
                return mVar.q - mVar.M();
            }

            @Override // defpackage.xy.b
            public int b(View view) {
                return m.this.G(view) - ((ViewGroup.MarginLayoutParams) ((n) view.getLayoutParams())).topMargin;
            }

            @Override // defpackage.xy.b
            public View c(int i) {
                return m.this.x(i);
            }

            @Override // defpackage.xy.b
            public int d() {
                return m.this.P();
            }

            @Override // defpackage.xy.b
            public int e(View view) {
                return m.this.B(view) + ((ViewGroup.MarginLayoutParams) ((n) view.getLayoutParams())).bottomMargin;
            }
        }

        public interface c {
        }

        public static class d {
            public int a;
            public int b;
            public boolean c;
            public boolean d;
        }

        public m() {
            a aVar = new a();
            this.c = aVar;
            b bVar = new b();
            this.d = bVar;
            this.e = new xy(aVar);
            this.f = new xy(bVar);
        }

        public static d R(Context context, AttributeSet attributeSet, int i2, int i3) {
            d dVar = new d();
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, wx.a, i2, i3);
            dVar.a = obtainStyledAttributes.getInt(0, 1);
            dVar.b = obtainStyledAttributes.getInt(10, 1);
            dVar.c = obtainStyledAttributes.getBoolean(9, false);
            dVar.d = obtainStyledAttributes.getBoolean(11, false);
            obtainStyledAttributes.recycle();
            return dVar;
        }

        public static boolean X(int i2, int i3, int i4) {
            int mode = View.MeasureSpec.getMode(i3);
            int size = View.MeasureSpec.getSize(i3);
            if (i4 > 0 && i2 != i4) {
                return false;
            }
            if (mode == Integer.MIN_VALUE) {
                return size >= i2;
            }
            if (mode != 0) {
                return mode == 1073741824 && size == i2;
            }
            return true;
        }

        public static int h(int i2, int i3, int i4) {
            int mode = View.MeasureSpec.getMode(i2);
            int size = View.MeasureSpec.getSize(i2);
            if (mode != Integer.MIN_VALUE) {
                return mode != 1073741824 ? Math.max(i3, i4) : size;
            }
            return Math.min(size, Math.max(i3, i4));
        }

        /* JADX WARNING: Code restructure failed: missing block: B:6:0x0017, code lost:
            if (r5 == 1073741824) goto L_0x0021;
         */
        public static int z(int i2, int i3, int i4, int i5, boolean z) {
            int max = Math.max(0, i2 - i4);
            if (z) {
                if (i5 < 0) {
                    if (i5 == -1) {
                        if (i3 != Integer.MIN_VALUE) {
                            if (i3 != 0) {
                            }
                        }
                        i5 = max;
                        return View.MeasureSpec.makeMeasureSpec(i5, i3);
                    }
                    i3 = 0;
                    i5 = 0;
                    return View.MeasureSpec.makeMeasureSpec(i5, i3);
                }
            } else if (i5 < 0) {
                if (i5 != -1) {
                    if (i5 == -2) {
                        i3 = (i3 == Integer.MIN_VALUE || i3 == 1073741824) ? Integer.MIN_VALUE : 0;
                    }
                    i3 = 0;
                    i5 = 0;
                    return View.MeasureSpec.makeMeasureSpec(i5, i3);
                }
                i5 = max;
                return View.MeasureSpec.makeMeasureSpec(i5, i3);
            }
            i3 = 1073741824;
            return View.MeasureSpec.makeMeasureSpec(i5, i3);
        }

        public int A(t tVar, y yVar) {
            return -1;
        }

        public Parcelable A0() {
            return null;
        }

        public int B(View view) {
            return view.getBottom() + ((n) view.getLayoutParams()).b.bottom;
        }

        public void B0(int i2) {
        }

        public int C(View view) {
            return view.getLeft() - ((n) view.getLayoutParams()).b.left;
        }

        /* JADX WARNING: Removed duplicated region for block: B:25:0x006d A[ADDED_TO_REGION] */
        public boolean C0(t tVar, y yVar, int i2, Bundle bundle) {
            int i3;
            int i4;
            int i5;
            int i6;
            RecyclerView recyclerView = this.b;
            if (recyclerView == null) {
                return false;
            }
            if (i2 == 4096) {
                i5 = recyclerView.canScrollVertically(1) ? (this.q - P()) - M() : 0;
                if (this.b.canScrollHorizontally(1)) {
                    i6 = (this.p - N()) - O();
                }
                i3 = i5;
                i4 = 0;
                if (i3 != 0) {
                }
                this.b.m0(i4, i3, null, Integer.MIN_VALUE, true);
                return true;
            } else if (i2 != 8192) {
                i4 = 0;
                i3 = 0;
                if (i3 != 0 && i4 == 0) {
                    return false;
                }
                this.b.m0(i4, i3, null, Integer.MIN_VALUE, true);
                return true;
            } else {
                i5 = recyclerView.canScrollVertically(-1) ? -((this.q - P()) - M()) : 0;
                if (this.b.canScrollHorizontally(-1)) {
                    i6 = -((this.p - N()) - O());
                }
                i3 = i5;
                i4 = 0;
                if (i3 != 0) {
                }
                this.b.m0(i4, i3, null, Integer.MIN_VALUE, true);
                return true;
            }
            i3 = i5;
            i4 = i6;
            if (i3 != 0) {
            }
            this.b.m0(i4, i3, null, Integer.MIN_VALUE, true);
            return true;
        }

        public int D(View view) {
            Rect rect = ((n) view.getLayoutParams()).b;
            return view.getMeasuredHeight() + rect.top + rect.bottom;
        }

        public boolean D0() {
            return false;
        }

        public int E(View view) {
            Rect rect = ((n) view.getLayoutParams()).b;
            return view.getMeasuredWidth() + rect.left + rect.right;
        }

        public void E0(t tVar) {
            for (int y = y() - 1; y >= 0; y--) {
                if (!RecyclerView.K(x(y)).shouldIgnore()) {
                    H0(y, tVar);
                }
            }
        }

        public int F(View view) {
            return view.getRight() + ((n) view.getLayoutParams()).b.right;
        }

        public void F0(t tVar) {
            int size = tVar.a.size();
            for (int i2 = size - 1; i2 >= 0; i2--) {
                View view = tVar.a.get(i2).itemView;
                b0 K = RecyclerView.K(view);
                if (!K.shouldIgnore()) {
                    K.setIsRecyclable(false);
                    if (K.isTmpDetached()) {
                        this.b.removeDetachedView(view, false);
                    }
                    j jVar = this.b.T;
                    if (jVar != null) {
                        jVar.endAnimation(K);
                    }
                    K.setIsRecyclable(true);
                    b0 K2 = RecyclerView.K(view);
                    K2.mScrapContainer = null;
                    K2.mInChangeScrap = false;
                    K2.clearReturnedFromScrapFlag();
                    tVar.h(K2);
                }
            }
            tVar.a.clear();
            ArrayList<b0> arrayList = tVar.b;
            if (arrayList != null) {
                arrayList.clear();
            }
            if (size > 0) {
                this.b.invalidate();
            }
        }

        public int G(View view) {
            return view.getTop() - ((n) view.getLayoutParams()).b.top;
        }

        public void G0(View view, t tVar) {
            cy cyVar = this.a;
            int indexOfChild = ((sy) cyVar.a).a.indexOfChild(view);
            if (indexOfChild >= 0) {
                if (cyVar.b.f(indexOfChild)) {
                    cyVar.l(view);
                }
                ((sy) cyVar.a).c(indexOfChild);
            }
            tVar.g(view);
        }

        public View H() {
            View focusedChild;
            RecyclerView recyclerView = this.b;
            if (recyclerView == null || (focusedChild = recyclerView.getFocusedChild()) == null || this.a.c.contains(focusedChild)) {
                return null;
            }
            return focusedChild;
        }

        public void H0(int i2, t tVar) {
            View x = x(i2);
            I0(i2);
            tVar.g(x);
        }

        public int I() {
            RecyclerView recyclerView = this.b;
            e adapter = recyclerView != null ? recyclerView.getAdapter() : null;
            if (adapter != null) {
                return adapter.getItemCount();
            }
            return 0;
        }

        public void I0(int i2) {
            cy cyVar;
            int f2;
            View a2;
            if (x(i2) != null && (a2 = ((sy) cyVar.a).a((f2 = (cyVar = this.a).f(i2)))) != null) {
                if (cyVar.b.f(f2)) {
                    cyVar.l(a2);
                }
                ((sy) cyVar.a).c(f2);
            }
        }

        public int J() {
            RecyclerView recyclerView = this.b;
            AtomicInteger atomicInteger = co.a;
            return co.d.d(recyclerView);
        }

        /* JADX WARNING: Code restructure failed: missing block: B:23:0x00b8, code lost:
            if (r1 == false) goto L_0x00bf;
         */
        public boolean J0(RecyclerView recyclerView, View view, Rect rect, boolean z, boolean z2) {
            boolean z3;
            int[] iArr = new int[2];
            int N = N();
            int P = P();
            int O = this.p - O();
            int M = this.q - M();
            int left = (view.getLeft() + rect.left) - view.getScrollX();
            int top = (view.getTop() + rect.top) - view.getScrollY();
            int width = rect.width() + left;
            int height = rect.height() + top;
            int i2 = left - N;
            int min = Math.min(0, i2);
            int i3 = top - P;
            int min2 = Math.min(0, i3);
            int i4 = width - O;
            int max = Math.max(0, i4);
            int max2 = Math.max(0, height - M);
            if (J() != 1) {
                if (min == 0) {
                    min = Math.min(i2, max);
                }
                max = min;
            } else if (max == 0) {
                max = Math.max(min, i4);
            }
            if (min2 == 0) {
                min2 = Math.min(i3, max2);
            }
            iArr[0] = max;
            iArr[1] = min2;
            int i5 = iArr[0];
            int i6 = iArr[1];
            if (z2) {
                View focusedChild = recyclerView.getFocusedChild();
                if (focusedChild != null) {
                    int N2 = N();
                    int P2 = P();
                    int O2 = this.p - O();
                    int M2 = this.q - M();
                    Rect rect2 = this.b.o;
                    RecyclerView.L(focusedChild, rect2);
                    if (rect2.left - i5 < O2 && rect2.right - i5 > N2 && rect2.top - i6 < M2 && rect2.bottom - i6 > P2) {
                        z3 = true;
                    }
                }
                z3 = false;
            }
            if (!(i5 == 0 && i6 == 0)) {
                if (z) {
                    recyclerView.scrollBy(i5, i6);
                } else {
                    recyclerView.m0(i5, i6, null, Integer.MIN_VALUE, false);
                }
                return true;
            }
            return false;
        }

        public int K() {
            RecyclerView recyclerView = this.b;
            AtomicInteger atomicInteger = co.a;
            return co.c.d(recyclerView);
        }

        public void K0() {
            RecyclerView recyclerView = this.b;
            if (recyclerView != null) {
                recyclerView.requestLayout();
            }
        }

        public int L() {
            RecyclerView recyclerView = this.b;
            AtomicInteger atomicInteger = co.a;
            return co.c.e(recyclerView);
        }

        public int L0(int i2, t tVar, y yVar) {
            return 0;
        }

        public int M() {
            RecyclerView recyclerView = this.b;
            if (recyclerView != null) {
                return recyclerView.getPaddingBottom();
            }
            return 0;
        }

        public void M0(int i2) {
        }

        public int N() {
            RecyclerView recyclerView = this.b;
            if (recyclerView != null) {
                return recyclerView.getPaddingLeft();
            }
            return 0;
        }

        public int N0(int i2, t tVar, y yVar) {
            return 0;
        }

        public int O() {
            RecyclerView recyclerView = this.b;
            if (recyclerView != null) {
                return recyclerView.getPaddingRight();
            }
            return 0;
        }

        public void O0(RecyclerView recyclerView) {
            P0(View.MeasureSpec.makeMeasureSpec(recyclerView.getWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(recyclerView.getHeight(), 1073741824));
        }

        public int P() {
            RecyclerView recyclerView = this.b;
            if (recyclerView != null) {
                return recyclerView.getPaddingTop();
            }
            return 0;
        }

        public void P0(int i2, int i3) {
            this.p = View.MeasureSpec.getSize(i2);
            int mode = View.MeasureSpec.getMode(i2);
            this.n = mode;
            if (mode == 0 && !RecyclerView.J0) {
                this.p = 0;
            }
            this.q = View.MeasureSpec.getSize(i3);
            int mode2 = View.MeasureSpec.getMode(i3);
            this.o = mode2;
            if (mode2 == 0 && !RecyclerView.J0) {
                this.q = 0;
            }
        }

        public int Q(View view) {
            return ((n) view.getLayoutParams()).a();
        }

        public void Q0(Rect rect, int i2, int i3) {
            int O = O() + N() + rect.width();
            int M = M() + P() + rect.height();
            this.b.setMeasuredDimension(h(i2, O, L()), h(i3, M, K()));
        }

        public void R0(int i2, int i3) {
            int y = y();
            if (y == 0) {
                this.b.o(i2, i3);
                return;
            }
            int i4 = Integer.MIN_VALUE;
            int i5 = Integer.MIN_VALUE;
            int i6 = Integer.MAX_VALUE;
            int i7 = Integer.MAX_VALUE;
            for (int i8 = 0; i8 < y; i8++) {
                View x = x(i8);
                Rect rect = this.b.o;
                RecyclerView.L(x, rect);
                int i9 = rect.left;
                if (i9 < i6) {
                    i6 = i9;
                }
                int i10 = rect.right;
                if (i10 > i4) {
                    i4 = i10;
                }
                int i11 = rect.top;
                if (i11 < i7) {
                    i7 = i11;
                }
                int i12 = rect.bottom;
                if (i12 > i5) {
                    i5 = i12;
                }
            }
            this.b.o.set(i6, i7, i4, i5);
            Q0(this.b.o, i2, i3);
        }

        public int S(t tVar, y yVar) {
            return -1;
        }

        public void S0(RecyclerView recyclerView) {
            if (recyclerView == null) {
                this.b = null;
                this.a = null;
                this.p = 0;
                this.q = 0;
            } else {
                this.b = recyclerView;
                this.a = recyclerView.k;
                this.p = recyclerView.getWidth();
                this.q = recyclerView.getHeight();
            }
            this.n = 1073741824;
            this.o = 1073741824;
        }

        public int T() {
            return 0;
        }

        public boolean T0(View view, int i2, int i3, n nVar) {
            return view.isLayoutRequested() || !this.j || !X(view.getWidth(), i2, ((ViewGroup.MarginLayoutParams) nVar).width) || !X(view.getHeight(), i3, ((ViewGroup.MarginLayoutParams) nVar).height);
        }

        public void U(View view, boolean z, Rect rect) {
            Matrix matrix;
            if (z) {
                Rect rect2 = ((n) view.getLayoutParams()).b;
                rect.set(-rect2.left, -rect2.top, view.getWidth() + rect2.right, view.getHeight() + rect2.bottom);
            } else {
                rect.set(0, 0, view.getWidth(), view.getHeight());
            }
            if (!(this.b == null || (matrix = view.getMatrix()) == null || matrix.isIdentity())) {
                RectF rectF = this.b.q;
                rectF.set(rect);
                matrix.mapRect(rectF);
                rect.set((int) Math.floor((double) rectF.left), (int) Math.floor((double) rectF.top), (int) Math.ceil((double) rectF.right), (int) Math.ceil((double) rectF.bottom));
            }
            rect.offset(view.getLeft(), view.getTop());
        }

        public boolean U0() {
            return false;
        }

        public boolean V() {
            return false;
        }

        public boolean V0(View view, int i2, int i3, n nVar) {
            return !this.j || !X(view.getMeasuredWidth(), i2, ((ViewGroup.MarginLayoutParams) nVar).width) || !X(view.getMeasuredHeight(), i3, ((ViewGroup.MarginLayoutParams) nVar).height);
        }

        public boolean W() {
            return false;
        }

        public void W0(RecyclerView recyclerView, y yVar, int i2) {
            Log.e("RecyclerView", "You must override smoothScrollToPosition to support smooth scrolling");
        }

        public void X0(x xVar) {
            x xVar2 = this.g;
            if (!(xVar2 == null || xVar == xVar2 || !xVar2.e)) {
                xVar2.f();
            }
            this.g = xVar;
            RecyclerView recyclerView = this.b;
            Objects.requireNonNull(xVar);
            recyclerView.l0.c();
            if (xVar.h) {
                StringBuilder J0 = ze0.J0("An instance of ");
                J0.append(xVar.getClass().getSimpleName());
                J0.append(" was started more than once. Each instance of");
                J0.append(xVar.getClass().getSimpleName());
                J0.append(" is intended to only be used once. You should create a new instance for each use.");
                Log.w("RecyclerView", J0.toString());
            }
            xVar.b = recyclerView;
            xVar.c = this;
            int i2 = xVar.a;
            if (i2 != -1) {
                recyclerView.o0.a = i2;
                xVar.e = true;
                xVar.d = true;
                xVar.f = recyclerView.s.t(i2);
                xVar.b.l0.a();
                xVar.h = true;
                return;
            }
            throw new IllegalArgumentException("Invalid target position");
        }

        public boolean Y(View view, boolean z) {
            boolean z2 = this.e.b(view, 24579) && this.f.b(view, 24579);
            return z ? z2 : !z2;
        }

        public boolean Y0() {
            return false;
        }

        public void Z(View view, int i2, int i3, int i4, int i5) {
            n nVar = (n) view.getLayoutParams();
            Rect rect = nVar.b;
            view.layout(i2 + rect.left + ((ViewGroup.MarginLayoutParams) nVar).leftMargin, i3 + rect.top + ((ViewGroup.MarginLayoutParams) nVar).topMargin, (i4 - rect.right) - ((ViewGroup.MarginLayoutParams) nVar).rightMargin, (i5 - rect.bottom) - ((ViewGroup.MarginLayoutParams) nVar).bottomMargin);
        }

        public void a0(int i2) {
            RecyclerView recyclerView = this.b;
            if (recyclerView != null) {
                int e2 = recyclerView.k.e();
                for (int i3 = 0; i3 < e2; i3++) {
                    recyclerView.k.d(i3).offsetLeftAndRight(i2);
                }
            }
        }

        public void b(View view) {
            c(view, -1, false);
        }

        public void b0(int i2) {
            RecyclerView recyclerView = this.b;
            if (recyclerView != null) {
                int e2 = recyclerView.k.e();
                for (int i3 = 0; i3 < e2; i3++) {
                    recyclerView.k.d(i3).offsetTopAndBottom(i2);
                }
            }
        }

        public final void c(View view, int i2, boolean z) {
            b0 K = RecyclerView.K(view);
            if (z || K.isRemoved()) {
                this.b.l.a(K);
            } else {
                this.b.l.f(K);
            }
            n nVar = (n) view.getLayoutParams();
            if (K.wasReturnedFromScrap() || K.isScrap()) {
                if (K.isScrap()) {
                    K.unScrap();
                } else {
                    K.clearReturnedFromScrapFlag();
                }
                this.a.b(view, i2, view.getLayoutParams(), false);
            } else {
                int i3 = -1;
                if (view.getParent() == this.b) {
                    int j2 = this.a.j(view);
                    if (i2 == -1) {
                        i2 = this.a.e();
                    }
                    if (j2 == -1) {
                        StringBuilder J0 = ze0.J0("Added View has RecyclerView as parent but view is not a real child. Unfiltered index:");
                        J0.append(this.b.indexOfChild(view));
                        throw new IllegalStateException(ze0.e0(this.b, J0));
                    } else if (j2 != i2) {
                        m mVar = this.b.s;
                        View x = mVar.x(j2);
                        if (x != null) {
                            mVar.x(j2);
                            mVar.r(j2);
                            n nVar2 = (n) x.getLayoutParams();
                            b0 K2 = RecyclerView.K(x);
                            if (K2.isRemoved()) {
                                mVar.b.l.a(K2);
                            } else {
                                mVar.b.l.f(K2);
                            }
                            mVar.a.b(x, i2, nVar2, K2.isRemoved());
                        } else {
                            throw new IllegalArgumentException("Cannot move a child from non-existing index:" + j2 + mVar.b.toString());
                        }
                    }
                } else {
                    this.a.a(view, i2, false);
                    nVar.c = true;
                    x xVar = this.g;
                    if (xVar != null && xVar.e) {
                        Objects.requireNonNull(xVar.b);
                        b0 K3 = RecyclerView.K(view);
                        if (K3 != null) {
                            i3 = K3.getLayoutPosition();
                        }
                        if (i3 == xVar.a) {
                            xVar.f = view;
                        }
                    }
                }
            }
            if (nVar.d) {
                K.itemView.invalidate();
                nVar.d = false;
            }
        }

        public void c0(e eVar, e eVar2) {
        }

        public void d(String str) {
            RecyclerView recyclerView = this.b;
            if (recyclerView != null) {
                recyclerView.i(str);
            }
        }

        /* JADX WARN: Incorrect args count in method signature: (Landroidx/recyclerview/widget/RecyclerView;Ljava/util/ArrayList<Landroid/view/View;>;II)Z */
        public boolean d0() {
            return false;
        }

        public boolean e() {
            return false;
        }

        public void e0() {
        }

        public boolean f() {
            return false;
        }

        @Deprecated
        public void f0() {
        }

        public boolean g(n nVar) {
            return nVar != null;
        }

        public void g0(RecyclerView recyclerView, t tVar) {
            f0();
        }

        public View h0(View view, int i2, t tVar, y yVar) {
            return null;
        }

        public void i(int i2, int i3, y yVar, c cVar) {
        }

        public void i0(AccessibilityEvent accessibilityEvent) {
            RecyclerView recyclerView = this.b;
            t tVar = recyclerView.h;
            y yVar = recyclerView.o0;
            j0(accessibilityEvent);
        }

        public void j(int i2, c cVar) {
        }

        public void j0(AccessibilityEvent accessibilityEvent) {
            RecyclerView recyclerView = this.b;
            if (recyclerView != null && accessibilityEvent != null) {
                boolean z = true;
                if (!recyclerView.canScrollVertically(1) && !this.b.canScrollVertically(-1) && !this.b.canScrollHorizontally(-1) && !this.b.canScrollHorizontally(1)) {
                    z = false;
                }
                accessibilityEvent.setScrollable(z);
                e eVar = this.b.r;
                if (eVar != null) {
                    accessibilityEvent.setItemCount(eVar.getItemCount());
                }
            }
        }

        public int k(y yVar) {
            return 0;
        }

        public void k0(t tVar, y yVar, lo loVar) {
            if (this.b.canScrollVertically(-1) || this.b.canScrollHorizontally(-1)) {
                loVar.a.addAction(b0.FLAG_BOUNCED_FROM_HIDDEN_LIST);
                loVar.a.setScrollable(true);
            }
            if (this.b.canScrollVertically(1) || this.b.canScrollHorizontally(1)) {
                loVar.a.addAction(4096);
                loVar.a.setScrollable(true);
            }
            loVar.i(lo.b.a(S(tVar, yVar), A(tVar, yVar), W(), T()));
        }

        public int l(y yVar) {
            return 0;
        }

        public void l0(View view, lo loVar) {
            b0 K = RecyclerView.K(view);
            if (K != null && !K.isRemoved() && !this.a.k(K.itemView)) {
                RecyclerView recyclerView = this.b;
                m0(recyclerView.h, recyclerView.o0, view, loVar);
            }
        }

        public int m(y yVar) {
            return 0;
        }

        public void m0(t tVar, y yVar, View view, lo loVar) {
        }

        public int n(y yVar) {
            return 0;
        }

        public View n0() {
            return null;
        }

        public int o(y yVar) {
            return 0;
        }

        public void o0(RecyclerView recyclerView, int i2, int i3) {
        }

        public int p(y yVar) {
            return 0;
        }

        public void p0(RecyclerView recyclerView) {
        }

        public void q(t tVar) {
            int y = y();
            while (true) {
                y--;
                if (y >= 0) {
                    View x = x(y);
                    b0 K = RecyclerView.K(x);
                    if (!K.shouldIgnore()) {
                        if (!K.isInvalid() || K.isRemoved() || this.b.r.hasStableIds()) {
                            x(y);
                            r(y);
                            tVar.i(x);
                            this.b.l.f(K);
                        } else {
                            I0(y);
                            tVar.h(K);
                        }
                    }
                } else {
                    return;
                }
            }
        }

        public void q0(RecyclerView recyclerView, int i2, int i3, int i4) {
        }

        public final void r(int i2) {
            this.a.c(i2);
        }

        public void r0(RecyclerView recyclerView, int i2, int i3) {
        }

        public View s(View view) {
            View C;
            RecyclerView recyclerView = this.b;
            if (recyclerView == null || (C = recyclerView.C(view)) == null || this.a.c.contains(C)) {
                return null;
            }
            return C;
        }

        public void s0() {
        }

        public View t(int i2) {
            int y = y();
            for (int i3 = 0; i3 < y; i3++) {
                View x = x(i3);
                b0 K = RecyclerView.K(x);
                if (K != null && K.getLayoutPosition() == i2 && !K.shouldIgnore() && (this.b.o0.g || !K.isRemoved())) {
                    return x;
                }
            }
            return null;
        }

        public void t0(RecyclerView recyclerView, int i2, int i3, Object obj) {
            s0();
        }

        public abstract n u();

        public void u0(t tVar, y yVar) {
            Log.e("RecyclerView", "You must override onLayoutChildren(Recycler recycler, State state) ");
        }

        public n v(Context context, AttributeSet attributeSet) {
            return new n(context, attributeSet);
        }

        public void v0(y yVar) {
        }

        public n w(ViewGroup.LayoutParams layoutParams) {
            if (layoutParams instanceof n) {
                return new n((n) layoutParams);
            }
            if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
                return new n((ViewGroup.MarginLayoutParams) layoutParams);
            }
            return new n(layoutParams);
        }

        public void w0(int i2, int i3) {
            this.b.o(i2, i3);
        }

        public View x(int i2) {
            cy cyVar = this.a;
            if (cyVar == null) {
                return null;
            }
            return ((sy) cyVar.a).a(cyVar.f(i2));
        }

        @Deprecated
        public boolean x0(RecyclerView recyclerView) {
            x xVar = this.g;
            if ((xVar != null && xVar.e) || recyclerView.P()) {
                return true;
            }
            return false;
        }

        public int y() {
            cy cyVar = this.a;
            if (cyVar != null) {
                return cyVar.e();
            }
            return 0;
        }

        public boolean y0(RecyclerView recyclerView, View view, View view2) {
            return x0(recyclerView);
        }

        public void z0(Parcelable parcelable) {
        }
    }

    public interface o {
        void a(View view);

        void b(View view);
    }

    public static abstract class p {
    }

    public interface q {
        boolean a(RecyclerView recyclerView, MotionEvent motionEvent);

        void b(RecyclerView recyclerView, MotionEvent motionEvent);

        void c(boolean z);
    }

    public static abstract class r {
        public void onScrollStateChanged(RecyclerView recyclerView, int i) {
        }

        public void onScrolled(RecyclerView recyclerView, int i, int i2) {
        }
    }

    public static class s {
        public SparseArray<a> a = new SparseArray<>();
        public int b = 0;

        public static class a {
            public final ArrayList<b0> a = new ArrayList<>();
            public int b = 5;
            public long c = 0;
            public long d = 0;
        }

        public final a a(int i) {
            a aVar = this.a.get(i);
            if (aVar != null) {
                return aVar;
            }
            a aVar2 = new a();
            this.a.put(i, aVar2);
            return aVar2;
        }

        public long b(long j, long j2) {
            if (j == 0) {
                return j2;
            }
            return (j2 / 4) + ((j / 4) * 3);
        }
    }

    public final class t {
        public final ArrayList<b0> a;
        public ArrayList<b0> b = null;
        public final ArrayList<b0> c = new ArrayList<>();
        public final List<b0> d;
        public int e;
        public int f;
        public s g;

        public t() {
            ArrayList<b0> arrayList = new ArrayList<>();
            this.a = arrayList;
            this.d = Collections.unmodifiableList(arrayList);
            this.e = 2;
            this.f = 2;
        }

        public void a(b0 b0Var, boolean z) {
            RecyclerView.k(b0Var);
            View view = b0Var.itemView;
            uy uyVar = RecyclerView.this.v0;
            if (uyVar != null) {
                uy.a aVar = uyVar.e;
                co.u(view, aVar instanceof uy.a ? aVar.e.remove(view) : null);
            }
            if (z) {
                u uVar = RecyclerView.this.t;
                if (uVar != null) {
                    uVar.a(b0Var);
                }
                int size = RecyclerView.this.u.size();
                for (int i = 0; i < size; i++) {
                    RecyclerView.this.u.get(i).a(b0Var);
                }
                e eVar = RecyclerView.this.r;
                if (eVar != null) {
                    eVar.onViewRecycled(b0Var);
                }
                RecyclerView recyclerView = RecyclerView.this;
                if (recyclerView.o0 != null) {
                    recyclerView.l.g(b0Var);
                }
            }
            b0Var.mBindingAdapter = null;
            b0Var.mOwnerRecyclerView = null;
            s d2 = d();
            Objects.requireNonNull(d2);
            int itemViewType = b0Var.getItemViewType();
            ArrayList<b0> arrayList = d2.a(itemViewType).a;
            if (d2.a.get(itemViewType).b > arrayList.size()) {
                b0Var.resetInternal();
                arrayList.add(b0Var);
            }
        }

        public void b() {
            this.a.clear();
            e();
        }

        public int c(int i) {
            if (i < 0 || i >= RecyclerView.this.o0.b()) {
                StringBuilder K0 = ze0.K0("invalid position ", i, ". State item count is ");
                K0.append(RecyclerView.this.o0.b());
                throw new IndexOutOfBoundsException(ze0.e0(RecyclerView.this, K0));
            }
            RecyclerView recyclerView = RecyclerView.this;
            if (!recyclerView.o0.g) {
                return i;
            }
            return recyclerView.j.f(i, 0);
        }

        public s d() {
            if (this.g == null) {
                this.g = new s();
            }
            return this.g;
        }

        public void e() {
            for (int size = this.c.size() - 1; size >= 0; size--) {
                f(size);
            }
            this.c.clear();
            if (RecyclerView.L0) {
                hy.b bVar = RecyclerView.this.n0;
                int[] iArr = bVar.c;
                if (iArr != null) {
                    Arrays.fill(iArr, -1);
                }
                bVar.d = 0;
            }
        }

        public void f(int i) {
            a(this.c.get(i), true);
            this.c.remove(i);
        }

        public void g(View view) {
            b0 K = RecyclerView.K(view);
            if (K.isTmpDetached()) {
                RecyclerView.this.removeDetachedView(view, false);
            }
            if (K.isScrap()) {
                K.unScrap();
            } else if (K.wasReturnedFromScrap()) {
                K.clearReturnedFromScrapFlag();
            }
            h(K);
            if (RecyclerView.this.T != null && !K.isRecyclable()) {
                RecyclerView.this.T.endAnimation(K);
            }
        }

        public void h(b0 b0Var) {
            boolean z = false;
            boolean z2 = true;
            if (b0Var.isScrap() || b0Var.itemView.getParent() != null) {
                StringBuilder J0 = ze0.J0("Scrapped or attached views may not be recycled. isScrap:");
                J0.append(b0Var.isScrap());
                J0.append(" isAttached:");
                if (b0Var.itemView.getParent() != null) {
                    z = true;
                }
                J0.append(z);
                throw new IllegalArgumentException(ze0.e0(RecyclerView.this, J0));
            } else if (b0Var.isTmpDetached()) {
                StringBuilder sb = new StringBuilder();
                sb.append("Tmp detached view should be removed from RecyclerView before it can be recycled: ");
                sb.append(b0Var);
                throw new IllegalArgumentException(ze0.e0(RecyclerView.this, sb));
            } else if (!b0Var.shouldIgnore()) {
                boolean doesTransientStatePreventRecycling = b0Var.doesTransientStatePreventRecycling();
                e eVar = RecyclerView.this.r;
                if ((eVar != null && doesTransientStatePreventRecycling && eVar.onFailedToRecycleView(b0Var)) || b0Var.isRecyclable()) {
                    if (this.f <= 0 || b0Var.hasAnyOfTheFlags(526)) {
                        z = false;
                    } else {
                        int size = this.c.size();
                        if (size >= this.f && size > 0) {
                            f(0);
                            size--;
                        }
                        if (RecyclerView.L0 && size > 0 && !RecyclerView.this.n0.c(b0Var.mPosition)) {
                            do {
                                size--;
                                if (size < 0) {
                                    break;
                                }
                            } while (RecyclerView.this.n0.c(this.c.get(size).mPosition));
                            size++;
                        }
                        this.c.add(size, b0Var);
                        z = true;
                    }
                    if (!z) {
                        a(b0Var, true);
                        RecyclerView.this.l.g(b0Var);
                        if (!z && !z2 && doesTransientStatePreventRecycling) {
                            b0Var.mBindingAdapter = null;
                            b0Var.mOwnerRecyclerView = null;
                            return;
                        }
                        return;
                    }
                }
                z2 = false;
                RecyclerView.this.l.g(b0Var);
                if (!z) {
                }
            } else {
                throw new IllegalArgumentException(ze0.e0(RecyclerView.this, ze0.J0("Trying to recycle an ignored view holder. You should first call stopIgnoringView(view) before calling recycle.")));
            }
        }

        public void i(View view) {
            b0 K = RecyclerView.K(view);
            if (!K.hasAnyOfTheFlags(12) && K.isUpdated()) {
                j jVar = RecyclerView.this.T;
                if (!(jVar == null || jVar.canReuseUpdatedViewHolder(K, K.getUnmodifiedPayloads()))) {
                    if (this.b == null) {
                        this.b = new ArrayList<>();
                    }
                    K.setScrapContainer(this, true);
                    this.b.add(K);
                    return;
                }
            }
            if (!K.isInvalid() || K.isRemoved() || RecyclerView.this.r.hasStableIds()) {
                K.setScrapContainer(this, false);
                this.a.add(K);
                return;
            }
            throw new IllegalArgumentException(ze0.e0(RecyclerView.this, ze0.J0("Called scrap view with an invalid view. Invalid views cannot be reused from scrap, they should rebound from recycler pool.")));
        }

        /* JADX WARNING: Code restructure failed: missing block: B:156:0x0318, code lost:
            r7 = r14;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:160:0x0323, code lost:
            r7 = null;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:224:0x046e, code lost:
            if ((r8 == 0 || r8 + r5 < r21) == false) goto L_0x0470;
         */
        /* JADX WARNING: Removed duplicated region for block: B:124:0x025d  */
        /* JADX WARNING: Removed duplicated region for block: B:204:0x03ff  */
        /* JADX WARNING: Removed duplicated region for block: B:218:0x0457  */
        /* JADX WARNING: Removed duplicated region for block: B:233:0x04a3  */
        /* JADX WARNING: Removed duplicated region for block: B:247:0x04d9  */
        /* JADX WARNING: Removed duplicated region for block: B:251:0x04e4  */
        /* JADX WARNING: Removed duplicated region for block: B:252:0x04f2  */
        /* JADX WARNING: Removed duplicated region for block: B:258:0x050e A[ADDED_TO_REGION] */
        /* JADX WARNING: Removed duplicated region for block: B:34:0x008f  */
        /* JADX WARNING: Removed duplicated region for block: B:39:0x0096  */
        public b0 j(int i, boolean z, long j) {
            b0 b0Var;
            boolean z2;
            boolean z3;
            ViewGroup.LayoutParams layoutParams;
            n nVar;
            AccessibilityManager accessibilityManager;
            RecyclerView F;
            b0 b0Var2;
            b0 b0Var3;
            b0 b0Var4;
            View view;
            boolean z4;
            int size;
            int f2;
            if (i < 0 || i >= RecyclerView.this.o0.b()) {
                StringBuilder L0 = ze0.L0("Invalid item position ", i, "(", i, "). Item count:");
                L0.append(RecyclerView.this.o0.b());
                throw new IndexOutOfBoundsException(ze0.e0(RecyclerView.this, L0));
            }
            int i2 = 32;
            if (RecyclerView.this.o0.g) {
                ArrayList<b0> arrayList = this.b;
                if (arrayList != null && (size = arrayList.size()) != 0) {
                    int i3 = 0;
                    while (true) {
                        if (i3 < size) {
                            b0Var = this.b.get(i3);
                            if (!b0Var.wasReturnedFromScrap() && b0Var.getLayoutPosition() == i) {
                                b0Var.addFlags(32);
                                break;
                            }
                            i3++;
                        } else if (RecyclerView.this.r.hasStableIds() && (f2 = RecyclerView.this.j.f(i, 0)) > 0 && f2 < RecyclerView.this.r.getItemCount()) {
                            long itemId = RecyclerView.this.r.getItemId(f2);
                            int i4 = 0;
                            while (true) {
                                if (i4 >= size) {
                                    break;
                                }
                                b0 b0Var5 = this.b.get(i4);
                                if (!b0Var5.wasReturnedFromScrap() && b0Var5.getItemId() == itemId) {
                                    b0Var5.addFlags(32);
                                    b0Var = b0Var5;
                                    break;
                                }
                                i4++;
                            }
                        }
                    }
                    if (b0Var != null) {
                        z2 = true;
                        if (b0Var == null) {
                            int size2 = this.a.size();
                            int i5 = 0;
                            while (true) {
                                if (i5 < size2) {
                                    b0Var4 = this.a.get(i5);
                                    if (b0Var4.wasReturnedFromScrap() || b0Var4.getLayoutPosition() != i || b0Var4.isInvalid() || (!RecyclerView.this.o0.g && b0Var4.isRemoved())) {
                                        i5++;
                                    }
                                } else {
                                    if (!z) {
                                        cy cyVar = RecyclerView.this.k;
                                        int size3 = cyVar.c.size();
                                        int i6 = 0;
                                        while (true) {
                                            if (i6 >= size3) {
                                                view = null;
                                                break;
                                            }
                                            view = cyVar.c.get(i6);
                                            Objects.requireNonNull((sy) cyVar.a);
                                            b0 K = RecyclerView.K(view);
                                            if (!(K.getLayoutPosition() != i || K.isInvalid() || K.isRemoved())) {
                                                break;
                                            }
                                            i6++;
                                        }
                                        if (view != null) {
                                            b0Var = RecyclerView.K(view);
                                            cy cyVar2 = RecyclerView.this.k;
                                            int indexOfChild = ((sy) cyVar2.a).a.indexOfChild(view);
                                            if (indexOfChild < 0) {
                                                throw new IllegalArgumentException("view is not a child, cannot hide " + view);
                                            } else if (cyVar2.b.d(indexOfChild)) {
                                                cyVar2.b.a(indexOfChild);
                                                cyVar2.l(view);
                                                int j2 = RecyclerView.this.k.j(view);
                                                if (j2 != -1) {
                                                    RecyclerView.this.k.c(j2);
                                                    i(view);
                                                    b0Var.addFlags(8224);
                                                } else {
                                                    StringBuilder sb = new StringBuilder();
                                                    sb.append("layout index should not be -1 after unhiding a view:");
                                                    sb.append(b0Var);
                                                    throw new IllegalStateException(ze0.e0(RecyclerView.this, sb));
                                                }
                                            } else {
                                                throw new RuntimeException("trying to unhide a view that was not hidden" + view);
                                            }
                                        }
                                    }
                                    int size4 = this.c.size();
                                    for (int i7 = 0; i7 < size4; i7++) {
                                        b0Var4 = this.c.get(i7);
                                        if (!b0Var4.isInvalid() && b0Var4.getLayoutPosition() == i && !b0Var4.isAttachedToTransitionOverlay()) {
                                            if (!z) {
                                                this.c.remove(i7);
                                            }
                                        }
                                    }
                                    b0Var = null;
                                }
                            }
                            b0Var4.addFlags(32);
                            b0Var = b0Var4;
                            if (b0Var != null) {
                                if (b0Var.isRemoved()) {
                                    z4 = RecyclerView.this.o0.g;
                                } else {
                                    int i8 = b0Var.mPosition;
                                    if (i8 < 0 || i8 >= RecyclerView.this.r.getItemCount()) {
                                        StringBuilder sb2 = new StringBuilder();
                                        sb2.append("Inconsistency detected. Invalid view holder adapter position");
                                        sb2.append(b0Var);
                                        throw new IndexOutOfBoundsException(ze0.e0(RecyclerView.this, sb2));
                                    }
                                    RecyclerView recyclerView = RecyclerView.this;
                                    z4 = (recyclerView.o0.g || recyclerView.r.getItemViewType(b0Var.mPosition) == b0Var.getItemViewType()) && (!RecyclerView.this.r.hasStableIds() || b0Var.getItemId() == RecyclerView.this.r.getItemId(b0Var.mPosition));
                                }
                                if (!z4) {
                                    if (!z) {
                                        b0Var.addFlags(4);
                                        if (b0Var.isScrap()) {
                                            RecyclerView.this.removeDetachedView(b0Var.itemView, false);
                                            b0Var.unScrap();
                                        } else if (b0Var.wasReturnedFromScrap()) {
                                            b0Var.clearReturnedFromScrapFlag();
                                        }
                                        h(b0Var);
                                    }
                                    b0Var = null;
                                } else {
                                    z2 = true;
                                }
                            }
                        }
                        if (b0Var == null) {
                            int f3 = RecyclerView.this.j.f(i, 0);
                            if (f3 < 0 || f3 >= RecyclerView.this.r.getItemCount()) {
                                StringBuilder L02 = ze0.L0("Inconsistency detected. Invalid item position ", i, "(offset:", f3, ").state:");
                                L02.append(RecyclerView.this.o0.b());
                                throw new IndexOutOfBoundsException(ze0.e0(RecyclerView.this, L02));
                            }
                            int itemViewType = RecyclerView.this.r.getItemViewType(f3);
                            if (RecyclerView.this.r.hasStableIds()) {
                                long itemId2 = RecyclerView.this.r.getItemId(f3);
                                int size5 = this.a.size() - 1;
                                while (true) {
                                    if (size5 < 0) {
                                        int size6 = this.c.size() - 1;
                                        while (true) {
                                            if (size6 < 0) {
                                                break;
                                            }
                                            b0Var3 = this.c.get(size6);
                                            if (b0Var3.getItemId() == itemId2 && !b0Var3.isAttachedToTransitionOverlay()) {
                                                if (itemViewType == b0Var3.getItemViewType()) {
                                                    if (!z) {
                                                        this.c.remove(size6);
                                                    }
                                                } else if (!z) {
                                                    f(size6);
                                                    break;
                                                }
                                            }
                                            size6--;
                                        }
                                    } else {
                                        b0Var3 = this.a.get(size5);
                                        if (b0Var3.getItemId() == itemId2 && !b0Var3.wasReturnedFromScrap()) {
                                            if (itemViewType == b0Var3.getItemViewType()) {
                                                b0Var3.addFlags(i2);
                                                if (b0Var3.isRemoved() && !RecyclerView.this.o0.g) {
                                                    b0Var3.setFlags(2, 14);
                                                }
                                            } else if (!z) {
                                                this.a.remove(size5);
                                                RecyclerView.this.removeDetachedView(b0Var3.itemView, false);
                                                b0 K2 = RecyclerView.K(b0Var3.itemView);
                                                K2.mScrapContainer = null;
                                                K2.mInChangeScrap = false;
                                                K2.clearReturnedFromScrapFlag();
                                                h(K2);
                                            }
                                        }
                                        size5--;
                                        i2 = 32;
                                    }
                                }
                                if (b0Var != null) {
                                    b0Var.mPosition = f3;
                                    z2 = true;
                                }
                            }
                            if (b0Var == null) {
                                s.a aVar = d().a.get(itemViewType);
                                if (aVar != null && !aVar.a.isEmpty()) {
                                    ArrayList<b0> arrayList2 = aVar.a;
                                    int size7 = arrayList2.size() - 1;
                                    while (true) {
                                        if (size7 < 0) {
                                            break;
                                        } else if (!arrayList2.get(size7).isAttachedToTransitionOverlay()) {
                                            b0Var2 = arrayList2.remove(size7);
                                            break;
                                        } else {
                                            size7--;
                                        }
                                    }
                                }
                                b0Var2 = null;
                                if (b0Var2 != null) {
                                    b0Var2.resetInternal();
                                    int[] iArr = RecyclerView.I0;
                                }
                                b0Var = b0Var2;
                            }
                            if (b0Var == null) {
                                long nanoTime = RecyclerView.this.getNanoTime();
                                if (j != Long.MAX_VALUE) {
                                    long j3 = this.g.a(itemViewType).c;
                                    if (!(j3 == 0 || j3 + nanoTime < j)) {
                                        return null;
                                    }
                                }
                                RecyclerView recyclerView2 = RecyclerView.this;
                                b0 createViewHolder = recyclerView2.r.createViewHolder(recyclerView2, itemViewType);
                                if (RecyclerView.L0 && (F = RecyclerView.F(createViewHolder.itemView)) != null) {
                                    createViewHolder.mNestedRecyclerView = new WeakReference<>(F);
                                }
                                long nanoTime2 = RecyclerView.this.getNanoTime();
                                s sVar = this.g;
                                long j4 = nanoTime2 - nanoTime;
                                s.a a2 = sVar.a(itemViewType);
                                a2.c = sVar.b(a2.c, j4);
                                b0Var = createViewHolder;
                            }
                        }
                        if (z2 && !RecyclerView.this.o0.g && b0Var.hasAnyOfTheFlags(b0.FLAG_BOUNCED_FROM_HIDDEN_LIST)) {
                            b0Var.setFlags(0, b0.FLAG_BOUNCED_FROM_HIDDEN_LIST);
                            if (RecyclerView.this.o0.j) {
                                RecyclerView recyclerView3 = RecyclerView.this;
                                RecyclerView.this.d0(b0Var, recyclerView3.T.recordPreLayoutInformation(recyclerView3.o0, b0Var, j.buildAdapterChangeFlagsForAnimations(b0Var) | 4096, b0Var.getUnmodifiedPayloads()));
                            }
                        }
                        if (!RecyclerView.this.o0.g && b0Var.isBound()) {
                            b0Var.mPreLayoutPosition = i;
                        } else if (!b0Var.isBound() || b0Var.needsUpdate() || b0Var.isInvalid()) {
                            int f4 = RecyclerView.this.j.f(i, 0);
                            b0Var.mBindingAdapter = null;
                            b0Var.mOwnerRecyclerView = RecyclerView.this;
                            int itemViewType2 = b0Var.getItemViewType();
                            long nanoTime3 = RecyclerView.this.getNanoTime();
                            if (j != Long.MAX_VALUE) {
                                long j5 = this.g.a(itemViewType2).d;
                            }
                            RecyclerView.this.r.bindViewHolder(b0Var, f4);
                            long nanoTime4 = RecyclerView.this.getNanoTime();
                            s sVar2 = this.g;
                            long j6 = nanoTime4 - nanoTime3;
                            s.a a3 = sVar2.a(b0Var.getItemViewType());
                            a3.d = sVar2.b(a3.d, j6);
                            accessibilityManager = RecyclerView.this.I;
                            if (accessibilityManager == null && accessibilityManager.isEnabled()) {
                                View view2 = b0Var.itemView;
                                AtomicInteger atomicInteger = co.a;
                                if (co.c.c(view2) == 0) {
                                    co.c.s(view2, 1);
                                }
                                uy uyVar = RecyclerView.this.v0;
                                if (uyVar != null) {
                                    uy.a aVar2 = uyVar.e;
                                    if (aVar2 instanceof uy.a) {
                                        Objects.requireNonNull(aVar2);
                                        mn g2 = co.g(view2);
                                        if (!(g2 == null || g2 == aVar2)) {
                                            aVar2.e.put(view2, g2);
                                        }
                                    }
                                    co.u(view2, aVar2);
                                }
                            }
                            if (RecyclerView.this.o0.g) {
                                b0Var.mPreLayoutPosition = i;
                            }
                            z3 = true;
                            layoutParams = b0Var.itemView.getLayoutParams();
                            if (layoutParams == null) {
                                nVar = (n) RecyclerView.this.generateDefaultLayoutParams();
                                b0Var.itemView.setLayoutParams(nVar);
                            } else if (!RecyclerView.this.checkLayoutParams(layoutParams)) {
                                nVar = (n) RecyclerView.this.generateLayoutParams(layoutParams);
                                b0Var.itemView.setLayoutParams(nVar);
                            } else {
                                nVar = (n) layoutParams;
                            }
                            nVar.a = b0Var;
                            nVar.d = !z2 && z3;
                            return b0Var;
                        }
                        z3 = false;
                        layoutParams = b0Var.itemView.getLayoutParams();
                        if (layoutParams == null) {
                        }
                        nVar.a = b0Var;
                        nVar.d = !z2 && z3;
                        return b0Var;
                    }
                }
                b0Var = null;
                if (b0Var != null) {
                }
            } else {
                b0Var = null;
            }
            z2 = false;
            if (b0Var == null) {
            }
            if (b0Var == null) {
            }
            b0Var.setFlags(0, b0.FLAG_BOUNCED_FROM_HIDDEN_LIST);
            if (RecyclerView.this.o0.j) {
            }
            if (!RecyclerView.this.o0.g) {
            }
            int f42 = RecyclerView.this.j.f(i, 0);
            b0Var.mBindingAdapter = null;
            b0Var.mOwnerRecyclerView = RecyclerView.this;
            int itemViewType22 = b0Var.getItemViewType();
            long nanoTime32 = RecyclerView.this.getNanoTime();
            if (j != Long.MAX_VALUE) {
            }
            RecyclerView.this.r.bindViewHolder(b0Var, f42);
            long nanoTime42 = RecyclerView.this.getNanoTime();
            s sVar22 = this.g;
            long j62 = nanoTime42 - nanoTime32;
            s.a a32 = sVar22.a(b0Var.getItemViewType());
            a32.d = sVar22.b(a32.d, j62);
            accessibilityManager = RecyclerView.this.I;
            if (accessibilityManager == null && accessibilityManager.isEnabled()) {
            }
            if (RecyclerView.this.o0.g) {
            }
            z3 = true;
            layoutParams = b0Var.itemView.getLayoutParams();
            if (layoutParams == null) {
            }
            nVar.a = b0Var;
            nVar.d = !z2 && z3;
            return b0Var;
        }

        public void k(b0 b0Var) {
            if (b0Var.mInChangeScrap) {
                this.b.remove(b0Var);
            } else {
                this.a.remove(b0Var);
            }
            b0Var.mScrapContainer = null;
            b0Var.mInChangeScrap = false;
            b0Var.clearReturnedFromScrapFlag();
        }

        public void l() {
            m mVar = RecyclerView.this.s;
            this.f = this.e + (mVar != null ? mVar.l : 0);
            for (int size = this.c.size() - 1; size >= 0 && this.c.size() > this.f; size--) {
                f(size);
            }
        }
    }

    public interface u {
        void a(b0 b0Var);
    }

    public class v extends g {
        public v() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        public void a() {
            RecyclerView.this.i(null);
            RecyclerView recyclerView = RecyclerView.this;
            recyclerView.o0.f = true;
            recyclerView.c0(true);
            if (!RecyclerView.this.j.g()) {
                RecyclerView.this.requestLayout();
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        public void c(int i, int i2, Object obj) {
            RecyclerView.this.i(null);
            xx xxVar = RecyclerView.this.j;
            Objects.requireNonNull(xxVar);
            boolean z = false;
            if (i2 >= 1) {
                xxVar.b.add(xxVar.h(4, i, i2, obj));
                xxVar.f |= 4;
                if (xxVar.b.size() == 1) {
                    z = true;
                }
            }
            if (z) {
                h();
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        public void d(int i, int i2) {
            RecyclerView.this.i(null);
            xx xxVar = RecyclerView.this.j;
            Objects.requireNonNull(xxVar);
            boolean z = false;
            if (i2 >= 1) {
                xxVar.b.add(xxVar.h(1, i, i2, null));
                xxVar.f |= 1;
                if (xxVar.b.size() == 1) {
                    z = true;
                }
            }
            if (z) {
                h();
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        public void e(int i, int i2, int i3) {
            RecyclerView.this.i(null);
            xx xxVar = RecyclerView.this.j;
            Objects.requireNonNull(xxVar);
            boolean z = false;
            if (i != i2) {
                if (i3 == 1) {
                    xxVar.b.add(xxVar.h(8, i, i2, null));
                    xxVar.f |= 8;
                    if (xxVar.b.size() == 1) {
                        z = true;
                    }
                } else {
                    throw new IllegalArgumentException("Moving more than 1 item is not supported yet");
                }
            }
            if (z) {
                h();
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        public void f(int i, int i2) {
            RecyclerView.this.i(null);
            xx xxVar = RecyclerView.this.j;
            Objects.requireNonNull(xxVar);
            boolean z = false;
            if (i2 >= 1) {
                xxVar.b.add(xxVar.h(2, i, i2, null));
                xxVar.f |= 2;
                if (xxVar.b.size() == 1) {
                    z = true;
                }
            }
            if (z) {
                h();
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        public void g() {
            e eVar;
            RecyclerView recyclerView = RecyclerView.this;
            if (recyclerView.i != null && (eVar = recyclerView.r) != null && eVar.canRestoreState()) {
                RecyclerView.this.requestLayout();
            }
        }

        public void h() {
            if (RecyclerView.K0) {
                RecyclerView recyclerView = RecyclerView.this;
                if (recyclerView.z && recyclerView.y) {
                    Runnable runnable = recyclerView.n;
                    AtomicInteger atomicInteger = co.a;
                    co.c.m(recyclerView, runnable);
                    return;
                }
            }
            RecyclerView recyclerView2 = RecyclerView.this;
            recyclerView2.H = true;
            recyclerView2.requestLayout();
        }
    }

    public static abstract class x {
        public int a = -1;
        public RecyclerView b;
        public m c;
        public boolean d;
        public boolean e;
        public View f;
        public final a g = new a(0, 0);
        public boolean h;

        public static class a {
            public int a;
            public int b;
            public int c;
            public int d = -1;
            public Interpolator e;
            public boolean f = false;
            public int g = 0;

            public a(int i, int i2) {
                this.a = i;
                this.b = i2;
                this.c = Integer.MIN_VALUE;
                this.e = null;
            }

            public void a(RecyclerView recyclerView) {
                int i = this.d;
                if (i >= 0) {
                    this.d = -1;
                    recyclerView.Q(i);
                    this.f = false;
                } else if (this.f) {
                    Interpolator interpolator = this.e;
                    if (interpolator == null || this.c >= 1) {
                        int i2 = this.c;
                        if (i2 >= 1) {
                            recyclerView.l0.b(this.a, this.b, i2, interpolator);
                            int i3 = this.g + 1;
                            this.g = i3;
                            if (i3 > 10) {
                                Log.e("RecyclerView", "Smooth Scroll action is being updated too frequently. Make sure you are not changing it unless necessary");
                            }
                            this.f = false;
                            return;
                        }
                        throw new IllegalStateException("Scroll duration must be a positive number");
                    }
                    throw new IllegalStateException("If you provide an interpolator, you must set a positive duration");
                } else {
                    this.g = 0;
                }
            }

            public void b(int i, int i2, int i3, Interpolator interpolator) {
                this.a = i;
                this.b = i2;
                this.c = i3;
                this.e = interpolator;
                this.f = true;
            }
        }

        public interface b {
            PointF a(int i);
        }

        public PointF a(int i) {
            m mVar = this.c;
            if (mVar instanceof b) {
                return ((b) mVar).a(i);
            }
            StringBuilder J0 = ze0.J0("You should override computeScrollVectorForPosition when the LayoutManager does not implement ");
            J0.append(b.class.getCanonicalName());
            Log.w("RecyclerView", J0.toString());
            return null;
        }

        public void b(int i, int i2) {
            PointF a2;
            RecyclerView recyclerView = this.b;
            int i3 = -1;
            if (this.a == -1 || recyclerView == null) {
                f();
            }
            if (this.d && this.f == null && this.c != null && (a2 = a(this.a)) != null) {
                float f2 = a2.x;
                if (!(f2 == Utils.FLOAT_EPSILON && a2.y == Utils.FLOAT_EPSILON)) {
                    recyclerView.j0((int) Math.signum(f2), (int) Math.signum(a2.y), null);
                }
            }
            boolean z = false;
            this.d = false;
            View view = this.f;
            if (view != null) {
                Objects.requireNonNull(this.b);
                b0 K = RecyclerView.K(view);
                if (K != null) {
                    i3 = K.getLayoutPosition();
                }
                if (i3 == this.a) {
                    e(this.f, recyclerView.o0, this.g);
                    this.g.a(recyclerView);
                    f();
                } else {
                    Log.e("RecyclerView", "Passed over target position while smooth scrolling.");
                    this.f = null;
                }
            }
            if (this.e) {
                c(i, i2, recyclerView.o0, this.g);
                a aVar = this.g;
                if (aVar.d >= 0) {
                    z = true;
                }
                aVar.a(recyclerView);
                if (z && this.e) {
                    this.d = true;
                    recyclerView.l0.a();
                }
            }
        }

        public abstract void c(int i, int i2, y yVar, a aVar);

        public abstract void d();

        public abstract void e(View view, y yVar, a aVar);

        public final void f() {
            if (this.e) {
                this.e = false;
                d();
                this.b.o0.a = -1;
                this.f = null;
                this.a = -1;
                this.d = false;
                m mVar = this.c;
                if (mVar.g == this) {
                    mVar.g = null;
                }
                this.c = null;
                this.b = null;
            }
        }
    }

    public static class y {
        public int a = -1;
        public int b = 0;
        public int c = 0;
        public int d = 1;
        public int e = 0;
        public boolean f = false;
        public boolean g = false;
        public boolean h = false;
        public boolean i = false;
        public boolean j = false;
        public boolean k = false;
        public int l;
        public long m;
        public int n;

        public void a(int i2) {
            if ((this.d & i2) == 0) {
                StringBuilder J0 = ze0.J0("Layout state should be one of ");
                J0.append(Integer.toBinaryString(i2));
                J0.append(" but it is ");
                J0.append(Integer.toBinaryString(this.d));
                throw new IllegalStateException(J0.toString());
            }
        }

        public int b() {
            if (this.g) {
                return this.b - this.c;
            }
            return this.e;
        }

        public String toString() {
            StringBuilder J0 = ze0.J0("State{mTargetPosition=");
            J0.append(this.a);
            J0.append(", mData=");
            J0.append((Object) null);
            J0.append(", mItemCount=");
            J0.append(this.e);
            J0.append(", mIsMeasuring=");
            J0.append(this.i);
            J0.append(", mPreviousLayoutItemCount=");
            J0.append(this.b);
            J0.append(", mDeletedInvisibleItemCountSincePreviousLayout=");
            J0.append(this.c);
            J0.append(", mStructureChanged=");
            J0.append(this.f);
            J0.append(", mInPreLayout=");
            J0.append(this.g);
            J0.append(", mRunSimpleAnimations=");
            J0.append(this.j);
            J0.append(", mRunPredictiveAnimations=");
            return ze0.D0(J0, this.k, '}');
        }
    }

    public static abstract class z {
    }

    static {
        Class<?> cls = Integer.TYPE;
        M0 = new Class[]{Context.class, AttributeSet.class, cls, cls};
    }

    public RecyclerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.recyclerViewStyle);
    }

    public static RecyclerView F(View view) {
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        if (view instanceof RecyclerView) {
            return (RecyclerView) view;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            RecyclerView F2 = F(viewGroup.getChildAt(i2));
            if (F2 != null) {
                return F2;
            }
        }
        return null;
    }

    public static b0 K(View view) {
        if (view == null) {
            return null;
        }
        return ((n) view.getLayoutParams()).a;
    }

    public static void L(View view, Rect rect) {
        n nVar = (n) view.getLayoutParams();
        Rect rect2 = nVar.b;
        rect.set((view.getLeft() - rect2.left) - ((ViewGroup.MarginLayoutParams) nVar).leftMargin, (view.getTop() - rect2.top) - ((ViewGroup.MarginLayoutParams) nVar).topMargin, view.getRight() + rect2.right + ((ViewGroup.MarginLayoutParams) nVar).rightMargin, view.getBottom() + rect2.bottom + ((ViewGroup.MarginLayoutParams) nVar).bottomMargin);
    }

    private rn getScrollingChildHelper() {
        if (this.y0 == null) {
            this.y0 = new rn(this);
        }
        return this.y0;
    }

    public static void k(b0 b0Var) {
        WeakReference<RecyclerView> weakReference = b0Var.mNestedRecyclerView;
        if (weakReference != null) {
            RecyclerView recyclerView = weakReference.get();
            while (recyclerView != null) {
                if (recyclerView != b0Var.itemView) {
                    ViewParent parent = recyclerView.getParent();
                    recyclerView = parent instanceof View ? (View) parent : null;
                } else {
                    return;
                }
            }
            b0Var.mNestedRecyclerView = null;
        }
    }

    public String A() {
        StringBuilder J02 = ze0.J0(" ");
        J02.append(super.toString());
        J02.append(", adapter:");
        J02.append(this.r);
        J02.append(", layout:");
        J02.append(this.s);
        J02.append(", context:");
        J02.append(getContext());
        return J02.toString();
    }

    public final void B(y yVar) {
        if (getScrollState() == 2) {
            OverScroller overScroller = this.l0.i;
            overScroller.getFinalX();
            overScroller.getCurrX();
            Objects.requireNonNull(yVar);
            overScroller.getFinalY();
            overScroller.getCurrY();
            return;
        }
        Objects.requireNonNull(yVar);
    }

    public View C(View view) {
        ViewParent parent = view.getParent();
        while (parent != null && parent != this && (parent instanceof View)) {
            view = (View) parent;
            parent = view.getParent();
        }
        if (parent == this) {
            return view;
        }
        return null;
    }

    public final boolean D(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        int size = this.w.size();
        for (int i2 = 0; i2 < size; i2++) {
            q qVar = this.w.get(i2);
            if (qVar.a(this, motionEvent) && action != 3) {
                this.x = qVar;
                return true;
            }
        }
        return false;
    }

    public final void E(int[] iArr) {
        int e2 = this.k.e();
        if (e2 == 0) {
            iArr[0] = -1;
            iArr[1] = -1;
            return;
        }
        int i2 = Integer.MAX_VALUE;
        int i3 = Integer.MIN_VALUE;
        for (int i4 = 0; i4 < e2; i4++) {
            b0 K2 = K(this.k.d(i4));
            if (!K2.shouldIgnore()) {
                int layoutPosition = K2.getLayoutPosition();
                if (layoutPosition < i2) {
                    i2 = layoutPosition;
                }
                if (layoutPosition > i3) {
                    i3 = layoutPosition;
                }
            }
        }
        iArr[0] = i2;
        iArr[1] = i3;
    }

    public b0 G(int i2) {
        b0 b0Var = null;
        if (this.K) {
            return null;
        }
        int h2 = this.k.h();
        for (int i3 = 0; i3 < h2; i3++) {
            b0 K2 = K(this.k.g(i3));
            if (K2 != null && !K2.isRemoved() && H(K2) == i2) {
                if (!this.k.k(K2.itemView)) {
                    return K2;
                }
                b0Var = K2;
            }
        }
        return b0Var;
    }

    public int H(b0 b0Var) {
        if (!b0Var.hasAnyOfTheFlags(524) && b0Var.isBound()) {
            xx xxVar = this.j;
            int i2 = b0Var.mPosition;
            int size = xxVar.b.size();
            for (int i3 = 0; i3 < size; i3++) {
                xx.b bVar = xxVar.b.get(i3);
                int i4 = bVar.a;
                if (i4 != 1) {
                    if (i4 == 2) {
                        int i5 = bVar.b;
                        if (i5 <= i2) {
                            int i6 = bVar.d;
                            if (i5 + i6 <= i2) {
                                i2 -= i6;
                            }
                        } else {
                            continue;
                        }
                    } else if (i4 == 8) {
                        int i7 = bVar.b;
                        if (i7 == i2) {
                            i2 = bVar.d;
                        } else {
                            if (i7 < i2) {
                                i2--;
                            }
                            if (bVar.d <= i2) {
                                i2++;
                            }
                        }
                    }
                } else if (bVar.b <= i2) {
                    i2 += bVar.d;
                }
            }
            return i2;
        }
        return -1;
    }

    public long I(b0 b0Var) {
        return this.r.hasStableIds() ? b0Var.getItemId() : (long) b0Var.mPosition;
    }

    public b0 J(View view) {
        ViewParent parent = view.getParent();
        if (parent == null || parent == this) {
            return K(view);
        }
        throw new IllegalArgumentException("View " + view + " is not a direct child of " + this);
    }

    public Rect M(View view) {
        n nVar = (n) view.getLayoutParams();
        if (!nVar.c) {
            return nVar.b;
        }
        if (this.o0.g && (nVar.b() || nVar.a.isInvalid())) {
            return nVar.b;
        }
        Rect rect = nVar.b;
        rect.set(0, 0, 0, 0);
        int size = this.v.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.o.set(0, 0, 0, 0);
            this.v.get(i2).d(this.o, view, this, this.o0);
            int i3 = rect.left;
            Rect rect2 = this.o;
            rect.left = i3 + rect2.left;
            rect.top += rect2.top;
            rect.right += rect2.right;
            rect.bottom += rect2.bottom;
        }
        nVar.c = false;
        return rect;
    }

    public boolean N() {
        return !this.B || this.K || this.j.g();
    }

    public void O() {
        this.S = null;
        this.Q = null;
        this.R = null;
        this.P = null;
    }

    public boolean P() {
        return this.M > 0;
    }

    public void Q(int i2) {
        if (this.s != null) {
            setScrollState(2);
            this.s.M0(i2);
            awakenScrollBars();
        }
    }

    public void R() {
        int h2 = this.k.h();
        for (int i2 = 0; i2 < h2; i2++) {
            ((n) this.k.g(i2).getLayoutParams()).c = true;
        }
        t tVar = this.h;
        int size = tVar.c.size();
        for (int i3 = 0; i3 < size; i3++) {
            n nVar = (n) tVar.c.get(i3).itemView.getLayoutParams();
            if (nVar != null) {
                nVar.c = true;
            }
        }
    }

    public void S(int i2, int i3, boolean z2) {
        int i4 = i2 + i3;
        int h2 = this.k.h();
        for (int i5 = 0; i5 < h2; i5++) {
            b0 K2 = K(this.k.g(i5));
            if (K2 != null && !K2.shouldIgnore()) {
                int i6 = K2.mPosition;
                if (i6 >= i4) {
                    K2.offsetPosition(-i3, z2);
                    this.o0.f = true;
                } else if (i6 >= i2) {
                    K2.flagRemovedAndOffsetPosition(i2 - 1, -i3, z2);
                    this.o0.f = true;
                }
            }
        }
        t tVar = this.h;
        int size = tVar.c.size();
        while (true) {
            size--;
            if (size >= 0) {
                b0 b0Var = tVar.c.get(size);
                if (b0Var != null) {
                    int i7 = b0Var.mPosition;
                    if (i7 >= i4) {
                        b0Var.offsetPosition(-i3, z2);
                    } else if (i7 >= i2) {
                        b0Var.addFlags(8);
                        tVar.f(size);
                    }
                }
            } else {
                requestLayout();
                return;
            }
        }
    }

    public void T() {
    }

    public void U() {
    }

    public void V() {
        this.M++;
    }

    public void W(boolean z2) {
        int i2;
        boolean z3 = true;
        int i3 = this.M - 1;
        this.M = i3;
        if (i3 < 1) {
            this.M = 0;
            if (z2) {
                int i4 = this.G;
                this.G = 0;
                if (i4 != 0) {
                    AccessibilityManager accessibilityManager = this.I;
                    if (accessibilityManager == null || !accessibilityManager.isEnabled()) {
                        z3 = false;
                    }
                    if (z3) {
                        AccessibilityEvent obtain = AccessibilityEvent.obtain();
                        obtain.setEventType(2048);
                        obtain.setContentChangeTypes(i4);
                        sendAccessibilityEventUnchecked(obtain);
                    }
                }
                for (int size = this.C0.size() - 1; size >= 0; size--) {
                    b0 b0Var = this.C0.get(size);
                    if (b0Var.itemView.getParent() == this && !b0Var.shouldIgnore() && (i2 = b0Var.mPendingAccessibilityState) != -1) {
                        View view = b0Var.itemView;
                        AtomicInteger atomicInteger = co.a;
                        co.c.s(view, i2);
                        b0Var.mPendingAccessibilityState = -1;
                    }
                }
                this.C0.clear();
            }
        }
    }

    public final void X(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.V) {
            int i2 = actionIndex == 0 ? 1 : 0;
            this.V = motionEvent.getPointerId(i2);
            int x2 = (int) (motionEvent.getX(i2) + 0.5f);
            this.c0 = x2;
            this.a0 = x2;
            int y2 = (int) (motionEvent.getY(i2) + 0.5f);
            this.d0 = y2;
            this.b0 = y2;
        }
    }

    public void Y() {
    }

    public void Z() {
    }

    public void a0() {
        if (!this.u0 && this.y) {
            Runnable runnable = this.D0;
            AtomicInteger atomicInteger = co.a;
            co.c.m(this, runnable);
            this.u0 = true;
        }
    }

    @Override // android.view.View, android.view.ViewGroup
    public void addFocusables(ArrayList<View> arrayList, int i2, int i3) {
        m mVar = this.s;
        if (mVar == null || !mVar.d0()) {
            super.addFocusables(arrayList, i2, i3);
        }
    }

    public final void b0() {
        boolean z2;
        boolean z3 = false;
        if (this.K) {
            xx xxVar = this.j;
            xxVar.l(xxVar.b);
            xxVar.l(xxVar.c);
            xxVar.f = 0;
            if (this.L) {
                this.s.p0(this);
            }
        }
        if (this.T != null && this.s.Y0()) {
            this.j.j();
        } else {
            this.j.c();
        }
        boolean z4 = this.r0 || this.s0;
        this.o0.j = this.B && this.T != null && ((z2 = this.K) || z4 || this.s.h) && (!z2 || this.r.hasStableIds());
        y yVar = this.o0;
        if (yVar.j && z4 && !this.K) {
            if (this.T != null && this.s.Y0()) {
                z3 = true;
            }
        }
        yVar.k = z3;
    }

    public void c0(boolean z2) {
        this.L = z2 | this.L;
        this.K = true;
        int h2 = this.k.h();
        for (int i2 = 0; i2 < h2; i2++) {
            b0 K2 = K(this.k.g(i2));
            if (K2 != null && !K2.shouldIgnore()) {
                K2.addFlags(6);
            }
        }
        R();
        t tVar = this.h;
        int size = tVar.c.size();
        for (int i3 = 0; i3 < size; i3++) {
            b0 b0Var = tVar.c.get(i3);
            if (b0Var != null) {
                b0Var.addFlags(6);
                b0Var.addChangePayload(null);
            }
        }
        e eVar = RecyclerView.this.r;
        if (eVar == null || !eVar.hasStableIds()) {
            tVar.e();
        }
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof n) && this.s.g((n) layoutParams);
    }

    public int computeHorizontalScrollExtent() {
        m mVar = this.s;
        if (mVar != null && mVar.e()) {
            return this.s.k(this.o0);
        }
        return 0;
    }

    public int computeHorizontalScrollOffset() {
        m mVar = this.s;
        if (mVar != null && mVar.e()) {
            return this.s.l(this.o0);
        }
        return 0;
    }

    public int computeHorizontalScrollRange() {
        m mVar = this.s;
        if (mVar != null && mVar.e()) {
            return this.s.m(this.o0);
        }
        return 0;
    }

    public int computeVerticalScrollExtent() {
        m mVar = this.s;
        if (mVar != null && mVar.f()) {
            return this.s.n(this.o0);
        }
        return 0;
    }

    public int computeVerticalScrollOffset() {
        m mVar = this.s;
        if (mVar != null && mVar.f()) {
            return this.s.o(this.o0);
        }
        return 0;
    }

    public int computeVerticalScrollRange() {
        m mVar = this.s;
        if (mVar != null && mVar.f()) {
            return this.s.p(this.o0);
        }
        return 0;
    }

    public void d0(b0 b0Var, j.c cVar) {
        b0Var.setFlags(0, b0.FLAG_BOUNCED_FROM_HIDDEN_LIST);
        if (this.o0.h && b0Var.isUpdated() && !b0Var.isRemoved() && !b0Var.shouldIgnore()) {
            this.l.b.k(I(b0Var), b0Var);
        }
        this.l.c(b0Var, cVar);
    }

    public boolean dispatchNestedFling(float f2, float f3, boolean z2) {
        return getScrollingChildHelper().a(f2, f3, z2);
    }

    public boolean dispatchNestedPreFling(float f2, float f3) {
        return getScrollingChildHelper().b(f2, f3);
    }

    public boolean dispatchNestedPreScroll(int i2, int i3, int[] iArr, int[] iArr2) {
        return getScrollingChildHelper().c(i2, i3, iArr, iArr2, 0);
    }

    public boolean dispatchNestedScroll(int i2, int i3, int i4, int i5, int[] iArr) {
        return getScrollingChildHelper().e(i2, i3, i4, i5, iArr);
    }

    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        onPopulateAccessibilityEvent(accessibilityEvent);
        return true;
    }

    @Override // android.view.View, android.view.ViewGroup
    public void dispatchRestoreInstanceState(SparseArray<Parcelable> sparseArray) {
        dispatchThawSelfOnly(sparseArray);
    }

    @Override // android.view.View, android.view.ViewGroup
    public void dispatchSaveInstanceState(SparseArray<Parcelable> sparseArray) {
        dispatchFreezeSelfOnly(sparseArray);
    }

    public void draw(Canvas canvas) {
        boolean z2;
        super.draw(canvas);
        int size = this.v.size();
        boolean z3 = false;
        for (int i2 = 0; i2 < size; i2++) {
            this.v.get(i2).f(canvas, this, this.o0);
        }
        EdgeEffect edgeEffect = this.P;
        boolean z4 = true;
        if (edgeEffect == null || edgeEffect.isFinished()) {
            z2 = false;
        } else {
            int save = canvas.save();
            int paddingBottom = this.m ? getPaddingBottom() : 0;
            canvas.rotate(270.0f);
            canvas.translate((float) ((-getHeight()) + paddingBottom), Utils.FLOAT_EPSILON);
            EdgeEffect edgeEffect2 = this.P;
            z2 = edgeEffect2 != null && edgeEffect2.draw(canvas);
            canvas.restoreToCount(save);
        }
        EdgeEffect edgeEffect3 = this.Q;
        if (edgeEffect3 != null && !edgeEffect3.isFinished()) {
            int save2 = canvas.save();
            if (this.m) {
                canvas.translate((float) getPaddingLeft(), (float) getPaddingTop());
            }
            EdgeEffect edgeEffect4 = this.Q;
            z2 |= edgeEffect4 != null && edgeEffect4.draw(canvas);
            canvas.restoreToCount(save2);
        }
        EdgeEffect edgeEffect5 = this.R;
        if (edgeEffect5 != null && !edgeEffect5.isFinished()) {
            int save3 = canvas.save();
            int width = getWidth();
            int paddingTop = this.m ? getPaddingTop() : 0;
            canvas.rotate(90.0f);
            canvas.translate((float) (-paddingTop), (float) (-width));
            EdgeEffect edgeEffect6 = this.R;
            z2 |= edgeEffect6 != null && edgeEffect6.draw(canvas);
            canvas.restoreToCount(save3);
        }
        EdgeEffect edgeEffect7 = this.S;
        if (edgeEffect7 != null && !edgeEffect7.isFinished()) {
            int save4 = canvas.save();
            canvas.rotate(180.0f);
            if (this.m) {
                canvas.translate((float) (getPaddingRight() + (-getWidth())), (float) (getPaddingBottom() + (-getHeight())));
            } else {
                canvas.translate((float) (-getWidth()), (float) (-getHeight()));
            }
            EdgeEffect edgeEffect8 = this.S;
            if (edgeEffect8 != null && edgeEffect8.draw(canvas)) {
                z3 = true;
            }
            z2 |= z3;
            canvas.restoreToCount(save4);
        }
        if (z2 || this.T == null || this.v.size() <= 0 || !this.T.isRunning()) {
            z4 = z2;
        }
        if (z4) {
            AtomicInteger atomicInteger = co.a;
            co.c.k(this);
        }
    }

    public boolean drawChild(Canvas canvas, View view, long j2) {
        return super.drawChild(canvas, view, j2);
    }

    public void e0() {
        j jVar = this.T;
        if (jVar != null) {
            jVar.endAnimations();
        }
        m mVar = this.s;
        if (mVar != null) {
            mVar.E0(this.h);
            this.s.F0(this.h);
        }
        this.h.b();
    }

    public final void f(b0 b0Var) {
        View view = b0Var.itemView;
        boolean z2 = view.getParent() == this;
        this.h.k(J(view));
        if (b0Var.isTmpDetached()) {
            this.k.b(view, -1, view.getLayoutParams(), true);
        } else if (!z2) {
            this.k.a(view, -1, true);
        } else {
            cy cyVar = this.k;
            int indexOfChild = ((sy) cyVar.a).a.indexOfChild(view);
            if (indexOfChild >= 0) {
                cyVar.b.h(indexOfChild);
                cyVar.i(view);
                return;
            }
            throw new IllegalArgumentException("view is not a child, cannot hide " + view);
        }
    }

    public void f0(r rVar) {
        List<r> list = this.q0;
        if (list != null) {
            list.remove(rVar);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:113:0x016b, code lost:
        if (r3 > 0) goto L_0x019f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:116:0x0185, code lost:
        if (r6 > 0) goto L_0x019f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:117:0x0188, code lost:
        if (r3 < 0) goto L_0x019f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:118:0x018b, code lost:
        if (r6 < 0) goto L_0x019f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:122:0x0194, code lost:
        if ((r6 * r1) <= 0) goto L_0x01a1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:126:0x019d, code lost:
        if ((r6 * r1) >= 0) goto L_0x01a1;
     */
    /* JADX WARNING: Removed duplicated region for block: B:130:0x01a5  */
    /* JADX WARNING: Removed duplicated region for block: B:132:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x005a  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x005c  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x005f  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x0061  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x0065  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x0068  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x0070  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x0072  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x0075  */
    public View focusSearch(View view, int i2) {
        View view2;
        int i3;
        char c2;
        boolean z2;
        View n02 = this.s.n0();
        if (n02 != null) {
            return n02;
        }
        boolean z3 = false;
        boolean z4 = this.r != null && this.s != null && !P() && !this.E;
        FocusFinder instance = FocusFinder.getInstance();
        if (!z4 || !(i2 == 2 || i2 == 1)) {
            View findNextFocus = instance.findNextFocus(this, view, i2);
            if (findNextFocus != null || !z4) {
                view2 = findNextFocus;
            } else {
                n();
                if (C(view) == null) {
                    return null;
                }
                o0();
                view2 = this.s.h0(view, i2, this.h, this.o0);
                q0(false);
            }
        } else {
            if (this.s.f()) {
                if (instance.findNextFocus(this, view, i2 == 2 ? 130 : 33) == null) {
                    z2 = true;
                    if (!z2 && this.s.e()) {
                        z2 = instance.findNextFocus(this, view, !((this.s.J() != 1) ^ (i2 != 2)) ? 66 : 17) != null;
                    }
                    if (z2) {
                        n();
                        if (C(view) == null) {
                            return null;
                        }
                        o0();
                        this.s.h0(view, i2, this.h, this.o0);
                        q0(false);
                    }
                    view2 = instance.findNextFocus(this, view, i2);
                }
            }
            z2 = false;
            if (instance.findNextFocus(this, view, !((this.s.J() != 1) ^ (i2 != 2)) ? 66 : 17) != null) {
            }
            if (z2) {
            }
            view2 = instance.findNextFocus(this, view, i2);
        }
        if (view2 == null || view2.hasFocusable()) {
            if (!(view2 == null || view2 == this || view2 == view)) {
                if (C(view2) != null) {
                    if (!(view == null || C(view) == null)) {
                        this.o.set(0, 0, view.getWidth(), view.getHeight());
                        this.p.set(0, 0, view2.getWidth(), view2.getHeight());
                        offsetDescendantRectToMyCoords(view, this.o);
                        offsetDescendantRectToMyCoords(view2, this.p);
                        int i4 = this.s.J() == 1 ? -1 : 1;
                        Rect rect = this.o;
                        int i5 = rect.left;
                        Rect rect2 = this.p;
                        int i6 = rect2.left;
                        if ((i5 < i6 || rect.right <= i6) && rect.right < rect2.right) {
                            i3 = 1;
                        } else {
                            int i7 = rect.right;
                            int i8 = rect2.right;
                            i3 = ((i7 > i8 || i5 >= i8) && i5 > i6) ? -1 : 0;
                        }
                        int i9 = rect.top;
                        int i10 = rect2.top;
                        if ((i9 < i10 || rect.bottom <= i10) && rect.bottom < rect2.bottom) {
                            c2 = 1;
                        } else {
                            int i11 = rect.bottom;
                            int i12 = rect2.bottom;
                            c2 = ((i11 > i12 || i9 >= i12) && i9 > i10) ? (char) 65535 : 0;
                        }
                        if (i2 != 1) {
                            if (i2 != 2) {
                                if (i2 != 17) {
                                    if (i2 != 33) {
                                        if (i2 != 66) {
                                            if (i2 != 130) {
                                                StringBuilder sb = new StringBuilder();
                                                sb.append("Invalid direction: ");
                                                sb.append(i2);
                                                throw new IllegalArgumentException(ze0.e0(this, sb));
                                            }
                                        }
                                    }
                                }
                            } else if (c2 <= 0) {
                                if (c2 == 0) {
                                }
                            }
                        } else if (c2 >= 0) {
                            if (c2 == 0) {
                            }
                        }
                    }
                    z3 = true;
                }
                return !z3 ? view2 : super.focusSearch(view, i2);
            }
            z3 = false;
            if (!z3) {
            }
        } else if (getFocusedChild() == null) {
            return super.focusSearch(view, i2);
        } else {
            g0(view2, null);
            return view;
        }
    }

    public void g(l lVar) {
        m mVar = this.s;
        if (mVar != null) {
            mVar.d("Cannot add item decoration during a scroll  or layout");
        }
        if (this.v.isEmpty()) {
            setWillNotDraw(false);
        }
        this.v.add(lVar);
        R();
        requestLayout();
    }

    public final void g0(View view, View view2) {
        View view3 = view2 != null ? view2 : view;
        this.o.set(0, 0, view3.getWidth(), view3.getHeight());
        ViewGroup.LayoutParams layoutParams = view3.getLayoutParams();
        if (layoutParams instanceof n) {
            n nVar = (n) layoutParams;
            if (!nVar.c) {
                Rect rect = nVar.b;
                Rect rect2 = this.o;
                rect2.left -= rect.left;
                rect2.right += rect.right;
                rect2.top -= rect.top;
                rect2.bottom += rect.bottom;
            }
        }
        if (view2 != null) {
            offsetDescendantRectToMyCoords(view2, this.o);
            offsetRectIntoDescendantCoords(view, this.o);
        }
        this.s.J0(this, view, this.o, !this.B, view2 == null);
    }

    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        m mVar = this.s;
        if (mVar != null) {
            return mVar.u();
        }
        throw new IllegalStateException(ze0.e0(this, ze0.J0("RecyclerView has no LayoutManager")));
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        m mVar = this.s;
        if (mVar != null) {
            return mVar.v(getContext(), attributeSet);
        }
        throw new IllegalStateException(ze0.e0(this, ze0.J0("RecyclerView has no LayoutManager")));
    }

    public CharSequence getAccessibilityClassName() {
        return "androidx.recyclerview.widget.RecyclerView";
    }

    public e getAdapter() {
        return this.r;
    }

    public int getBaseline() {
        m mVar = this.s;
        if (mVar == null) {
            return super.getBaseline();
        }
        Objects.requireNonNull(mVar);
        return -1;
    }

    public int getChildDrawingOrder(int i2, int i3) {
        h hVar = this.w0;
        if (hVar == null) {
            return super.getChildDrawingOrder(i2, i3);
        }
        return hVar.a(i2, i3);
    }

    public boolean getClipToPadding() {
        return this.m;
    }

    public uy getCompatAccessibilityDelegate() {
        return this.v0;
    }

    public i getEdgeEffectFactory() {
        return this.O;
    }

    public j getItemAnimator() {
        return this.T;
    }

    public int getItemDecorationCount() {
        return this.v.size();
    }

    public m getLayoutManager() {
        return this.s;
    }

    public int getMaxFlingVelocity() {
        return this.h0;
    }

    public int getMinFlingVelocity() {
        return this.g0;
    }

    public long getNanoTime() {
        if (L0) {
            return System.nanoTime();
        }
        return 0;
    }

    public p getOnFlingListener() {
        return this.f0;
    }

    public boolean getPreserveFocusAfterLayout() {
        return this.k0;
    }

    public s getRecycledViewPool() {
        return this.h.d();
    }

    public int getScrollState() {
        return this.U;
    }

    public void h(r rVar) {
        if (this.q0 == null) {
            this.q0 = new ArrayList();
        }
        this.q0.add(rVar);
    }

    public final void h0() {
        VelocityTracker velocityTracker = this.W;
        if (velocityTracker != null) {
            velocityTracker.clear();
        }
        boolean z2 = false;
        r0(0);
        EdgeEffect edgeEffect = this.P;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            z2 = this.P.isFinished();
        }
        EdgeEffect edgeEffect2 = this.Q;
        if (edgeEffect2 != null) {
            edgeEffect2.onRelease();
            z2 |= this.Q.isFinished();
        }
        EdgeEffect edgeEffect3 = this.R;
        if (edgeEffect3 != null) {
            edgeEffect3.onRelease();
            z2 |= this.R.isFinished();
        }
        EdgeEffect edgeEffect4 = this.S;
        if (edgeEffect4 != null) {
            edgeEffect4.onRelease();
            z2 |= this.S.isFinished();
        }
        if (z2) {
            AtomicInteger atomicInteger = co.a;
            co.c.k(this);
        }
    }

    public boolean hasNestedScrollingParent() {
        return getScrollingChildHelper().h(0);
    }

    public void i(String str) {
        if (P()) {
            if (str == null) {
                throw new IllegalStateException(ze0.e0(this, ze0.J0("Cannot call this method while RecyclerView is computing a layout or scrolling")));
            }
            throw new IllegalStateException(str);
        } else if (this.N > 0) {
            Log.w("RecyclerView", "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame.", new IllegalStateException(ze0.e0(this, ze0.J0(""))));
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:31:0x00e1  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x00f7  */
    public boolean i0(int i2, int i3, MotionEvent motionEvent, int i4) {
        int i5;
        int i6;
        int i7;
        int i8;
        boolean z2;
        n();
        if (this.r != null) {
            int[] iArr = this.B0;
            iArr[0] = 0;
            iArr[1] = 0;
            j0(i2, i3, iArr);
            int[] iArr2 = this.B0;
            int i9 = iArr2[0];
            int i10 = iArr2[1];
            i8 = i10;
            i7 = i9;
            i6 = i2 - i9;
            i5 = i3 - i10;
        } else {
            i8 = 0;
            i7 = 0;
            i6 = 0;
            i5 = 0;
        }
        if (!this.v.isEmpty()) {
            invalidate();
        }
        int[] iArr3 = this.B0;
        iArr3[0] = 0;
        iArr3[1] = 0;
        u(i7, i8, i6, i5, this.z0, i4, iArr3);
        int[] iArr4 = this.B0;
        int i11 = i6 - iArr4[0];
        int i12 = i5 - iArr4[1];
        boolean z3 = (iArr4[0] == 0 && iArr4[1] == 0) ? false : true;
        int i13 = this.c0;
        int[] iArr5 = this.z0;
        this.c0 = i13 - iArr5[0];
        this.d0 -= iArr5[1];
        int[] iArr6 = this.A0;
        iArr6[0] = iArr6[0] + iArr5[0];
        iArr6[1] = iArr6[1] + iArr5[1];
        if (getOverScrollMode() != 2) {
            if (motionEvent != null) {
                if (!((motionEvent.getSource() & 8194) == 8194)) {
                    float x2 = motionEvent.getX();
                    float f2 = (float) i11;
                    float y2 = motionEvent.getY();
                    float f3 = (float) i12;
                    if (f2 < Utils.FLOAT_EPSILON) {
                        x();
                        this.P.onPull((-f2) / ((float) getWidth()), 1.0f - (y2 / ((float) getHeight())));
                    } else if (f2 > Utils.FLOAT_EPSILON) {
                        y();
                        this.R.onPull(f2 / ((float) getWidth()), y2 / ((float) getHeight()));
                    } else {
                        z2 = false;
                        if (f3 >= Utils.FLOAT_EPSILON) {
                            z();
                            this.Q.onPull((-f3) / ((float) getHeight()), x2 / ((float) getWidth()));
                        } else {
                            if (f3 > Utils.FLOAT_EPSILON) {
                                w();
                                this.S.onPull(f3 / ((float) getHeight()), 1.0f - (x2 / ((float) getWidth())));
                            }
                            if (!(!z2 && f2 == Utils.FLOAT_EPSILON && f3 == Utils.FLOAT_EPSILON)) {
                                AtomicInteger atomicInteger = co.a;
                                co.c.k(this);
                            }
                        }
                        z2 = true;
                        AtomicInteger atomicInteger2 = co.a;
                        co.c.k(this);
                    }
                    z2 = true;
                    if (f3 >= Utils.FLOAT_EPSILON) {
                    }
                    z2 = true;
                    AtomicInteger atomicInteger22 = co.a;
                    co.c.k(this);
                }
            }
            m(i2, i3);
        }
        if (!(i7 == 0 && i8 == 0)) {
            v(i7, i8);
        }
        if (!awakenScrollBars()) {
            invalidate();
        }
        return (!z3 && i7 == 0 && i8 == 0) ? false : true;
    }

    public boolean isAttachedToWindow() {
        return this.y;
    }

    public final boolean isLayoutSuppressed() {
        return this.E;
    }

    public boolean isNestedScrollingEnabled() {
        return getScrollingChildHelper().d;
    }

    public final void j() {
        h0();
        setScrollState(0);
    }

    public void j0(int i2, int i3, int[] iArr) {
        b0 b0Var;
        o0();
        V();
        int i4 = km.a;
        Trace.beginSection("RV Scroll");
        B(this.o0);
        int L02 = i2 != 0 ? this.s.L0(i2, this.h, this.o0) : 0;
        int N02 = i3 != 0 ? this.s.N0(i3, this.h, this.o0) : 0;
        Trace.endSection();
        int e2 = this.k.e();
        for (int i5 = 0; i5 < e2; i5++) {
            View d2 = this.k.d(i5);
            b0 J2 = J(d2);
            if (!(J2 == null || (b0Var = J2.mShadowingHolder) == null)) {
                View view = b0Var.itemView;
                int left = d2.getLeft();
                int top = d2.getTop();
                if (left != view.getLeft() || top != view.getTop()) {
                    view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
                }
            }
        }
        W(true);
        q0(false);
        if (iArr != null) {
            iArr[0] = L02;
            iArr[1] = N02;
        }
    }

    public void k0(int i2) {
        if (!this.E) {
            s0();
            m mVar = this.s;
            if (mVar == null) {
                Log.e("RecyclerView", "Cannot scroll to position a LayoutManager set. Call setLayoutManager with a non-null argument.");
                return;
            }
            mVar.M0(i2);
            awakenScrollBars();
        }
    }

    public void l() {
        int h2 = this.k.h();
        for (int i2 = 0; i2 < h2; i2++) {
            b0 K2 = K(this.k.g(i2));
            if (!K2.shouldIgnore()) {
                K2.clearOldPosition();
            }
        }
        t tVar = this.h;
        int size = tVar.c.size();
        for (int i3 = 0; i3 < size; i3++) {
            tVar.c.get(i3).clearOldPosition();
        }
        int size2 = tVar.a.size();
        for (int i4 = 0; i4 < size2; i4++) {
            tVar.a.get(i4).clearOldPosition();
        }
        ArrayList<b0> arrayList = tVar.b;
        if (arrayList != null) {
            int size3 = arrayList.size();
            for (int i5 = 0; i5 < size3; i5++) {
                tVar.b.get(i5).clearOldPosition();
            }
        }
    }

    public boolean l0(b0 b0Var, int i2) {
        if (P()) {
            b0Var.mPendingAccessibilityState = i2;
            this.C0.add(b0Var);
            return false;
        }
        View view = b0Var.itemView;
        AtomicInteger atomicInteger = co.a;
        co.c.s(view, i2);
        return true;
    }

    public void m(int i2, int i3) {
        boolean z2;
        EdgeEffect edgeEffect = this.P;
        if (edgeEffect == null || edgeEffect.isFinished() || i2 <= 0) {
            z2 = false;
        } else {
            this.P.onRelease();
            z2 = this.P.isFinished();
        }
        EdgeEffect edgeEffect2 = this.R;
        if (edgeEffect2 != null && !edgeEffect2.isFinished() && i2 < 0) {
            this.R.onRelease();
            z2 |= this.R.isFinished();
        }
        EdgeEffect edgeEffect3 = this.Q;
        if (edgeEffect3 != null && !edgeEffect3.isFinished() && i3 > 0) {
            this.Q.onRelease();
            z2 |= this.Q.isFinished();
        }
        EdgeEffect edgeEffect4 = this.S;
        if (edgeEffect4 != null && !edgeEffect4.isFinished() && i3 < 0) {
            this.S.onRelease();
            z2 |= this.S.isFinished();
        }
        if (z2) {
            AtomicInteger atomicInteger = co.a;
            co.c.k(this);
        }
    }

    public void m0(int i2, int i3, Interpolator interpolator, int i4, boolean z2) {
        m mVar = this.s;
        if (mVar == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else if (!this.E) {
            int i5 = 0;
            if (!mVar.e()) {
                i2 = 0;
            }
            if (!this.s.f()) {
                i3 = 0;
            }
            if (i2 != 0 || i3 != 0) {
                if (i4 == Integer.MIN_VALUE || i4 > 0) {
                    if (z2) {
                        if (i2 != 0) {
                            i5 = 1;
                        }
                        if (i3 != 0) {
                            i5 |= 2;
                        }
                        p0(i5, 1);
                    }
                    this.l0.b(i2, i3, i4, interpolator);
                    return;
                }
                scrollBy(i2, i3);
            }
        }
    }

    public void n() {
        if (!this.B || this.K) {
            int i2 = km.a;
            Trace.beginSection("RV FullInvalidate");
            q();
            Trace.endSection();
        } else if (this.j.g()) {
            xx xxVar = this.j;
            int i3 = xxVar.f;
            boolean z2 = false;
            if ((i3 & 4) != 0) {
                if (!((i3 & 11) != 0)) {
                    int i4 = km.a;
                    Trace.beginSection("RV PartialInvalidate");
                    o0();
                    V();
                    this.j.j();
                    if (!this.D) {
                        int e2 = this.k.e();
                        int i5 = 0;
                        while (true) {
                            if (i5 < e2) {
                                b0 K2 = K(this.k.d(i5));
                                if (K2 != null && !K2.shouldIgnore() && K2.isUpdated()) {
                                    z2 = true;
                                    break;
                                }
                                i5++;
                            } else {
                                break;
                            }
                        }
                        if (z2) {
                            q();
                        } else {
                            this.j.b();
                        }
                    }
                    q0(true);
                    W(true);
                    Trace.endSection();
                    return;
                }
            }
            if (xxVar.g()) {
                int i6 = km.a;
                Trace.beginSection("RV FullInvalidate");
                q();
                Trace.endSection();
            }
        }
    }

    public void n0(int i2) {
        if (!this.E) {
            m mVar = this.s;
            if (mVar == null) {
                Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            } else {
                mVar.W0(this, this.o0, i2);
            }
        }
    }

    public void o(int i2, int i3) {
        int paddingRight = getPaddingRight() + getPaddingLeft();
        AtomicInteger atomicInteger = co.a;
        setMeasuredDimension(m.h(i2, paddingRight, co.c.e(this)), m.h(i3, getPaddingBottom() + getPaddingTop(), co.c.d(this)));
    }

    public void o0() {
        int i2 = this.C + 1;
        this.C = i2;
        if (i2 == 1 && !this.E) {
            this.D = false;
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.M = 0;
        this.y = true;
        this.B = this.B && !isLayoutRequested();
        m mVar = this.s;
        if (mVar != null) {
            mVar.i = true;
            mVar.e0();
        }
        this.u0 = false;
        if (L0) {
            ThreadLocal<hy> threadLocal = hy.k;
            hy hyVar = threadLocal.get();
            this.m0 = hyVar;
            if (hyVar == null) {
                this.m0 = new hy();
                AtomicInteger atomicInteger = co.a;
                Display b2 = co.d.b(this);
                float f2 = 60.0f;
                if (!isInEditMode() && b2 != null) {
                    float refreshRate = b2.getRefreshRate();
                    if (refreshRate >= 30.0f) {
                        f2 = refreshRate;
                    }
                }
                hy hyVar2 = this.m0;
                hyVar2.i = (long) (1.0E9f / f2);
                threadLocal.set(hyVar2);
            }
            this.m0.g.add(this);
        }
    }

    public void onDetachedFromWindow() {
        hy hyVar;
        super.onDetachedFromWindow();
        j jVar = this.T;
        if (jVar != null) {
            jVar.endAnimations();
        }
        s0();
        this.y = false;
        m mVar = this.s;
        if (mVar != null) {
            t tVar = this.h;
            mVar.i = false;
            mVar.g0(this, tVar);
        }
        this.C0.clear();
        removeCallbacks(this.D0);
        Objects.requireNonNull(this.l);
        do {
        } while (yy.a.d.b() != null);
        if (L0 && (hyVar = this.m0) != null) {
            hyVar.g.remove(this);
            this.m0 = null;
        }
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int size = this.v.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.v.get(i2).e(canvas, this, this.o0);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:33:0x0078  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x0081  */
    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        float f2;
        float f3;
        m mVar;
        if (this.s != null && !this.E && motionEvent.getAction() == 8) {
            if ((motionEvent.getSource() & 2) != 0) {
                f3 = this.s.f() ? -motionEvent.getAxisValue(9) : Utils.FLOAT_EPSILON;
                if (this.s.e()) {
                    f2 = motionEvent.getAxisValue(10);
                    if (!(f3 == Utils.FLOAT_EPSILON && f2 == Utils.FLOAT_EPSILON)) {
                        int i2 = (int) (f2 * this.i0);
                        int i3 = (int) (f3 * this.j0);
                        mVar = this.s;
                        if (mVar == null) {
                            Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
                        } else if (!this.E) {
                            int[] iArr = this.B0;
                            iArr[0] = 0;
                            iArr[1] = 0;
                            boolean e2 = mVar.e();
                            boolean f4 = this.s.f();
                            p0(f4 ? e2 | 2 : e2, 1);
                            if (t(e2 ? i2 : 0, f4 ? i3 : 0, this.B0, this.z0, 1)) {
                                int[] iArr2 = this.B0;
                                i2 -= iArr2[0];
                                i3 -= iArr2[1];
                            }
                            i0(e2 ? i2 : 0, f4 ? i3 : 0, motionEvent, 1);
                            hy hyVar = this.m0;
                            if (!(hyVar == null || (i2 == 0 && i3 == 0))) {
                                hyVar.a(this, i2, i3);
                            }
                            getScrollingChildHelper().j(1);
                        }
                    }
                }
            } else {
                if ((motionEvent.getSource() & 4194304) != 0) {
                    float axisValue = motionEvent.getAxisValue(26);
                    if (this.s.f()) {
                        f3 = -axisValue;
                    } else if (this.s.e()) {
                        f2 = axisValue;
                        f3 = Utils.FLOAT_EPSILON;
                        int i22 = (int) (f2 * this.i0);
                        int i32 = (int) (f3 * this.j0);
                        mVar = this.s;
                        if (mVar == null) {
                        }
                    }
                }
                f3 = Utils.FLOAT_EPSILON;
            }
            f2 = Utils.FLOAT_EPSILON;
            int i222 = (int) (f2 * this.i0);
            int i322 = (int) (f3 * this.j0);
            mVar = this.s;
            if (mVar == null) {
            }
        }
        return false;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z2;
        if (this.E) {
            return false;
        }
        this.x = null;
        if (D(motionEvent)) {
            j();
            return true;
        }
        m mVar = this.s;
        if (mVar == null) {
            return false;
        }
        boolean e2 = mVar.e();
        boolean f2 = this.s.f();
        if (this.W == null) {
            this.W = VelocityTracker.obtain();
        }
        this.W.addMovement(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            if (this.F) {
                this.F = false;
            }
            this.V = motionEvent.getPointerId(0);
            int x2 = (int) (motionEvent.getX() + 0.5f);
            this.c0 = x2;
            this.a0 = x2;
            int y2 = (int) (motionEvent.getY() + 0.5f);
            this.d0 = y2;
            this.b0 = y2;
            if (this.U == 2) {
                getParent().requestDisallowInterceptTouchEvent(true);
                setScrollState(1);
                r0(1);
            }
            int[] iArr = this.A0;
            iArr[1] = 0;
            iArr[0] = 0;
            if (f2) {
                boolean z3 = e2 ? 1 : 0;
                char c2 = e2 ? 1 : 0;
                e2 = z3 | true;
            }
            int i2 = e2 ? 1 : 0;
            int i3 = e2 ? 1 : 0;
            int i4 = e2 ? 1 : 0;
            p0(i2, 0);
        } else if (actionMasked == 1) {
            this.W.clear();
            r0(0);
        } else if (actionMasked == 2) {
            int findPointerIndex = motionEvent.findPointerIndex(this.V);
            if (findPointerIndex < 0) {
                StringBuilder J02 = ze0.J0("Error processing scroll; pointer index for id ");
                J02.append(this.V);
                J02.append(" not found. Did any MotionEvents get skipped?");
                Log.e("RecyclerView", J02.toString());
                return false;
            }
            int x3 = (int) (motionEvent.getX(findPointerIndex) + 0.5f);
            int y3 = (int) (motionEvent.getY(findPointerIndex) + 0.5f);
            if (this.U != 1) {
                int i5 = x3 - this.a0;
                int i6 = y3 - this.b0;
                if (!e2 || Math.abs(i5) <= this.e0) {
                    z2 = false;
                } else {
                    this.c0 = x3;
                    z2 = true;
                }
                if (f2 && Math.abs(i6) > this.e0) {
                    this.d0 = y3;
                    z2 = true;
                }
                if (z2) {
                    setScrollState(1);
                }
            }
        } else if (actionMasked == 3) {
            j();
        } else if (actionMasked == 5) {
            this.V = motionEvent.getPointerId(actionIndex);
            int x4 = (int) (motionEvent.getX(actionIndex) + 0.5f);
            this.c0 = x4;
            this.a0 = x4;
            int y4 = (int) (motionEvent.getY(actionIndex) + 0.5f);
            this.d0 = y4;
            this.b0 = y4;
        } else if (actionMasked == 6) {
            X(motionEvent);
        }
        if (this.U == 1) {
            return true;
        }
        return false;
    }

    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int i6 = km.a;
        Trace.beginSection("RV OnLayout");
        q();
        Trace.endSection();
        this.B = true;
    }

    public void onMeasure(int i2, int i3) {
        m mVar = this.s;
        if (mVar == null) {
            o(i2, i3);
            return;
        }
        boolean z2 = false;
        if (mVar.V()) {
            int mode = View.MeasureSpec.getMode(i2);
            int mode2 = View.MeasureSpec.getMode(i3);
            this.s.w0(i2, i3);
            if (mode == 1073741824 && mode2 == 1073741824) {
                z2 = true;
            }
            this.E0 = z2;
            if (!z2 && this.r != null) {
                if (this.o0.d == 1) {
                    r();
                }
                this.s.P0(i2, i3);
                this.o0.i = true;
                s();
                this.s.R0(i2, i3);
                if (this.s.U0()) {
                    this.s.P0(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824));
                    this.o0.i = true;
                    s();
                    this.s.R0(i2, i3);
                }
                this.F0 = getMeasuredWidth();
                this.G0 = getMeasuredHeight();
            }
        } else if (this.z) {
            this.s.w0(i2, i3);
        } else {
            if (this.H) {
                o0();
                V();
                b0();
                W(true);
                y yVar = this.o0;
                if (yVar.k) {
                    yVar.g = true;
                } else {
                    this.j.c();
                    this.o0.g = false;
                }
                this.H = false;
                q0(false);
            } else if (this.o0.k) {
                setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
                return;
            }
            e eVar = this.r;
            if (eVar != null) {
                this.o0.e = eVar.getItemCount();
            } else {
                this.o0.e = 0;
            }
            o0();
            this.s.w0(i2, i3);
            q0(false);
            this.o0.g = false;
        }
    }

    public boolean onRequestFocusInDescendants(int i2, Rect rect) {
        if (P()) {
            return false;
        }
        return super.onRequestFocusInDescendants(i2, rect);
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof w)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        w wVar = (w) parcelable;
        this.i = wVar;
        super.onRestoreInstanceState(wVar.g);
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        w wVar = new w(super.onSaveInstanceState());
        w wVar2 = this.i;
        if (wVar2 != null) {
            wVar.i = wVar2.i;
        } else {
            m mVar = this.s;
            if (mVar != null) {
                wVar.i = mVar.A0();
            } else {
                wVar.i = null;
            }
        }
        return wVar;
    }

    public void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        if (i2 != i4 || i3 != i5) {
            O();
        }
    }

    /* JADX DEBUG: Failed to insert an additional move for type inference into block B:202:0x032f */
    /* JADX DEBUG: Failed to insert an additional move for type inference into block B:205:0x0334 */
    /* JADX WARNING: Code restructure failed: missing block: B:196:0x0321, code lost:
        if (r3 < r8) goto L_0x0324;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:219:0x03a4, code lost:
        if (r8 != false) goto L_0x03aa;
     */
    /* JADX WARNING: Removed duplicated region for block: B:200:0x0327  */
    /* JADX WARNING: Removed duplicated region for block: B:201:0x0329  */
    /* JADX WARNING: Removed duplicated region for block: B:203:0x0331  */
    /* JADX WARNING: Removed duplicated region for block: B:206:0x0336  */
    /* JADX WARNING: Removed duplicated region for block: B:228:0x03d8  */
    /* JADX WARNING: Removed duplicated region for block: B:229:0x03e0  */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x00fa  */
    /* JADX WARNING: Removed duplicated region for block: B:60:0x0110  */
    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z2;
        MotionEvent motionEvent2;
        RecyclerView recyclerView;
        boolean z3;
        MotionEvent motionEvent3;
        boolean z4;
        boolean z5;
        boolean z6;
        int minFlingVelocity;
        boolean z7;
        int i2;
        boolean z8;
        py pyVar;
        PointF a2;
        boolean z9;
        boolean z10;
        boolean z11 = false;
        if (this.E || this.F) {
            return false;
        }
        q qVar = this.x;
        qy qyVar = null;
        if (qVar != null) {
            qVar.b(this, motionEvent);
            int action = motionEvent.getAction();
            if (action == 3 || action == 1) {
                this.x = null;
            }
            z2 = true;
        } else if (motionEvent.getAction() == 0) {
            z2 = false;
        } else {
            z2 = D(motionEvent);
        }
        if (z2) {
            j();
            return true;
        }
        m mVar = this.s;
        if (mVar == null) {
            return false;
        }
        boolean e2 = mVar.e();
        boolean f2 = this.s.f();
        if (this.W == null) {
            this.W = VelocityTracker.obtain();
        }
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            int[] iArr = this.A0;
            iArr[1] = 0;
            iArr[0] = 0;
        }
        MotionEvent obtain = MotionEvent.obtain(motionEvent);
        int[] iArr2 = this.A0;
        obtain.offsetLocation((float) iArr2[0], (float) iArr2[1]);
        if (actionMasked == 0) {
            recyclerView = this;
            motionEvent2 = obtain;
            recyclerView.V = motionEvent.getPointerId(0);
            int x2 = (int) (motionEvent.getX() + 0.5f);
            recyclerView.c0 = x2;
            recyclerView.a0 = x2;
            int y2 = (int) (motionEvent.getY() + 0.5f);
            recyclerView.d0 = y2;
            recyclerView.b0 = y2;
            if (f2) {
                boolean z12 = e2 ? 1 : 0;
                boolean z13 = e2 ? 1 : 0;
                e2 = z12 | true;
            }
            int i3 = e2 ? 1 : 0;
            int i4 = e2 ? 1 : 0;
            int i5 = e2 ? 1 : 0;
            recyclerView.p0(i3, 0);
        } else if (actionMasked != 1) {
            if (actionMasked == 2) {
                int findPointerIndex = motionEvent.findPointerIndex(this.V);
                if (findPointerIndex < 0) {
                    StringBuilder J02 = ze0.J0("Error processing scroll; pointer index for id ");
                    J02.append(this.V);
                    J02.append(" not found. Did any MotionEvents get skipped?");
                    Log.e("RecyclerView", J02.toString());
                    return false;
                }
                int x3 = (int) (motionEvent.getX(findPointerIndex) + 0.5f);
                int y3 = (int) (motionEvent.getY(findPointerIndex) + 0.5f);
                int i6 = this.c0 - x3;
                int i7 = this.d0 - y3;
                if (this.U != 1) {
                    if (e2) {
                        if (i6 > 0) {
                            i6 = Math.max(0, i6 - this.e0);
                        } else {
                            i6 = Math.min(0, i6 + this.e0);
                        }
                        if (i6 != 0) {
                            z10 = true;
                            if (f2) {
                                if (i7 > 0) {
                                    i7 = Math.max(0, i7 - this.e0);
                                } else {
                                    i7 = Math.min(0, i7 + this.e0);
                                }
                                if (i7 != 0) {
                                    z10 = true;
                                }
                            }
                            if (z10) {
                                setScrollState(1);
                            }
                        }
                    }
                    z10 = false;
                    if (f2) {
                    }
                    if (z10) {
                    }
                }
                int i8 = i6;
                int i9 = i7;
                if (this.U == 1) {
                    int[] iArr3 = this.B0;
                    iArr3[0] = 0;
                    iArr3[1] = 0;
                    if (t(e2 ? i8 : 0, f2 ? i9 : 0, iArr3, this.z0, 0)) {
                        int[] iArr4 = this.B0;
                        i8 -= iArr4[0];
                        i9 -= iArr4[1];
                        int[] iArr5 = this.A0;
                        int i10 = iArr5[0];
                        int[] iArr6 = this.z0;
                        iArr5[0] = i10 + iArr6[0];
                        iArr5[1] = iArr5[1] + iArr6[1];
                        getParent().requestDisallowInterceptTouchEvent(true);
                    }
                    int[] iArr7 = this.z0;
                    this.c0 = x3 - iArr7[0];
                    this.d0 = y3 - iArr7[1];
                    if (i0(e2 ? i8 : 0, f2 ? i9 : 0, motionEvent, 0)) {
                        getParent().requestDisallowInterceptTouchEvent(true);
                    }
                    hy hyVar = this.m0;
                    if (!(hyVar == null || (i8 == 0 && i9 == 0))) {
                        hyVar.a(this, i8, i9);
                    }
                }
            } else if (actionMasked == 3) {
                j();
            } else if (actionMasked == 5) {
                this.V = motionEvent.getPointerId(actionIndex);
                int x4 = (int) (motionEvent.getX(actionIndex) + 0.5f);
                this.c0 = x4;
                this.a0 = x4;
                int y4 = (int) (motionEvent.getY(actionIndex) + 0.5f);
                this.d0 = y4;
                this.b0 = y4;
            } else if (actionMasked == 6) {
                X(motionEvent);
            }
            recyclerView = this;
            motionEvent2 = obtain;
        } else {
            this.W.addMovement(obtain);
            this.W.computeCurrentVelocity(vf0.DEFAULT_IMAGE_TIMEOUT_MS, (float) this.h0);
            float f3 = e2 ? -this.W.getXVelocity(this.V) : Utils.FLOAT_EPSILON;
            float f4 = f2 ? -this.W.getYVelocity(this.V) : Utils.FLOAT_EPSILON;
            if (f3 == Utils.FLOAT_EPSILON && f4 == Utils.FLOAT_EPSILON) {
                recyclerView = this;
                motionEvent2 = obtain;
            } else {
                int i11 = (int) f3;
                int i12 = (int) f4;
                m mVar2 = this.s;
                if (mVar2 == null) {
                    Log.e("RecyclerView", "Cannot fling without a LayoutManager set. Call setLayoutManager with a non-null argument.");
                } else if (!this.E) {
                    boolean e3 = mVar2.e();
                    boolean f5 = this.s.f();
                    if (!e3 || Math.abs(i11) < this.g0) {
                        i11 = 0;
                    }
                    if (!f5 || Math.abs(i12) < this.g0) {
                        i12 = 0;
                    }
                    if (!(i11 == 0 && i12 == 0)) {
                        float f6 = (float) i11;
                        float f7 = (float) i12;
                        if (!dispatchNestedPreFling(f6, f7)) {
                            boolean z14 = e3 || f5;
                            dispatchNestedFling(f6, f7, z14);
                            p pVar = this.f0;
                            if (pVar != null) {
                                wy wyVar = (wy) pVar;
                                m layoutManager = wyVar.a.getLayoutManager();
                                if (layoutManager == null || wyVar.a.getAdapter() == null || (Math.abs(i12) <= (minFlingVelocity = wyVar.a.getMinFlingVelocity()) && Math.abs(i11) <= minFlingVelocity)) {
                                    z4 = e3;
                                    z5 = f5;
                                    motionEvent2 = obtain;
                                } else {
                                    boolean z15 = layoutManager instanceof x.b;
                                    if (z15) {
                                        ry ryVar = (ry) wyVar;
                                        if (z15) {
                                            qyVar = new qy(ryVar, ryVar.a.getContext());
                                        }
                                        if (qyVar != null) {
                                            int I2 = layoutManager.I();
                                            if (I2 != 0) {
                                                if (layoutManager.f()) {
                                                    pyVar = ryVar.h(layoutManager);
                                                } else {
                                                    pyVar = layoutManager.e() ? ryVar.g(layoutManager) : null;
                                                }
                                                if (pyVar != null) {
                                                    int y5 = layoutManager.y();
                                                    View view = null;
                                                    int i13 = Integer.MIN_VALUE;
                                                    z8 = e3;
                                                    motionEvent2 = obtain;
                                                    View view2 = null;
                                                    int i14 = 0;
                                                    int i15 = Integer.MAX_VALUE;
                                                    while (i14 < y5) {
                                                        View x5 = layoutManager.x(i14);
                                                        if (x5 == null) {
                                                            z9 = f5;
                                                        } else {
                                                            z9 = f5;
                                                            int e4 = ryVar.e(x5, pyVar);
                                                            if (e4 <= 0 && e4 > i13) {
                                                                i13 = e4;
                                                                view2 = x5;
                                                            }
                                                            if (e4 >= 0 && e4 < i15) {
                                                                i15 = e4;
                                                                view = x5;
                                                            }
                                                        }
                                                        i14++;
                                                        y5 = y5;
                                                        f5 = z9;
                                                    }
                                                    z5 = f5;
                                                    boolean z16 = !layoutManager.e() ? i12 > 0 : i11 > 0;
                                                    if (z16 && view != null) {
                                                        i2 = layoutManager.Q(view);
                                                        z7 = z8;
                                                        if (i2 != -1) {
                                                        }
                                                        if (z11) {
                                                        }
                                                    } else if (z16 || view2 == null) {
                                                        if (z16) {
                                                            view = view2;
                                                        }
                                                        if (view != null) {
                                                            i2 = ((z15 && (a2 = ((x.b) layoutManager).a(layoutManager.I() + -1)) != null && ((a2.x > Utils.FLOAT_EPSILON ? 1 : (a2.x == Utils.FLOAT_EPSILON ? 0 : -1)) < 0 || (a2.y > Utils.FLOAT_EPSILON ? 1 : (a2.y == Utils.FLOAT_EPSILON ? 0 : -1)) < 0)) == z16 ? -1 : 1) + layoutManager.Q(view);
                                                            z7 = z8;
                                                            if (i2 >= 0) {
                                                            }
                                                        }
                                                        i2 = -1;
                                                        z7 = z8;
                                                        if (i2 != -1) {
                                                            z11 = false;
                                                            z4 = z7;
                                                        } else {
                                                            qyVar.a = i2;
                                                            layoutManager.X0(qyVar);
                                                            z11 = true;
                                                            z4 = z7;
                                                        }
                                                        if (z11) {
                                                            z6 = true;
                                                            if (z6) {
                                                                z11 = true;
                                                                recyclerView = this;
                                                            }
                                                        }
                                                    } else {
                                                        i2 = layoutManager.Q(view2);
                                                        z7 = z8;
                                                        if (i2 != -1) {
                                                        }
                                                        if (z11) {
                                                        }
                                                    }
                                                }
                                            }
                                            z8 = e3;
                                            z5 = f5;
                                            motionEvent2 = obtain;
                                            i2 = -1;
                                            z7 = z8;
                                            if (i2 != -1) {
                                            }
                                            if (z11) {
                                            }
                                        }
                                    }
                                    z4 = e3;
                                    z5 = f5;
                                    motionEvent2 = obtain;
                                    if (z11) {
                                    }
                                }
                                z6 = false;
                                if (z6) {
                                }
                            } else {
                                z4 = e3;
                                z5 = f5;
                                motionEvent2 = obtain;
                            }
                            if (z14) {
                                recyclerView = this;
                                recyclerView.p0(z5 ? z4 | 2 : z4, 1);
                                int i16 = recyclerView.h0;
                                int max = Math.max(-i16, Math.min(i11, i16));
                                int i17 = recyclerView.h0;
                                int max2 = Math.max(-i17, Math.min(i12, i17));
                                a0 a0Var = recyclerView.l0;
                                RecyclerView.this.setScrollState(2);
                                a0Var.h = 0;
                                a0Var.g = 0;
                                Interpolator interpolator = a0Var.j;
                                Interpolator interpolator2 = N0;
                                if (interpolator != interpolator2) {
                                    a0Var.j = interpolator2;
                                    a0Var.i = new OverScroller(RecyclerView.this.getContext(), interpolator2);
                                }
                                a0Var.i.fling(0, 0, max, max2, Integer.MIN_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MAX_VALUE);
                                a0Var.a();
                                z11 = true;
                            } else {
                                recyclerView = this;
                            }
                        } else {
                            recyclerView = this;
                            motionEvent2 = obtain;
                        }
                        z11 = false;
                    }
                }
                recyclerView = this;
                motionEvent2 = obtain;
            }
            recyclerView.setScrollState(0);
            h0();
            z3 = true;
            if (z3) {
                motionEvent3 = motionEvent2;
                recyclerView.W.addMovement(motionEvent3);
            } else {
                motionEvent3 = motionEvent2;
            }
            motionEvent3.recycle();
            return true;
        }
        z3 = false;
        if (z3) {
        }
        motionEvent3.recycle();
        return true;
    }

    public void p(View view) {
        b0 K2 = K(view);
        U();
        e eVar = this.r;
        if (!(eVar == null || K2 == null)) {
            eVar.onViewDetachedFromWindow(K2);
        }
        List<o> list = this.J;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.J.get(size).b(view);
            }
        }
    }

    public boolean p0(int i2, int i3) {
        return getScrollingChildHelper().i(i2, i3);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:140:0x033b, code lost:
        if (r17.k.k(getFocusedChild()) == false) goto L_0x040f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:184:0x03d8, code lost:
        r1 = java.lang.Math.min(r1, r3) - 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:185:0x03dd, code lost:
        if (r1 < 0) goto L_0x03f4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:186:0x03df, code lost:
        r2 = G(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:187:0x03e3, code lost:
        if (r2 != null) goto L_0x03e6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:189:0x03ec, code lost:
        if (r2.itemView.hasFocusable() == false) goto L_0x03f1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:190:0x03ee, code lost:
        r1 = r2.itemView;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:191:0x03f1, code lost:
        r1 = r1 - 1;
     */
    public void q() {
        b0 b0Var;
        View findViewById;
        View view;
        b0 b0Var2;
        if (this.r == null) {
            Log.w("RecyclerView", "No adapter attached; skipping layout");
        } else if (this.s == null) {
            Log.e("RecyclerView", "No layout manager attached; skipping layout");
        } else {
            int i2 = 0;
            this.o0.i = false;
            boolean z2 = true;
            boolean z3 = this.E0 && !(this.F0 == getWidth() && this.G0 == getHeight());
            this.F0 = 0;
            this.G0 = 0;
            this.E0 = false;
            if (this.o0.d == 1) {
                r();
                this.s.O0(this);
                s();
            } else {
                xx xxVar = this.j;
                if ((!xxVar.c.isEmpty() && !xxVar.b.isEmpty()) || z3 || this.s.p != getWidth() || this.s.q != getHeight()) {
                    this.s.O0(this);
                    s();
                } else {
                    this.s.O0(this);
                }
            }
            int i3 = 4;
            this.o0.a(4);
            o0();
            V();
            y yVar = this.o0;
            yVar.d = 1;
            View view2 = null;
            if (yVar.j) {
                int e2 = this.k.e() - 1;
                while (e2 >= 0) {
                    b0 K2 = K(this.k.d(e2));
                    if (!K2.shouldIgnore()) {
                        long I2 = I(K2);
                        j.c recordPostLayoutInformation = this.T.recordPostLayoutInformation(this.o0, K2);
                        b0 h2 = this.l.b.h(I2, null);
                        if (h2 == null || h2.shouldIgnore()) {
                            this.l.b(K2, recordPostLayoutInformation);
                        } else {
                            boolean d2 = this.l.d(h2);
                            boolean d3 = this.l.d(K2);
                            if (!d2 || h2 != K2) {
                                j.c e3 = this.l.e(h2, i3);
                                this.l.b(K2, recordPostLayoutInformation);
                                j.c e4 = this.l.e(K2, 8);
                                if (e3 == null) {
                                    int e5 = this.k.e();
                                    for (int i4 = 0; i4 < e5; i4++) {
                                        b0 K3 = K(this.k.d(i4));
                                        if (K3 != K2 && I(K3) == I2) {
                                            e eVar = this.r;
                                            if (eVar == null || !eVar.hasStableIds()) {
                                                StringBuilder sb = new StringBuilder();
                                                sb.append("Two different ViewHolders have the same change ID. This might happen due to inconsistent Adapter update events or if the LayoutManager lays out the same View multiple times.\n ViewHolder 1:");
                                                sb.append(K3);
                                                sb.append(" \n View Holder 2:");
                                                sb.append(K2);
                                                throw new IllegalStateException(ze0.e0(this, sb));
                                            }
                                            StringBuilder sb2 = new StringBuilder();
                                            sb2.append("Two different ViewHolders have the same stable ID. Stable IDs in your adapter MUST BE unique and SHOULD NOT change.\n ViewHolder 1:");
                                            sb2.append(K3);
                                            sb2.append(" \n View Holder 2:");
                                            sb2.append(K2);
                                            throw new IllegalStateException(ze0.e0(this, sb2));
                                        }
                                    }
                                    Log.e("RecyclerView", "Problem while matching changed view holders with the newones. The pre-layout information for the change holder " + h2 + " cannot be found but it is necessary for " + K2 + A());
                                } else {
                                    h2.setIsRecyclable(false);
                                    if (d2) {
                                        f(h2);
                                    }
                                    if (h2 != K2) {
                                        if (d3) {
                                            f(K2);
                                        }
                                        h2.mShadowedHolder = K2;
                                        f(h2);
                                        this.h.k(h2);
                                        K2.setIsRecyclable(false);
                                        K2.mShadowingHolder = h2;
                                    }
                                    if (this.T.animateChange(h2, K2, e3, e4)) {
                                        a0();
                                    }
                                }
                            } else {
                                this.l.b(K2, recordPostLayoutInformation);
                            }
                        }
                    }
                    e2--;
                    i3 = 4;
                }
                yy yyVar = this.l;
                yy.b bVar = this.H0;
                for (int i5 = yyVar.a.i - 1; i5 >= 0; i5--) {
                    b0 h3 = yyVar.a.h(i5);
                    yy.a j2 = yyVar.a.j(i5);
                    int i6 = j2.a;
                    if ((i6 & 3) == 3) {
                        RecyclerView recyclerView = RecyclerView.this;
                        recyclerView.s.G0(h3.itemView, recyclerView.h);
                    } else if ((i6 & 1) != 0) {
                        j.c cVar = j2.b;
                        if (cVar == null) {
                            RecyclerView recyclerView2 = RecyclerView.this;
                            recyclerView2.s.G0(h3.itemView, recyclerView2.h);
                        } else {
                            ((d) bVar).a(h3, cVar, j2.c);
                        }
                    } else if ((i6 & 14) == 14) {
                        j.c cVar2 = j2.b;
                        j.c cVar3 = j2.c;
                        RecyclerView recyclerView3 = RecyclerView.this;
                        Objects.requireNonNull(recyclerView3);
                        h3.setIsRecyclable(false);
                        if (recyclerView3.T.animateAppearance(h3, cVar2, cVar3)) {
                            recyclerView3.a0();
                        }
                    } else if ((i6 & 12) == 12) {
                        j.c cVar4 = j2.b;
                        j.c cVar5 = j2.c;
                        d dVar = (d) bVar;
                        Objects.requireNonNull(dVar);
                        h3.setIsRecyclable(false);
                        RecyclerView recyclerView4 = RecyclerView.this;
                        if (recyclerView4.K) {
                            if (recyclerView4.T.animateChange(h3, h3, cVar4, cVar5)) {
                                RecyclerView.this.a0();
                            }
                        } else if (recyclerView4.T.animatePersistence(h3, cVar4, cVar5)) {
                            RecyclerView.this.a0();
                        }
                    } else if ((i6 & 4) != 0) {
                        ((d) bVar).a(h3, j2.b, null);
                    } else if ((i6 & 8) != 0) {
                        j.c cVar6 = j2.b;
                        j.c cVar7 = j2.c;
                        RecyclerView recyclerView5 = RecyclerView.this;
                        Objects.requireNonNull(recyclerView5);
                        h3.setIsRecyclable(false);
                        if (recyclerView5.T.animateAppearance(h3, cVar6, cVar7)) {
                            recyclerView5.a0();
                        }
                    }
                    yy.a.b(j2);
                }
            }
            this.s.F0(this.h);
            y yVar2 = this.o0;
            yVar2.b = yVar2.e;
            this.K = false;
            this.L = false;
            yVar2.j = false;
            yVar2.k = false;
            this.s.h = false;
            ArrayList<b0> arrayList = this.h.b;
            if (arrayList != null) {
                arrayList.clear();
            }
            m mVar = this.s;
            if (mVar.m) {
                mVar.l = 0;
                mVar.m = false;
                this.h.l();
            }
            this.s.v0(this.o0);
            W(true);
            q0(false);
            yy yyVar2 = this.l;
            yyVar2.a.clear();
            yyVar2.b.c();
            int[] iArr = this.x0;
            int i7 = iArr[0];
            int i8 = iArr[1];
            E(iArr);
            int[] iArr2 = this.x0;
            if (iArr2[0] == i7 && iArr2[1] == i8) {
                z2 = false;
            }
            if (z2) {
                v(0, 0);
            }
            if (this.k0 && this.r != null && hasFocus() && getDescendantFocusability() != 393216 && (getDescendantFocusability() != 131072 || !isFocused())) {
                if (!isFocused()) {
                }
                if (this.o0.m == -1 || !this.r.hasStableIds()) {
                    b0Var = null;
                } else {
                    long j3 = this.o0.m;
                    e eVar2 = this.r;
                    if (eVar2 == null || !eVar2.hasStableIds()) {
                        b0Var2 = null;
                    } else {
                        int h4 = this.k.h();
                        int i9 = 0;
                        b0Var2 = null;
                        while (true) {
                            if (i9 >= h4) {
                                break;
                            }
                            b0Var = K(this.k.g(i9));
                            if (b0Var != null && !b0Var.isRemoved() && b0Var.getItemId() == j3) {
                                if (!this.k.k(b0Var.itemView)) {
                                    break;
                                }
                                b0Var2 = b0Var;
                            }
                            i9++;
                        }
                    }
                    b0Var = b0Var2;
                }
                if (b0Var != null && !this.k.k(b0Var.itemView) && b0Var.itemView.hasFocusable()) {
                    view2 = b0Var.itemView;
                } else if (this.k.e() > 0) {
                    y yVar3 = this.o0;
                    int i10 = yVar3.l;
                    if (i10 != -1) {
                        i2 = i10;
                    }
                    int b2 = yVar3.b();
                    int i11 = i2;
                    while (true) {
                        if (i11 >= b2) {
                            break;
                        }
                        b0 G2 = G(i11);
                        if (G2 == null) {
                            break;
                        } else if (G2.itemView.hasFocusable()) {
                            view = G2.itemView;
                            break;
                        } else {
                            i11++;
                        }
                    }
                    view2 = view;
                }
                if (view2 != null) {
                    int i12 = this.o0.n;
                    if (!(((long) i12) == -1 || (findViewById = view2.findViewById(i12)) == null || !findViewById.isFocusable())) {
                        view2 = findViewById;
                    }
                    view2.requestFocus();
                }
            }
            y yVar4 = this.o0;
            yVar4.m = -1;
            yVar4.l = -1;
            yVar4.n = -1;
        }
    }

    public void q0(boolean z2) {
        if (this.C < 1) {
            this.C = 1;
        }
        if (!z2 && !this.E) {
            this.D = false;
        }
        if (this.C == 1) {
            if (z2 && this.D && !this.E && this.s != null && this.r != null) {
                q();
            }
            if (!this.E) {
                this.D = false;
            }
        }
        this.C--;
    }

    public final void r() {
        int i2;
        View C2;
        this.o0.a(1);
        B(this.o0);
        this.o0.i = false;
        o0();
        yy yyVar = this.l;
        yyVar.a.clear();
        yyVar.b.c();
        V();
        b0();
        View focusedChild = (!this.k0 || !hasFocus() || this.r == null) ? null : getFocusedChild();
        b0 J2 = (focusedChild == null || (C2 = C(focusedChild)) == null) ? null : J(C2);
        long j2 = -1;
        if (J2 == null) {
            y yVar = this.o0;
            yVar.m = -1;
            yVar.l = -1;
            yVar.n = -1;
        } else {
            y yVar2 = this.o0;
            if (this.r.hasStableIds()) {
                j2 = J2.getItemId();
            }
            yVar2.m = j2;
            y yVar3 = this.o0;
            if (this.K) {
                i2 = -1;
            } else if (J2.isRemoved()) {
                i2 = J2.mOldPosition;
            } else {
                i2 = J2.getAbsoluteAdapterPosition();
            }
            yVar3.l = i2;
            y yVar4 = this.o0;
            View view = J2.itemView;
            int id = view.getId();
            while (!view.isFocused() && (view instanceof ViewGroup) && view.hasFocus()) {
                view = ((ViewGroup) view).getFocusedChild();
                if (view.getId() != -1) {
                    id = view.getId();
                }
            }
            yVar4.n = id;
        }
        y yVar5 = this.o0;
        yVar5.h = yVar5.j && this.s0;
        this.s0 = false;
        this.r0 = false;
        yVar5.g = yVar5.k;
        yVar5.e = this.r.getItemCount();
        E(this.x0);
        if (this.o0.j) {
            int e2 = this.k.e();
            for (int i3 = 0; i3 < e2; i3++) {
                b0 K2 = K(this.k.d(i3));
                if (!K2.shouldIgnore() && (!K2.isInvalid() || this.r.hasStableIds())) {
                    this.l.c(K2, this.T.recordPreLayoutInformation(this.o0, K2, j.buildAdapterChangeFlagsForAnimations(K2), K2.getUnmodifiedPayloads()));
                    if (this.o0.h && K2.isUpdated() && !K2.isRemoved() && !K2.shouldIgnore() && !K2.isInvalid()) {
                        this.l.b.k(I(K2), K2);
                    }
                }
            }
        }
        if (this.o0.k) {
            int h2 = this.k.h();
            for (int i4 = 0; i4 < h2; i4++) {
                b0 K3 = K(this.k.g(i4));
                if (!K3.shouldIgnore()) {
                    K3.saveOldPosition();
                }
            }
            y yVar6 = this.o0;
            boolean z2 = yVar6.f;
            yVar6.f = false;
            this.s.u0(this.h, yVar6);
            this.o0.f = z2;
            for (int i5 = 0; i5 < this.k.e(); i5++) {
                b0 K4 = K(this.k.d(i5));
                if (!K4.shouldIgnore()) {
                    yy.a orDefault = this.l.a.getOrDefault(K4, null);
                    if (!((orDefault == null || (orDefault.a & 4) == 0) ? false : true)) {
                        int buildAdapterChangeFlagsForAnimations = j.buildAdapterChangeFlagsForAnimations(K4);
                        boolean hasAnyOfTheFlags = K4.hasAnyOfTheFlags(b0.FLAG_BOUNCED_FROM_HIDDEN_LIST);
                        if (!hasAnyOfTheFlags) {
                            buildAdapterChangeFlagsForAnimations |= 4096;
                        }
                        j.c recordPreLayoutInformation = this.T.recordPreLayoutInformation(this.o0, K4, buildAdapterChangeFlagsForAnimations, K4.getUnmodifiedPayloads());
                        if (hasAnyOfTheFlags) {
                            d0(K4, recordPreLayoutInformation);
                        } else {
                            yy yyVar2 = this.l;
                            yy.a orDefault2 = yyVar2.a.getOrDefault(K4, null);
                            if (orDefault2 == null) {
                                orDefault2 = yy.a.a();
                                yyVar2.a.put(K4, orDefault2);
                            }
                            orDefault2.a |= 2;
                            orDefault2.b = recordPreLayoutInformation;
                        }
                    }
                }
            }
            l();
        } else {
            l();
        }
        W(true);
        q0(false);
        this.o0.d = 2;
    }

    public void r0(int i2) {
        getScrollingChildHelper().j(i2);
    }

    public void removeDetachedView(View view, boolean z2) {
        b0 K2 = K(view);
        if (K2 != null) {
            if (K2.isTmpDetached()) {
                K2.clearTmpDetachFlag();
            } else if (!K2.shouldIgnore()) {
                StringBuilder sb = new StringBuilder();
                sb.append("Called removeDetachedView with a view which is not flagged as tmp detached.");
                sb.append(K2);
                throw new IllegalArgumentException(ze0.e0(this, sb));
            }
        }
        view.clearAnimation();
        p(view);
        super.removeDetachedView(view, z2);
    }

    public void requestChildFocus(View view, View view2) {
        if (!this.s.y0(this, view, view2) && view2 != null) {
            g0(view, view2);
        }
        super.requestChildFocus(view, view2);
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z2) {
        return this.s.J0(this, view, rect, z2, false);
    }

    public void requestDisallowInterceptTouchEvent(boolean z2) {
        int size = this.w.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.w.get(i2).c(z2);
        }
        super.requestDisallowInterceptTouchEvent(z2);
    }

    public void requestLayout() {
        if (this.C != 0 || this.E) {
            this.D = true;
        } else {
            super.requestLayout();
        }
    }

    public final void s() {
        o0();
        V();
        this.o0.a(6);
        this.j.c();
        this.o0.e = this.r.getItemCount();
        this.o0.c = 0;
        if (this.i != null && this.r.canRestoreState()) {
            Parcelable parcelable = this.i.i;
            if (parcelable != null) {
                this.s.z0(parcelable);
            }
            this.i = null;
        }
        y yVar = this.o0;
        yVar.g = false;
        this.s.u0(this.h, yVar);
        y yVar2 = this.o0;
        yVar2.f = false;
        yVar2.j = yVar2.j && this.T != null;
        yVar2.d = 4;
        W(true);
        q0(false);
    }

    public void s0() {
        x xVar;
        setScrollState(0);
        this.l0.c();
        m mVar = this.s;
        if (mVar != null && (xVar = mVar.g) != null) {
            xVar.f();
        }
    }

    public void scrollBy(int i2, int i3) {
        m mVar = this.s;
        if (mVar == null) {
            Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else if (!this.E) {
            boolean e2 = mVar.e();
            boolean f2 = this.s.f();
            if (e2 || f2) {
                if (!e2) {
                    i2 = 0;
                }
                if (!f2) {
                    i3 = 0;
                }
                i0(i2, i3, null, 0);
            }
        }
    }

    public void scrollTo(int i2, int i3) {
        Log.w("RecyclerView", "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead");
    }

    public void sendAccessibilityEventUnchecked(AccessibilityEvent accessibilityEvent) {
        int i2 = 0;
        if (P()) {
            int contentChangeTypes = accessibilityEvent != null ? accessibilityEvent.getContentChangeTypes() : 0;
            if (contentChangeTypes != 0) {
                i2 = contentChangeTypes;
            }
            this.G |= i2;
            i2 = 1;
        }
        if (i2 == 0) {
            super.sendAccessibilityEventUnchecked(accessibilityEvent);
        }
    }

    public void setAccessibilityDelegateCompat(uy uyVar) {
        this.v0 = uyVar;
        co.u(this, uyVar);
    }

    public void setAdapter(e eVar) {
        setLayoutFrozen(false);
        e eVar2 = this.r;
        if (eVar2 != null) {
            eVar2.unregisterAdapterDataObserver(this.g);
            this.r.onDetachedFromRecyclerView(this);
        }
        e0();
        xx xxVar = this.j;
        xxVar.l(xxVar.b);
        xxVar.l(xxVar.c);
        xxVar.f = 0;
        e eVar3 = this.r;
        this.r = eVar;
        if (eVar != null) {
            eVar.registerAdapterDataObserver(this.g);
            eVar.onAttachedToRecyclerView(this);
        }
        m mVar = this.s;
        if (mVar != null) {
            mVar.c0(eVar3, this.r);
        }
        t tVar = this.h;
        e eVar4 = this.r;
        tVar.b();
        s d2 = tVar.d();
        Objects.requireNonNull(d2);
        if (eVar3 != null) {
            d2.b--;
        }
        if (d2.b == 0) {
            for (int i2 = 0; i2 < d2.a.size(); i2++) {
                d2.a.valueAt(i2).a.clear();
            }
        }
        if (eVar4 != null) {
            d2.b++;
        }
        this.o0.f = true;
        c0(false);
        requestLayout();
    }

    public void setChildDrawingOrderCallback(h hVar) {
        if (hVar != this.w0) {
            this.w0 = hVar;
            setChildrenDrawingOrderEnabled(hVar != null);
        }
    }

    public void setClipToPadding(boolean z2) {
        if (z2 != this.m) {
            O();
        }
        this.m = z2;
        super.setClipToPadding(z2);
        if (this.B) {
            requestLayout();
        }
    }

    public void setEdgeEffectFactory(i iVar) {
        Objects.requireNonNull(iVar);
        this.O = iVar;
        O();
    }

    public void setHasFixedSize(boolean z2) {
        this.z = z2;
    }

    public void setItemAnimator(j jVar) {
        j jVar2 = this.T;
        if (jVar2 != null) {
            jVar2.endAnimations();
            this.T.setListener(null);
        }
        this.T = jVar;
        if (jVar != null) {
            jVar.setListener(this.t0);
        }
    }

    public void setItemViewCacheSize(int i2) {
        t tVar = this.h;
        tVar.e = i2;
        tVar.l();
    }

    @Deprecated
    public void setLayoutFrozen(boolean z2) {
        suppressLayout(z2);
    }

    public void setLayoutManager(m mVar) {
        if (mVar != this.s) {
            s0();
            if (this.s != null) {
                j jVar = this.T;
                if (jVar != null) {
                    jVar.endAnimations();
                }
                this.s.E0(this.h);
                this.s.F0(this.h);
                this.h.b();
                if (this.y) {
                    m mVar2 = this.s;
                    t tVar = this.h;
                    mVar2.i = false;
                    mVar2.g0(this, tVar);
                }
                this.s.S0(null);
                this.s = null;
            } else {
                this.h.b();
            }
            cy cyVar = this.k;
            cy.a aVar = cyVar.b;
            aVar.a = 0;
            cy.a aVar2 = aVar.b;
            if (aVar2 != null) {
                aVar2.g();
            }
            int size = cyVar.c.size();
            while (true) {
                size--;
                if (size < 0) {
                    break;
                }
                sy syVar = (sy) cyVar.a;
                Objects.requireNonNull(syVar);
                b0 K2 = K(cyVar.c.get(size));
                if (K2 != null) {
                    K2.onLeftHiddenState(syVar.a);
                }
                cyVar.c.remove(size);
            }
            sy syVar2 = (sy) cyVar.a;
            int b2 = syVar2.b();
            for (int i2 = 0; i2 < b2; i2++) {
                View a2 = syVar2.a(i2);
                syVar2.a.p(a2);
                a2.clearAnimation();
            }
            syVar2.a.removeAllViews();
            this.s = mVar;
            if (mVar != null) {
                if (mVar.b == null) {
                    mVar.S0(this);
                    if (this.y) {
                        m mVar3 = this.s;
                        mVar3.i = true;
                        mVar3.e0();
                    }
                } else {
                    StringBuilder sb = new StringBuilder();
                    sb.append("LayoutManager ");
                    sb.append(mVar);
                    sb.append(" is already attached to a RecyclerView:");
                    throw new IllegalArgumentException(ze0.e0(mVar.b, sb));
                }
            }
            this.h.l();
            requestLayout();
        }
    }

    @Deprecated
    public void setLayoutTransition(LayoutTransition layoutTransition) {
        if (layoutTransition == null) {
            super.setLayoutTransition(null);
            return;
        }
        throw new IllegalArgumentException("Providing a LayoutTransition into RecyclerView is not supported. Please use setItemAnimator() instead for animating changes to the items in this RecyclerView");
    }

    public void setNestedScrollingEnabled(boolean z2) {
        rn scrollingChildHelper = getScrollingChildHelper();
        if (scrollingChildHelper.d) {
            View view = scrollingChildHelper.c;
            AtomicInteger atomicInteger = co.a;
            co.h.z(view);
        }
        scrollingChildHelper.d = z2;
    }

    public void setOnFlingListener(p pVar) {
        this.f0 = pVar;
    }

    @Deprecated
    public void setOnScrollListener(r rVar) {
        this.p0 = rVar;
    }

    public void setPreserveFocusAfterLayout(boolean z2) {
        this.k0 = z2;
    }

    public void setRecycledViewPool(s sVar) {
        t tVar = this.h;
        s sVar2 = tVar.g;
        if (sVar2 != null) {
            sVar2.b--;
        }
        tVar.g = sVar;
        if (sVar != null && RecyclerView.this.getAdapter() != null) {
            tVar.g.b++;
        }
    }

    @Deprecated
    public void setRecyclerListener(u uVar) {
        this.t = uVar;
    }

    public void setScrollState(int i2) {
        x xVar;
        if (i2 != this.U) {
            this.U = i2;
            if (i2 != 2) {
                this.l0.c();
                m mVar = this.s;
                if (!(mVar == null || (xVar = mVar.g) == null)) {
                    xVar.f();
                }
            }
            m mVar2 = this.s;
            if (mVar2 != null) {
                mVar2.B0(i2);
            }
            Y();
            r rVar = this.p0;
            if (rVar != null) {
                rVar.onScrollStateChanged(this, i2);
            }
            List<r> list = this.q0;
            if (list != null) {
                int size = list.size();
                while (true) {
                    size--;
                    if (size >= 0) {
                        this.q0.get(size).onScrollStateChanged(this, i2);
                    } else {
                        return;
                    }
                }
            }
        }
    }

    public void setScrollingTouchSlop(int i2) {
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        if (i2 != 0) {
            if (i2 != 1) {
                Log.w("RecyclerView", "setScrollingTouchSlop(): bad argument constant " + i2 + "; using default value");
            } else {
                this.e0 = viewConfiguration.getScaledPagingTouchSlop();
                return;
            }
        }
        this.e0 = viewConfiguration.getScaledTouchSlop();
    }

    public void setViewCacheExtension(z zVar) {
        Objects.requireNonNull(this.h);
    }

    public boolean startNestedScroll(int i2) {
        return getScrollingChildHelper().i(i2, 0);
    }

    public void stopNestedScroll() {
        getScrollingChildHelper().j(0);
    }

    public final void suppressLayout(boolean z2) {
        if (z2 != this.E) {
            i("Do not suppressLayout in layout or scroll");
            if (!z2) {
                this.E = false;
                if (!(!this.D || this.s == null || this.r == null)) {
                    requestLayout();
                }
                this.D = false;
                return;
            }
            long uptimeMillis = SystemClock.uptimeMillis();
            onTouchEvent(MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, Utils.FLOAT_EPSILON, Utils.FLOAT_EPSILON, 0));
            this.E = true;
            this.F = true;
            s0();
        }
    }

    public boolean t(int i2, int i3, int[] iArr, int[] iArr2, int i4) {
        return getScrollingChildHelper().c(i2, i3, iArr, iArr2, i4);
    }

    public final void u(int i2, int i3, int i4, int i5, int[] iArr, int i6, int[] iArr2) {
        getScrollingChildHelper().f(i2, i3, i4, i5, iArr, i6, iArr2);
    }

    public void v(int i2, int i3) {
        this.N++;
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        onScrollChanged(scrollX, scrollY, scrollX - i2, scrollY - i3);
        Z();
        r rVar = this.p0;
        if (rVar != null) {
            rVar.onScrolled(this, i2, i3);
        }
        List<r> list = this.q0;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.q0.get(size).onScrolled(this, i2, i3);
            }
        }
        this.N--;
    }

    public void w() {
        if (this.S == null) {
            EdgeEffect a2 = this.O.a(this);
            this.S = a2;
            if (this.m) {
                a2.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
            } else {
                a2.setSize(getMeasuredWidth(), getMeasuredHeight());
            }
        }
    }

    public void x() {
        if (this.P == null) {
            EdgeEffect a2 = this.O.a(this);
            this.P = a2;
            if (this.m) {
                a2.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
            } else {
                a2.setSize(getMeasuredHeight(), getMeasuredWidth());
            }
        }
    }

    public void y() {
        if (this.R == null) {
            EdgeEffect a2 = this.O.a(this);
            this.R = a2;
            if (this.m) {
                a2.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
            } else {
                a2.setSize(getMeasuredHeight(), getMeasuredWidth());
            }
        }
    }

    public void z() {
        if (this.Q == null) {
            EdgeEffect a2 = this.O.a(this);
            this.Q = a2;
            if (this.m) {
                a2.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
            } else {
                a2.setSize(getMeasuredWidth(), getMeasuredHeight());
            }
        }
    }

    public static abstract class e<VH extends b0> {
        private boolean mHasStableIds = false;
        private final f mObservable = new f();
        private a mStateRestorationPolicy = a.ALLOW;

        public enum a {
            ALLOW,
            PREVENT_WHEN_EMPTY,
            PREVENT
        }

        public final void bindViewHolder(VH vh, int i) {
            boolean z = vh.mBindingAdapter == null;
            if (z) {
                vh.mPosition = i;
                if (hasStableIds()) {
                    vh.mItemId = getItemId(i);
                }
                vh.setFlags(1, 519);
                int i2 = km.a;
                Trace.beginSection("RV OnBindView");
            }
            vh.mBindingAdapter = this;
            onBindViewHolder(vh, i, vh.getUnmodifiedPayloads());
            if (z) {
                vh.clearPayload();
                ViewGroup.LayoutParams layoutParams = vh.itemView.getLayoutParams();
                if (layoutParams instanceof n) {
                    ((n) layoutParams).c = true;
                }
                int i3 = km.a;
                Trace.endSection();
            }
        }

        public boolean canRestoreState() {
            int ordinal = this.mStateRestorationPolicy.ordinal();
            if (ordinal != 1) {
                return ordinal != 2;
            }
            if (getItemCount() > 0) {
                return true;
            }
            return false;
        }

        public final VH createViewHolder(ViewGroup viewGroup, int i) {
            try {
                int i2 = km.a;
                Trace.beginSection("RV CreateView");
                VH onCreateViewHolder = onCreateViewHolder(viewGroup, i);
                if (onCreateViewHolder.itemView.getParent() == null) {
                    onCreateViewHolder.mItemViewType = i;
                    Trace.endSection();
                    return onCreateViewHolder;
                }
                throw new IllegalStateException("ViewHolder views must not be attached when created. Ensure that you are not passing 'true' to the attachToRoot parameter of LayoutInflater.inflate(..., boolean attachToRoot)");
            } catch (Throwable th) {
                int i3 = km.a;
                Trace.endSection();
                throw th;
            }
        }

        public int findRelativeAdapterPositionIn(e<? extends b0> eVar, b0 b0Var, int i) {
            if (eVar == this) {
                return i;
            }
            return -1;
        }

        public abstract int getItemCount();

        public long getItemId(int i) {
            return -1;
        }

        public int getItemViewType(int i) {
            return 0;
        }

        public final a getStateRestorationPolicy() {
            return this.mStateRestorationPolicy;
        }

        public final boolean hasObservers() {
            return this.mObservable.a();
        }

        public final boolean hasStableIds() {
            return this.mHasStableIds;
        }

        public final void notifyDataSetChanged() {
            this.mObservable.b();
        }

        public final void notifyItemChanged(int i) {
            this.mObservable.d(i, 1, null);
        }

        public final void notifyItemInserted(int i) {
            this.mObservable.e(i, 1);
        }

        public final void notifyItemMoved(int i, int i2) {
            this.mObservable.c(i, i2);
        }

        public final void notifyItemRangeChanged(int i, int i2) {
            this.mObservable.d(i, i2, null);
        }

        public final void notifyItemRangeInserted(int i, int i2) {
            this.mObservable.e(i, i2);
        }

        public final void notifyItemRangeRemoved(int i, int i2) {
            this.mObservable.f(i, i2);
        }

        public final void notifyItemRemoved(int i) {
            this.mObservable.f(i, 1);
        }

        public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        }

        public abstract void onBindViewHolder(VH vh, int i);

        public void onBindViewHolder(VH vh, int i, List<Object> list) {
            onBindViewHolder(vh, i);
        }

        public abstract VH onCreateViewHolder(ViewGroup viewGroup, int i);

        public void onDetachedFromRecyclerView(RecyclerView recyclerView) {
        }

        public boolean onFailedToRecycleView(VH vh) {
            return false;
        }

        public void onViewAttachedToWindow(VH vh) {
        }

        public void onViewDetachedFromWindow(VH vh) {
        }

        public void onViewRecycled(VH vh) {
        }

        public void registerAdapterDataObserver(g gVar) {
            this.mObservable.registerObserver(gVar);
        }

        public void setHasStableIds(boolean z) {
            if (!hasObservers()) {
                this.mHasStableIds = z;
                return;
            }
            throw new IllegalStateException("Cannot change whether this adapter has stable IDs while the adapter has registered observers.");
        }

        public void setStateRestorationPolicy(a aVar) {
            this.mStateRestorationPolicy = aVar;
            this.mObservable.g();
        }

        public void unregisterAdapterDataObserver(g gVar) {
            this.mObservable.unregisterObserver(gVar);
        }

        public final void notifyItemChanged(int i, Object obj) {
            this.mObservable.d(i, 1, obj);
        }

        public final void notifyItemRangeChanged(int i, int i2, Object obj) {
            this.mObservable.d(i, i2, obj);
        }
    }

    public RecyclerView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        float f2;
        float f3;
        char c2;
        ClassLoader classLoader;
        Object[] objArr;
        Constructor<? extends U> constructor;
        this.g = new v();
        this.h = new t();
        this.l = new yy();
        this.n = new a();
        this.o = new Rect();
        this.p = new Rect();
        this.q = new RectF();
        this.u = new ArrayList();
        this.v = new ArrayList<>();
        this.w = new ArrayList<>();
        this.C = 0;
        this.K = false;
        this.L = false;
        this.M = 0;
        this.N = 0;
        this.O = new i();
        this.T = new dy();
        this.U = 0;
        this.V = -1;
        this.i0 = Float.MIN_VALUE;
        this.j0 = Float.MIN_VALUE;
        this.k0 = true;
        this.l0 = new a0();
        this.n0 = L0 ? new hy.b() : null;
        this.o0 = new y();
        this.r0 = false;
        this.s0 = false;
        this.t0 = new k();
        this.u0 = false;
        this.x0 = new int[2];
        this.z0 = new int[2];
        this.A0 = new int[2];
        this.B0 = new int[2];
        this.C0 = new ArrayList();
        this.D0 = new b();
        this.F0 = 0;
        this.G0 = 0;
        this.H0 = new d();
        setScrollContainer(true);
        setFocusableInTouchMode(true);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.e0 = viewConfiguration.getScaledTouchSlop();
        Method method = Cdo.a;
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 26) {
            f2 = viewConfiguration.getScaledHorizontalScrollFactor();
        } else {
            f2 = Cdo.a(viewConfiguration, context);
        }
        this.i0 = f2;
        if (i3 >= 26) {
            f3 = viewConfiguration.getScaledVerticalScrollFactor();
        } else {
            f3 = Cdo.a(viewConfiguration, context);
        }
        this.j0 = f3;
        this.g0 = viewConfiguration.getScaledMinimumFlingVelocity();
        this.h0 = viewConfiguration.getScaledMaximumFlingVelocity();
        setWillNotDraw(getOverScrollMode() == 2);
        this.T.setListener(this.t0);
        this.j = new xx(new ty(this));
        this.k = new cy(new sy(this));
        AtomicInteger atomicInteger = co.a;
        if ((i3 >= 26 ? co.k.b(this) : 0) == 0 && i3 >= 26) {
            co.k.l(this, 8);
        }
        if (co.c.c(this) == 0) {
            co.c.s(this, 1);
        }
        this.I = (AccessibilityManager) getContext().getSystemService("accessibility");
        setAccessibilityDelegateCompat(new uy(this));
        int[] iArr = wx.a;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, i2, 0);
        co.t(this, context, iArr, attributeSet, obtainStyledAttributes, i2, 0);
        String string = obtainStyledAttributes.getString(8);
        if (obtainStyledAttributes.getInt(2, -1) == -1) {
            setDescendantFocusability(262144);
        }
        this.m = obtainStyledAttributes.getBoolean(1, true);
        boolean z2 = obtainStyledAttributes.getBoolean(3, false);
        this.A = z2;
        if (z2) {
            StateListDrawable stateListDrawable = (StateListDrawable) obtainStyledAttributes.getDrawable(6);
            Drawable drawable = obtainStyledAttributes.getDrawable(7);
            StateListDrawable stateListDrawable2 = (StateListDrawable) obtainStyledAttributes.getDrawable(4);
            Drawable drawable2 = obtainStyledAttributes.getDrawable(5);
            if (stateListDrawable == null || drawable == null || stateListDrawable2 == null || drawable2 == null) {
                throw new IllegalArgumentException(ze0.e0(this, ze0.J0("Trying to set fast scroller without both required drawables.")));
            }
            Resources resources = getContext().getResources();
            c2 = 2;
            new gy(this, stateListDrawable, drawable, stateListDrawable2, drawable2, resources.getDimensionPixelSize(R.dimen.fastscroll_default_thickness), resources.getDimensionPixelSize(R.dimen.fastscroll_minimum_range), resources.getDimensionPixelOffset(R.dimen.fastscroll_margin));
        } else {
            c2 = 2;
        }
        obtainStyledAttributes.recycle();
        if (string != null) {
            String trim = string.trim();
            if (!trim.isEmpty()) {
                if (trim.charAt(0) == '.') {
                    trim = context.getPackageName() + trim;
                } else if (!trim.contains(".")) {
                    trim = RecyclerView.class.getPackage().getName() + '.' + trim;
                }
                try {
                    if (isInEditMode()) {
                        classLoader = getClass().getClassLoader();
                    } else {
                        classLoader = context.getClassLoader();
                    }
                    Class<? extends U> asSubclass = Class.forName(trim, false, classLoader).asSubclass(m.class);
                    try {
                        constructor = asSubclass.getConstructor(M0);
                        Object[] objArr2 = new Object[4];
                        objArr2[0] = context;
                        objArr2[1] = attributeSet;
                        objArr2[c2] = Integer.valueOf(i2);
                        objArr2[3] = 0;
                        objArr = objArr2;
                    } catch (NoSuchMethodException e2) {
                        try {
                            constructor = asSubclass.getConstructor(new Class[0]);
                            objArr = null;
                        } catch (NoSuchMethodException e3) {
                            e3.initCause(e2);
                            throw new IllegalStateException(attributeSet.getPositionDescription() + ": Error creating LayoutManager " + trim, e3);
                        }
                    }
                    constructor.setAccessible(true);
                    setLayoutManager((m) constructor.newInstance(objArr));
                } catch (ClassNotFoundException e4) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Unable to find LayoutManager " + trim, e4);
                } catch (InvocationTargetException e5) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + trim, e5);
                } catch (InstantiationException e6) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + trim, e6);
                } catch (IllegalAccessException e7) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Cannot access non-public constructor " + trim, e7);
                } catch (ClassCastException e8) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Class is not a LayoutManager " + trim, e8);
                }
            }
        }
        int[] iArr2 = I0;
        TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, iArr2, i2, 0);
        co.t(this, context, iArr2, attributeSet, obtainStyledAttributes2, i2, 0);
        boolean z3 = obtainStyledAttributes2.getBoolean(0, true);
        obtainStyledAttributes2.recycle();
        setNestedScrollingEnabled(z3);
    }

    public static class w extends dp {
        public static final Parcelable.Creator<w> CREATOR = new a();
        public Parcelable i;

        public class a implements Parcelable.ClassLoaderCreator<w> {
            /* Return type fixed from 'java.lang.Object' to match base method */
            @Override // android.os.Parcelable.ClassLoaderCreator
            public w createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new w(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            public Object[] newArray(int i) {
                return new w[i];
            }

            @Override // android.os.Parcelable.Creator
            public Object createFromParcel(Parcel parcel) {
                return new w(parcel, null);
            }
        }

        public w(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.i = parcel.readParcelable(classLoader == null ? m.class.getClassLoader() : classLoader);
        }

        @Override // defpackage.dp
        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeParcelable(this.g, i2);
            parcel.writeParcelable(this.i, 0);
        }

        public w(Parcelable parcelable) {
            super(parcelable);
        }
    }

    public static class n extends ViewGroup.MarginLayoutParams {
        public b0 a;
        public final Rect b = new Rect();
        public boolean c = true;
        public boolean d = false;

        public n(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public int a() {
            return this.a.getLayoutPosition();
        }

        public boolean b() {
            return this.a.isUpdated();
        }

        public boolean c() {
            return this.a.isRemoved();
        }

        public n(int i, int i2) {
            super(i, i2);
        }

        public n(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public n(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public n(n nVar) {
            super((ViewGroup.LayoutParams) nVar);
        }
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        m mVar = this.s;
        if (mVar != null) {
            return mVar.w(layoutParams);
        }
        throw new IllegalStateException(ze0.e0(this, ze0.J0("RecyclerView has no LayoutManager")));
    }
}
