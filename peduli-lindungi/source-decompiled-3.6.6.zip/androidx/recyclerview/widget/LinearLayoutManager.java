package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.recyclerview.widget.RecyclerView;
import com.github.mikephil.charting.utils.Utils;
import defpackage.hy;
import java.util.List;
import java.util.Objects;

public class LinearLayoutManager extends RecyclerView.m implements RecyclerView.x.b {
    public int A;
    public d B;
    public final a C;
    public final b D;
    public int E;
    public int[] F;
    public int r;
    public c s;
    public py t;
    public boolean u;
    public boolean v;
    public boolean w;
    public boolean x;
    public boolean y;
    public int z;

    public static class a {
        public py a;
        public int b;
        public int c;
        public boolean d;
        public boolean e;

        public a() {
            d();
        }

        public void a() {
            int i;
            if (this.d) {
                i = this.a.g();
            } else {
                i = this.a.k();
            }
            this.c = i;
        }

        public void b(View view, int i) {
            if (this.d) {
                this.c = this.a.m() + this.a.b(view);
            } else {
                this.c = this.a.e(view);
            }
            this.b = i;
        }

        public void c(View view, int i) {
            int m = this.a.m();
            if (m >= 0) {
                b(view, i);
                return;
            }
            this.b = i;
            if (this.d) {
                int g = (this.a.g() - m) - this.a.b(view);
                this.c = this.a.g() - g;
                if (g > 0) {
                    int c2 = this.c - this.a.c(view);
                    int k = this.a.k();
                    int min = c2 - (Math.min(this.a.e(view) - k, 0) + k);
                    if (min < 0) {
                        this.c = Math.min(g, -min) + this.c;
                        return;
                    }
                    return;
                }
                return;
            }
            int e2 = this.a.e(view);
            int k2 = e2 - this.a.k();
            this.c = e2;
            if (k2 > 0) {
                int g2 = (this.a.g() - Math.min(0, (this.a.g() - m) - this.a.b(view))) - (this.a.c(view) + e2);
                if (g2 < 0) {
                    this.c -= Math.min(k2, -g2);
                }
            }
        }

        public void d() {
            this.b = -1;
            this.c = Integer.MIN_VALUE;
            this.d = false;
            this.e = false;
        }

        public String toString() {
            StringBuilder J0 = ze0.J0("AnchorInfo{mPosition=");
            J0.append(this.b);
            J0.append(", mCoordinate=");
            J0.append(this.c);
            J0.append(", mLayoutFromEnd=");
            J0.append(this.d);
            J0.append(", mValid=");
            return ze0.D0(J0, this.e, '}');
        }
    }

    public static class b {
        public int a;
        public boolean b;
        public boolean c;
        public boolean d;
    }

    public static class c {
        public boolean a = true;
        public int b;
        public int c;
        public int d;
        public int e;
        public int f;
        public int g;
        public int h = 0;
        public int i = 0;
        public int j;
        public List<RecyclerView.b0> k = null;
        public boolean l;

        public void a(View view) {
            int a2;
            int size = this.k.size();
            View view2 = null;
            int i2 = Integer.MAX_VALUE;
            for (int i3 = 0; i3 < size; i3++) {
                View view3 = this.k.get(i3).itemView;
                RecyclerView.n nVar = (RecyclerView.n) view3.getLayoutParams();
                if (view3 != view && !nVar.c() && (a2 = (nVar.a() - this.d) * this.e) >= 0 && a2 < i2) {
                    view2 = view3;
                    if (a2 == 0) {
                        break;
                    }
                    i2 = a2;
                }
            }
            if (view2 == null) {
                this.d = -1;
            } else {
                this.d = ((RecyclerView.n) view2.getLayoutParams()).a();
            }
        }

        public boolean b(RecyclerView.y yVar) {
            int i2 = this.d;
            return i2 >= 0 && i2 < yVar.b();
        }

        public View c(RecyclerView.t tVar) {
            List<RecyclerView.b0> list = this.k;
            if (list != null) {
                int size = list.size();
                for (int i2 = 0; i2 < size; i2++) {
                    View view = this.k.get(i2).itemView;
                    RecyclerView.n nVar = (RecyclerView.n) view.getLayoutParams();
                    if (!nVar.c() && this.d == nVar.a()) {
                        a(view);
                        return view;
                    }
                }
                return null;
            }
            View view2 = tVar.j(this.d, false, Long.MAX_VALUE).itemView;
            this.d += this.e;
            return view2;
        }
    }

    @SuppressLint({"BanParcelableUsage"})
    public static class d implements Parcelable {
        public static final Parcelable.Creator<d> CREATOR = new a();
        public int g;
        public int h;
        public boolean i;

        public class a implements Parcelable.Creator<d> {
            /* Return type fixed from 'java.lang.Object' to match base method */
            @Override // android.os.Parcelable.Creator
            public d createFromParcel(Parcel parcel) {
                return new d(parcel);
            }

            /* Return type fixed from 'java.lang.Object[]' to match base method */
            @Override // android.os.Parcelable.Creator
            public d[] newArray(int i) {
                return new d[i];
            }
        }

        public d() {
        }

        public boolean a() {
            return this.g >= 0;
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeInt(this.g);
            parcel.writeInt(this.h);
            parcel.writeInt(this.i ? 1 : 0);
        }

        public d(Parcel parcel) {
            this.g = parcel.readInt();
            this.h = parcel.readInt();
            this.i = parcel.readInt() != 1 ? false : true;
        }

        public d(d dVar) {
            this.g = dVar.g;
            this.h = dVar.h;
            this.i = dVar.i;
        }
    }

    public LinearLayoutManager(Context context) {
        this(1, false);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public Parcelable A0() {
        d dVar = this.B;
        if (dVar != null) {
            return new d(dVar);
        }
        d dVar2 = new d();
        if (y() > 0) {
            f1();
            boolean z2 = this.u ^ this.w;
            dVar2.i = z2;
            if (z2) {
                View s1 = s1();
                dVar2.h = this.t.g() - this.t.b(s1);
                dVar2.g = Q(s1);
            } else {
                View t1 = t1();
                dVar2.g = Q(t1);
                dVar2.h = this.t.e(t1) - this.t.k();
            }
        } else {
            dVar2.g = -1;
        }
        return dVar2;
    }

    public final void A1() {
        if (this.r == 1 || !u1()) {
            this.w = this.v;
        } else {
            this.w = !this.v;
        }
    }

    public int B1(int i, RecyclerView.t tVar, RecyclerView.y yVar) {
        if (y() == 0 || i == 0) {
            return 0;
        }
        f1();
        this.s.a = true;
        int i2 = i > 0 ? 1 : -1;
        int abs = Math.abs(i);
        E1(i2, abs, true, yVar);
        c cVar = this.s;
        int g1 = g1(tVar, cVar, yVar, false) + cVar.g;
        if (g1 < 0) {
            return 0;
        }
        if (abs > g1) {
            i = i2 * g1;
        }
        this.t.p(-i);
        this.s.j = i;
        return i;
    }

    public void C1(int i) {
        if (i == 0 || i == 1) {
            d(null);
            if (i != this.r || this.t == null) {
                py a2 = py.a(this, i);
                this.t = a2;
                this.C.a = a2;
                this.r = i;
                K0();
                return;
            }
            return;
        }
        throw new IllegalArgumentException(ze0.j0("invalid orientation:", i));
    }

    public void D1(boolean z2) {
        d(null);
        if (this.x != z2) {
            this.x = z2;
            K0();
        }
    }

    public final void E1(int i, int i2, boolean z2, RecyclerView.y yVar) {
        int i3;
        this.s.l = z1();
        this.s.f = i;
        int[] iArr = this.F;
        boolean z3 = false;
        iArr[0] = 0;
        int i4 = 1;
        iArr[1] = 0;
        Z0(yVar, iArr);
        int max = Math.max(0, this.F[0]);
        int max2 = Math.max(0, this.F[1]);
        if (i == 1) {
            z3 = true;
        }
        c cVar = this.s;
        int i5 = z3 ? max2 : max;
        cVar.h = i5;
        if (!z3) {
            max = max2;
        }
        cVar.i = max;
        if (z3) {
            cVar.h = this.t.h() + i5;
            View s1 = s1();
            c cVar2 = this.s;
            if (this.w) {
                i4 = -1;
            }
            cVar2.e = i4;
            int Q = Q(s1);
            c cVar3 = this.s;
            cVar2.d = Q + cVar3.e;
            cVar3.b = this.t.b(s1);
            i3 = this.t.b(s1) - this.t.g();
        } else {
            View t1 = t1();
            c cVar4 = this.s;
            cVar4.h = this.t.k() + cVar4.h;
            c cVar5 = this.s;
            if (!this.w) {
                i4 = -1;
            }
            cVar5.e = i4;
            int Q2 = Q(t1);
            c cVar6 = this.s;
            cVar5.d = Q2 + cVar6.e;
            cVar6.b = this.t.e(t1);
            i3 = (-this.t.e(t1)) + this.t.k();
        }
        c cVar7 = this.s;
        cVar7.c = i2;
        if (z2) {
            cVar7.c = i2 - i3;
        }
        cVar7.g = i3;
    }

    public final void F1(int i, int i2) {
        this.s.c = this.t.g() - i2;
        c cVar = this.s;
        cVar.e = this.w ? -1 : 1;
        cVar.d = i;
        cVar.f = 1;
        cVar.b = i2;
        cVar.g = Integer.MIN_VALUE;
    }

    public final void G1(int i, int i2) {
        this.s.c = i2 - this.t.k();
        c cVar = this.s;
        cVar.d = i;
        cVar.e = this.w ? 1 : -1;
        cVar.f = -1;
        cVar.b = i2;
        cVar.g = Integer.MIN_VALUE;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int L0(int i, RecyclerView.t tVar, RecyclerView.y yVar) {
        if (this.r == 1) {
            return 0;
        }
        return B1(i, tVar, yVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void M0(int i) {
        this.z = i;
        this.A = Integer.MIN_VALUE;
        d dVar = this.B;
        if (dVar != null) {
            dVar.g = -1;
        }
        K0();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int N0(int i, RecyclerView.t tVar, RecyclerView.y yVar) {
        if (this.r == 0) {
            return 0;
        }
        return B1(i, tVar, yVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean U0() {
        boolean z2;
        if (!(this.o == 1073741824 || this.n == 1073741824)) {
            int y2 = y();
            int i = 0;
            while (true) {
                if (i >= y2) {
                    z2 = false;
                    break;
                }
                ViewGroup.LayoutParams layoutParams = x(i).getLayoutParams();
                if (layoutParams.width < 0 && layoutParams.height < 0) {
                    z2 = true;
                    break;
                }
                i++;
            }
            if (z2) {
                return true;
            }
        }
        return false;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean V() {
        return true;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void W0(RecyclerView recyclerView, RecyclerView.y yVar, int i) {
        jy jyVar = new jy(recyclerView.getContext());
        jyVar.a = i;
        X0(jyVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean Y0() {
        return this.B == null && this.u == this.x;
    }

    public void Z0(RecyclerView.y yVar, int[] iArr) {
        int i;
        int l = yVar.a != -1 ? this.t.l() : 0;
        if (this.s.f == -1) {
            i = 0;
        } else {
            i = l;
            l = 0;
        }
        iArr[0] = l;
        iArr[1] = i;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.x.b
    public PointF a(int i) {
        if (y() == 0) {
            return null;
        }
        boolean z2 = false;
        int i2 = 1;
        if (i < Q(x(0))) {
            z2 = true;
        }
        if (z2 != this.w) {
            i2 = -1;
        }
        if (this.r == 0) {
            return new PointF((float) i2, Utils.FLOAT_EPSILON);
        }
        return new PointF(Utils.FLOAT_EPSILON, (float) i2);
    }

    public void a1(RecyclerView.y yVar, c cVar, RecyclerView.m.c cVar2) {
        int i = cVar.d;
        if (i >= 0 && i < yVar.b()) {
            ((hy.b) cVar2).a(i, Math.max(0, cVar.g));
        }
    }

    public final int b1(RecyclerView.y yVar) {
        if (y() == 0) {
            return 0;
        }
        f1();
        return pu.c(yVar, this.t, j1(!this.y, true), i1(!this.y, true), this, this.y);
    }

    public final int c1(RecyclerView.y yVar) {
        if (y() == 0) {
            return 0;
        }
        f1();
        return pu.d(yVar, this.t, j1(!this.y, true), i1(!this.y, true), this, this.y, this.w);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void d(String str) {
        RecyclerView recyclerView;
        if (this.B == null && (recyclerView = this.b) != null) {
            recyclerView.i(str);
        }
    }

    public final int d1(RecyclerView.y yVar) {
        if (y() == 0) {
            return 0;
        }
        f1();
        return pu.e(yVar, this.t, j1(!this.y, true), i1(!this.y, true), this, this.y);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean e() {
        return this.r == 0;
    }

    public int e1(int i) {
        if (i == 1) {
            return (this.r != 1 && u1()) ? 1 : -1;
        }
        if (i == 2) {
            return (this.r != 1 && u1()) ? -1 : 1;
        }
        if (i != 17) {
            if (i != 33) {
                if (i != 66) {
                    return (i == 130 && this.r == 1) ? 1 : Integer.MIN_VALUE;
                }
                if (this.r == 0) {
                    return 1;
                }
                return Integer.MIN_VALUE;
            } else if (this.r == 1) {
                return -1;
            } else {
                return Integer.MIN_VALUE;
            }
        } else if (this.r == 0) {
            return -1;
        } else {
            return Integer.MIN_VALUE;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean f() {
        return this.r == 1;
    }

    public void f1() {
        if (this.s == null) {
            this.s = new c();
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void g0(RecyclerView recyclerView, RecyclerView.t tVar) {
        f0();
    }

    public int g1(RecyclerView.t tVar, c cVar, RecyclerView.y yVar, boolean z2) {
        int i = cVar.c;
        int i2 = cVar.g;
        if (i2 != Integer.MIN_VALUE) {
            if (i < 0) {
                cVar.g = i2 + i;
            }
            x1(tVar, cVar);
        }
        int i3 = cVar.c + cVar.h;
        b bVar = this.D;
        while (true) {
            if ((!cVar.l && i3 <= 0) || !cVar.b(yVar)) {
                break;
            }
            bVar.a = 0;
            bVar.b = false;
            bVar.c = false;
            bVar.d = false;
            v1(tVar, yVar, cVar, bVar);
            if (!bVar.b) {
                int i4 = cVar.b;
                int i5 = bVar.a;
                cVar.b = (cVar.f * i5) + i4;
                if (!bVar.c || cVar.k != null || !yVar.g) {
                    cVar.c -= i5;
                    i3 -= i5;
                }
                int i6 = cVar.g;
                if (i6 != Integer.MIN_VALUE) {
                    int i7 = i6 + i5;
                    cVar.g = i7;
                    int i8 = cVar.c;
                    if (i8 < 0) {
                        cVar.g = i7 + i8;
                    }
                    x1(tVar, cVar);
                }
                if (z2 && bVar.d) {
                    break;
                }
            } else {
                break;
            }
        }
        return i - cVar.c;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public View h0(View view, int i, RecyclerView.t tVar, RecyclerView.y yVar) {
        int e1;
        View view2;
        View view3;
        A1();
        if (y() == 0 || (e1 = e1(i)) == Integer.MIN_VALUE) {
            return null;
        }
        f1();
        E1(e1, (int) (((float) this.t.l()) * 0.33333334f), false, yVar);
        c cVar = this.s;
        cVar.g = Integer.MIN_VALUE;
        cVar.a = false;
        g1(tVar, cVar, yVar, true);
        if (e1 == -1) {
            if (this.w) {
                view2 = n1(y() - 1, -1);
            } else {
                view2 = n1(0, y());
            }
        } else if (this.w) {
            view2 = n1(0, y());
        } else {
            view2 = n1(y() - 1, -1);
        }
        if (e1 == -1) {
            view3 = t1();
        } else {
            view3 = s1();
        }
        if (!view3.hasFocusable()) {
            return view2;
        }
        if (view2 == null) {
            return null;
        }
        return view3;
    }

    public int h1() {
        View o1 = o1(0, y(), true, false);
        if (o1 == null) {
            return -1;
        }
        return Q(o1);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void i(int i, int i2, RecyclerView.y yVar, RecyclerView.m.c cVar) {
        if (this.r != 0) {
            i = i2;
        }
        if (y() != 0 && i != 0) {
            f1();
            E1(i > 0 ? 1 : -1, Math.abs(i), true, yVar);
            a1(yVar, this.s, cVar);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void i0(AccessibilityEvent accessibilityEvent) {
        RecyclerView.t tVar = this.b.h;
        j0(accessibilityEvent);
        if (y() > 0) {
            accessibilityEvent.setFromIndex(k1());
            accessibilityEvent.setToIndex(m1());
        }
    }

    public View i1(boolean z2, boolean z3) {
        if (this.w) {
            return o1(0, y(), z2, z3);
        }
        return o1(y() - 1, -1, z2, z3);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void j(int i, RecyclerView.m.c cVar) {
        boolean z2;
        int i2;
        d dVar = this.B;
        int i3 = -1;
        if (dVar == null || !dVar.a()) {
            A1();
            z2 = this.w;
            i2 = this.z;
            if (i2 == -1) {
                i2 = z2 ? i - 1 : 0;
            }
        } else {
            d dVar2 = this.B;
            z2 = dVar2.i;
            i2 = dVar2.g;
        }
        if (!z2) {
            i3 = 1;
        }
        for (int i4 = 0; i4 < this.E && i2 >= 0 && i2 < i; i4++) {
            ((hy.b) cVar).a(i2, 0);
            i2 += i3;
        }
    }

    public View j1(boolean z2, boolean z3) {
        if (this.w) {
            return o1(y() - 1, -1, z2, z3);
        }
        return o1(0, y(), z2, z3);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int k(RecyclerView.y yVar) {
        return b1(yVar);
    }

    public int k1() {
        View o1 = o1(0, y(), false, true);
        if (o1 == null) {
            return -1;
        }
        return Q(o1);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int l(RecyclerView.y yVar) {
        return c1(yVar);
    }

    public int l1() {
        View o1 = o1(y() - 1, -1, true, false);
        if (o1 == null) {
            return -1;
        }
        return Q(o1);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int m(RecyclerView.y yVar) {
        return d1(yVar);
    }

    public int m1() {
        View o1 = o1(y() - 1, -1, false, true);
        if (o1 == null) {
            return -1;
        }
        return Q(o1);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int n(RecyclerView.y yVar) {
        return b1(yVar);
    }

    public View n1(int i, int i2) {
        int i3;
        int i4;
        f1();
        if ((i2 > i ? 1 : i2 < i ? (char) 65535 : 0) == 0) {
            return x(i);
        }
        if (this.t.e(x(i)) < this.t.k()) {
            i4 = 16644;
            i3 = 16388;
        } else {
            i4 = 4161;
            i3 = 4097;
        }
        if (this.r == 0) {
            return this.e.a(i, i2, i4, i3);
        }
        return this.f.a(i, i2, i4, i3);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int o(RecyclerView.y yVar) {
        return c1(yVar);
    }

    public View o1(int i, int i2, boolean z2, boolean z3) {
        f1();
        int i3 = 320;
        int i4 = z2 ? 24579 : 320;
        if (!z3) {
            i3 = 0;
        }
        if (this.r == 0) {
            return this.e.a(i, i2, i4, i3);
        }
        return this.f.a(i, i2, i4, i3);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int p(RecyclerView.y yVar) {
        return d1(yVar);
    }

    public View p1(RecyclerView.t tVar, RecyclerView.y yVar, boolean z2, boolean z3) {
        int i;
        int i2;
        f1();
        int y2 = y();
        int i3 = -1;
        if (z3) {
            i2 = y() - 1;
            i = -1;
        } else {
            i3 = y2;
            i2 = 0;
            i = 1;
        }
        int b2 = yVar.b();
        int k = this.t.k();
        int g = this.t.g();
        View view = null;
        View view2 = null;
        View view3 = null;
        while (i2 != i3) {
            View x2 = x(i2);
            int Q = Q(x2);
            int e = this.t.e(x2);
            int b3 = this.t.b(x2);
            if (Q >= 0 && Q < b2) {
                if (!((RecyclerView.n) x2.getLayoutParams()).c()) {
                    boolean z4 = b3 <= k && e < k;
                    boolean z5 = e >= g && b3 > g;
                    if (!z4 && !z5) {
                        return x2;
                    }
                    if (z2) {
                        if (!z5) {
                            if (view != null) {
                            }
                            view = x2;
                        }
                    } else if (!z4) {
                        if (view != null) {
                        }
                        view = x2;
                    }
                    view2 = x2;
                } else if (view3 == null) {
                    view3 = x2;
                }
            }
            i2 += i;
        }
        if (view != null) {
            return view;
        }
        return view2 != null ? view2 : view3;
    }

    public final int q1(int i, RecyclerView.t tVar, RecyclerView.y yVar, boolean z2) {
        int g;
        int g2 = this.t.g() - i;
        if (g2 <= 0) {
            return 0;
        }
        int i2 = -B1(-g2, tVar, yVar);
        int i3 = i + i2;
        if (!z2 || (g = this.t.g() - i3) <= 0) {
            return i2;
        }
        this.t.p(g);
        return g + i2;
    }

    public final int r1(int i, RecyclerView.t tVar, RecyclerView.y yVar, boolean z2) {
        int k;
        int k2 = i - this.t.k();
        if (k2 <= 0) {
            return 0;
        }
        int i2 = -B1(k2, tVar, yVar);
        int i3 = i + i2;
        if (!z2 || (k = i3 - this.t.k()) <= 0) {
            return i2;
        }
        this.t.p(-k);
        return i2 - k;
    }

    public final View s1() {
        return x(this.w ? 0 : y() - 1);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public View t(int i) {
        int y2 = y();
        if (y2 == 0) {
            return null;
        }
        int Q = i - Q(x(0));
        if (Q >= 0 && Q < y2) {
            View x2 = x(Q);
            if (Q(x2) == i) {
                return x2;
            }
        }
        return super.t(i);
    }

    public final View t1() {
        return x(this.w ? y() - 1 : 0);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public RecyclerView.n u() {
        return new RecyclerView.n(-2, -2);
    }

    /* JADX WARNING: Removed duplicated region for block: B:118:0x020e  */
    /* JADX WARNING: Removed duplicated region for block: B:78:0x0180  */
    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void u0(RecyclerView.t tVar, RecyclerView.y yVar) {
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        View t2;
        int i7;
        int i8;
        boolean z2;
        boolean z3;
        View p1;
        int i9;
        int i10;
        if (!(this.B == null && this.z == -1) && yVar.b() == 0) {
            E0(tVar);
            return;
        }
        d dVar = this.B;
        if (dVar != null && dVar.a()) {
            this.z = this.B.g;
        }
        f1();
        this.s.a = false;
        A1();
        View H = H();
        a aVar = this.C;
        if (!aVar.e || this.z != -1 || this.B != null) {
            aVar.d();
            a aVar2 = this.C;
            aVar2.d = this.w ^ this.x;
            if (!yVar.g && (i9 = this.z) != -1) {
                if (i9 < 0 || i9 >= yVar.b()) {
                    this.z = -1;
                    this.A = Integer.MIN_VALUE;
                } else {
                    aVar2.b = this.z;
                    d dVar2 = this.B;
                    if (dVar2 != null && dVar2.a()) {
                        boolean z4 = this.B.i;
                        aVar2.d = z4;
                        if (z4) {
                            aVar2.c = this.t.g() - this.B.h;
                        } else {
                            aVar2.c = this.t.k() + this.B.h;
                        }
                    } else if (this.A == Integer.MIN_VALUE) {
                        View t3 = t(this.z);
                        if (t3 == null) {
                            if (y() > 0) {
                                aVar2.d = (this.z < Q(x(0))) == this.w;
                            }
                            aVar2.a();
                        } else if (this.t.c(t3) > this.t.l()) {
                            aVar2.a();
                        } else if (this.t.e(t3) - this.t.k() < 0) {
                            aVar2.c = this.t.k();
                            aVar2.d = false;
                        } else if (this.t.g() - this.t.b(t3) < 0) {
                            aVar2.c = this.t.g();
                            aVar2.d = true;
                        } else {
                            if (aVar2.d) {
                                i10 = this.t.m() + this.t.b(t3);
                            } else {
                                i10 = this.t.e(t3);
                            }
                            aVar2.c = i10;
                        }
                    } else {
                        boolean z5 = this.w;
                        aVar2.d = z5;
                        if (z5) {
                            aVar2.c = this.t.g() - this.A;
                        } else {
                            aVar2.c = this.t.k() + this.A;
                        }
                    }
                    z2 = true;
                    if (!z2) {
                        if (y() != 0) {
                            View H2 = H();
                            if (H2 != null) {
                                RecyclerView.n nVar = (RecyclerView.n) H2.getLayoutParams();
                                if (!nVar.c() && nVar.a() >= 0 && nVar.a() < yVar.b()) {
                                    aVar2.c(H2, Q(H2));
                                    z3 = true;
                                    if (!z3) {
                                        aVar2.a();
                                        aVar2.b = this.x ? yVar.b() - 1 : 0;
                                    }
                                }
                            }
                            boolean z6 = this.u;
                            boolean z7 = this.x;
                            if (z6 == z7 && (p1 = p1(tVar, yVar, aVar2.d, z7)) != null) {
                                aVar2.b(p1, Q(p1));
                                if (!yVar.g && Y0()) {
                                    int e = this.t.e(p1);
                                    int b2 = this.t.b(p1);
                                    int k = this.t.k();
                                    int g = this.t.g();
                                    boolean z8 = b2 <= k && e < k;
                                    boolean z9 = e >= g && b2 > g;
                                    if (z8 || z9) {
                                        if (aVar2.d) {
                                            k = g;
                                        }
                                        aVar2.c = k;
                                    }
                                }
                                z3 = true;
                                if (!z3) {
                                }
                            }
                        }
                        z3 = false;
                        if (!z3) {
                        }
                    }
                    this.C.e = true;
                }
            }
            z2 = false;
            if (!z2) {
            }
            this.C.e = true;
        } else if (H != null && (this.t.e(H) >= this.t.g() || this.t.b(H) <= this.t.k())) {
            this.C.c(H, Q(H));
        }
        c cVar = this.s;
        cVar.f = cVar.j >= 0 ? 1 : -1;
        int[] iArr = this.F;
        iArr[0] = 0;
        iArr[1] = 0;
        Z0(yVar, iArr);
        int k2 = this.t.k() + Math.max(0, this.F[0]);
        int h = this.t.h() + Math.max(0, this.F[1]);
        if (!(!yVar.g || (i6 = this.z) == -1 || this.A == Integer.MIN_VALUE || (t2 = t(i6)) == null)) {
            if (this.w) {
                i7 = this.t.g() - this.t.b(t2);
                i8 = this.A;
            } else {
                i8 = this.t.e(t2) - this.t.k();
                i7 = this.A;
            }
            int i11 = i7 - i8;
            if (i11 > 0) {
                k2 += i11;
            } else {
                h -= i11;
            }
        }
        a aVar3 = this.C;
        w1(tVar, yVar, aVar3, (!aVar3.d ? !this.w : this.w) ? 1 : -1);
        q(tVar);
        this.s.l = z1();
        Objects.requireNonNull(this.s);
        this.s.i = 0;
        a aVar4 = this.C;
        if (aVar4.d) {
            G1(aVar4.b, aVar4.c);
            c cVar2 = this.s;
            cVar2.h = k2;
            g1(tVar, cVar2, yVar, false);
            c cVar3 = this.s;
            i2 = cVar3.b;
            int i12 = cVar3.d;
            int i13 = cVar3.c;
            if (i13 > 0) {
                h += i13;
            }
            a aVar5 = this.C;
            F1(aVar5.b, aVar5.c);
            c cVar4 = this.s;
            cVar4.h = h;
            cVar4.d += cVar4.e;
            g1(tVar, cVar4, yVar, false);
            c cVar5 = this.s;
            i = cVar5.b;
            int i14 = cVar5.c;
            if (i14 > 0) {
                G1(i12, i2);
                c cVar6 = this.s;
                cVar6.h = i14;
                g1(tVar, cVar6, yVar, false);
                i2 = this.s.b;
            }
        } else {
            F1(aVar4.b, aVar4.c);
            c cVar7 = this.s;
            cVar7.h = h;
            g1(tVar, cVar7, yVar, false);
            c cVar8 = this.s;
            i = cVar8.b;
            int i15 = cVar8.d;
            int i16 = cVar8.c;
            if (i16 > 0) {
                k2 += i16;
            }
            a aVar6 = this.C;
            G1(aVar6.b, aVar6.c);
            c cVar9 = this.s;
            cVar9.h = k2;
            cVar9.d += cVar9.e;
            g1(tVar, cVar9, yVar, false);
            c cVar10 = this.s;
            i2 = cVar10.b;
            int i17 = cVar10.c;
            if (i17 > 0) {
                F1(i15, i);
                c cVar11 = this.s;
                cVar11.h = i17;
                g1(tVar, cVar11, yVar, false);
                i = this.s.b;
            }
        }
        if (y() > 0) {
            if (this.w ^ this.x) {
                int q1 = q1(i, tVar, yVar, true);
                i4 = i2 + q1;
                i3 = i + q1;
                i5 = r1(i4, tVar, yVar, false);
            } else {
                int r1 = r1(i2, tVar, yVar, true);
                i4 = i2 + r1;
                i3 = i + r1;
                i5 = q1(i3, tVar, yVar, false);
            }
            i2 = i4 + i5;
            i = i3 + i5;
        }
        if (yVar.k && y() != 0 && !yVar.g && Y0()) {
            List<RecyclerView.b0> list = tVar.d;
            int size = list.size();
            int Q = Q(x(0));
            int i18 = 0;
            int i19 = 0;
            for (int i20 = 0; i20 < size; i20++) {
                RecyclerView.b0 b0Var = list.get(i20);
                if (!b0Var.isRemoved()) {
                    if (((b0Var.getLayoutPosition() < Q) != this.w ? (char) 65535 : 1) == 65535) {
                        i18 += this.t.c(b0Var.itemView);
                    } else {
                        i19 += this.t.c(b0Var.itemView);
                    }
                }
            }
            this.s.k = list;
            if (i18 > 0) {
                G1(Q(t1()), i2);
                c cVar12 = this.s;
                cVar12.h = i18;
                cVar12.c = 0;
                cVar12.a(null);
                g1(tVar, this.s, yVar, false);
            }
            if (i19 > 0) {
                F1(Q(s1()), i);
                c cVar13 = this.s;
                cVar13.h = i19;
                cVar13.c = 0;
                cVar13.a(null);
                g1(tVar, this.s, yVar, false);
            }
            this.s.k = null;
        }
        if (!yVar.g) {
            py pyVar = this.t;
            pyVar.b = pyVar.l();
        } else {
            this.C.d();
        }
        this.u = this.x;
    }

    public boolean u1() {
        return J() == 1;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void v0(RecyclerView.y yVar) {
        this.B = null;
        this.z = -1;
        this.A = Integer.MIN_VALUE;
        this.C.d();
    }

    public void v1(RecyclerView.t tVar, RecyclerView.y yVar, c cVar, b bVar) {
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        View c2 = cVar.c(tVar);
        if (c2 == null) {
            bVar.b = true;
            return;
        }
        RecyclerView.n nVar = (RecyclerView.n) c2.getLayoutParams();
        if (cVar.k == null) {
            if (this.w == (cVar.f == -1)) {
                c(c2, -1, false);
            } else {
                c(c2, 0, false);
            }
        } else {
            if (this.w == (cVar.f == -1)) {
                c(c2, -1, true);
            } else {
                c(c2, 0, true);
            }
        }
        RecyclerView.n nVar2 = (RecyclerView.n) c2.getLayoutParams();
        Rect M = this.b.M(c2);
        int z2 = RecyclerView.m.z(this.p, this.n, O() + N() + ((ViewGroup.MarginLayoutParams) nVar2).leftMargin + ((ViewGroup.MarginLayoutParams) nVar2).rightMargin + M.left + M.right + 0, ((ViewGroup.MarginLayoutParams) nVar2).width, e());
        int z3 = RecyclerView.m.z(this.q, this.o, M() + P() + ((ViewGroup.MarginLayoutParams) nVar2).topMargin + ((ViewGroup.MarginLayoutParams) nVar2).bottomMargin + M.top + M.bottom + 0, ((ViewGroup.MarginLayoutParams) nVar2).height, f());
        if (T0(c2, z2, z3, nVar2)) {
            c2.measure(z2, z3);
        }
        bVar.a = this.t.c(c2);
        if (this.r == 1) {
            if (u1()) {
                i5 = this.p - O();
                i4 = i5 - this.t.d(c2);
            } else {
                i4 = N();
                i5 = this.t.d(c2) + i4;
            }
            if (cVar.f == -1) {
                int i6 = cVar.b;
                i = i6;
                i2 = i5;
                i3 = i6 - bVar.a;
            } else {
                int i7 = cVar.b;
                i3 = i7;
                i2 = i5;
                i = bVar.a + i7;
            }
        } else {
            int P = P();
            int d2 = this.t.d(c2) + P;
            if (cVar.f == -1) {
                int i8 = cVar.b;
                i2 = i8;
                i3 = P;
                i = d2;
                i4 = i8 - bVar.a;
            } else {
                int i9 = cVar.b;
                i3 = P;
                i2 = bVar.a + i9;
                i = d2;
                i4 = i9;
            }
        }
        Z(c2, i4, i3, i2, i);
        if (nVar.c() || nVar.b()) {
            bVar.c = true;
        }
        bVar.d = c2.hasFocusable();
    }

    public void w1(RecyclerView.t tVar, RecyclerView.y yVar, a aVar, int i) {
    }

    public final void x1(RecyclerView.t tVar, c cVar) {
        if (cVar.a && !cVar.l) {
            int i = cVar.g;
            int i2 = cVar.i;
            if (cVar.f == -1) {
                int y2 = y();
                if (i >= 0) {
                    int f = (this.t.f() - i) + i2;
                    if (this.w) {
                        for (int i3 = 0; i3 < y2; i3++) {
                            View x2 = x(i3);
                            if (this.t.e(x2) < f || this.t.o(x2) < f) {
                                y1(tVar, 0, i3);
                                return;
                            }
                        }
                        return;
                    }
                    int i4 = y2 - 1;
                    for (int i5 = i4; i5 >= 0; i5--) {
                        View x3 = x(i5);
                        if (this.t.e(x3) < f || this.t.o(x3) < f) {
                            y1(tVar, i4, i5);
                            return;
                        }
                    }
                }
            } else if (i >= 0) {
                int i6 = i - i2;
                int y3 = y();
                if (this.w) {
                    int i7 = y3 - 1;
                    for (int i8 = i7; i8 >= 0; i8--) {
                        View x4 = x(i8);
                        if (this.t.b(x4) > i6 || this.t.n(x4) > i6) {
                            y1(tVar, i7, i8);
                            return;
                        }
                    }
                    return;
                }
                for (int i9 = 0; i9 < y3; i9++) {
                    View x5 = x(i9);
                    if (this.t.b(x5) > i6 || this.t.n(x5) > i6) {
                        y1(tVar, 0, i9);
                        return;
                    }
                }
            }
        }
    }

    public final void y1(RecyclerView.t tVar, int i, int i2) {
        if (i != i2) {
            if (i2 > i) {
                for (int i3 = i2 - 1; i3 >= i; i3--) {
                    H0(i3, tVar);
                }
                return;
            }
            while (i > i2) {
                H0(i, tVar);
                i--;
            }
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void z0(Parcelable parcelable) {
        if (parcelable instanceof d) {
            d dVar = (d) parcelable;
            this.B = dVar;
            if (this.z != -1) {
                dVar.g = -1;
            }
            K0();
        }
    }

    public boolean z1() {
        return this.t.i() == 0 && this.t.f() == 0;
    }

    public LinearLayoutManager(int i, boolean z2) {
        this.r = 1;
        this.v = false;
        this.w = false;
        this.x = false;
        this.y = true;
        this.z = -1;
        this.A = Integer.MIN_VALUE;
        this.B = null;
        this.C = new a();
        this.D = new b();
        this.E = 2;
        this.F = new int[2];
        C1(i);
        d(null);
        if (z2 != this.v) {
            this.v = z2;
            K0();
        }
    }

    public LinearLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        this.r = 1;
        this.v = false;
        this.w = false;
        this.x = false;
        this.y = true;
        this.z = -1;
        this.A = Integer.MIN_VALUE;
        this.B = null;
        this.C = new a();
        this.D = new b();
        this.E = 2;
        this.F = new int[2];
        RecyclerView.m.d R = RecyclerView.m.R(context, attributeSet, i, i2);
        C1(R.a);
        boolean z2 = R.c;
        d(null);
        if (z2 != this.v) {
            this.v = z2;
            K0();
        }
        D1(R.d);
    }
}
