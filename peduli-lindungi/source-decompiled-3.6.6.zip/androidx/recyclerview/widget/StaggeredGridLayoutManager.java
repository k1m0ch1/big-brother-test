package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.recyclerview.widget.RecyclerView;
import com.github.mikephil.charting.utils.Utils;
import defpackage.hy;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;
import java.util.Objects;

public class StaggeredGridLayoutManager extends RecyclerView.m implements RecyclerView.x.b {
    public BitSet A;
    public int B;
    public int C;
    public d D;
    public int E;
    public boolean F;
    public boolean G;
    public e H;
    public int I;
    public final Rect J;
    public final b K;
    public boolean L;
    public int[] M;
    public final Runnable N;
    public int r = -1;
    public f[] s;
    public py t;
    public py u;
    public int v;
    public int w;
    public final iy x;
    public boolean y;
    public boolean z;

    public class a implements Runnable {
        public a() {
        }

        public void run() {
            StaggeredGridLayoutManager.this.a1();
        }
    }

    public class b {
        public int a;
        public int b;
        public boolean c;
        public boolean d;
        public boolean e;
        public int[] f;

        public b() {
            b();
        }

        public void a() {
            int i;
            if (this.c) {
                i = StaggeredGridLayoutManager.this.t.g();
            } else {
                i = StaggeredGridLayoutManager.this.t.k();
            }
            this.b = i;
        }

        public void b() {
            this.a = -1;
            this.b = Integer.MIN_VALUE;
            this.c = false;
            this.d = false;
            this.e = false;
            int[] iArr = this.f;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
        }
    }

    public static class c extends RecyclerView.n {
        public f e;

        public c(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public c(int i, int i2) {
            super(i, i2);
        }

        public c(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public c(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    @SuppressLint({"BanParcelableUsage"})
    public static class e implements Parcelable {
        public static final Parcelable.Creator<e> CREATOR = new a();
        public int g;
        public int h;
        public int i;
        public int[] j;
        public int k;
        public int[] l;
        public List<d.a> m;
        public boolean n;
        public boolean o;
        public boolean p;

        public class a implements Parcelable.Creator<e> {
            /* Return type fixed from 'java.lang.Object' to match base method */
            @Override // android.os.Parcelable.Creator
            public e createFromParcel(Parcel parcel) {
                return new e(parcel);
            }

            /* Return type fixed from 'java.lang.Object[]' to match base method */
            @Override // android.os.Parcelable.Creator
            public e[] newArray(int i) {
                return new e[i];
            }
        }

        public e() {
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeInt(this.g);
            parcel.writeInt(this.h);
            parcel.writeInt(this.i);
            if (this.i > 0) {
                parcel.writeIntArray(this.j);
            }
            parcel.writeInt(this.k);
            if (this.k > 0) {
                parcel.writeIntArray(this.l);
            }
            parcel.writeInt(this.n ? 1 : 0);
            parcel.writeInt(this.o ? 1 : 0);
            parcel.writeInt(this.p ? 1 : 0);
            parcel.writeList(this.m);
        }

        public e(Parcel parcel) {
            this.g = parcel.readInt();
            this.h = parcel.readInt();
            int readInt = parcel.readInt();
            this.i = readInt;
            if (readInt > 0) {
                int[] iArr = new int[readInt];
                this.j = iArr;
                parcel.readIntArray(iArr);
            }
            int readInt2 = parcel.readInt();
            this.k = readInt2;
            if (readInt2 > 0) {
                int[] iArr2 = new int[readInt2];
                this.l = iArr2;
                parcel.readIntArray(iArr2);
            }
            boolean z = false;
            this.n = parcel.readInt() == 1;
            this.o = parcel.readInt() == 1;
            this.p = parcel.readInt() == 1 ? true : z;
            this.m = parcel.readArrayList(d.a.class.getClassLoader());
        }

        public e(e eVar) {
            this.i = eVar.i;
            this.g = eVar.g;
            this.h = eVar.h;
            this.j = eVar.j;
            this.k = eVar.k;
            this.l = eVar.l;
            this.n = eVar.n;
            this.o = eVar.o;
            this.p = eVar.p;
            this.m = eVar.m;
        }
    }

    public class f {
        public ArrayList<View> a = new ArrayList<>();
        public int b = Integer.MIN_VALUE;
        public int c = Integer.MIN_VALUE;
        public int d = 0;
        public final int e;

        public f(int i) {
            this.e = i;
        }

        public void a(View view) {
            c j = j(view);
            j.e = this;
            this.a.add(view);
            this.c = Integer.MIN_VALUE;
            if (this.a.size() == 1) {
                this.b = Integer.MIN_VALUE;
            }
            if (j.c() || j.b()) {
                this.d = StaggeredGridLayoutManager.this.t.c(view) + this.d;
            }
        }

        public void b() {
            ArrayList<View> arrayList = this.a;
            View view = arrayList.get(arrayList.size() - 1);
            c j = j(view);
            this.c = StaggeredGridLayoutManager.this.t.b(view);
            Objects.requireNonNull(j);
        }

        public void c() {
            View view = this.a.get(0);
            c j = j(view);
            this.b = StaggeredGridLayoutManager.this.t.e(view);
            Objects.requireNonNull(j);
        }

        public void d() {
            this.a.clear();
            this.b = Integer.MIN_VALUE;
            this.c = Integer.MIN_VALUE;
            this.d = 0;
        }

        public int e() {
            if (StaggeredGridLayoutManager.this.y) {
                return g(this.a.size() - 1, -1, true);
            }
            return g(0, this.a.size(), true);
        }

        public int f() {
            if (StaggeredGridLayoutManager.this.y) {
                return g(0, this.a.size(), true);
            }
            return g(this.a.size() - 1, -1, true);
        }

        public int g(int i, int i2, boolean z) {
            int k = StaggeredGridLayoutManager.this.t.k();
            int g = StaggeredGridLayoutManager.this.t.g();
            int i3 = i2 > i ? 1 : -1;
            while (i != i2) {
                View view = this.a.get(i);
                int e2 = StaggeredGridLayoutManager.this.t.e(view);
                int b2 = StaggeredGridLayoutManager.this.t.b(view);
                boolean z2 = false;
                boolean z3 = !z ? e2 < g : e2 <= g;
                if (!z ? b2 > k : b2 >= k) {
                    z2 = true;
                }
                if (z3 && z2 && (e2 < k || b2 > g)) {
                    return StaggeredGridLayoutManager.this.Q(view);
                }
                i += i3;
            }
            return -1;
        }

        public int h(int i) {
            int i2 = this.c;
            if (i2 != Integer.MIN_VALUE) {
                return i2;
            }
            if (this.a.size() == 0) {
                return i;
            }
            b();
            return this.c;
        }

        public View i(int i, int i2) {
            View view = null;
            if (i2 != -1) {
                int size = this.a.size() - 1;
                while (size >= 0) {
                    View view2 = this.a.get(size);
                    StaggeredGridLayoutManager staggeredGridLayoutManager = StaggeredGridLayoutManager.this;
                    if (staggeredGridLayoutManager.y && staggeredGridLayoutManager.Q(view2) >= i) {
                        break;
                    }
                    StaggeredGridLayoutManager staggeredGridLayoutManager2 = StaggeredGridLayoutManager.this;
                    if ((!staggeredGridLayoutManager2.y && staggeredGridLayoutManager2.Q(view2) <= i) || !view2.hasFocusable()) {
                        break;
                    }
                    size--;
                    view = view2;
                }
            } else {
                int size2 = this.a.size();
                int i3 = 0;
                while (i3 < size2) {
                    View view3 = this.a.get(i3);
                    StaggeredGridLayoutManager staggeredGridLayoutManager3 = StaggeredGridLayoutManager.this;
                    if (staggeredGridLayoutManager3.y && staggeredGridLayoutManager3.Q(view3) <= i) {
                        break;
                    }
                    StaggeredGridLayoutManager staggeredGridLayoutManager4 = StaggeredGridLayoutManager.this;
                    if ((!staggeredGridLayoutManager4.y && staggeredGridLayoutManager4.Q(view3) >= i) || !view3.hasFocusable()) {
                        break;
                    }
                    i3++;
                    view = view3;
                }
            }
            return view;
        }

        public c j(View view) {
            return (c) view.getLayoutParams();
        }

        public int k(int i) {
            int i2 = this.b;
            if (i2 != Integer.MIN_VALUE) {
                return i2;
            }
            if (this.a.size() == 0) {
                return i;
            }
            c();
            return this.b;
        }

        public void l() {
            int size = this.a.size();
            View remove = this.a.remove(size - 1);
            c j = j(remove);
            j.e = null;
            if (j.c() || j.b()) {
                this.d -= StaggeredGridLayoutManager.this.t.c(remove);
            }
            if (size == 1) {
                this.b = Integer.MIN_VALUE;
            }
            this.c = Integer.MIN_VALUE;
        }

        public void m() {
            View remove = this.a.remove(0);
            c j = j(remove);
            j.e = null;
            if (this.a.size() == 0) {
                this.c = Integer.MIN_VALUE;
            }
            if (j.c() || j.b()) {
                this.d -= StaggeredGridLayoutManager.this.t.c(remove);
            }
            this.b = Integer.MIN_VALUE;
        }

        public void n(View view) {
            c j = j(view);
            j.e = this;
            this.a.add(0, view);
            this.b = Integer.MIN_VALUE;
            if (this.a.size() == 1) {
                this.c = Integer.MIN_VALUE;
            }
            if (j.c() || j.b()) {
                this.d = StaggeredGridLayoutManager.this.t.c(view) + this.d;
            }
        }
    }

    public StaggeredGridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        this.y = false;
        this.z = false;
        this.B = -1;
        this.C = Integer.MIN_VALUE;
        this.D = new d();
        this.E = 2;
        this.J = new Rect();
        this.K = new b();
        this.L = true;
        this.N = new a();
        RecyclerView.m.d R = RecyclerView.m.R(context, attributeSet, i, i2);
        int i3 = R.a;
        if (i3 == 0 || i3 == 1) {
            d(null);
            if (i3 != this.v) {
                this.v = i3;
                py pyVar = this.t;
                this.t = this.u;
                this.u = pyVar;
                K0();
            }
            int i4 = R.b;
            d(null);
            if (i4 != this.r) {
                this.D.a();
                K0();
                this.r = i4;
                this.A = new BitSet(this.r);
                this.s = new f[this.r];
                for (int i5 = 0; i5 < this.r; i5++) {
                    this.s[i5] = new f(i5);
                }
                K0();
            }
            boolean z2 = R.c;
            d(null);
            e eVar = this.H;
            if (!(eVar == null || eVar.n == z2)) {
                eVar.n = z2;
            }
            this.y = z2;
            K0();
            this.x = new iy();
            this.t = py.a(this, this.v);
            this.u = py.a(this, 1 - this.v);
            return;
        }
        throw new IllegalArgumentException("invalid orientation.");
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public Parcelable A0() {
        int i;
        View view;
        int i2;
        int i3;
        int[] iArr;
        e eVar = this.H;
        if (eVar != null) {
            return new e(eVar);
        }
        e eVar2 = new e();
        eVar2.n = this.y;
        eVar2.o = this.F;
        eVar2.p = this.G;
        d dVar = this.D;
        if (dVar == null || (iArr = dVar.a) == null) {
            eVar2.k = 0;
        } else {
            eVar2.l = iArr;
            eVar2.k = iArr.length;
            eVar2.m = dVar.b;
        }
        int i4 = -1;
        if (y() > 0) {
            if (this.F) {
                i = k1();
            } else {
                i = j1();
            }
            eVar2.g = i;
            if (this.z) {
                view = f1(true);
            } else {
                view = g1(true);
            }
            if (view != null) {
                i4 = Q(view);
            }
            eVar2.h = i4;
            int i5 = this.r;
            eVar2.i = i5;
            eVar2.j = new int[i5];
            for (int i6 = 0; i6 < this.r; i6++) {
                if (this.F) {
                    i2 = this.s[i6].h(Integer.MIN_VALUE);
                    if (i2 != Integer.MIN_VALUE) {
                        i3 = this.t.g();
                    } else {
                        eVar2.j[i6] = i2;
                    }
                } else {
                    i2 = this.s[i6].k(Integer.MIN_VALUE);
                    if (i2 != Integer.MIN_VALUE) {
                        i3 = this.t.k();
                    } else {
                        eVar2.j[i6] = i2;
                    }
                }
                i2 -= i3;
                eVar2.j[i6] = i2;
            }
        } else {
            eVar2.g = -1;
            eVar2.h = -1;
            eVar2.i = 0;
        }
        return eVar2;
    }

    public final void A1(int i, int i2) {
        for (int i3 = 0; i3 < this.r; i3++) {
            if (!this.s[i3].a.isEmpty()) {
                C1(this.s[i3], i, i2);
            }
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void B0(int i) {
        if (i == 0) {
            a1();
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:25:0x0042  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x0059  */
    public final void B1(int i, RecyclerView.y yVar) {
        int i2;
        int i3;
        RecyclerView recyclerView;
        int i4;
        iy iyVar = this.x;
        boolean z2 = false;
        iyVar.b = 0;
        iyVar.c = i;
        RecyclerView.x xVar = this.g;
        if (!(xVar != null && xVar.e) || (i4 = yVar.a) == -1) {
            i3 = 0;
        } else {
            if (this.z == (i4 < i)) {
                i3 = this.t.l();
            } else {
                i2 = this.t.l();
                i3 = 0;
                recyclerView = this.b;
                if (!(recyclerView == null && recyclerView.m)) {
                    this.x.f = this.t.k() - i2;
                    this.x.g = this.t.g() + i3;
                } else {
                    this.x.g = this.t.f() + i3;
                    this.x.f = -i2;
                }
                iy iyVar2 = this.x;
                iyVar2.h = false;
                iyVar2.a = true;
                if (this.t.i() == 0 && this.t.f() == 0) {
                    z2 = true;
                }
                iyVar2.i = z2;
            }
        }
        i2 = 0;
        recyclerView = this.b;
        if (!(recyclerView == null && recyclerView.m)) {
        }
        iy iyVar22 = this.x;
        iyVar22.h = false;
        iyVar22.a = true;
        z2 = true;
        iyVar22.i = z2;
    }

    public final void C1(f fVar, int i, int i2) {
        int i3 = fVar.d;
        if (i == -1) {
            int i4 = fVar.b;
            if (i4 == Integer.MIN_VALUE) {
                fVar.c();
                i4 = fVar.b;
            }
            if (i4 + i3 <= i2) {
                this.A.set(fVar.e, false);
                return;
            }
            return;
        }
        int i5 = fVar.c;
        if (i5 == Integer.MIN_VALUE) {
            fVar.b();
            i5 = fVar.c;
        }
        if (i5 - i3 >= i2) {
            this.A.set(fVar.e, false);
        }
    }

    public final int D1(int i, int i2, int i3) {
        if (i2 == 0 && i3 == 0) {
            return i;
        }
        int mode = View.MeasureSpec.getMode(i);
        if (mode == Integer.MIN_VALUE || mode == 1073741824) {
            return View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i) - i2) - i3), mode);
        }
        return i;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int L0(int i, RecyclerView.t tVar, RecyclerView.y yVar) {
        return y1(i, tVar, yVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void M0(int i) {
        e eVar = this.H;
        if (!(eVar == null || eVar.g == i)) {
            eVar.j = null;
            eVar.i = 0;
            eVar.g = -1;
            eVar.h = -1;
        }
        this.B = i;
        this.C = Integer.MIN_VALUE;
        K0();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int N0(int i, RecyclerView.t tVar, RecyclerView.y yVar) {
        return y1(i, tVar, yVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void Q0(Rect rect, int i, int i2) {
        int i3;
        int i4;
        int O = O() + N();
        int M2 = M() + P();
        if (this.v == 1) {
            i4 = RecyclerView.m.h(i2, rect.height() + M2, K());
            i3 = RecyclerView.m.h(i, (this.w * this.r) + O, L());
        } else {
            i3 = RecyclerView.m.h(i, rect.width() + O, L());
            i4 = RecyclerView.m.h(i2, (this.w * this.r) + M2, K());
        }
        this.b.setMeasuredDimension(i3, i4);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean V() {
        return this.E != 0;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void W0(RecyclerView recyclerView, RecyclerView.y yVar, int i) {
        jy jyVar = new jy(recyclerView.getContext());
        jyVar.a = i;
        X0(jyVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean Y0() {
        return this.H == null;
    }

    public final int Z0(int i) {
        if (y() != 0) {
            if ((i < j1()) != this.z) {
                return -1;
            }
            return 1;
        } else if (this.z) {
            return 1;
        } else {
            return -1;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.x.b
    public PointF a(int i) {
        int Z0 = Z0(i);
        PointF pointF = new PointF();
        if (Z0 == 0) {
            return null;
        }
        if (this.v == 0) {
            pointF.x = (float) Z0;
            pointF.y = Utils.FLOAT_EPSILON;
        } else {
            pointF.x = Utils.FLOAT_EPSILON;
            pointF.y = (float) Z0;
        }
        return pointF;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void a0(int i) {
        super.a0(i);
        for (int i2 = 0; i2 < this.r; i2++) {
            f fVar = this.s[i2];
            int i3 = fVar.b;
            if (i3 != Integer.MIN_VALUE) {
                fVar.b = i3 + i;
            }
            int i4 = fVar.c;
            if (i4 != Integer.MIN_VALUE) {
                fVar.c = i4 + i;
            }
        }
    }

    public boolean a1() {
        int i;
        if (!(y() == 0 || this.E == 0 || !this.i)) {
            if (this.z) {
                i = k1();
                j1();
            } else {
                i = j1();
                k1();
            }
            if (i == 0 && o1() != null) {
                this.D.a();
                this.h = true;
                K0();
                return true;
            }
        }
        return false;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void b0(int i) {
        super.b0(i);
        for (int i2 = 0; i2 < this.r; i2++) {
            f fVar = this.s[i2];
            int i3 = fVar.b;
            if (i3 != Integer.MIN_VALUE) {
                fVar.b = i3 + i;
            }
            int i4 = fVar.c;
            if (i4 != Integer.MIN_VALUE) {
                fVar.c = i4 + i;
            }
        }
    }

    public final int b1(RecyclerView.y yVar) {
        if (y() == 0) {
            return 0;
        }
        return pu.c(yVar, this.t, g1(!this.L), f1(!this.L), this, this.L);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void c0(RecyclerView.e eVar, RecyclerView.e eVar2) {
        this.D.a();
        for (int i = 0; i < this.r; i++) {
            this.s[i].d();
        }
    }

    public final int c1(RecyclerView.y yVar) {
        if (y() == 0) {
            return 0;
        }
        return pu.d(yVar, this.t, g1(!this.L), f1(!this.L), this, this.L, this.z);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void d(String str) {
        RecyclerView recyclerView;
        if (this.H == null && (recyclerView = this.b) != null) {
            recyclerView.i(str);
        }
    }

    public final int d1(RecyclerView.y yVar) {
        if (y() == 0) {
            return 0;
        }
        return pu.e(yVar, this.t, g1(!this.L), f1(!this.L), this, this.L);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean e() {
        return this.v == 0;
    }

    public final int e1(RecyclerView.t tVar, iy iyVar, RecyclerView.y yVar) {
        int i;
        int i2;
        int i3;
        f fVar;
        boolean z2;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        boolean z3 = false;
        this.A.set(0, this.r, true);
        if (this.x.i) {
            i = iyVar.e == 1 ? Integer.MAX_VALUE : Integer.MIN_VALUE;
        } else {
            if (iyVar.e == 1) {
                i11 = iyVar.g + iyVar.b;
            } else {
                i11 = iyVar.f - iyVar.b;
            }
            i = i11;
        }
        A1(iyVar.e, i);
        if (this.z) {
            i2 = this.t.g();
        } else {
            i2 = this.t.k();
        }
        boolean z4 = false;
        while (true) {
            int i12 = iyVar.c;
            if ((i12 >= 0 && i12 < yVar.b()) && (this.x.i || !this.A.isEmpty())) {
                View view = tVar.j(iyVar.c, z3, Long.MAX_VALUE).itemView;
                iyVar.c += iyVar.d;
                c cVar = (c) view.getLayoutParams();
                int a2 = cVar.a();
                int[] iArr = this.D.a;
                int i13 = (iArr == null || a2 >= iArr.length) ? -1 : iArr[a2];
                if (i13 == -1) {
                    if (s1(iyVar.e)) {
                        i10 = this.r - 1;
                        i9 = -1;
                        i8 = -1;
                    } else {
                        i9 = this.r;
                        i10 = 0;
                        i8 = 1;
                    }
                    f fVar2 = null;
                    if (iyVar.e == 1) {
                        int k = this.t.k();
                        int i14 = Integer.MAX_VALUE;
                        while (i10 != i9) {
                            f fVar3 = this.s[i10];
                            int h = fVar3.h(k);
                            if (h < i14) {
                                fVar2 = fVar3;
                                i14 = h;
                            }
                            i10 += i8;
                        }
                    } else {
                        int g = this.t.g();
                        int i15 = Integer.MIN_VALUE;
                        while (i10 != i9) {
                            f fVar4 = this.s[i10];
                            int k2 = fVar4.k(g);
                            if (k2 > i15) {
                                fVar2 = fVar4;
                                i15 = k2;
                            }
                            i10 += i8;
                        }
                    }
                    fVar = fVar2;
                    d dVar = this.D;
                    dVar.b(a2);
                    dVar.a[a2] = fVar.e;
                } else {
                    fVar = this.s[i13];
                }
                cVar.e = fVar;
                if (iyVar.e == 1) {
                    z2 = false;
                    c(view, -1, false);
                } else {
                    z2 = false;
                    c(view, 0, false);
                }
                if (this.v == 1) {
                    int i16 = this.w;
                    int i17 = this.n;
                    int i18 = ((ViewGroup.MarginLayoutParams) cVar).width;
                    int i19 = z2 ? 1 : 0;
                    int i20 = z2 ? 1 : 0;
                    int i21 = z2 ? 1 : 0;
                    q1(view, RecyclerView.m.z(i16, i17, i19, i18, z2), RecyclerView.m.z(this.q, this.o, M() + P(), ((ViewGroup.MarginLayoutParams) cVar).height, true), z2);
                } else {
                    q1(view, RecyclerView.m.z(this.p, this.n, O() + N(), ((ViewGroup.MarginLayoutParams) cVar).width, true), RecyclerView.m.z(this.w, this.o, 0, ((ViewGroup.MarginLayoutParams) cVar).height, false), false);
                }
                if (iyVar.e == 1) {
                    int h2 = fVar.h(i2);
                    i5 = h2;
                    i4 = this.t.c(view) + h2;
                } else {
                    int k3 = fVar.k(i2);
                    i4 = k3;
                    i5 = k3 - this.t.c(view);
                }
                if (iyVar.e == 1) {
                    cVar.e.a(view);
                } else {
                    cVar.e.n(view);
                }
                if (!p1() || this.v != 1) {
                    i6 = this.u.k() + (fVar.e * this.w);
                    i7 = this.u.c(view) + i6;
                } else {
                    i7 = this.u.g() - (((this.r - 1) - fVar.e) * this.w);
                    i6 = i7 - this.u.c(view);
                }
                if (this.v == 1) {
                    Z(view, i6, i5, i7, i4);
                } else {
                    Z(view, i5, i6, i4, i7);
                }
                C1(fVar, this.x.e, i);
                u1(tVar, this.x);
                if (this.x.h && view.hasFocusable()) {
                    this.A.set(fVar.e, false);
                }
                z4 = true;
                z3 = false;
            }
        }
        if (!z4) {
            u1(tVar, this.x);
        }
        if (this.x.e == -1) {
            i3 = this.t.k() - m1(this.t.k());
        } else {
            i3 = l1(this.t.g()) - this.t.g();
        }
        if (i3 > 0) {
            return Math.min(iyVar.b, i3);
        }
        return 0;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean f() {
        return this.v == 1;
    }

    public View f1(boolean z2) {
        int k = this.t.k();
        int g = this.t.g();
        View view = null;
        for (int y2 = y() - 1; y2 >= 0; y2--) {
            View x2 = x(y2);
            int e2 = this.t.e(x2);
            int b2 = this.t.b(x2);
            if (b2 > k && e2 < g) {
                if (b2 <= g || !z2) {
                    return x2;
                }
                if (view == null) {
                    view = x2;
                }
            }
        }
        return view;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public boolean g(RecyclerView.n nVar) {
        return nVar instanceof c;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void g0(RecyclerView recyclerView, RecyclerView.t tVar) {
        f0();
        Runnable runnable = this.N;
        RecyclerView recyclerView2 = this.b;
        if (recyclerView2 != null) {
            recyclerView2.removeCallbacks(runnable);
        }
        for (int i = 0; i < this.r; i++) {
            this.s[i].d();
        }
        recyclerView.requestLayout();
    }

    public View g1(boolean z2) {
        int k = this.t.k();
        int g = this.t.g();
        int y2 = y();
        View view = null;
        for (int i = 0; i < y2; i++) {
            View x2 = x(i);
            int e2 = this.t.e(x2);
            if (this.t.b(x2) > k && e2 < g) {
                if (e2 >= k || !z2) {
                    return x2;
                }
                if (view == null) {
                    view = x2;
                }
            }
        }
        return view;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0038, code lost:
        if (r8.v == 1) goto L_0x005c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x003d, code lost:
        if (r8.v == 0) goto L_0x005c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x004c, code lost:
        if (p1() == false) goto L_0x005a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x0058, code lost:
        if (p1() == false) goto L_0x005c;
     */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x005f A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x0060  */
    @Override // androidx.recyclerview.widget.RecyclerView.m
    public View h0(View view, int i, RecyclerView.t tVar, RecyclerView.y yVar) {
        View s2;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        if (y() == 0 || (s2 = s(view)) == null) {
            return null;
        }
        x1();
        if (i == 1) {
            if (this.v != 1) {
            }
            i2 = -1;
            if (i2 == Integer.MIN_VALUE) {
            }
        } else if (i != 2) {
            if (i != 17) {
                if (i != 33) {
                    if (i == 66) {
                    }
                }
            }
            i2 = Integer.MIN_VALUE;
            if (i2 == Integer.MIN_VALUE) {
                return null;
            }
            c cVar = (c) s2.getLayoutParams();
            Objects.requireNonNull(cVar);
            f fVar = cVar.e;
            if (i2 == 1) {
                i3 = k1();
            } else {
                i3 = j1();
            }
            B1(i3, yVar);
            z1(i2);
            iy iyVar = this.x;
            iyVar.c = iyVar.d + i3;
            iyVar.b = (int) (((float) this.t.l()) * 0.33333334f);
            iy iyVar2 = this.x;
            iyVar2.h = true;
            iyVar2.a = false;
            e1(tVar, iyVar2, yVar);
            this.F = this.z;
            View i7 = fVar.i(i3, i2);
            if (!(i7 == null || i7 == s2)) {
                return i7;
            }
            if (s1(i2)) {
                for (int i8 = this.r - 1; i8 >= 0; i8--) {
                    View i9 = this.s[i8].i(i3, i2);
                    if (!(i9 == null || i9 == s2)) {
                        return i9;
                    }
                }
            } else {
                for (int i10 = 0; i10 < this.r; i10++) {
                    View i11 = this.s[i10].i(i3, i2);
                    if (!(i11 == null || i11 == s2)) {
                        return i11;
                    }
                }
            }
            boolean z2 = (this.y ^ true) == (i2 == -1);
            if (z2) {
                i4 = fVar.e();
            } else {
                i4 = fVar.f();
            }
            View t2 = t(i4);
            if (!(t2 == null || t2 == s2)) {
                return t2;
            }
            if (s1(i2)) {
                for (int i12 = this.r - 1; i12 >= 0; i12--) {
                    if (i12 != fVar.e) {
                        if (z2) {
                            i6 = this.s[i12].e();
                        } else {
                            i6 = this.s[i12].f();
                        }
                        View t3 = t(i6);
                        if (!(t3 == null || t3 == s2)) {
                            return t3;
                        }
                    }
                }
            } else {
                for (int i13 = 0; i13 < this.r; i13++) {
                    if (z2) {
                        i5 = this.s[i13].e();
                    } else {
                        i5 = this.s[i13].f();
                    }
                    View t4 = t(i5);
                    if (!(t4 == null || t4 == s2)) {
                        return t4;
                    }
                }
            }
            return null;
        } else if (this.v != 1) {
        }
        i2 = 1;
        if (i2 == Integer.MIN_VALUE) {
        }
    }

    public final void h1(RecyclerView.t tVar, RecyclerView.y yVar, boolean z2) {
        int g;
        int l1 = l1(Integer.MIN_VALUE);
        if (l1 != Integer.MIN_VALUE && (g = this.t.g() - l1) > 0) {
            int i = g - (-y1(-g, tVar, yVar));
            if (z2 && i > 0) {
                this.t.p(i);
            }
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void i(int i, int i2, RecyclerView.y yVar, RecyclerView.m.c cVar) {
        int i3;
        int i4;
        if (this.v != 0) {
            i = i2;
        }
        if (!(y() == 0 || i == 0)) {
            t1(i, yVar);
            int[] iArr = this.M;
            if (iArr == null || iArr.length < this.r) {
                this.M = new int[this.r];
            }
            int i5 = 0;
            for (int i6 = 0; i6 < this.r; i6++) {
                iy iyVar = this.x;
                if (iyVar.d == -1) {
                    i4 = iyVar.f;
                    i3 = this.s[i6].k(i4);
                } else {
                    i4 = this.s[i6].h(iyVar.g);
                    i3 = this.x.g;
                }
                int i7 = i4 - i3;
                if (i7 >= 0) {
                    this.M[i5] = i7;
                    i5++;
                }
            }
            Arrays.sort(this.M, 0, i5);
            for (int i8 = 0; i8 < i5; i8++) {
                int i9 = this.x.c;
                if (i9 >= 0 && i9 < yVar.b()) {
                    ((hy.b) cVar).a(this.x.c, this.M[i8]);
                    iy iyVar2 = this.x;
                    iyVar2.c += iyVar2.d;
                } else {
                    return;
                }
            }
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void i0(AccessibilityEvent accessibilityEvent) {
        RecyclerView.t tVar = this.b.h;
        j0(accessibilityEvent);
        if (y() > 0) {
            View g1 = g1(false);
            View f1 = f1(false);
            if (g1 != null && f1 != null) {
                int Q = Q(g1);
                int Q2 = Q(f1);
                if (Q < Q2) {
                    accessibilityEvent.setFromIndex(Q);
                    accessibilityEvent.setToIndex(Q2);
                    return;
                }
                accessibilityEvent.setFromIndex(Q2);
                accessibilityEvent.setToIndex(Q);
            }
        }
    }

    public final void i1(RecyclerView.t tVar, RecyclerView.y yVar, boolean z2) {
        int k;
        int m1 = m1(Integer.MAX_VALUE);
        if (m1 != Integer.MAX_VALUE && (k = m1 - this.t.k()) > 0) {
            int y1 = k - y1(k, tVar, yVar);
            if (z2 && y1 > 0) {
                this.t.p(-y1);
            }
        }
    }

    public int j1() {
        if (y() == 0) {
            return 0;
        }
        return Q(x(0));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int k(RecyclerView.y yVar) {
        return b1(yVar);
    }

    public int k1() {
        int y2 = y();
        if (y2 == 0) {
            return 0;
        }
        return Q(x(y2 - 1));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int l(RecyclerView.y yVar) {
        return c1(yVar);
    }

    public final int l1(int i) {
        int h = this.s[0].h(i);
        for (int i2 = 1; i2 < this.r; i2++) {
            int h2 = this.s[i2].h(i);
            if (h2 > h) {
                h = h2;
            }
        }
        return h;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int m(RecyclerView.y yVar) {
        return d1(yVar);
    }

    public final int m1(int i) {
        int k = this.s[0].k(i);
        for (int i2 = 1; i2 < this.r; i2++) {
            int k2 = this.s[i2].k(i);
            if (k2 < k) {
                k = k2;
            }
        }
        return k;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int n(RecyclerView.y yVar) {
        return b1(yVar);
    }

    /* JADX WARNING: Removed duplicated region for block: B:13:0x0025  */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x003c  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0043 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0044  */
    public final void n1(int i, int i2, int i3) {
        int i4;
        int i5;
        int k1 = this.z ? k1() : j1();
        if (i3 != 8) {
            i5 = i + i2;
        } else if (i < i2) {
            i5 = i2 + 1;
        } else {
            i5 = i + 1;
            i4 = i2;
            this.D.d(i4);
            if (i3 != 1) {
                this.D.e(i, i2);
            } else if (i3 == 2) {
                this.D.f(i, i2);
            } else if (i3 == 8) {
                this.D.f(i, 1);
                this.D.e(i2, 1);
            }
            if (i5 <= k1) {
                if (i4 <= (this.z ? j1() : k1())) {
                    K0();
                    return;
                }
                return;
            }
            return;
        }
        i4 = i;
        this.D.d(i4);
        if (i3 != 1) {
        }
        if (i5 <= k1) {
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int o(RecyclerView.y yVar) {
        return c1(yVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void o0(RecyclerView recyclerView, int i, int i2) {
        n1(i, i2, 1);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:41:0x00bc, code lost:
        if (r10 == r11) goto L_0x00d0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:45:0x00ce, code lost:
        if (r10 == r11) goto L_0x00d0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x00d2, code lost:
        r10 = false;
     */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x009a  */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x0099 A[SYNTHETIC] */
    public View o1() {
        int i;
        boolean z2;
        int y2 = y() - 1;
        BitSet bitSet = new BitSet(this.r);
        bitSet.set(0, this.r, true);
        int i2 = -1;
        char c2 = (this.v != 1 || !p1()) ? (char) 65535 : 1;
        if (this.z) {
            i = -1;
        } else {
            i = y2 + 1;
            y2 = 0;
        }
        if (y2 < i) {
            i2 = 1;
        }
        while (y2 != i) {
            View x2 = x(y2);
            c cVar = (c) x2.getLayoutParams();
            if (bitSet.get(cVar.e.e)) {
                f fVar = cVar.e;
                if (this.z) {
                    int i3 = fVar.c;
                    if (i3 == Integer.MIN_VALUE) {
                        fVar.b();
                        i3 = fVar.c;
                    }
                    if (i3 < this.t.g()) {
                        ArrayList<View> arrayList = fVar.a;
                        Objects.requireNonNull(fVar.j(arrayList.get(arrayList.size() - 1)));
                    }
                    z2 = false;
                    if (z2) {
                        return x2;
                    }
                    bitSet.clear(cVar.e.e);
                } else {
                    int i4 = fVar.b;
                    if (i4 == Integer.MIN_VALUE) {
                        fVar.c();
                        i4 = fVar.b;
                    }
                    if (i4 > this.t.k()) {
                        Objects.requireNonNull(fVar.j(fVar.a.get(0)));
                    }
                    z2 = false;
                    if (z2) {
                    }
                }
                z2 = true;
                if (z2) {
                }
            }
            int i5 = y2 + i2;
            if (i5 != i) {
                View x3 = x(i5);
                if (this.z) {
                    int b2 = this.t.b(x2);
                    int b3 = this.t.b(x3);
                    if (b2 < b3) {
                        return x2;
                    }
                } else {
                    int e2 = this.t.e(x2);
                    int e3 = this.t.e(x3);
                    if (e2 > e3) {
                        return x2;
                    }
                }
                boolean z3 = true;
                if (!z3) {
                    continue;
                } else {
                    if ((cVar.e.e - ((c) x3.getLayoutParams()).e.e < 0) != (c2 < 0)) {
                        return x2;
                    }
                }
            }
            y2 += i2;
        }
        return null;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public int p(RecyclerView.y yVar) {
        return d1(yVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void p0(RecyclerView recyclerView) {
        this.D.a();
        K0();
    }

    public boolean p1() {
        return J() == 1;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void q0(RecyclerView recyclerView, int i, int i2, int i3) {
        n1(i, i2, 8);
    }

    public final void q1(View view, int i, int i2, boolean z2) {
        boolean z3;
        Rect rect = this.J;
        RecyclerView recyclerView = this.b;
        if (recyclerView == null) {
            rect.set(0, 0, 0, 0);
        } else {
            rect.set(recyclerView.M(view));
        }
        c cVar = (c) view.getLayoutParams();
        int i3 = ((ViewGroup.MarginLayoutParams) cVar).leftMargin;
        Rect rect2 = this.J;
        int D1 = D1(i, i3 + rect2.left, ((ViewGroup.MarginLayoutParams) cVar).rightMargin + rect2.right);
        int i4 = ((ViewGroup.MarginLayoutParams) cVar).topMargin;
        Rect rect3 = this.J;
        int D12 = D1(i2, i4 + rect3.top, ((ViewGroup.MarginLayoutParams) cVar).bottomMargin + rect3.bottom);
        if (z2) {
            z3 = V0(view, D1, D12, cVar);
        } else {
            z3 = T0(view, D1, D12, cVar);
        }
        if (z3) {
            view.measure(D1, D12);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void r0(RecyclerView recyclerView, int i, int i2) {
        n1(i, i2, 2);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:232:0x0417, code lost:
        if (a1() != false) goto L_0x041b;
     */
    /* JADX WARNING: Removed duplicated region for block: B:105:0x01b9  */
    public final void r1(RecyclerView.t tVar, RecyclerView.y yVar, boolean z2) {
        e eVar;
        int i;
        boolean z3;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        b bVar = this.K;
        if (!(this.H == null && this.B == -1) && yVar.b() == 0) {
            E0(tVar);
            bVar.b();
            return;
        }
        boolean z4 = true;
        boolean z5 = (bVar.e && this.B == -1 && this.H == null) ? false : true;
        if (z5) {
            bVar.b();
            e eVar2 = this.H;
            if (eVar2 != null) {
                int i7 = eVar2.i;
                if (i7 > 0) {
                    if (i7 == this.r) {
                        for (int i8 = 0; i8 < this.r; i8++) {
                            this.s[i8].d();
                            e eVar3 = this.H;
                            int i9 = eVar3.j[i8];
                            if (i9 != Integer.MIN_VALUE) {
                                if (eVar3.o) {
                                    i6 = this.t.g();
                                } else {
                                    i6 = this.t.k();
                                }
                                i9 += i6;
                            }
                            f fVar = this.s[i8];
                            fVar.b = i9;
                            fVar.c = i9;
                        }
                    } else {
                        eVar2.j = null;
                        eVar2.i = 0;
                        eVar2.k = 0;
                        eVar2.l = null;
                        eVar2.m = null;
                        eVar2.g = eVar2.h;
                    }
                }
                e eVar4 = this.H;
                this.G = eVar4.p;
                boolean z6 = eVar4.n;
                d(null);
                e eVar5 = this.H;
                if (!(eVar5 == null || eVar5.n == z6)) {
                    eVar5.n = z6;
                }
                this.y = z6;
                K0();
                x1();
                e eVar6 = this.H;
                int i10 = eVar6.g;
                if (i10 != -1) {
                    this.B = i10;
                    bVar.c = eVar6.o;
                } else {
                    bVar.c = this.z;
                }
                if (eVar6.k > 1) {
                    d dVar = this.D;
                    dVar.a = eVar6.l;
                    dVar.b = eVar6.m;
                }
            } else {
                x1();
                bVar.c = this.z;
            }
            if (!yVar.g && (i3 = this.B) != -1) {
                if (i3 < 0 || i3 >= yVar.b()) {
                    this.B = -1;
                    this.C = Integer.MIN_VALUE;
                } else {
                    e eVar7 = this.H;
                    if (eVar7 == null || eVar7.g == -1 || eVar7.i < 1) {
                        View t2 = t(this.B);
                        if (t2 != null) {
                            if (this.z) {
                                i4 = k1();
                            } else {
                                i4 = j1();
                            }
                            bVar.a = i4;
                            if (this.C != Integer.MIN_VALUE) {
                                if (bVar.c) {
                                    bVar.b = (this.t.g() - this.C) - this.t.b(t2);
                                } else {
                                    bVar.b = (this.t.k() + this.C) - this.t.e(t2);
                                }
                            } else if (this.t.c(t2) > this.t.l()) {
                                if (bVar.c) {
                                    i5 = this.t.g();
                                } else {
                                    i5 = this.t.k();
                                }
                                bVar.b = i5;
                            } else {
                                int e2 = this.t.e(t2) - this.t.k();
                                if (e2 < 0) {
                                    bVar.b = -e2;
                                } else {
                                    int g = this.t.g() - this.t.b(t2);
                                    if (g < 0) {
                                        bVar.b = g;
                                    } else {
                                        bVar.b = Integer.MIN_VALUE;
                                    }
                                }
                            }
                        } else {
                            int i11 = this.B;
                            bVar.a = i11;
                            int i12 = this.C;
                            if (i12 == Integer.MIN_VALUE) {
                                bVar.c = Z0(i11) == 1;
                                bVar.a();
                            } else if (bVar.c) {
                                bVar.b = StaggeredGridLayoutManager.this.t.g() - i12;
                            } else {
                                bVar.b = StaggeredGridLayoutManager.this.t.k() + i12;
                            }
                            bVar.d = true;
                        }
                    } else {
                        bVar.b = Integer.MIN_VALUE;
                        bVar.a = this.B;
                    }
                    z3 = true;
                    if (!z3) {
                        if (this.F) {
                            int b2 = yVar.b();
                            int y2 = y();
                            while (true) {
                                y2--;
                                if (y2 < 0) {
                                    break;
                                }
                                i2 = Q(x(y2));
                                if (i2 >= 0 && i2 < b2) {
                                    break;
                                }
                            }
                        } else {
                            int b3 = yVar.b();
                            int y3 = y();
                            int i13 = 0;
                            while (true) {
                                if (i13 >= y3) {
                                    break;
                                }
                                int Q = Q(x(i13));
                                if (Q >= 0 && Q < b3) {
                                    i2 = Q;
                                    break;
                                }
                                i13++;
                            }
                        }
                        i2 = 0;
                        bVar.a = i2;
                        bVar.b = Integer.MIN_VALUE;
                    }
                    bVar.e = true;
                }
            }
            z3 = false;
            if (!z3) {
            }
            bVar.e = true;
        }
        if (this.H == null && this.B == -1 && !(bVar.c == this.F && p1() == this.G)) {
            this.D.a();
            bVar.d = true;
        }
        if (y() > 0 && ((eVar = this.H) == null || eVar.i < 1)) {
            if (bVar.d) {
                for (int i14 = 0; i14 < this.r; i14++) {
                    this.s[i14].d();
                    int i15 = bVar.b;
                    if (i15 != Integer.MIN_VALUE) {
                        f fVar2 = this.s[i14];
                        fVar2.b = i15;
                        fVar2.c = i15;
                    }
                }
            } else if (z5 || this.K.f == null) {
                for (int i16 = 0; i16 < this.r; i16++) {
                    f fVar3 = this.s[i16];
                    boolean z7 = this.z;
                    int i17 = bVar.b;
                    if (z7) {
                        i = fVar3.h(Integer.MIN_VALUE);
                    } else {
                        i = fVar3.k(Integer.MIN_VALUE);
                    }
                    fVar3.d();
                    if (i != Integer.MIN_VALUE && ((!z7 || i >= StaggeredGridLayoutManager.this.t.g()) && (z7 || i <= StaggeredGridLayoutManager.this.t.k()))) {
                        if (i17 != Integer.MIN_VALUE) {
                            i += i17;
                        }
                        fVar3.c = i;
                        fVar3.b = i;
                    }
                }
                b bVar2 = this.K;
                f[] fVarArr = this.s;
                Objects.requireNonNull(bVar2);
                int length = fVarArr.length;
                int[] iArr = bVar2.f;
                if (iArr == null || iArr.length < length) {
                    bVar2.f = new int[StaggeredGridLayoutManager.this.s.length];
                }
                for (int i18 = 0; i18 < length; i18++) {
                    bVar2.f[i18] = fVarArr[i18].k(Integer.MIN_VALUE);
                }
            } else {
                for (int i19 = 0; i19 < this.r; i19++) {
                    f fVar4 = this.s[i19];
                    fVar4.d();
                    int i20 = this.K.f[i19];
                    fVar4.b = i20;
                    fVar4.c = i20;
                }
            }
        }
        q(tVar);
        this.x.a = false;
        int l = this.u.l();
        this.w = l / this.r;
        this.I = View.MeasureSpec.makeMeasureSpec(l, this.u.i());
        B1(bVar.a, yVar);
        if (bVar.c) {
            z1(-1);
            e1(tVar, this.x, yVar);
            z1(1);
            iy iyVar = this.x;
            iyVar.c = bVar.a + iyVar.d;
            e1(tVar, iyVar, yVar);
        } else {
            z1(1);
            e1(tVar, this.x, yVar);
            z1(-1);
            iy iyVar2 = this.x;
            iyVar2.c = bVar.a + iyVar2.d;
            e1(tVar, iyVar2, yVar);
        }
        if (this.u.i() != 1073741824) {
            float f2 = Utils.FLOAT_EPSILON;
            int y4 = y();
            for (int i21 = 0; i21 < y4; i21++) {
                View x2 = x(i21);
                float c2 = (float) this.u.c(x2);
                if (c2 >= f2) {
                    Objects.requireNonNull((c) x2.getLayoutParams());
                    f2 = Math.max(f2, c2);
                }
            }
            int i22 = this.w;
            int round = Math.round(f2 * ((float) this.r));
            if (this.u.i() == Integer.MIN_VALUE) {
                round = Math.min(round, this.u.l());
            }
            this.w = round / this.r;
            this.I = View.MeasureSpec.makeMeasureSpec(round, this.u.i());
            if (this.w != i22) {
                for (int i23 = 0; i23 < y4; i23++) {
                    View x3 = x(i23);
                    c cVar = (c) x3.getLayoutParams();
                    Objects.requireNonNull(cVar);
                    if (!p1() || this.v != 1) {
                        int i24 = cVar.e.e;
                        int i25 = this.w * i24;
                        int i26 = i24 * i22;
                        if (this.v == 1) {
                            x3.offsetLeftAndRight(i25 - i26);
                        } else {
                            x3.offsetTopAndBottom(i25 - i26);
                        }
                    } else {
                        int i27 = this.r;
                        int i28 = cVar.e.e;
                        x3.offsetLeftAndRight(((-((i27 - 1) - i28)) * this.w) - ((-((i27 - 1) - i28)) * i22));
                    }
                }
            }
        }
        if (y() > 0) {
            if (this.z) {
                h1(tVar, yVar, true);
                i1(tVar, yVar, false);
            } else {
                i1(tVar, yVar, true);
                h1(tVar, yVar, false);
            }
        }
        if (z2 && !yVar.g) {
            if ((this.E == 0 || y() <= 0 || o1() == null) ? false : true) {
                Runnable runnable = this.N;
                RecyclerView recyclerView = this.b;
                if (recyclerView != null) {
                    recyclerView.removeCallbacks(runnable);
                }
            }
        }
        z4 = false;
        if (yVar.g) {
            this.K.b();
        }
        this.F = bVar.c;
        this.G = p1();
        if (z4) {
            this.K.b();
            r1(tVar, yVar, false);
        }
    }

    public final boolean s1(int i) {
        if (this.v == 0) {
            if ((i == -1) != this.z) {
                return true;
            }
            return false;
        }
        if (((i == -1) == this.z) == p1()) {
            return true;
        }
        return false;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void t0(RecyclerView recyclerView, int i, int i2, Object obj) {
        n1(i, i2, 4);
    }

    public void t1(int i, RecyclerView.y yVar) {
        int i2;
        int i3;
        if (i > 0) {
            i3 = k1();
            i2 = 1;
        } else {
            i3 = j1();
            i2 = -1;
        }
        this.x.a = true;
        B1(i3, yVar);
        z1(i2);
        iy iyVar = this.x;
        iyVar.c = i3 + iyVar.d;
        iyVar.b = Math.abs(i);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public RecyclerView.n u() {
        if (this.v == 0) {
            return new c(-2, -1);
        }
        return new c(-1, -2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void u0(RecyclerView.t tVar, RecyclerView.y yVar) {
        r1(tVar, yVar, true);
    }

    public final void u1(RecyclerView.t tVar, iy iyVar) {
        int i;
        int i2;
        if (iyVar.a && !iyVar.i) {
            if (iyVar.b != 0) {
                int i3 = 1;
                if (iyVar.e == -1) {
                    int i4 = iyVar.f;
                    int k = this.s[0].k(i4);
                    while (i3 < this.r) {
                        int k2 = this.s[i3].k(i4);
                        if (k2 > k) {
                            k = k2;
                        }
                        i3++;
                    }
                    int i5 = i4 - k;
                    if (i5 < 0) {
                        i2 = iyVar.g;
                    } else {
                        i2 = iyVar.g - Math.min(i5, iyVar.b);
                    }
                    v1(tVar, i2);
                    return;
                }
                int i6 = iyVar.g;
                int h = this.s[0].h(i6);
                while (i3 < this.r) {
                    int h2 = this.s[i3].h(i6);
                    if (h2 < h) {
                        h = h2;
                    }
                    i3++;
                }
                int i7 = h - iyVar.g;
                if (i7 < 0) {
                    i = iyVar.f;
                } else {
                    i = Math.min(i7, iyVar.b) + iyVar.f;
                }
                w1(tVar, i);
            } else if (iyVar.e == -1) {
                v1(tVar, iyVar.g);
            } else {
                w1(tVar, iyVar.f);
            }
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public RecyclerView.n v(Context context, AttributeSet attributeSet) {
        return new c(context, attributeSet);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void v0(RecyclerView.y yVar) {
        this.B = -1;
        this.C = Integer.MIN_VALUE;
        this.H = null;
        this.K.b();
    }

    public final void v1(RecyclerView.t tVar, int i) {
        for (int y2 = y() - 1; y2 >= 0; y2--) {
            View x2 = x(y2);
            if (this.t.e(x2) >= i && this.t.o(x2) >= i) {
                c cVar = (c) x2.getLayoutParams();
                Objects.requireNonNull(cVar);
                if (cVar.e.a.size() != 1) {
                    cVar.e.l();
                    G0(x2, tVar);
                } else {
                    return;
                }
            } else {
                return;
            }
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public RecyclerView.n w(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            return new c((ViewGroup.MarginLayoutParams) layoutParams);
        }
        return new c(layoutParams);
    }

    public final void w1(RecyclerView.t tVar, int i) {
        while (y() > 0) {
            View x2 = x(0);
            if (this.t.b(x2) <= i && this.t.n(x2) <= i) {
                c cVar = (c) x2.getLayoutParams();
                Objects.requireNonNull(cVar);
                if (cVar.e.a.size() != 1) {
                    cVar.e.m();
                    G0(x2, tVar);
                } else {
                    return;
                }
            } else {
                return;
            }
        }
    }

    public final void x1() {
        if (this.v == 1 || !p1()) {
            this.z = this.y;
        } else {
            this.z = !this.y;
        }
    }

    public int y1(int i, RecyclerView.t tVar, RecyclerView.y yVar) {
        if (y() == 0 || i == 0) {
            return 0;
        }
        t1(i, yVar);
        int e1 = e1(tVar, this.x, yVar);
        if (this.x.b >= e1) {
            i = i < 0 ? -e1 : e1;
        }
        this.t.p(-i);
        this.F = this.z;
        iy iyVar = this.x;
        iyVar.b = 0;
        u1(tVar, iyVar);
        return i;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.m
    public void z0(Parcelable parcelable) {
        if (parcelable instanceof e) {
            e eVar = (e) parcelable;
            this.H = eVar;
            if (this.B != -1) {
                eVar.j = null;
                eVar.i = 0;
                eVar.g = -1;
                eVar.h = -1;
                eVar.j = null;
                eVar.i = 0;
                eVar.k = 0;
                eVar.l = null;
                eVar.m = null;
            }
            K0();
        }
    }

    public final void z1(int i) {
        iy iyVar = this.x;
        iyVar.e = i;
        int i2 = 1;
        if (this.z != (i == -1)) {
            i2 = -1;
        }
        iyVar.d = i2;
    }

    public static class d {
        public int[] a;
        public List<a> b;

        public void a() {
            int[] iArr = this.a;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            this.b = null;
        }

        public void b(int i) {
            int[] iArr = this.a;
            if (iArr == null) {
                int[] iArr2 = new int[(Math.max(i, 10) + 1)];
                this.a = iArr2;
                Arrays.fill(iArr2, -1);
            } else if (i >= iArr.length) {
                int length = iArr.length;
                while (length <= i) {
                    length *= 2;
                }
                int[] iArr3 = new int[length];
                this.a = iArr3;
                System.arraycopy(iArr, 0, iArr3, 0, iArr.length);
                int[] iArr4 = this.a;
                Arrays.fill(iArr4, iArr.length, iArr4.length, -1);
            }
        }

        public a c(int i) {
            List<a> list = this.b;
            if (list == null) {
                return null;
            }
            for (int size = list.size() - 1; size >= 0; size--) {
                a aVar = this.b.get(size);
                if (aVar.g == i) {
                    return aVar;
                }
            }
            return null;
        }

        /* JADX WARNING: Removed duplicated region for block: B:21:0x0048  */
        /* JADX WARNING: Removed duplicated region for block: B:23:0x0052  */
        public int d(int i) {
            int i2;
            int[] iArr = this.a;
            if (iArr == null || i >= iArr.length) {
                return -1;
            }
            if (this.b != null) {
                a c = c(i);
                if (c != null) {
                    this.b.remove(c);
                }
                int size = this.b.size();
                int i3 = 0;
                while (true) {
                    if (i3 >= size) {
                        i3 = -1;
                        break;
                    } else if (this.b.get(i3).g >= i) {
                        break;
                    } else {
                        i3++;
                    }
                }
                if (i3 != -1) {
                    this.b.remove(i3);
                    i2 = this.b.get(i3).g;
                    if (i2 != -1) {
                        int[] iArr2 = this.a;
                        Arrays.fill(iArr2, i, iArr2.length, -1);
                        return this.a.length;
                    }
                    int min = Math.min(i2 + 1, this.a.length);
                    Arrays.fill(this.a, i, min, -1);
                    return min;
                }
            }
            i2 = -1;
            if (i2 != -1) {
            }
        }

        public void e(int i, int i2) {
            int[] iArr = this.a;
            if (iArr != null && i < iArr.length) {
                int i3 = i + i2;
                b(i3);
                int[] iArr2 = this.a;
                System.arraycopy(iArr2, i, iArr2, i3, (iArr2.length - i) - i2);
                Arrays.fill(this.a, i, i3, -1);
                List<a> list = this.b;
                if (list != null) {
                    for (int size = list.size() - 1; size >= 0; size--) {
                        a aVar = this.b.get(size);
                        int i4 = aVar.g;
                        if (i4 >= i) {
                            aVar.g = i4 + i2;
                        }
                    }
                }
            }
        }

        public void f(int i, int i2) {
            int[] iArr = this.a;
            if (iArr != null && i < iArr.length) {
                int i3 = i + i2;
                b(i3);
                int[] iArr2 = this.a;
                System.arraycopy(iArr2, i3, iArr2, i, (iArr2.length - i) - i2);
                int[] iArr3 = this.a;
                Arrays.fill(iArr3, iArr3.length - i2, iArr3.length, -1);
                List<a> list = this.b;
                if (list != null) {
                    for (int size = list.size() - 1; size >= 0; size--) {
                        a aVar = this.b.get(size);
                        int i4 = aVar.g;
                        if (i4 >= i) {
                            if (i4 < i3) {
                                this.b.remove(size);
                            } else {
                                aVar.g = i4 - i2;
                            }
                        }
                    }
                }
            }
        }

        @SuppressLint({"BanParcelableUsage"})
        public static class a implements Parcelable {
            public static final Parcelable.Creator<a> CREATOR = new C0004a();
            public int g;
            public int h;
            public int[] i;
            public boolean j;

            /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a$a  reason: collision with other inner class name */
            public class C0004a implements Parcelable.Creator<a> {
                /* Return type fixed from 'java.lang.Object' to match base method */
                @Override // android.os.Parcelable.Creator
                public a createFromParcel(Parcel parcel) {
                    return new a(parcel);
                }

                /* Return type fixed from 'java.lang.Object[]' to match base method */
                @Override // android.os.Parcelable.Creator
                public a[] newArray(int i) {
                    return new a[i];
                }
            }

            public a(Parcel parcel) {
                this.g = parcel.readInt();
                this.h = parcel.readInt();
                this.j = parcel.readInt() != 1 ? false : true;
                int readInt = parcel.readInt();
                if (readInt > 0) {
                    int[] iArr = new int[readInt];
                    this.i = iArr;
                    parcel.readIntArray(iArr);
                }
            }

            public int describeContents() {
                return 0;
            }

            public String toString() {
                StringBuilder J0 = ze0.J0("FullSpanItem{mPosition=");
                J0.append(this.g);
                J0.append(", mGapDir=");
                J0.append(this.h);
                J0.append(", mHasUnwantedGapAfter=");
                J0.append(this.j);
                J0.append(", mGapPerSpan=");
                J0.append(Arrays.toString(this.i));
                J0.append('}');
                return J0.toString();
            }

            public void writeToParcel(Parcel parcel, int i2) {
                parcel.writeInt(this.g);
                parcel.writeInt(this.h);
                parcel.writeInt(this.j ? 1 : 0);
                int[] iArr = this.i;
                if (iArr == null || iArr.length <= 0) {
                    parcel.writeInt(0);
                    return;
                }
                parcel.writeInt(iArr.length);
                parcel.writeIntArray(this.i);
            }

            public a() {
            }
        }
    }
}
