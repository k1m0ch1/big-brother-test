package androidx.work.impl.utils;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteAccessPermException;
import android.database.sqlite.SQLiteCantOpenDatabaseException;
import android.database.sqlite.SQLiteDatabaseCorruptException;
import android.os.Build;
import android.util.Log;
import androidx.work.impl.WorkDatabase;
import defpackage.u20;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ForceStopRunnable implements Runnable {
    public static final String i = u20.e("ForceStopRunnable");
    public static final long j = TimeUnit.DAYS.toMillis(3650);
    public final Context g;
    public final q30 h;

    public static class BroadcastReceiver extends android.content.BroadcastReceiver {
        public static final String a = u20.e("ForceStopRunnable$Rcvr");

        public void onReceive(Context context, Intent intent) {
            if (intent != null && "ACTION_FORCE_STOP_RESCHEDULE".equals(intent.getAction())) {
                u20 c = u20.c();
                String str = a;
                if (((u20.a) c).b <= 2) {
                    Log.v(str, "Rescheduling alarm that keeps track of force-stops.");
                }
                ForceStopRunnable.c(context);
            }
        }
    }

    public ForceStopRunnable(Context context, q30 q30) {
        this.g = context.getApplicationContext();
        this.h = q30;
    }

    public static PendingIntent b(Context context, int i2) {
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(context, BroadcastReceiver.class));
        intent.setAction("ACTION_FORCE_STOP_RESCHEDULE");
        return PendingIntent.getBroadcast(context, -1, intent, i2);
    }

    public static void c(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService("alarm");
        PendingIntent b = b(context, 134217728);
        long currentTimeMillis = System.currentTimeMillis() + j;
        if (alarmManager != null) {
            alarmManager.setExact(0, currentTimeMillis, b);
        }
    }

    public boolean a() {
        List<JobInfo> e;
        if (Build.VERSION.SDK_INT >= 23) {
            Context context = this.g;
            String str = e40.k;
            JobScheduler jobScheduler = (JobScheduler) context.getSystemService("jobscheduler");
            if (!(jobScheduler == null || (e = e40.e(context, jobScheduler)) == null || e.isEmpty())) {
                for (JobInfo jobInfo : e) {
                    if (e40.g(jobInfo) == null) {
                        e40.a(jobScheduler, jobInfo.getId());
                    }
                }
            }
        }
        WorkDatabase workDatabase = this.h.c;
        s50 r = workDatabase.r();
        p50 q = workDatabase.q();
        workDatabase.c();
        try {
            t50 t50 = (t50) r;
            List<r50> e2 = t50.e();
            boolean z = !((ArrayList) e2).isEmpty();
            if (z) {
                Iterator it = ((ArrayList) e2).iterator();
                while (it.hasNext()) {
                    r50 r50 = (r50) it.next();
                    t50.p(a30.ENQUEUED, r50.a);
                    t50.l(r50.a, -1);
                }
            }
            ((q50) q).b();
            workDatabase.l();
            return z;
        } finally {
            workDatabase.g();
        }
    }

    public boolean d() {
        Long a = ((i50) this.h.g.a.n()).a("reschedule_needed");
        return a != null && a.longValue() == 1;
    }

    public void run() {
        boolean z;
        String str;
        File file;
        Context context = this.g;
        String str2 = p30.a;
        File databasePath = context.getDatabasePath("androidx.work.workdb");
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 23 && databasePath.exists()) {
            u20.c().a(p30.a, "Migrating WorkDatabase to the no-backup directory", new Throwable[0]);
            HashMap hashMap = new HashMap();
            if (i2 >= 23) {
                File databasePath2 = context.getDatabasePath("androidx.work.workdb");
                if (i2 < 23) {
                    file = context.getDatabasePath("androidx.work.workdb");
                } else {
                    file = new File(context.getNoBackupFilesDir(), "androidx.work.workdb");
                }
                hashMap.put(databasePath2, file);
                String[] strArr = p30.b;
                for (String str3 : strArr) {
                    hashMap.put(new File(databasePath2.getPath() + str3), new File(file.getPath() + str3));
                }
            }
            for (File file2 : hashMap.keySet()) {
                File file3 = (File) hashMap.get(file2);
                if (file2.exists() && file3 != null) {
                    if (file3.exists()) {
                        u20.c().f(p30.a, String.format("Over-writing contents of %s", file3), new Throwable[0]);
                    }
                    if (file2.renameTo(file3)) {
                        str = String.format("Migrated %s to %s", file2, file3);
                    } else {
                        str = String.format("Renaming %s to %s failed", file2, file3);
                    }
                    u20.c().a(p30.a, str, new Throwable[0]);
                }
            }
        }
        u20 c = u20.c();
        String str4 = i;
        c.a(str4, "Performing cleanup operations.", new Throwable[0]);
        try {
            boolean a = a();
            if (d()) {
                u20.c().a(str4, "Rescheduling Workers.", new Throwable[0]);
                this.h.e();
                this.h.g.a(false);
            } else {
                if (b(this.g, 536870912) == null) {
                    c(this.g);
                    z = true;
                } else {
                    z = false;
                }
                if (z) {
                    u20.c().a(str4, "Application was force-stopped, rescheduling.", new Throwable[0]);
                    this.h.e();
                } else if (a) {
                    u20.c().a(str4, "Found unfinished work, scheduling it.", new Throwable[0]);
                    q30 q30 = this.h;
                    k30.a(q30.b, q30.c, q30.e);
                }
            }
            this.h.d();
        } catch (SQLiteAccessPermException | SQLiteCantOpenDatabaseException | SQLiteDatabaseCorruptException e) {
            u20.c().b(i, "The file system on the device is in a bad state. WorkManager cannot access the app's internal data store.", e);
            throw new IllegalStateException("The file system on the device is in a bad state. WorkManager cannot access the app's internal data store.", e);
        }
    }
}
