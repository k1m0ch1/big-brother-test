package androidx.work.impl;

import java.util.concurrent.TimeUnit;

public abstract class WorkDatabase extends ez {
    public static final long j = TimeUnit.DAYS.toMillis(7);
    public static final /* synthetic */ int k = 0;

    public abstract e50 m();

    public abstract h50 n();

    public abstract k50 o();

    public abstract n50 p();

    public abstract p50 q();

    public abstract s50 r();

    public abstract v50 s();
}
