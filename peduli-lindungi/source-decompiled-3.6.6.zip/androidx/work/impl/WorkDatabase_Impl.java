package androidx.work.impl;

import android.content.Context;
import defpackage.ez;
import defpackage.fz;
import defpackage.mz;
import defpackage.sz;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

public final class WorkDatabase_Impl extends WorkDatabase {
    public static final /* synthetic */ int s = 0;
    public volatile s50 l;
    public volatile e50 m;
    public volatile v50 n;
    public volatile k50 o;
    public volatile n50 p;
    public volatile p50 q;
    public volatile h50 r;

    public class a extends fz.a {
        public a(int i) {
            super(i);
        }

        @Override // defpackage.fz.a
        public void a(rz rzVar) {
            ((vz) rzVar).g.execSQL("CREATE TABLE IF NOT EXISTS `Dependency` (`work_spec_id` TEXT NOT NULL, `prerequisite_id` TEXT NOT NULL, PRIMARY KEY(`work_spec_id`, `prerequisite_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE , FOREIGN KEY(`prerequisite_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            vz vzVar = (vz) rzVar;
            vzVar.g.execSQL("CREATE INDEX IF NOT EXISTS `index_Dependency_work_spec_id` ON `Dependency` (`work_spec_id`)");
            vzVar.g.execSQL("CREATE INDEX IF NOT EXISTS `index_Dependency_prerequisite_id` ON `Dependency` (`prerequisite_id`)");
            vzVar.g.execSQL("CREATE TABLE IF NOT EXISTS `WorkSpec` (`id` TEXT NOT NULL, `state` INTEGER NOT NULL, `worker_class_name` TEXT NOT NULL, `input_merger_class_name` TEXT, `input` BLOB NOT NULL, `output` BLOB NOT NULL, `initial_delay` INTEGER NOT NULL, `interval_duration` INTEGER NOT NULL, `flex_duration` INTEGER NOT NULL, `run_attempt_count` INTEGER NOT NULL, `backoff_policy` INTEGER NOT NULL, `backoff_delay_duration` INTEGER NOT NULL, `period_start_time` INTEGER NOT NULL, `minimum_retention_duration` INTEGER NOT NULL, `schedule_requested_at` INTEGER NOT NULL, `run_in_foreground` INTEGER NOT NULL, `required_network_type` INTEGER, `requires_charging` INTEGER NOT NULL, `requires_device_idle` INTEGER NOT NULL, `requires_battery_not_low` INTEGER NOT NULL, `requires_storage_not_low` INTEGER NOT NULL, `trigger_content_update_delay` INTEGER NOT NULL, `trigger_max_content_delay` INTEGER NOT NULL, `content_uri_triggers` BLOB, PRIMARY KEY(`id`))");
            vzVar.g.execSQL("CREATE INDEX IF NOT EXISTS `index_WorkSpec_schedule_requested_at` ON `WorkSpec` (`schedule_requested_at`)");
            vzVar.g.execSQL("CREATE INDEX IF NOT EXISTS `index_WorkSpec_period_start_time` ON `WorkSpec` (`period_start_time`)");
            vzVar.g.execSQL("CREATE TABLE IF NOT EXISTS `WorkTag` (`tag` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`tag`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            vzVar.g.execSQL("CREATE INDEX IF NOT EXISTS `index_WorkTag_work_spec_id` ON `WorkTag` (`work_spec_id`)");
            vzVar.g.execSQL("CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            vzVar.g.execSQL("CREATE TABLE IF NOT EXISTS `WorkName` (`name` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`name`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            vzVar.g.execSQL("CREATE INDEX IF NOT EXISTS `index_WorkName_work_spec_id` ON `WorkName` (`work_spec_id`)");
            vzVar.g.execSQL("CREATE TABLE IF NOT EXISTS `WorkProgress` (`work_spec_id` TEXT NOT NULL, `progress` BLOB NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            vzVar.g.execSQL("CREATE TABLE IF NOT EXISTS `Preference` (`key` TEXT NOT NULL, `long_value` INTEGER, PRIMARY KEY(`key`))");
            vzVar.g.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
            vzVar.g.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'cf029002fffdcadf079e8d0a1c9a70ac')");
        }

        @Override // defpackage.fz.a
        public void b(rz rzVar) {
            vz vzVar = (vz) rzVar;
            vzVar.g.execSQL("DROP TABLE IF EXISTS `Dependency`");
            vzVar.g.execSQL("DROP TABLE IF EXISTS `WorkSpec`");
            vzVar.g.execSQL("DROP TABLE IF EXISTS `WorkTag`");
            vzVar.g.execSQL("DROP TABLE IF EXISTS `SystemIdInfo`");
            vzVar.g.execSQL("DROP TABLE IF EXISTS `WorkName`");
            vzVar.g.execSQL("DROP TABLE IF EXISTS `WorkProgress`");
            vzVar.g.execSQL("DROP TABLE IF EXISTS `Preference`");
            WorkDatabase_Impl workDatabase_Impl = WorkDatabase_Impl.this;
            int i = WorkDatabase_Impl.s;
            List<ez.b> list = workDatabase_Impl.g;
            if (list != null) {
                int size = list.size();
                for (int i2 = 0; i2 < size; i2++) {
                    Objects.requireNonNull(WorkDatabase_Impl.this.g.get(i2));
                }
            }
        }

        @Override // defpackage.fz.a
        public void c(rz rzVar) {
            WorkDatabase_Impl workDatabase_Impl = WorkDatabase_Impl.this;
            int i = WorkDatabase_Impl.s;
            List<ez.b> list = workDatabase_Impl.g;
            if (list != null) {
                int size = list.size();
                for (int i2 = 0; i2 < size; i2++) {
                    Objects.requireNonNull(WorkDatabase_Impl.this.g.get(i2));
                }
            }
        }

        @Override // defpackage.fz.a
        public void d(rz rzVar) {
            WorkDatabase_Impl workDatabase_Impl = WorkDatabase_Impl.this;
            int i = WorkDatabase_Impl.s;
            workDatabase_Impl.a = rzVar;
            ((vz) rzVar).g.execSQL("PRAGMA foreign_keys = ON");
            WorkDatabase_Impl.this.i(rzVar);
            List<ez.b> list = WorkDatabase_Impl.this.g;
            if (list != null) {
                int size = list.size();
                for (int i2 = 0; i2 < size; i2++) {
                    WorkDatabase_Impl.this.g.get(i2).a(rzVar);
                }
            }
        }

        @Override // defpackage.fz.a
        public void e(rz rzVar) {
        }

        @Override // defpackage.fz.a
        public void f(rz rzVar) {
            lz.a(rzVar);
        }

        @Override // defpackage.fz.a
        public fz.b g(rz rzVar) {
            HashMap hashMap = new HashMap(2);
            hashMap.put("work_spec_id", new mz.a("work_spec_id", "TEXT", true, 1, null, 1));
            hashMap.put("prerequisite_id", new mz.a("prerequisite_id", "TEXT", true, 2, null, 1));
            HashSet hashSet = new HashSet(2);
            hashSet.add(new mz.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
            hashSet.add(new mz.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("prerequisite_id"), Arrays.asList("id")));
            HashSet hashSet2 = new HashSet(2);
            hashSet2.add(new mz.d("index_Dependency_work_spec_id", false, Arrays.asList("work_spec_id")));
            hashSet2.add(new mz.d("index_Dependency_prerequisite_id", false, Arrays.asList("prerequisite_id")));
            mz mzVar = new mz("Dependency", hashMap, hashSet, hashSet2);
            mz a = mz.a(rzVar, "Dependency");
            if (!mzVar.equals(a)) {
                return new fz.b(false, "Dependency(androidx.work.impl.model.Dependency).\n Expected:\n" + mzVar + "\n Found:\n" + a);
            }
            HashMap hashMap2 = new HashMap(24);
            hashMap2.put("id", new mz.a("id", "TEXT", true, 1, null, 1));
            hashMap2.put("state", new mz.a("state", "INTEGER", true, 0, null, 1));
            hashMap2.put("worker_class_name", new mz.a("worker_class_name", "TEXT", true, 0, null, 1));
            hashMap2.put("input_merger_class_name", new mz.a("input_merger_class_name", "TEXT", false, 0, null, 1));
            hashMap2.put("input", new mz.a("input", "BLOB", true, 0, null, 1));
            hashMap2.put("output", new mz.a("output", "BLOB", true, 0, null, 1));
            hashMap2.put("initial_delay", new mz.a("initial_delay", "INTEGER", true, 0, null, 1));
            hashMap2.put("interval_duration", new mz.a("interval_duration", "INTEGER", true, 0, null, 1));
            hashMap2.put("flex_duration", new mz.a("flex_duration", "INTEGER", true, 0, null, 1));
            hashMap2.put("run_attempt_count", new mz.a("run_attempt_count", "INTEGER", true, 0, null, 1));
            hashMap2.put("backoff_policy", new mz.a("backoff_policy", "INTEGER", true, 0, null, 1));
            hashMap2.put("backoff_delay_duration", new mz.a("backoff_delay_duration", "INTEGER", true, 0, null, 1));
            hashMap2.put("period_start_time", new mz.a("period_start_time", "INTEGER", true, 0, null, 1));
            hashMap2.put("minimum_retention_duration", new mz.a("minimum_retention_duration", "INTEGER", true, 0, null, 1));
            hashMap2.put("schedule_requested_at", new mz.a("schedule_requested_at", "INTEGER", true, 0, null, 1));
            hashMap2.put("run_in_foreground", new mz.a("run_in_foreground", "INTEGER", true, 0, null, 1));
            hashMap2.put("required_network_type", new mz.a("required_network_type", "INTEGER", false, 0, null, 1));
            hashMap2.put("requires_charging", new mz.a("requires_charging", "INTEGER", true, 0, null, 1));
            hashMap2.put("requires_device_idle", new mz.a("requires_device_idle", "INTEGER", true, 0, null, 1));
            hashMap2.put("requires_battery_not_low", new mz.a("requires_battery_not_low", "INTEGER", true, 0, null, 1));
            hashMap2.put("requires_storage_not_low", new mz.a("requires_storage_not_low", "INTEGER", true, 0, null, 1));
            hashMap2.put("trigger_content_update_delay", new mz.a("trigger_content_update_delay", "INTEGER", true, 0, null, 1));
            hashMap2.put("trigger_max_content_delay", new mz.a("trigger_max_content_delay", "INTEGER", true, 0, null, 1));
            hashMap2.put("content_uri_triggers", new mz.a("content_uri_triggers", "BLOB", false, 0, null, 1));
            HashSet hashSet3 = new HashSet(0);
            HashSet hashSet4 = new HashSet(2);
            hashSet4.add(new mz.d("index_WorkSpec_schedule_requested_at", false, Arrays.asList("schedule_requested_at")));
            hashSet4.add(new mz.d("index_WorkSpec_period_start_time", false, Arrays.asList("period_start_time")));
            mz mzVar2 = new mz("WorkSpec", hashMap2, hashSet3, hashSet4);
            mz a2 = mz.a(rzVar, "WorkSpec");
            if (!mzVar2.equals(a2)) {
                return new fz.b(false, "WorkSpec(androidx.work.impl.model.WorkSpec).\n Expected:\n" + mzVar2 + "\n Found:\n" + a2);
            }
            HashMap hashMap3 = new HashMap(2);
            hashMap3.put("tag", new mz.a("tag", "TEXT", true, 1, null, 1));
            hashMap3.put("work_spec_id", new mz.a("work_spec_id", "TEXT", true, 2, null, 1));
            HashSet hashSet5 = new HashSet(1);
            hashSet5.add(new mz.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
            HashSet hashSet6 = new HashSet(1);
            hashSet6.add(new mz.d("index_WorkTag_work_spec_id", false, Arrays.asList("work_spec_id")));
            mz mzVar3 = new mz("WorkTag", hashMap3, hashSet5, hashSet6);
            mz a3 = mz.a(rzVar, "WorkTag");
            if (!mzVar3.equals(a3)) {
                return new fz.b(false, "WorkTag(androidx.work.impl.model.WorkTag).\n Expected:\n" + mzVar3 + "\n Found:\n" + a3);
            }
            HashMap hashMap4 = new HashMap(2);
            hashMap4.put("work_spec_id", new mz.a("work_spec_id", "TEXT", true, 1, null, 1));
            hashMap4.put("system_id", new mz.a("system_id", "INTEGER", true, 0, null, 1));
            HashSet hashSet7 = new HashSet(1);
            hashSet7.add(new mz.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
            mz mzVar4 = new mz("SystemIdInfo", hashMap4, hashSet7, new HashSet(0));
            mz a4 = mz.a(rzVar, "SystemIdInfo");
            if (!mzVar4.equals(a4)) {
                return new fz.b(false, "SystemIdInfo(androidx.work.impl.model.SystemIdInfo).\n Expected:\n" + mzVar4 + "\n Found:\n" + a4);
            }
            HashMap hashMap5 = new HashMap(2);
            hashMap5.put("name", new mz.a("name", "TEXT", true, 1, null, 1));
            hashMap5.put("work_spec_id", new mz.a("work_spec_id", "TEXT", true, 2, null, 1));
            HashSet hashSet8 = new HashSet(1);
            hashSet8.add(new mz.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
            HashSet hashSet9 = new HashSet(1);
            hashSet9.add(new mz.d("index_WorkName_work_spec_id", false, Arrays.asList("work_spec_id")));
            mz mzVar5 = new mz("WorkName", hashMap5, hashSet8, hashSet9);
            mz a5 = mz.a(rzVar, "WorkName");
            if (!mzVar5.equals(a5)) {
                return new fz.b(false, "WorkName(androidx.work.impl.model.WorkName).\n Expected:\n" + mzVar5 + "\n Found:\n" + a5);
            }
            HashMap hashMap6 = new HashMap(2);
            hashMap6.put("work_spec_id", new mz.a("work_spec_id", "TEXT", true, 1, null, 1));
            hashMap6.put("progress", new mz.a("progress", "BLOB", true, 0, null, 1));
            HashSet hashSet10 = new HashSet(1);
            hashSet10.add(new mz.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
            mz mzVar6 = new mz("WorkProgress", hashMap6, hashSet10, new HashSet(0));
            mz a6 = mz.a(rzVar, "WorkProgress");
            if (!mzVar6.equals(a6)) {
                return new fz.b(false, "WorkProgress(androidx.work.impl.model.WorkProgress).\n Expected:\n" + mzVar6 + "\n Found:\n" + a6);
            }
            HashMap hashMap7 = new HashMap(2);
            hashMap7.put("key", new mz.a("key", "TEXT", true, 1, null, 1));
            hashMap7.put("long_value", new mz.a("long_value", "INTEGER", false, 0, null, 1));
            mz mzVar7 = new mz("Preference", hashMap7, new HashSet(0), new HashSet(0));
            mz a7 = mz.a(rzVar, "Preference");
            if (mzVar7.equals(a7)) {
                return new fz.b(true, null);
            }
            return new fz.b(false, "Preference(androidx.work.impl.model.Preference).\n Expected:\n" + mzVar7 + "\n Found:\n" + a7);
        }
    }

    @Override // defpackage.ez
    public dz e() {
        return new dz(this, new HashMap(0), new HashMap(0), "Dependency", "WorkSpec", "WorkTag", "SystemIdInfo", "WorkName", "WorkProgress", "Preference");
    }

    @Override // defpackage.ez
    public sz f(zy zyVar) {
        fz fzVar = new fz(zyVar, new a(11), "cf029002fffdcadf079e8d0a1c9a70ac", "8aff2efc47fafe870c738f727dfcfc6e");
        Context context = zyVar.b;
        String str = zyVar.c;
        if (context != null) {
            return zyVar.a.a(new sz.b(context, str, fzVar, false));
        }
        throw new IllegalArgumentException("Must set a non-null context to create the configuration.");
    }

    @Override // androidx.work.impl.WorkDatabase
    public e50 m() {
        e50 e50;
        if (this.m != null) {
            return this.m;
        }
        synchronized (this) {
            if (this.m == null) {
                this.m = new f50(this);
            }
            e50 = this.m;
        }
        return e50;
    }

    @Override // androidx.work.impl.WorkDatabase
    public h50 n() {
        h50 h50;
        if (this.r != null) {
            return this.r;
        }
        synchronized (this) {
            if (this.r == null) {
                this.r = new i50(this);
            }
            h50 = this.r;
        }
        return h50;
    }

    @Override // androidx.work.impl.WorkDatabase
    public k50 o() {
        k50 k50;
        if (this.o != null) {
            return this.o;
        }
        synchronized (this) {
            if (this.o == null) {
                this.o = new l50(this);
            }
            k50 = this.o;
        }
        return k50;
    }

    @Override // androidx.work.impl.WorkDatabase
    public n50 p() {
        n50 n50;
        if (this.p != null) {
            return this.p;
        }
        synchronized (this) {
            if (this.p == null) {
                this.p = new o50(this);
            }
            n50 = this.p;
        }
        return n50;
    }

    @Override // androidx.work.impl.WorkDatabase
    public p50 q() {
        p50 p50;
        if (this.q != null) {
            return this.q;
        }
        synchronized (this) {
            if (this.q == null) {
                this.q = new q50(this);
            }
            p50 = this.q;
        }
        return p50;
    }

    @Override // androidx.work.impl.WorkDatabase
    public s50 r() {
        s50 s50;
        if (this.l != null) {
            return this.l;
        }
        synchronized (this) {
            if (this.l == null) {
                this.l = new t50(this);
            }
            s50 = this.l;
        }
        return s50;
    }

    @Override // androidx.work.impl.WorkDatabase
    public v50 s() {
        v50 v50;
        if (this.n != null) {
            return this.n;
        }
        synchronized (this) {
            if (this.n == null) {
                this.n = new w50(this);
            }
            v50 = this.n;
        }
        return v50;
    }
}
