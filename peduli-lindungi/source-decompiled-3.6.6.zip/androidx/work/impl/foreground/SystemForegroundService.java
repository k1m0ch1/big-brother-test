package androidx.work.impl.foreground;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import androidx.lifecycle.LifecycleService;
import androidx.work.impl.WorkDatabase;
import defpackage.a50;
import java.util.Objects;
import java.util.UUID;

public class SystemForegroundService extends LifecycleService implements a50.a {
    public static final String l = u20.e("SystemFgService");
    public static SystemForegroundService m = null;
    public Handler h;
    public boolean i;
    public a50 j;
    public NotificationManager k;

    public class a implements Runnable {
        public final /* synthetic */ int g;
        public final /* synthetic */ Notification h;
        public final /* synthetic */ int i;

        public a(int i2, Notification notification, int i3) {
            this.g = i2;
            this.h = notification;
            this.i = i3;
        }

        public void run() {
            if (Build.VERSION.SDK_INT >= 29) {
                SystemForegroundService.this.startForeground(this.g, this.h, this.i);
            } else {
                SystemForegroundService.this.startForeground(this.g, this.h);
            }
        }
    }

    public class b implements Runnable {
        public final /* synthetic */ int g;

        public b(int i) {
            this.g = i;
        }

        public void run() {
            SystemForegroundService.this.k.cancel(this.g);
        }
    }

    public void a(int i2) {
        this.h.post(new b(i2));
    }

    public final void b() {
        this.h = new Handler(Looper.getMainLooper());
        this.k = (NotificationManager) getApplicationContext().getSystemService("notification");
        a50 a50 = new a50(getApplicationContext());
        this.j = a50;
        if (a50.q != null) {
            u20.c().b(a50.r, "A callback already exists.", new Throwable[0]);
        } else {
            a50.q = this;
        }
    }

    public void c(int i2, int i3, Notification notification) {
        this.h.post(new a(i2, notification, i3));
    }

    @Override // androidx.lifecycle.LifecycleService
    public void onCreate() {
        super.onCreate();
        m = this;
        b();
    }

    @Override // androidx.lifecycle.LifecycleService
    public void onDestroy() {
        super.onDestroy();
        this.j.c();
    }

    @Override // androidx.lifecycle.LifecycleService
    public int onStartCommand(Intent intent, int i2, int i3) {
        super.onStartCommand(intent, i2, i3);
        if (this.i) {
            u20.c().d(l, "Re-initializing SystemForegroundService after a request to shut-down.", new Throwable[0]);
            this.j.c();
            b();
            this.i = false;
        }
        if (intent == null) {
            return 3;
        }
        a50 a50 = this.j;
        Objects.requireNonNull(a50);
        String action = intent.getAction();
        if ("ACTION_START_FOREGROUND".equals(action)) {
            u20.c().d(a50.r, String.format("Started foreground service %s", intent), new Throwable[0]);
            String stringExtra = intent.getStringExtra("KEY_WORKSPEC_ID");
            WorkDatabase workDatabase = a50.h.c;
            o60 o60 = a50.i;
            ((p60) o60).a.execute(new z40(a50, workDatabase, stringExtra));
            a50.b(intent);
            return 3;
        } else if ("ACTION_NOTIFY".equals(action)) {
            a50.b(intent);
            return 3;
        } else if (!"ACTION_CANCEL_WORK".equals(action)) {
            return 3;
        } else {
            u20.c().d(a50.r, String.format("Stopping foreground work for %s", intent), new Throwable[0]);
            String stringExtra2 = intent.getStringExtra("KEY_WORKSPEC_ID");
            if (stringExtra2 == null || TextUtils.isEmpty(stringExtra2)) {
                return 3;
            }
            q30 q30 = a50.h;
            UUID fromString = UUID.fromString(stringExtra2);
            Objects.requireNonNull(q30);
            ((p60) q30.d).a.execute(new x50(q30, fromString));
            return 3;
        }
    }
}
