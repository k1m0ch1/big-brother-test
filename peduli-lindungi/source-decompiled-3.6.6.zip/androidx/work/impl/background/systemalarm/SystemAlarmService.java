package androidx.work.impl.background.systemalarm;

import android.content.Intent;
import android.os.PowerManager;
import androidx.lifecycle.LifecycleService;
import defpackage.b40;
import java.util.HashMap;
import java.util.WeakHashMap;

public class SystemAlarmService extends LifecycleService implements b40.c {
    public static final String j = u20.e("SystemAlarmService");
    public b40 h;
    public boolean i;

    public final void a() {
        b40 b40 = new b40(this);
        this.h = b40;
        if (b40.p != null) {
            u20.c().b(b40.q, "A completion listener for SystemAlarmDispatcher already exists.", new Throwable[0]);
        } else {
            b40.p = this;
        }
    }

    public void b() {
        this.i = true;
        u20.c().a(j, "All commands completed in dispatcher", new Throwable[0]);
        String str = h60.a;
        HashMap hashMap = new HashMap();
        WeakHashMap<PowerManager.WakeLock, String> weakHashMap = h60.b;
        synchronized (weakHashMap) {
            hashMap.putAll(weakHashMap);
        }
        for (PowerManager.WakeLock wakeLock : hashMap.keySet()) {
            if (wakeLock != null && wakeLock.isHeld()) {
                u20.c().f(h60.a, String.format("WakeLock held for %s", hashMap.get(wakeLock)), new Throwable[0]);
            }
        }
        stopSelf();
    }

    @Override // androidx.lifecycle.LifecycleService
    public void onCreate() {
        super.onCreate();
        a();
        this.i = false;
    }

    @Override // androidx.lifecycle.LifecycleService
    public void onDestroy() {
        super.onDestroy();
        this.i = true;
        this.h.d();
    }

    @Override // androidx.lifecycle.LifecycleService
    public int onStartCommand(Intent intent, int i2, int i3) {
        super.onStartCommand(intent, i2, i3);
        if (this.i) {
            u20.c().d(j, "Re-initializing SystemAlarmDispatcher after a request to shut-down.", new Throwable[0]);
            this.h.d();
            a();
            this.i = false;
        }
        if (intent == null) {
            return 3;
        }
        this.h.b(intent, i3);
        return 3;
    }
}
