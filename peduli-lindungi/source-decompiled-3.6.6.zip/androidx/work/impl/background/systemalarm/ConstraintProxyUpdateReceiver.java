package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.work.impl.background.systemalarm.ConstraintProxy;

public class ConstraintProxyUpdateReceiver extends BroadcastReceiver {
    public static final String a = u20.e("ConstrntProxyUpdtRecvr");

    public class a implements Runnable {
        public final /* synthetic */ Intent g;
        public final /* synthetic */ Context h;
        public final /* synthetic */ BroadcastReceiver.PendingResult i;

        public a(ConstraintProxyUpdateReceiver constraintProxyUpdateReceiver, Intent intent, Context context, BroadcastReceiver.PendingResult pendingResult) {
            this.g = intent;
            this.h = context;
            this.i = pendingResult;
        }

        public void run() {
            try {
                boolean booleanExtra = this.g.getBooleanExtra("KEY_BATTERY_NOT_LOW_PROXY_ENABLED", false);
                boolean booleanExtra2 = this.g.getBooleanExtra("KEY_BATTERY_CHARGING_PROXY_ENABLED", false);
                boolean booleanExtra3 = this.g.getBooleanExtra("KEY_STORAGE_NOT_LOW_PROXY_ENABLED", false);
                boolean booleanExtra4 = this.g.getBooleanExtra("KEY_NETWORK_STATE_PROXY_ENABLED", false);
                u20.c().a(ConstraintProxyUpdateReceiver.a, String.format("Updating proxies: BatteryNotLowProxy enabled (%s), BatteryChargingProxy enabled (%s), StorageNotLowProxy (%s), NetworkStateProxy enabled (%s)", Boolean.valueOf(booleanExtra), Boolean.valueOf(booleanExtra2), Boolean.valueOf(booleanExtra3), Boolean.valueOf(booleanExtra4)), new Throwable[0]);
                c60.a(this.h, ConstraintProxy.BatteryNotLowProxy.class, booleanExtra);
                c60.a(this.h, ConstraintProxy.BatteryChargingProxy.class, booleanExtra2);
                c60.a(this.h, ConstraintProxy.StorageNotLowProxy.class, booleanExtra3);
                c60.a(this.h, ConstraintProxy.NetworkStateProxy.class, booleanExtra4);
            } finally {
                this.i.finish();
            }
        }
    }

    public void onReceive(Context context, Intent intent) {
        String action = intent != null ? intent.getAction() : null;
        if (!"androidx.work.impl.background.systemalarm.UpdateProxies".equals(action)) {
            u20.c().a(a, String.format("Ignoring unknown action %s", action), new Throwable[0]);
            return;
        }
        BroadcastReceiver.PendingResult goAsync = goAsync();
        ((p60) q30.b(context).d).a.execute(new a(this, intent, context, goAsync));
    }
}
