package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Objects;

public class RescheduleReceiver extends BroadcastReceiver {
    public static final String a = u20.e("RescheduleReceiver");

    public void onReceive(Context context, Intent intent) {
        u20.c().a(a, String.format("Received intent %s", intent), new Throwable[0]);
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                q30 b = q30.b(context);
                BroadcastReceiver.PendingResult goAsync = goAsync();
                Objects.requireNonNull(b);
                synchronized (q30.l) {
                    b.i = goAsync;
                    if (b.h) {
                        goAsync.finish();
                        b.i = null;
                    }
                }
            } catch (IllegalStateException unused) {
                u20.c().b(a, "Cannot reschedule jobs. WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().", new Throwable[0]);
            }
        } else {
            String str = y30.j;
            Intent intent2 = new Intent(context, SystemAlarmService.class);
            intent2.setAction("ACTION_RESCHEDULE");
            context.startService(intent2);
        }
    }
}
