package androidx.work.impl.background.systemjob;

import android.app.Application;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.PersistableBundle;
import android.text.TextUtils;
import java.util.HashMap;
import java.util.Map;

public class SystemJobService extends JobService implements g30 {
    public static final String i = u20.e("SystemJobService");
    public q30 g;
    public final Map<String, JobParameters> h = new HashMap();

    public static String b(JobParameters jobParameters) {
        try {
            PersistableBundle extras = jobParameters.getExtras();
            if (extras == null || !extras.containsKey("EXTRA_WORK_SPEC_ID")) {
                return null;
            }
            return extras.getString("EXTRA_WORK_SPEC_ID");
        } catch (NullPointerException unused) {
            return null;
        }
    }

    @Override // defpackage.g30
    public void a(String str, boolean z) {
        JobParameters remove;
        u20.c().a(i, String.format("%s executed on JobScheduler", str), new Throwable[0]);
        synchronized (this.h) {
            remove = this.h.remove(str);
        }
        if (remove != null) {
            jobFinished(remove, z);
        }
    }

    public void onCreate() {
        super.onCreate();
        try {
            q30 b = q30.b(getApplicationContext());
            this.g = b;
            b.f.b(this);
        } catch (IllegalStateException unused) {
            if (Application.class.equals(getApplication().getClass())) {
                u20.c().f(i, "Could not find WorkManager instance; this may be because an auto-backup is in progress. Ignoring JobScheduler commands for now. Please make sure that you are initializing WorkManager if you have manually disabled WorkManagerInitializer.", new Throwable[0]);
                return;
            }
            throw new IllegalStateException("WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().");
        }
    }

    public void onDestroy() {
        super.onDestroy();
        q30 q30 = this.g;
        if (q30 != null) {
            q30.f.e(this);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:18:0x006c, code lost:
        r2 = null;
        r3 = android.os.Build.VERSION.SDK_INT;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0071, code lost:
        if (r3 < 24) goto L_0x009f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0073, code lost:
        r2 = new androidx.work.WorkerParameters.a();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x007c, code lost:
        if (r9.getTriggeredContentUris() == null) goto L_0x0088;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x007e, code lost:
        r2.b = java.util.Arrays.asList(r9.getTriggeredContentUris());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x008c, code lost:
        if (r9.getTriggeredContentAuthorities() == null) goto L_0x0098;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x008e, code lost:
        r2.a = java.util.Arrays.asList(r9.getTriggeredContentAuthorities());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x009a, code lost:
        if (r3 < 28) goto L_0x009f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x009c, code lost:
        r9.getNetwork();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x009f, code lost:
        r9 = r8.g;
        r3 = r9.d;
        ((defpackage.p60) r3).a.execute(new defpackage.f60(r9, r0, r2));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x00af, code lost:
        return true;
     */
    public boolean onStartJob(JobParameters jobParameters) {
        if (this.g == null) {
            u20.c().a(i, "WorkManager is not initialized; requesting retry.", new Throwable[0]);
            jobFinished(jobParameters, true);
            return false;
        }
        String b = b(jobParameters);
        if (TextUtils.isEmpty(b)) {
            u20.c().b(i, "WorkSpec id not found!", new Throwable[0]);
            return false;
        }
        synchronized (this.h) {
            if (this.h.containsKey(b)) {
                u20.c().a(i, String.format("Job is already being executed by SystemJobService: %s", b), new Throwable[0]);
                return false;
            }
            u20.c().a(i, String.format("onStartJob for %s", b), new Throwable[0]);
            this.h.put(b, jobParameters);
        }
    }

    public boolean onStopJob(JobParameters jobParameters) {
        boolean contains;
        if (this.g == null) {
            u20.c().a(i, "WorkManager is not initialized; requesting retry.", new Throwable[0]);
            return true;
        }
        String b = b(jobParameters);
        if (TextUtils.isEmpty(b)) {
            u20.c().b(i, "WorkSpec id not found!", new Throwable[0]);
            return false;
        }
        u20.c().a(i, String.format("onStopJob for %s", b), new Throwable[0]);
        synchronized (this.h) {
            this.h.remove(b);
        }
        this.g.f(b);
        i30 i30 = this.g.f;
        synchronized (i30.p) {
            contains = i30.n.contains(b);
        }
        return !contains;
    }
}
