package androidx.work.impl.workers;

import android.content.Context;
import android.text.TextUtils;
import androidx.work.ListenableWorker;
import androidx.work.WorkerParameters;
import java.util.Collections;
import java.util.List;

public class ConstraintTrackingWorker extends ListenableWorker implements h40 {
    public static final String o = u20.e("ConstraintTrkngWrkr");
    public WorkerParameters j;
    public final Object k = new Object();
    public volatile boolean l = false;
    public n60<ListenableWorker.a> m = new n60<>();
    public ListenableWorker n;

    public class a implements Runnable {
        public a() {
        }

        public void run() {
            ConstraintTrackingWorker constraintTrackingWorker = ConstraintTrackingWorker.this;
            Object obj = constraintTrackingWorker.h.b.a.get("androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME");
            String str = obj instanceof String ? (String) obj : null;
            if (TextUtils.isEmpty(str)) {
                u20.c().b(ConstraintTrackingWorker.o, "No worker to delegate to.", new Throwable[0]);
                constraintTrackingWorker.g();
                return;
            }
            ListenableWorker a = constraintTrackingWorker.h.d.a(constraintTrackingWorker.g, str, constraintTrackingWorker.j);
            constraintTrackingWorker.n = a;
            if (a == null) {
                u20.c().a(ConstraintTrackingWorker.o, "No worker to delegate to.", new Throwable[0]);
                constraintTrackingWorker.g();
                return;
            }
            r50 i = ((t50) q30.b(constraintTrackingWorker.g).c.r()).i(constraintTrackingWorker.h.a.toString());
            if (i == null) {
                constraintTrackingWorker.g();
                return;
            }
            Context context = constraintTrackingWorker.g;
            i40 i40 = new i40(context, q30.b(context).d, constraintTrackingWorker);
            i40.b(Collections.singletonList(i));
            if (i40.a(constraintTrackingWorker.h.a.toString())) {
                u20.c().a(ConstraintTrackingWorker.o, String.format("Constraints met for delegate %s", str), new Throwable[0]);
                try {
                    g03<ListenableWorker.a> c = constraintTrackingWorker.n.c();
                    c.a(new q60(constraintTrackingWorker, c), constraintTrackingWorker.h.c);
                } catch (Throwable th) {
                    u20 c2 = u20.c();
                    String str2 = ConstraintTrackingWorker.o;
                    c2.a(str2, String.format("Delegated worker %s threw exception in startWork.", str), th);
                    synchronized (constraintTrackingWorker.k) {
                        if (constraintTrackingWorker.l) {
                            u20.c().a(str2, "Constraints were unmet, Retrying.", new Throwable[0]);
                            constraintTrackingWorker.h();
                        } else {
                            constraintTrackingWorker.g();
                        }
                    }
                }
            } else {
                u20.c().a(ConstraintTrackingWorker.o, String.format("Constraints not met for delegate %s. Requesting retry.", str), new Throwable[0]);
                constraintTrackingWorker.h();
            }
        }
    }

    public ConstraintTrackingWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
        this.j = workerParameters;
    }

    @Override // androidx.work.ListenableWorker
    public boolean a() {
        ListenableWorker listenableWorker = this.n;
        return listenableWorker != null && listenableWorker.a();
    }

    @Override // androidx.work.ListenableWorker
    public void b() {
        ListenableWorker listenableWorker = this.n;
        if (listenableWorker != null) {
            listenableWorker.f();
        }
    }

    @Override // androidx.work.ListenableWorker
    public g03<ListenableWorker.a> c() {
        this.h.c.execute(new a());
        return this.m;
    }

    @Override // defpackage.h40
    public void d(List<String> list) {
        u20.c().a(o, String.format("Constraints changed for %s", list), new Throwable[0]);
        synchronized (this.k) {
            this.l = true;
        }
    }

    @Override // defpackage.h40
    public void e(List<String> list) {
    }

    public void g() {
        this.m.j(new ListenableWorker.a.C0005a());
    }

    public void h() {
        this.m.j(new ListenableWorker.a.b());
    }
}
