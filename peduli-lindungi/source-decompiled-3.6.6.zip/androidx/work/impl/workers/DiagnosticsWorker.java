package androidx.work.impl.workers;

import android.content.Context;
import android.database.Cursor;
import android.os.Build;
import android.text.TextUtils;
import androidx.work.ListenableWorker;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class DiagnosticsWorker extends Worker {
    public static final String k = u20.e("DiagnosticsWrkr");

    public DiagnosticsWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
    }

    /* JADX INFO: finally extract failed */
    public static String h(n50 n50, v50 v50, k50 k50, List<r50> list) {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("\n Id \t Class Name\t %s\t State\t Unique Name\t Tags\t", Build.VERSION.SDK_INT >= 23 ? "Job Id" : "Alarm Id"));
        for (r50 r50 : list) {
            j50 a = ((l50) k50).a(r50.a);
            Integer valueOf = a != null ? Integer.valueOf(a.b) : null;
            String str = r50.a;
            o50 o50 = (o50) n50;
            Objects.requireNonNull(o50);
            gz d = gz.d("SELECT name FROM workname WHERE work_spec_id=?", 1);
            if (str == null) {
                d.h(1);
            } else {
                d.i(1, str);
            }
            o50.a.b();
            Cursor b = lz.b(o50.a, d, false, null);
            try {
                ArrayList arrayList = new ArrayList(b.getCount());
                while (b.moveToNext()) {
                    arrayList.add(b.getString(0));
                }
                b.close();
                d.j();
                sb.append(String.format("\n%s\t %s\t %s\t %s\t %s\t %s\t", r50.a, r50.c, valueOf, r50.b.name(), TextUtils.join(",", arrayList), TextUtils.join(",", ((w50) v50).a(r50.a))));
            } catch (Throwable th) {
                b.close();
                d.j();
                throw th;
            }
        }
        return sb.toString();
    }

    @Override // androidx.work.Worker
    public ListenableWorker.a g() {
        gz gzVar;
        Throwable th;
        k50 k50;
        v50 v50;
        n50 n50;
        int i;
        WorkDatabase workDatabase = q30.b(this.g).c;
        s50 r = workDatabase.r();
        n50 p = workDatabase.p();
        v50 s = workDatabase.s();
        k50 o = workDatabase.o();
        long currentTimeMillis = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(1);
        t50 t50 = (t50) r;
        Objects.requireNonNull(t50);
        gz d = gz.d("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground` FROM workspec WHERE period_start_time >= ? AND state IN (2, 3, 5) ORDER BY period_start_time DESC", 1);
        d.e(1, currentTimeMillis);
        t50.a.b();
        Cursor b = lz.b(t50.a, d, false, null);
        try {
            int h = pu.h(b, "required_network_type");
            int h2 = pu.h(b, "requires_charging");
            int h3 = pu.h(b, "requires_device_idle");
            int h4 = pu.h(b, "requires_battery_not_low");
            int h5 = pu.h(b, "requires_storage_not_low");
            int h6 = pu.h(b, "trigger_content_update_delay");
            int h7 = pu.h(b, "trigger_max_content_delay");
            int h8 = pu.h(b, "content_uri_triggers");
            int h9 = pu.h(b, "id");
            int h10 = pu.h(b, "state");
            int h11 = pu.h(b, "worker_class_name");
            int h12 = pu.h(b, "input_merger_class_name");
            int h13 = pu.h(b, "input");
            int h14 = pu.h(b, "output");
            gzVar = d;
            try {
                int h15 = pu.h(b, "initial_delay");
                int h16 = pu.h(b, "interval_duration");
                int h17 = pu.h(b, "flex_duration");
                int h18 = pu.h(b, "run_attempt_count");
                int h19 = pu.h(b, "backoff_policy");
                int h20 = pu.h(b, "backoff_delay_duration");
                int h21 = pu.h(b, "period_start_time");
                int h22 = pu.h(b, "minimum_retention_duration");
                int h23 = pu.h(b, "schedule_requested_at");
                int h24 = pu.h(b, "run_in_foreground");
                int i2 = h14;
                ArrayList arrayList = new ArrayList(b.getCount());
                while (b.moveToNext()) {
                    String string = b.getString(h9);
                    String string2 = b.getString(h11);
                    m20 m20 = new m20();
                    m20.a = pu.m(b.getInt(h));
                    m20.b = b.getInt(h2) != 0;
                    m20.c = b.getInt(h3) != 0;
                    m20.d = b.getInt(h4) != 0;
                    m20.e = b.getInt(h5) != 0;
                    m20.f = b.getLong(h6);
                    m20.g = b.getLong(h7);
                    m20.h = pu.a(b.getBlob(h8));
                    r50 r50 = new r50(string, string2);
                    r50.b = pu.n(b.getInt(h10));
                    r50.d = b.getString(h12);
                    r50.e = o20.a(b.getBlob(h13));
                    r50.f = o20.a(b.getBlob(i2));
                    i2 = i2;
                    r50.g = b.getLong(h15);
                    r50.h = b.getLong(h16);
                    r50.i = b.getLong(h17);
                    r50.k = b.getInt(h18);
                    r50.l = pu.l(b.getInt(h19));
                    h17 = h17;
                    r50.m = b.getLong(h20);
                    r50.n = b.getLong(h21);
                    h21 = h21;
                    r50.o = b.getLong(h22);
                    h22 = h22;
                    r50.p = b.getLong(h23);
                    r50.q = b.getInt(h24) != 0;
                    r50.j = m20;
                    arrayList.add(r50);
                    h23 = h23;
                    h24 = h24;
                    h2 = h2;
                    h10 = h10;
                    h12 = h12;
                    h11 = h11;
                    h3 = h3;
                    h = h;
                    h15 = h15;
                    h9 = h9;
                    h20 = h20;
                    h13 = h13;
                    h16 = h16;
                    h18 = h18;
                    h19 = h19;
                }
                b.close();
                gzVar.j();
                t50 t502 = (t50) r;
                List<r50> e = t502.e();
                List<r50> b2 = t502.b();
                if (!arrayList.isEmpty()) {
                    u20 c = u20.c();
                    String str = k;
                    i = 0;
                    c.d(str, "Recently completed work:\n\n", new Throwable[0]);
                    k50 = o;
                    n50 = p;
                    v50 = s;
                    u20.c().d(str, h(n50, v50, k50, arrayList), new Throwable[0]);
                } else {
                    k50 = o;
                    n50 = p;
                    v50 = s;
                    i = 0;
                }
                if (!((ArrayList) e).isEmpty()) {
                    u20 c2 = u20.c();
                    String str2 = k;
                    c2.d(str2, "Running work:\n\n", new Throwable[i]);
                    u20.c().d(str2, h(n50, v50, k50, e), new Throwable[i]);
                }
                if (!((ArrayList) b2).isEmpty()) {
                    u20 c3 = u20.c();
                    String str3 = k;
                    c3.d(str3, "Enqueued work:\n\n", new Throwable[i]);
                    u20.c().d(str3, h(n50, v50, k50, b2), new Throwable[i]);
                }
                return new ListenableWorker.a.c();
            } catch (Throwable th2) {
                th = th2;
                b.close();
                gzVar.j();
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            gzVar = d;
            b.close();
            gzVar.j();
            throw th;
        }
    }
}
