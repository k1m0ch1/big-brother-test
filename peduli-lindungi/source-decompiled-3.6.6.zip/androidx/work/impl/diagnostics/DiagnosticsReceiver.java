package androidx.work.impl.diagnostics;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.work.impl.workers.DiagnosticsWorker;

public class DiagnosticsReceiver extends BroadcastReceiver {
    public static final String a = u20.e("DiagnosticsRcvr");

    public void onReceive(Context context, Intent intent) {
        if (intent != null) {
            u20.c().a(a, "Requesting diagnostics", new Throwable[0]);
            try {
                q30.b(context).a(w20.b(DiagnosticsWorker.class));
            } catch (IllegalStateException e) {
                u20.c().b(a, "WorkManager is not initialized", e);
            }
        }
    }
}
