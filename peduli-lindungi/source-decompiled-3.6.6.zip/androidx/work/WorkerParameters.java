package androidx.work;

import android.net.Uri;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Executor;

public final class WorkerParameters {
    public UUID a;
    public o20 b;
    public Executor c;
    public e30 d;

    public static class a {
        public List<String> a = Collections.emptyList();
        public List<Uri> b = Collections.emptyList();
    }

    public WorkerParameters(UUID uuid, o20 o20, Collection<String> collection, a aVar, int i, Executor executor, o60 o60, e30 e30, y20 y20, i60 i60) {
        this.a = uuid;
        this.b = o20;
        new HashSet(collection);
        this.c = executor;
        this.d = e30;
    }
}
