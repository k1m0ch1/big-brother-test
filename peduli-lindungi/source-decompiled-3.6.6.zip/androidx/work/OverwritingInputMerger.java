package androidx.work;

import defpackage.o20;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public final class OverwritingInputMerger extends r20 {
    @Override // defpackage.r20
    public o20 a(List<o20> list) {
        o20.a aVar = new o20.a();
        HashMap hashMap = new HashMap();
        for (o20 o20 : list) {
            hashMap.putAll(Collections.unmodifiableMap(o20.a));
        }
        aVar.b(hashMap);
        return aVar.a();
    }
}
