package androidx.work;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.Keep;

public abstract class ListenableWorker {
    public Context g;
    public WorkerParameters h;
    public boolean i;

    @Keep
    @SuppressLint({"BanKeepAnnotation"})
    public ListenableWorker(Context context, WorkerParameters workerParameters) {
        if (context == null) {
            throw new IllegalArgumentException("Application Context is null");
        } else if (workerParameters != null) {
            this.g = context;
            this.h = workerParameters;
        } else {
            throw new IllegalArgumentException("WorkerParameters is null");
        }
    }

    public boolean a() {
        return false;
    }

    public void b() {
    }

    public abstract g03<a> c();

    public final void f() {
        b();
    }

    public static abstract class a {

        /* renamed from: androidx.work.ListenableWorker$a$a  reason: collision with other inner class name */
        public static final class C0005a extends a {
            public final o20 a = o20.c;

            public boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                if (obj == null || C0005a.class != obj.getClass()) {
                    return false;
                }
                return this.a.equals(((C0005a) obj).a);
            }

            public int hashCode() {
                return this.a.hashCode() + (C0005a.class.getName().hashCode() * 31);
            }

            public String toString() {
                StringBuilder J0 = ze0.J0("Failure {mOutputData=");
                J0.append(this.a);
                J0.append('}');
                return J0.toString();
            }
        }

        public static final class b extends a {
            public boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                return obj != null && b.class == obj.getClass();
            }

            public int hashCode() {
                return b.class.getName().hashCode();
            }

            public String toString() {
                return "Retry";
            }
        }

        public static final class c extends a {
            public final o20 a;

            public c() {
                this.a = o20.c;
            }

            public boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                if (obj == null || c.class != obj.getClass()) {
                    return false;
                }
                return this.a.equals(((c) obj).a);
            }

            public int hashCode() {
                return this.a.hashCode() + (c.class.getName().hashCode() * 31);
            }

            public String toString() {
                StringBuilder J0 = ze0.J0("Success {mOutputData=");
                J0.append(this.a);
                J0.append('}');
                return J0.toString();
            }

            public c(o20 o20) {
                this.a = o20;
            }
        }
    }
}
