package androidx.media;

import android.app.Service;
import android.content.Intent;
import android.media.browse.MediaBrowser;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.service.media.MediaBrowserService;
import android.support.v4.media.MediaBrowserCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.text.TextUtils;
import android.util.Log;
import defpackage.nt;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

public abstract class MediaBrowserServiceCompat extends Service {
    public static final boolean j = Log.isLoggable("MBServiceCompat", 3);
    public b g;
    public final mg<IBinder, a> h = new mg<>();
    public final k i = new k();

    public class a implements IBinder.DeathRecipient {
        public final String a;
        public final i b;
        public final HashMap<String, List<hn<IBinder, Bundle>>> c = new HashMap<>();

        /* renamed from: androidx.media.MediaBrowserServiceCompat$a$a  reason: collision with other inner class name */
        public class RunnableC0003a implements Runnable {
            public RunnableC0003a() {
            }

            public void run() {
                a aVar = a.this;
                MediaBrowserServiceCompat.this.h.remove(((j) aVar.b).a());
            }
        }

        public a(String str, int i, int i2, Bundle bundle, i iVar) {
            this.a = str;
            if (Build.VERSION.SDK_INT >= 28) {
                new ot(str, i, i2);
            }
            this.b = iVar;
        }

        public void binderDied() {
            MediaBrowserServiceCompat.this.i.post(new RunnableC0003a());
        }
    }

    public interface b {
        void d();
    }

    public class c implements b, kt {
        public final List<Bundle> a = new ArrayList();
        public Object b;
        public Messenger c;

        public class a extends g<List<MediaBrowserCompat.MediaItem>> {
            public final /* synthetic */ jt e;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            public a(c cVar, Object obj, jt jtVar) {
                super(obj);
                this.e = jtVar;
            }

            /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object] */
            @Override // androidx.media.MediaBrowserServiceCompat.g
            public void c(List<MediaBrowserCompat.MediaItem> list) {
                ArrayList arrayList;
                List<MediaBrowserCompat.MediaItem> list2 = list;
                if (list2 != null) {
                    arrayList = new ArrayList();
                    for (MediaBrowserCompat.MediaItem mediaItem : list2) {
                        Parcel obtain = Parcel.obtain();
                        mediaItem.writeToParcel(obtain, 0);
                        arrayList.add(obtain);
                    }
                } else {
                    arrayList = null;
                }
                this.e.a(arrayList);
            }
        }

        public c() {
        }

        @Override // defpackage.kt
        public void a(String str, jt<List<Parcel>> jtVar) {
            MediaBrowserServiceCompat.this.c(str, new a(this, str, jtVar));
        }

        @Override // androidx.media.MediaBrowserServiceCompat.b
        public void d() {
            it itVar = new it(MediaBrowserServiceCompat.this, this);
            this.b = itVar;
            itVar.onCreate();
        }

        @Override // defpackage.kt
        public ht e(String str, int i, Bundle bundle) {
            if (!(bundle == null || bundle.getInt("extra_client_version", 0) == 0)) {
                bundle.remove("extra_client_version");
                this.c = new Messenger(MediaBrowserServiceCompat.this.i);
                Bundle M0 = ze0.M0("extra_service_version", 2);
                M0.putBinder("extra_messenger", this.c.getBinder());
                Objects.requireNonNull(MediaBrowserServiceCompat.this);
                this.a.add(M0);
            }
            MediaBrowserServiceCompat mediaBrowserServiceCompat = MediaBrowserServiceCompat.this;
            new HashMap();
            if (Build.VERSION.SDK_INT >= 28) {
                new ot(str, -1, i);
            }
            Objects.requireNonNull(mediaBrowserServiceCompat);
            MediaBrowserServiceCompat.this.b(str, i, bundle);
            Objects.requireNonNull(MediaBrowserServiceCompat.this);
            return null;
        }
    }

    public class d extends c implements mt {

        public class a extends g<MediaBrowserCompat.MediaItem> {
            public final /* synthetic */ jt e;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            public a(d dVar, Object obj, jt jtVar) {
                super(obj);
                this.e = jtVar;
            }

            /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object] */
            @Override // androidx.media.MediaBrowserServiceCompat.g
            public void c(MediaBrowserCompat.MediaItem mediaItem) {
                MediaBrowserCompat.MediaItem mediaItem2 = mediaItem;
                if (mediaItem2 == null) {
                    this.e.a(null);
                    return;
                }
                Parcel obtain = Parcel.obtain();
                mediaItem2.writeToParcel(obtain, 0);
                this.e.a(obtain);
            }
        }

        public d() {
            super();
        }

        @Override // defpackage.mt
        public void b(String str, jt<Parcel> jtVar) {
            MediaBrowserServiceCompat.this.e(new a(this, str, jtVar));
        }

        @Override // androidx.media.MediaBrowserServiceCompat.c, androidx.media.MediaBrowserServiceCompat.b
        public void d() {
            lt ltVar = new lt(MediaBrowserServiceCompat.this, this);
            this.b = ltVar;
            ltVar.onCreate();
        }
    }

    public class e extends d implements nt.c {

        public class a extends g<List<MediaBrowserCompat.MediaItem>> {
            public final /* synthetic */ nt.b e;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            public a(e eVar, Object obj, nt.b bVar) {
                super(obj);
                this.e = bVar;
            }

            /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object] */
            @Override // androidx.media.MediaBrowserServiceCompat.g
            public void c(List<MediaBrowserCompat.MediaItem> list) {
                ArrayList<Parcel> arrayList;
                List<MediaBrowserCompat.MediaItem> list2 = list;
                ArrayList arrayList2 = null;
                if (list2 != null) {
                    arrayList = new ArrayList();
                    for (MediaBrowserCompat.MediaItem mediaItem : list2) {
                        Parcel obtain = Parcel.obtain();
                        mediaItem.writeToParcel(obtain, 0);
                        arrayList.add(obtain);
                    }
                } else {
                    arrayList = null;
                }
                nt.b bVar = this.e;
                int i = this.d;
                Objects.requireNonNull(bVar);
                try {
                    nt.a.setInt(bVar.a, i);
                } catch (IllegalAccessException e2) {
                    Log.w("MBSCompatApi26", e2);
                }
                MediaBrowserService.Result result = bVar.a;
                if (arrayList != null) {
                    arrayList2 = new ArrayList();
                    for (Parcel parcel : arrayList) {
                        parcel.setDataPosition(0);
                        arrayList2.add(MediaBrowser.MediaItem.CREATOR.createFromParcel(parcel));
                        parcel.recycle();
                    }
                }
                result.sendResult(arrayList2);
            }
        }

        public e() {
            super();
        }

        @Override // defpackage.nt.c
        public void c(String str, nt.b bVar, Bundle bundle) {
            MediaBrowserServiceCompat.this.d(str, new a(this, str, bVar));
        }

        @Override // androidx.media.MediaBrowserServiceCompat.c, androidx.media.MediaBrowserServiceCompat.b, androidx.media.MediaBrowserServiceCompat.d
        public void d() {
            MediaBrowserServiceCompat mediaBrowserServiceCompat = MediaBrowserServiceCompat.this;
            Field field = nt.a;
            nt.a aVar = new nt.a(mediaBrowserServiceCompat, this);
            this.b = aVar;
            aVar.onCreate();
        }
    }

    public class f extends e {
        public f(MediaBrowserServiceCompat mediaBrowserServiceCompat) {
            super();
        }
    }

    public static class g<T> {
        public final Object a;
        public boolean b;
        public boolean c;
        public int d;

        public g(Object obj) {
            this.a = obj;
        }

        public boolean a() {
            return this.b || this.c;
        }

        public void b(Bundle bundle) {
            StringBuilder J0 = ze0.J0("It is not supported to send an error for ");
            J0.append(this.a);
            throw new UnsupportedOperationException(J0.toString());
        }

        public void c(T t) {
            throw null;
        }

        public void d(T t) {
            if (this.b || this.c) {
                StringBuilder J0 = ze0.J0("sendResult() called when either sendResult() or sendError() had already been called for: ");
                J0.append(this.a);
                throw new IllegalStateException(J0.toString());
            }
            this.b = true;
            c(null);
        }
    }

    public class h {
        public h() {
        }
    }

    public interface i {
    }

    public static class j implements i {
        public final Messenger a;

        public j(Messenger messenger) {
            this.a = messenger;
        }

        public IBinder a() {
            return this.a.getBinder();
        }

        public void b(String str, List<MediaBrowserCompat.MediaItem> list, Bundle bundle, Bundle bundle2) {
            Bundle bundle3 = new Bundle();
            bundle3.putString("data_media_item_id", str);
            bundle3.putBundle("data_options", bundle);
            bundle3.putBundle("data_notify_children_changed_options", bundle2);
            if (list != null) {
                bundle3.putParcelableArrayList("data_media_item_list", list instanceof ArrayList ? (ArrayList) list : new ArrayList<>(list));
            }
            c(3, bundle3);
        }

        public final void c(int i, Bundle bundle) {
            Message obtain = Message.obtain();
            obtain.what = i;
            obtain.arg1 = 2;
            obtain.setData(bundle);
            this.a.send(obtain);
        }
    }

    public final class k extends Handler {
        public final h a;

        public k() {
            this.a = new h();
        }

        public void a(Runnable runnable) {
            if (Thread.currentThread() == getLooper().getThread()) {
                runnable.run();
            } else {
                post(runnable);
            }
        }

        public void handleMessage(Message message) {
            Bundle data = message.getData();
            switch (message.what) {
                case 1:
                    Bundle bundle = data.getBundle("data_root_hints");
                    MediaSessionCompat.a(bundle);
                    h hVar = this.a;
                    String string = data.getString("data_package_name");
                    int i = data.getInt("data_calling_pid");
                    int i2 = data.getInt("data_calling_uid");
                    j jVar = new j(message.replyTo);
                    MediaBrowserServiceCompat mediaBrowserServiceCompat = MediaBrowserServiceCompat.this;
                    Objects.requireNonNull(mediaBrowserServiceCompat);
                    boolean z = false;
                    if (string != null) {
                        String[] packagesForUid = mediaBrowserServiceCompat.getPackageManager().getPackagesForUid(i2);
                        int length = packagesForUid.length;
                        int i3 = 0;
                        while (true) {
                            if (i3 < length) {
                                if (packagesForUid[i3].equals(string)) {
                                    z = true;
                                } else {
                                    i3++;
                                }
                            }
                        }
                    }
                    if (z) {
                        MediaBrowserServiceCompat.this.i.a(new ys(hVar, jVar, string, i, i2, bundle));
                        return;
                    }
                    throw new IllegalArgumentException("Package/uid mismatch: uid=" + i2 + " package=" + string);
                case 2:
                    h hVar2 = this.a;
                    MediaBrowserServiceCompat.this.i.a(new zs(hVar2, new j(message.replyTo)));
                    return;
                case 3:
                    Bundle bundle2 = data.getBundle("data_options");
                    MediaSessionCompat.a(bundle2);
                    h hVar3 = this.a;
                    String string2 = data.getString("data_media_item_id");
                    IBinder binder = data.getBinder("data_callback_token");
                    MediaBrowserServiceCompat.this.i.a(new at(hVar3, new j(message.replyTo), string2, binder, bundle2));
                    return;
                case 4:
                    h hVar4 = this.a;
                    String string3 = data.getString("data_media_item_id");
                    IBinder binder2 = data.getBinder("data_callback_token");
                    MediaBrowserServiceCompat.this.i.a(new bt(hVar4, new j(message.replyTo), string3, binder2));
                    return;
                case 5:
                    h hVar5 = this.a;
                    String string4 = data.getString("data_media_item_id");
                    e0 e0Var = (e0) data.getParcelable("data_result_receiver");
                    j jVar2 = new j(message.replyTo);
                    Objects.requireNonNull(hVar5);
                    if (!TextUtils.isEmpty(string4) && e0Var != null) {
                        MediaBrowserServiceCompat.this.i.a(new ct(hVar5, jVar2, string4, e0Var));
                        return;
                    }
                    return;
                case 6:
                    Bundle bundle3 = data.getBundle("data_root_hints");
                    MediaSessionCompat.a(bundle3);
                    h hVar6 = this.a;
                    MediaBrowserServiceCompat.this.i.a(new dt(hVar6, new j(message.replyTo), data.getString("data_package_name"), data.getInt("data_calling_pid"), data.getInt("data_calling_uid"), bundle3));
                    return;
                case 7:
                    h hVar7 = this.a;
                    MediaBrowserServiceCompat.this.i.a(new et(hVar7, new j(message.replyTo)));
                    return;
                case 8:
                    Bundle bundle4 = data.getBundle("data_search_extras");
                    MediaSessionCompat.a(bundle4);
                    h hVar8 = this.a;
                    String string5 = data.getString("data_search_query");
                    e0 e0Var2 = (e0) data.getParcelable("data_result_receiver");
                    j jVar3 = new j(message.replyTo);
                    Objects.requireNonNull(hVar8);
                    if (!TextUtils.isEmpty(string5) && e0Var2 != null) {
                        MediaBrowserServiceCompat.this.i.a(new ft(hVar8, jVar3, string5, bundle4, e0Var2));
                        return;
                    }
                    return;
                case 9:
                    Bundle bundle5 = data.getBundle("data_custom_action_extras");
                    MediaSessionCompat.a(bundle5);
                    h hVar9 = this.a;
                    String string6 = data.getString("data_custom_action");
                    e0 e0Var3 = (e0) data.getParcelable("data_result_receiver");
                    j jVar4 = new j(message.replyTo);
                    Objects.requireNonNull(hVar9);
                    if (!TextUtils.isEmpty(string6) && e0Var3 != null) {
                        MediaBrowserServiceCompat.this.i.a(new gt(hVar9, jVar4, string6, bundle5, e0Var3));
                        return;
                    }
                    return;
                default:
                    Log.w("MBServiceCompat", "Unhandled message: " + message + "\n  Service version: " + 2 + "\n  Client version: " + message.arg1);
                    return;
            }
        }

        public boolean sendMessageAtTime(Message message, long j) {
            Bundle data = message.getData();
            data.setClassLoader(MediaBrowserCompat.class.getClassLoader());
            data.putInt("data_calling_uid", Binder.getCallingUid());
            data.putInt("data_calling_pid", Binder.getCallingPid());
            return super.sendMessageAtTime(message, j);
        }
    }

    /* JADX WARN: Incorrect args count in method signature: (Ljava/lang/String;Landroid/os/Bundle;Landroidx/media/MediaBrowserServiceCompat$g<Landroid/os/Bundle;>;)V */
    public void a(g gVar) {
        if (gVar.b || gVar.c) {
            StringBuilder J0 = ze0.J0("sendError() called when either sendResult() or sendError() had already been called for: ");
            J0.append(gVar.a);
            throw new IllegalStateException(J0.toString());
        }
        gVar.c = true;
        gVar.b(null);
    }

    public abstract void b(String str, int i2, Bundle bundle);

    public abstract void c(String str, g<List<MediaBrowserCompat.MediaItem>> gVar);

    /* JADX WARN: Incorrect args count in method signature: (Ljava/lang/String;Landroidx/media/MediaBrowserServiceCompat$g<Ljava/util/List<Landroid/support/v4/media/MediaBrowserCompat$MediaItem;>;>;Landroid/os/Bundle;)V */
    public void d(String str, g gVar) {
        gVar.d = 1;
        c(str, gVar);
    }

    public void dump(FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
    }

    /* JADX WARN: Incorrect args count in method signature: (Ljava/lang/String;Landroidx/media/MediaBrowserServiceCompat$g<Landroid/support/v4/media/MediaBrowserCompat$MediaItem;>;)V */
    public void e(g gVar) {
        gVar.d = 2;
        gVar.d(null);
    }

    /* JADX WARN: Incorrect args count in method signature: (Ljava/lang/String;Landroid/os/Bundle;Landroidx/media/MediaBrowserServiceCompat$g<Ljava/util/List<Landroid/support/v4/media/MediaBrowserCompat$MediaItem;>;>;)V */
    public void f(g gVar) {
        gVar.d = 4;
        gVar.d(null);
    }

    public void g() {
    }

    public void h() {
    }

    public IBinder onBind(Intent intent) {
        return ((MediaBrowserService) ((c) this.g).b).onBind(intent);
    }

    public void onCreate() {
        super.onCreate();
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 28) {
            this.g = new f(this);
        } else if (i2 >= 26) {
            this.g = new e();
        } else if (i2 >= 23) {
            this.g = new d();
        } else {
            this.g = new c();
        }
        this.g.d();
    }
}
