package androidx.media;

import androidx.versionedparcelable.VersionedParcel;
import java.util.Objects;

public final class AudioAttributesCompatParcelizer {
    public static AudioAttributesCompat read(VersionedParcel versionedParcel) {
        AudioAttributesCompat audioAttributesCompat = new AudioAttributesCompat();
        q10 q10 = audioAttributesCompat.a;
        if (versionedParcel.i(1)) {
            q10 = versionedParcel.o();
        }
        audioAttributesCompat.a = (AudioAttributesImpl) q10;
        return audioAttributesCompat;
    }

    public static void write(AudioAttributesCompat audioAttributesCompat, VersionedParcel versionedParcel) {
        Objects.requireNonNull(versionedParcel);
        AudioAttributesImpl audioAttributesImpl = audioAttributesCompat.a;
        versionedParcel.p(1);
        versionedParcel.w(audioAttributesImpl);
    }
}
