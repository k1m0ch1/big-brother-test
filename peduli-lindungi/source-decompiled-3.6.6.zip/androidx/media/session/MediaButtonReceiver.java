package androidx.media.session;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.media.browse.MediaBrowser;
import android.media.session.MediaController;
import android.os.Build;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.v4.media.MediaBrowserCompat;
import android.support.v4.media.session.MediaControllerCompat$MediaControllerImplApi21;
import android.support.v4.media.session.MediaSessionCompat;
import android.util.Log;
import android.view.KeyEvent;
import java.util.HashSet;
import java.util.List;

public class MediaButtonReceiver extends BroadcastReceiver {

    public static class a extends MediaBrowserCompat.b {
        public final Context c;
        public final Intent d;
        public final BroadcastReceiver.PendingResult e;
        public MediaBrowserCompat f;

        public a(Context context, Intent intent, BroadcastReceiver.PendingResult pendingResult) {
            this.c = context;
            this.d = intent;
            this.e = pendingResult;
        }

        @Override // android.support.v4.media.MediaBrowserCompat.b
        public void a() {
            MediaControllerCompat$MediaControllerImplApi21 mediaControllerCompat$MediaControllerImplApi21;
            try {
                Context context = this.c;
                MediaBrowserCompat.d dVar = (MediaBrowserCompat.d) this.f.a;
                if (dVar.h == null) {
                    dVar.h = MediaSessionCompat.Token.a(((MediaBrowser) dVar.b).getSessionToken(), null);
                }
                MediaSessionCompat.Token token = dVar.h;
                new HashSet();
                if (token != null) {
                    int i = Build.VERSION.SDK_INT;
                    if (i >= 24) {
                        mediaControllerCompat$MediaControllerImplApi21 = new a0(context, token);
                    } else if (i >= 23) {
                        mediaControllerCompat$MediaControllerImplApi21 = new z(context, token);
                    } else {
                        mediaControllerCompat$MediaControllerImplApi21 = new MediaControllerCompat$MediaControllerImplApi21(context, token);
                    }
                    KeyEvent keyEvent = (KeyEvent) this.d.getParcelableExtra("android.intent.extra.KEY_EVENT");
                    if (keyEvent != null) {
                        ((MediaController) mediaControllerCompat$MediaControllerImplApi21.a).dispatchMediaButtonEvent(keyEvent);
                        b();
                        return;
                    }
                    throw new IllegalArgumentException("KeyEvent may not be null");
                }
                throw new IllegalArgumentException("sessionToken must not be null");
            } catch (RemoteException e2) {
                Log.e("MediaButtonReceiver", "Failed to create a media controller", e2);
            }
        }

        public final void b() {
            Messenger messenger;
            MediaBrowserCompat.d dVar = (MediaBrowserCompat.d) this.f.a;
            MediaBrowserCompat.h hVar = dVar.f;
            if (!(hVar == null || (messenger = dVar.g) == null)) {
                try {
                    hVar.a(7, null, messenger);
                } catch (RemoteException unused) {
                    Log.i("MediaBrowserCompat", "Remote error unregistering client messenger.");
                }
            }
            ((MediaBrowser) dVar.b).disconnect();
            this.e.finish();
        }
    }

    public static ComponentName a(Context context, String str) {
        PackageManager packageManager = context.getPackageManager();
        Intent intent = new Intent(str);
        intent.setPackage(context.getPackageName());
        List<ResolveInfo> queryIntentServices = packageManager.queryIntentServices(intent, 0);
        if (queryIntentServices.size() == 1) {
            ServiceInfo serviceInfo = queryIntentServices.get(0).serviceInfo;
            return new ComponentName(serviceInfo.packageName, serviceInfo.name);
        } else if (queryIntentServices.isEmpty()) {
            return null;
        } else {
            StringBuilder O0 = ze0.O0("Expected 1 service that handles ", str, ", found ");
            O0.append(queryIntentServices.size());
            throw new IllegalStateException(O0.toString());
        }
    }

    public void onReceive(Context context, Intent intent) {
        if (intent == null || !"android.intent.action.MEDIA_BUTTON".equals(intent.getAction()) || !intent.hasExtra("android.intent.extra.KEY_EVENT")) {
            Log.d("MediaButtonReceiver", "Ignore unsupported intent: " + intent);
            return;
        }
        ComponentName a2 = a(context, "android.intent.action.MEDIA_BUTTON");
        if (a2 != null) {
            intent.setComponent(a2);
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(intent);
            } else {
                context.startService(intent);
            }
        } else {
            ComponentName a3 = a(context, "android.media.browse.MediaBrowserService");
            if (a3 != null) {
                BroadcastReceiver.PendingResult goAsync = goAsync();
                Context applicationContext = context.getApplicationContext();
                a aVar = new a(applicationContext, intent, goAsync);
                MediaBrowserCompat mediaBrowserCompat = new MediaBrowserCompat(applicationContext, a3, aVar, null);
                aVar.f = mediaBrowserCompat;
                ((MediaBrowser) ((MediaBrowserCompat.d) mediaBrowserCompat.a).b).connect();
                return;
            }
            throw new IllegalStateException("Could not find any Service that handles android.intent.action.MEDIA_BUTTON or implements a media browser service.");
        }
    }
}
