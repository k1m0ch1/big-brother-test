package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcelable;
import androidx.versionedparcelable.VersionedParcel;
import java.nio.charset.Charset;
import java.util.Objects;

public class IconCompatParcelizer {
    public static IconCompat read(VersionedParcel versionedParcel) {
        IconCompat iconCompat = new IconCompat();
        iconCompat.a = versionedParcel.k(iconCompat.a, 1);
        byte[] bArr = iconCompat.c;
        if (versionedParcel.i(2)) {
            bArr = versionedParcel.g();
        }
        iconCompat.c = bArr;
        iconCompat.d = versionedParcel.m(iconCompat.d, 3);
        iconCompat.e = versionedParcel.k(iconCompat.e, 4);
        iconCompat.f = versionedParcel.k(iconCompat.f, 5);
        iconCompat.g = (ColorStateList) versionedParcel.m(iconCompat.g, 6);
        String str = iconCompat.i;
        if (versionedParcel.i(7)) {
            str = versionedParcel.n();
        }
        iconCompat.i = str;
        String str2 = iconCompat.j;
        if (versionedParcel.i(8)) {
            str2 = versionedParcel.n();
        }
        iconCompat.j = str2;
        iconCompat.h = PorterDuff.Mode.valueOf(iconCompat.i);
        switch (iconCompat.a) {
            case -1:
                Parcelable parcelable = iconCompat.d;
                if (parcelable != null) {
                    iconCompat.b = parcelable;
                    break;
                } else {
                    throw new IllegalArgumentException("Invalid icon");
                }
            case 1:
            case 5:
                Parcelable parcelable2 = iconCompat.d;
                if (parcelable2 == null) {
                    byte[] bArr2 = iconCompat.c;
                    iconCompat.b = bArr2;
                    iconCompat.a = 3;
                    iconCompat.e = 0;
                    iconCompat.f = bArr2.length;
                    break;
                } else {
                    iconCompat.b = parcelable2;
                    break;
                }
            case 2:
            case 4:
            case 6:
                String str3 = new String(iconCompat.c, Charset.forName("UTF-16"));
                iconCompat.b = str3;
                if (iconCompat.a == 2 && iconCompat.j == null) {
                    iconCompat.j = str3.split(":", -1)[0];
                    break;
                }
            case 3:
                iconCompat.b = iconCompat.c;
                break;
        }
        return iconCompat;
    }

    public static void write(IconCompat iconCompat, VersionedParcel versionedParcel) {
        Objects.requireNonNull(versionedParcel);
        iconCompat.i = iconCompat.h.name();
        switch (iconCompat.a) {
            case -1:
                iconCompat.d = (Parcelable) iconCompat.b;
                break;
            case 1:
            case 5:
                iconCompat.d = (Parcelable) iconCompat.b;
                break;
            case 2:
                iconCompat.c = ((String) iconCompat.b).getBytes(Charset.forName("UTF-16"));
                break;
            case 3:
                iconCompat.c = (byte[]) iconCompat.b;
                break;
            case 4:
            case 6:
                iconCompat.c = iconCompat.b.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i = iconCompat.a;
        if (-1 != i) {
            versionedParcel.p(1);
            versionedParcel.t(i);
        }
        byte[] bArr = iconCompat.c;
        if (bArr != null) {
            versionedParcel.p(2);
            versionedParcel.r(bArr);
        }
        Parcelable parcelable = iconCompat.d;
        if (parcelable != null) {
            versionedParcel.p(3);
            versionedParcel.u(parcelable);
        }
        int i2 = iconCompat.e;
        if (i2 != 0) {
            versionedParcel.p(4);
            versionedParcel.t(i2);
        }
        int i3 = iconCompat.f;
        if (i3 != 0) {
            versionedParcel.p(5);
            versionedParcel.t(i3);
        }
        ColorStateList colorStateList = iconCompat.g;
        if (colorStateList != null) {
            versionedParcel.p(6);
            versionedParcel.u(colorStateList);
        }
        String str = iconCompat.i;
        if (str != null) {
            versionedParcel.p(7);
            versionedParcel.v(str);
        }
        String str2 = iconCompat.j;
        if (str2 != null) {
            versionedParcel.p(8);
            versionedParcel.v(str2);
        }
    }
}
