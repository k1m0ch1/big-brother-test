package androidx.core.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import com.github.mikephil.charting.utils.Utils;
import com.telkom.tracencare.R;
import defpackage.co;
import defpackage.lo;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.KotlinVersion;

public class NestedScrollView extends FrameLayout implements tn, qn {
    public static final a G = new a();
    public static final int[] H = {16843130};
    public int A;
    public c B;
    public final un C;
    public final rn D;
    public float E;
    public b F;
    public long g;
    public final Rect h = new Rect();
    public OverScroller i;
    public EdgeEffect j;
    public EdgeEffect k;
    public int l;
    public boolean m = true;
    public boolean n = false;
    public View o = null;
    public boolean p = false;
    public VelocityTracker q;
    public boolean r;
    public boolean s = true;
    public int t;
    public int u;
    public int v;
    public int w = -1;
    public final int[] x = new int[2];
    public final int[] y = new int[2];
    public int z;

    public static class a extends mn {
        @Override // defpackage.mn
        public void c(View view, AccessibilityEvent accessibilityEvent) {
            this.a.onInitializeAccessibilityEvent(view, accessibilityEvent);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            accessibilityEvent.setClassName(ScrollView.class.getName());
            accessibilityEvent.setScrollable(nestedScrollView.getScrollRange() > 0);
            accessibilityEvent.setScrollX(nestedScrollView.getScrollX());
            accessibilityEvent.setScrollY(nestedScrollView.getScrollY());
            accessibilityEvent.setMaxScrollX(nestedScrollView.getScrollX());
            accessibilityEvent.setMaxScrollY(nestedScrollView.getScrollRange());
        }

        @Override // defpackage.mn
        public void d(View view, lo loVar) {
            int scrollRange;
            this.a.onInitializeAccessibilityNodeInfo(view, loVar.a);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            loVar.a.setClassName(ScrollView.class.getName());
            if (nestedScrollView.isEnabled() && (scrollRange = nestedScrollView.getScrollRange()) > 0) {
                loVar.a.setScrollable(true);
                if (nestedScrollView.getScrollY() > 0) {
                    loVar.a(lo.a.g);
                    loVar.a(lo.a.k);
                }
                if (nestedScrollView.getScrollY() < scrollRange) {
                    loVar.a(lo.a.f);
                    loVar.a(lo.a.l);
                }
            }
        }

        @Override // defpackage.mn
        public boolean g(View view, int i, Bundle bundle) {
            if (super.g(view, i, bundle)) {
                return true;
            }
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            if (!nestedScrollView.isEnabled()) {
                return false;
            }
            if (i != 4096) {
                if (i == 8192 || i == 16908344) {
                    int max = Math.max(nestedScrollView.getScrollY() - ((nestedScrollView.getHeight() - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), 0);
                    if (max == nestedScrollView.getScrollY()) {
                        return false;
                    }
                    nestedScrollView.z(0 - nestedScrollView.getScrollX(), max - nestedScrollView.getScrollY(), 250, true);
                    return true;
                } else if (i != 16908346) {
                    return false;
                }
            }
            int min = Math.min(nestedScrollView.getScrollY() + ((nestedScrollView.getHeight() - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), nestedScrollView.getScrollRange());
            if (min == nestedScrollView.getScrollY()) {
                return false;
            }
            nestedScrollView.z(0 - nestedScrollView.getScrollX(), min - nestedScrollView.getScrollY(), 250, true);
            return true;
        }
    }

    public interface b {
        void a(NestedScrollView nestedScrollView, int i, int i2, int i3, int i4);
    }

    public static class c extends View.BaseSavedState {
        public static final Parcelable.Creator<c> CREATOR = new a();
        public int g;

        public class a implements Parcelable.Creator<c> {
            /* Return type fixed from 'java.lang.Object' to match base method */
            @Override // android.os.Parcelable.Creator
            public c createFromParcel(Parcel parcel) {
                return new c(parcel);
            }

            /* Return type fixed from 'java.lang.Object[]' to match base method */
            @Override // android.os.Parcelable.Creator
            public c[] newArray(int i) {
                return new c[i];
            }
        }

        public c(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder J0 = ze0.J0("HorizontalScrollView.SavedState{");
            J0.append(Integer.toHexString(System.identityHashCode(this)));
            J0.append(" scrollPosition=");
            return ze0.w0(J0, this.g, "}");
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.g);
        }

        public c(Parcel parcel) {
            super(parcel);
            this.g = parcel.readInt();
        }
    }

    public NestedScrollView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.nestedScrollViewStyle);
        EdgeEffect edgeEffect;
        EdgeEffect edgeEffect2;
        if (ek.Q()) {
            edgeEffect = uo.a(context, attributeSet);
        } else {
            edgeEffect = new EdgeEffect(context);
        }
        this.j = edgeEffect;
        if (ek.Q()) {
            edgeEffect2 = uo.a(context, attributeSet);
        } else {
            edgeEffect2 = new EdgeEffect(context);
        }
        this.k = edgeEffect2;
        this.i = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.t = viewConfiguration.getScaledTouchSlop();
        this.u = viewConfiguration.getScaledMinimumFlingVelocity();
        this.v = viewConfiguration.getScaledMaximumFlingVelocity();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, H, R.attr.nestedScrollViewStyle, 0);
        setFillViewport(obtainStyledAttributes.getBoolean(0, false));
        obtainStyledAttributes.recycle();
        this.C = new un();
        this.D = new rn(this);
        setNestedScrollingEnabled(true);
        co.u(this, G);
    }

    public static int c(int i2, int i3, int i4) {
        if (i3 >= i4 || i2 < 0) {
            return 0;
        }
        return i3 + i2 > i4 ? i4 - i3 : i2;
    }

    private float getVerticalScrollFactorCompat() {
        if (this.E == Utils.FLOAT_EPSILON) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (context.getTheme().resolveAttribute(16842829, typedValue, true)) {
                this.E = typedValue.getDimension(context.getResources().getDisplayMetrics());
            } else {
                throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
            }
        }
        return this.E;
    }

    public static boolean q(View view, View view2) {
        if (view == view2) {
            return true;
        }
        ViewParent parent = view.getParent();
        if (!(parent instanceof ViewGroup) || !q((View) parent, view2)) {
            return false;
        }
        return true;
    }

    public boolean A(int i2, int i3) {
        return this.D.i(i2, i3);
    }

    public final boolean B(MotionEvent motionEvent) {
        boolean z2;
        if (ek.C(this.j) != Utils.FLOAT_EPSILON) {
            ek.Y(this.j, Utils.FLOAT_EPSILON, motionEvent.getY() / ((float) getHeight()));
            z2 = true;
        } else {
            z2 = false;
        }
        if (ek.C(this.k) == Utils.FLOAT_EPSILON) {
            return z2;
        }
        ek.Y(this.k, Utils.FLOAT_EPSILON, 1.0f - (motionEvent.getY() / ((float) getHeight())));
        return true;
    }

    public final void a() {
        this.i.abortAnimation();
        this.D.j(1);
    }

    public void addView(View view) {
        if (getChildCount() <= 0) {
            super.addView(view);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public boolean b(int i2) {
        View findFocus = findFocus();
        if (findFocus == this) {
            findFocus = null;
        }
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, i2);
        int maxScrollAmount = getMaxScrollAmount();
        if (findNextFocus == null || !r(findNextFocus, maxScrollAmount, getHeight())) {
            if (i2 == 33 && getScrollY() < maxScrollAmount) {
                maxScrollAmount = getScrollY();
            } else if (i2 == 130 && getChildCount() > 0) {
                View childAt = getChildAt(0);
                maxScrollAmount = Math.min((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - ((getHeight() + getScrollY()) - getPaddingBottom()), maxScrollAmount);
            }
            if (maxScrollAmount == 0) {
                return false;
            }
            if (i2 != 130) {
                maxScrollAmount = -maxScrollAmount;
            }
            f(maxScrollAmount);
        } else {
            findNextFocus.getDrawingRect(this.h);
            offsetDescendantRectToMyCoords(findNextFocus, this.h);
            f(d(this.h));
            findNextFocus.requestFocus(i2);
        }
        if (findFocus != null && findFocus.isFocused() && (!r(findFocus, 0, getHeight()))) {
            int descendantFocusability = getDescendantFocusability();
            setDescendantFocusability(131072);
            requestFocus();
            setDescendantFocusability(descendantFocusability);
        }
        return true;
    }

    public int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    public int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    public int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    public void computeScroll() {
        if (!this.i.isFinished()) {
            this.i.computeScrollOffset();
            int currY = this.i.getCurrY();
            int i2 = currY - this.A;
            this.A = currY;
            int[] iArr = this.y;
            boolean z2 = false;
            iArr[1] = 0;
            e(0, i2, iArr, null, 1);
            int i3 = i2 - this.y[1];
            int scrollRange = getScrollRange();
            if (i3 != 0) {
                int scrollY = getScrollY();
                u(0, i3, getScrollX(), scrollY, 0, scrollRange, 0, 0);
                int scrollY2 = getScrollY() - scrollY;
                int i4 = i3 - scrollY2;
                int[] iArr2 = this.y;
                iArr2[1] = 0;
                this.D.f(0, scrollY2, 0, i4, this.x, 1, iArr2);
                i3 = i4 - this.y[1];
            }
            if (i3 != 0) {
                int overScrollMode = getOverScrollMode();
                if (overScrollMode == 0 || (overScrollMode == 1 && scrollRange > 0)) {
                    z2 = true;
                }
                if (z2) {
                    if (i3 < 0) {
                        if (this.j.isFinished()) {
                            this.j.onAbsorb((int) this.i.getCurrVelocity());
                        }
                    } else if (this.k.isFinished()) {
                        this.k.onAbsorb((int) this.i.getCurrVelocity());
                    }
                }
                a();
            }
            if (!this.i.isFinished()) {
                AtomicInteger atomicInteger = co.a;
                co.c.k(this);
                return;
            }
            this.D.j(1);
        }
    }

    public int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    public int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    public int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int max = Math.max(0, bottom - height);
        if (scrollY < 0) {
            return bottom - scrollY;
        }
        return scrollY > max ? bottom + (scrollY - max) : bottom;
    }

    public int d(Rect rect) {
        int i2;
        int i3;
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i4 = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int i5 = rect.bottom < (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin ? i4 - verticalFadingEdgeLength : i4;
        int i6 = rect.bottom;
        if (i6 > i5 && rect.top > scrollY) {
            if (rect.height() > height) {
                i3 = rect.top - scrollY;
            } else {
                i3 = rect.bottom - i5;
            }
            return Math.min(i3 + 0, (childAt.getBottom() + layoutParams.bottomMargin) - i4);
        } else if (rect.top >= scrollY || i6 >= i5) {
            return 0;
        } else {
            if (rect.height() > height) {
                i2 = 0 - (i5 - rect.bottom);
            } else {
                i2 = 0 - (scrollY - rect.top);
            }
            return Math.max(i2, -getScrollY());
        }
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || g(keyEvent);
    }

    public boolean dispatchNestedFling(float f, float f2, boolean z2) {
        return this.D.a(f, f2, z2);
    }

    public boolean dispatchNestedPreFling(float f, float f2) {
        return this.D.b(f, f2);
    }

    public boolean dispatchNestedPreScroll(int i2, int i3, int[] iArr, int[] iArr2) {
        return e(i2, i3, iArr, iArr2, 0);
    }

    public boolean dispatchNestedScroll(int i2, int i3, int i4, int i5, int[] iArr) {
        return this.D.e(i2, i3, i4, i5, iArr);
    }

    public void draw(Canvas canvas) {
        int i2;
        super.draw(canvas);
        int scrollY = getScrollY();
        int i3 = 0;
        if (!this.j.isFinished()) {
            int save = canvas.save();
            int width = getWidth();
            int height = getHeight();
            int min = Math.min(0, scrollY);
            if (getClipToPadding()) {
                width -= getPaddingRight() + getPaddingLeft();
                i2 = getPaddingLeft() + 0;
            } else {
                i2 = 0;
            }
            if (getClipToPadding()) {
                height -= getPaddingBottom() + getPaddingTop();
                min += getPaddingTop();
            }
            canvas.translate((float) i2, (float) min);
            this.j.setSize(width, height);
            if (this.j.draw(canvas)) {
                AtomicInteger atomicInteger = co.a;
                co.c.k(this);
            }
            canvas.restoreToCount(save);
        }
        if (!this.k.isFinished()) {
            int save2 = canvas.save();
            int width2 = getWidth();
            int height2 = getHeight();
            int max = Math.max(getScrollRange(), scrollY) + height2;
            if (getClipToPadding()) {
                width2 -= getPaddingRight() + getPaddingLeft();
                i3 = 0 + getPaddingLeft();
            }
            if (getClipToPadding()) {
                height2 -= getPaddingBottom() + getPaddingTop();
                max -= getPaddingBottom();
            }
            canvas.translate((float) (i3 - width2), (float) max);
            canvas.rotate(180.0f, (float) width2, Utils.FLOAT_EPSILON);
            this.k.setSize(width2, height2);
            if (this.k.draw(canvas)) {
                AtomicInteger atomicInteger2 = co.a;
                co.c.k(this);
            }
            canvas.restoreToCount(save2);
        }
    }

    public boolean e(int i2, int i3, int[] iArr, int[] iArr2, int i4) {
        return this.D.c(i2, i3, iArr, iArr2, i4);
    }

    public final void f(int i2) {
        if (i2 == 0) {
            return;
        }
        if (this.s) {
            z(0, i2, 250, false);
        } else {
            scrollBy(0, i2);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:22:0x0062  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0038  */
    public boolean g(KeyEvent keyEvent) {
        boolean z2;
        this.h.setEmpty();
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            if (childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin > (getHeight() - getPaddingTop()) - getPaddingBottom()) {
                z2 = true;
                if (z2) {
                    if (!isFocused() || keyEvent.getKeyCode() == 4) {
                        return false;
                    }
                    View findFocus = findFocus();
                    if (findFocus == this) {
                        findFocus = null;
                    }
                    View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, 130);
                    if (findNextFocus == null || findNextFocus == this || !findNextFocus.requestFocus(130)) {
                        return false;
                    }
                    return true;
                } else if (keyEvent.getAction() != 0) {
                    return false;
                } else {
                    int keyCode = keyEvent.getKeyCode();
                    int i2 = 33;
                    if (keyCode != 19) {
                        if (keyCode != 20) {
                            if (keyCode != 62) {
                                return false;
                            }
                            if (!keyEvent.isShiftPressed()) {
                                i2 = 130;
                            }
                            boolean z3 = i2 == 130;
                            int height = getHeight();
                            if (z3) {
                                this.h.top = getScrollY() + height;
                                int childCount = getChildCount();
                                if (childCount > 0) {
                                    View childAt2 = getChildAt(childCount - 1);
                                    int paddingBottom = getPaddingBottom() + childAt2.getBottom() + ((FrameLayout.LayoutParams) childAt2.getLayoutParams()).bottomMargin;
                                    Rect rect = this.h;
                                    if (rect.top + height > paddingBottom) {
                                        rect.top = paddingBottom - height;
                                    }
                                }
                            } else {
                                this.h.top = getScrollY() - height;
                                Rect rect2 = this.h;
                                if (rect2.top < 0) {
                                    rect2.top = 0;
                                }
                            }
                            Rect rect3 = this.h;
                            int i3 = rect3.top;
                            int i4 = height + i3;
                            rect3.bottom = i4;
                            x(i2, i3, i4);
                            return false;
                        } else if (!keyEvent.isAltPressed()) {
                            return b(130);
                        } else {
                            return l(130);
                        }
                    } else if (!keyEvent.isAltPressed()) {
                        return b(33);
                    } else {
                        return l(33);
                    }
                }
            }
        }
        z2 = false;
        if (z2) {
        }
    }

    public float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return Utils.FLOAT_EPSILON;
        }
        View childAt = getChildAt(0);
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return ((float) bottom) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (((float) getHeight()) * 0.5f);
    }

    public int getNestedScrollAxes() {
        return this.C.a();
    }

    public int getScrollRange() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    public float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return Utils.FLOAT_EPSILON;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return ((float) scrollY) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    @Override // defpackage.sn
    public void h(View view, View view2, int i2, int i3) {
        un unVar = this.C;
        if (i3 == 1) {
            unVar.b = i2;
        } else {
            unVar.a = i2;
        }
        A(2, i3);
    }

    public boolean hasNestedScrollingParent() {
        return p(0);
    }

    @Override // defpackage.sn
    public void i(View view, int i2) {
        un unVar = this.C;
        if (i2 == 1) {
            unVar.b = 0;
        } else {
            unVar.a = 0;
        }
        this.D.j(i2);
    }

    public boolean isNestedScrollingEnabled() {
        return this.D.d;
    }

    @Override // defpackage.sn
    public void j(View view, int i2, int i3, int[] iArr, int i4) {
        e(i2, i3, iArr, null, i4);
    }

    public void k(int i2) {
        if (getChildCount() > 0) {
            this.i.fling(getScrollX(), getScrollY(), 0, i2, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, 0, 0);
            w(true);
        }
    }

    public boolean l(int i2) {
        int childCount;
        boolean z2 = i2 == 130;
        int height = getHeight();
        Rect rect = this.h;
        rect.top = 0;
        rect.bottom = height;
        if (z2 && (childCount = getChildCount()) > 0) {
            View childAt = getChildAt(childCount - 1);
            this.h.bottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
            Rect rect2 = this.h;
            rect2.top = rect2.bottom - height;
        }
        Rect rect3 = this.h;
        return x(i2, rect3.top, rect3.bottom);
    }

    @Override // defpackage.tn
    public void m(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        s(i5, i6, iArr);
    }

    public void measureChild(View view, int i2, int i3) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        view.measure(FrameLayout.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    public void measureChildWithMargins(View view, int i2, int i3, int i4, int i5) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(FrameLayout.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    @Override // defpackage.sn
    public void n(View view, int i2, int i3, int i4, int i5, int i6) {
        s(i5, i6, null);
    }

    @Override // defpackage.sn
    public boolean o(View view, View view2, int i2, int i3) {
        return (i2 & 2) != 0;
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.n = false;
    }

    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        if ((motionEvent.getSource() & 2) != 0 && motionEvent.getAction() == 8 && !this.p) {
            float axisValue = motionEvent.getAxisValue(9);
            if (axisValue != Utils.FLOAT_EPSILON) {
                int scrollRange = getScrollRange();
                int scrollY = getScrollY();
                int verticalScrollFactorCompat = scrollY - ((int) (axisValue * getVerticalScrollFactorCompat()));
                if (verticalScrollFactorCompat < 0) {
                    scrollRange = 0;
                } else if (verticalScrollFactorCompat <= scrollRange) {
                    scrollRange = verticalScrollFactorCompat;
                }
                if (scrollRange != scrollY) {
                    super.scrollTo(getScrollX(), scrollRange);
                    return true;
                }
            }
        }
        return false;
    }

    /* JADX WARNING: Removed duplicated region for block: B:47:0x00e6  */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x00fc  */
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z2;
        int action = motionEvent.getAction();
        boolean z3 = true;
        if (action == 2 && this.p) {
            return true;
        }
        int i2 = action & KotlinVersion.MAX_COMPONENT_VALUE;
        if (i2 != 0) {
            if (i2 != 1) {
                if (i2 == 2) {
                    int i3 = this.w;
                    if (i3 != -1) {
                        int findPointerIndex = motionEvent.findPointerIndex(i3);
                        if (findPointerIndex == -1) {
                            Log.e("NestedScrollView", "Invalid pointerId=" + i3 + " in onInterceptTouchEvent");
                        } else {
                            int y2 = (int) motionEvent.getY(findPointerIndex);
                            if (Math.abs(y2 - this.l) > this.t && (2 & getNestedScrollAxes()) == 0) {
                                this.p = true;
                                this.l = y2;
                                if (this.q == null) {
                                    this.q = VelocityTracker.obtain();
                                }
                                this.q.addMovement(motionEvent);
                                this.z = 0;
                                ViewParent parent = getParent();
                                if (parent != null) {
                                    parent.requestDisallowInterceptTouchEvent(true);
                                }
                            }
                        }
                    }
                } else if (i2 != 3) {
                    if (i2 == 6) {
                        t(motionEvent);
                    }
                }
            }
            this.p = false;
            this.w = -1;
            v();
            if (this.i.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                AtomicInteger atomicInteger = co.a;
                co.c.k(this);
            }
            this.D.j(0);
        } else {
            int y3 = (int) motionEvent.getY();
            int x2 = (int) motionEvent.getX();
            if (getChildCount() > 0) {
                int scrollY = getScrollY();
                View childAt = getChildAt(0);
                if (y3 >= childAt.getTop() - scrollY && y3 < childAt.getBottom() - scrollY && x2 >= childAt.getLeft() && x2 < childAt.getRight()) {
                    z2 = true;
                    if (z2) {
                        if (!B(motionEvent) && this.i.isFinished()) {
                            z3 = false;
                        }
                        this.p = z3;
                        v();
                    } else {
                        this.l = y3;
                        this.w = motionEvent.getPointerId(0);
                        VelocityTracker velocityTracker = this.q;
                        if (velocityTracker == null) {
                            this.q = VelocityTracker.obtain();
                        } else {
                            velocityTracker.clear();
                        }
                        this.q.addMovement(motionEvent);
                        this.i.computeScrollOffset();
                        if (!B(motionEvent) && this.i.isFinished()) {
                            z3 = false;
                        }
                        this.p = z3;
                        A(2, 0);
                    }
                }
            }
            z2 = false;
            if (z2) {
            }
        }
        return this.p;
    }

    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        int i6 = 0;
        this.m = false;
        View view = this.o;
        if (view != null && q(view, this)) {
            y(this.o);
        }
        this.o = null;
        if (!this.n) {
            if (this.B != null) {
                scrollTo(getScrollX(), this.B.g);
                this.B = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                i6 = childAt.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            }
            int paddingTop = ((i5 - i3) - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            int c2 = c(scrollY, paddingTop, i6);
            if (c2 != scrollY) {
                scrollTo(getScrollX(), c2);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.n = true;
    }

    public void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        if (this.r && View.MeasureSpec.getMode(i3) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int measuredHeight2 = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (measuredHeight < measuredHeight2) {
                childAt.measure(FrameLayout.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
            }
        }
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z2) {
        if (z2) {
            return false;
        }
        dispatchNestedFling(Utils.FLOAT_EPSILON, f2, true);
        k((int) f2);
        return true;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        return dispatchNestedPreFling(f, f2);
    }

    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
        e(i2, i3, iArr, null, 0);
    }

    public void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        s(i5, 0, null);
    }

    public void onNestedScrollAccepted(View view, View view2, int i2) {
        this.C.a = i2;
        A(2, 0);
    }

    public void onOverScrolled(int i2, int i3, boolean z2, boolean z3) {
        super.scrollTo(i2, i3);
    }

    public boolean onRequestFocusInDescendants(int i2, Rect rect) {
        View view;
        if (i2 == 2) {
            i2 = 130;
        } else if (i2 == 1) {
            i2 = 33;
        }
        if (rect == null) {
            view = FocusFinder.getInstance().findNextFocus(this, null, i2);
        } else {
            view = FocusFinder.getInstance().findNextFocusFromRect(this, rect, i2);
        }
        if (view != null && !(true ^ r(view, 0, getHeight()))) {
            return view.requestFocus(i2, rect);
        }
        return false;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof c)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        c cVar = (c) parcelable;
        super.onRestoreInstanceState(cVar.getSuperState());
        this.B = cVar;
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        c cVar = new c(super.onSaveInstanceState());
        cVar.g = getScrollY();
        return cVar;
    }

    public void onScrollChanged(int i2, int i3, int i4, int i5) {
        super.onScrollChanged(i2, i3, i4, i5);
        b bVar = this.F;
        if (bVar != null) {
            bVar.a(this, i2, i3, i4, i5);
        }
    }

    public void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        View findFocus = findFocus();
        if (findFocus != null && this != findFocus && r(findFocus, 0, i5)) {
            findFocus.getDrawingRect(this.h);
            offsetDescendantRectToMyCoords(findFocus, this.h);
            f(d(this.h));
        }
    }

    public boolean onStartNestedScroll(View view, View view2, int i2) {
        return (i2 & 2) != 0;
    }

    public void onStopNestedScroll(View view) {
        this.C.a = 0;
        this.D.j(0);
    }

    /* JADX WARNING: Removed duplicated region for block: B:103:0x029b  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x012b  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x0141  */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x0148  */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x014c  */
    /* JADX WARNING: Removed duplicated region for block: B:57:0x0154  */
    /* JADX WARNING: Removed duplicated region for block: B:91:0x0256  */
    public boolean onTouchEvent(MotionEvent motionEvent) {
        ViewParent parent;
        boolean z2;
        int round;
        int i2;
        ViewParent parent2;
        float Y;
        if (this.q == null) {
            this.q = VelocityTracker.obtain();
        }
        int actionMasked = motionEvent.getActionMasked();
        boolean z3 = false;
        if (actionMasked == 0) {
            this.z = 0;
        }
        MotionEvent obtain = MotionEvent.obtain(motionEvent);
        float f = Utils.FLOAT_EPSILON;
        obtain.offsetLocation(Utils.FLOAT_EPSILON, (float) this.z);
        if (actionMasked != 0) {
            if (actionMasked == 1) {
                VelocityTracker velocityTracker = this.q;
                velocityTracker.computeCurrentVelocity(vf0.DEFAULT_IMAGE_TIMEOUT_MS, (float) this.v);
                int yVelocity = (int) velocityTracker.getYVelocity(this.w);
                if (Math.abs(yVelocity) >= this.u) {
                    if (ek.C(this.j) != Utils.FLOAT_EPSILON) {
                        this.j.onAbsorb(yVelocity);
                    } else if (ek.C(this.k) != Utils.FLOAT_EPSILON) {
                        this.k.onAbsorb(-yVelocity);
                    } else {
                        z2 = false;
                        if (!z2) {
                            int i3 = -yVelocity;
                            float f2 = (float) i3;
                            if (!dispatchNestedPreFling(Utils.FLOAT_EPSILON, f2)) {
                                dispatchNestedFling(Utils.FLOAT_EPSILON, f2, true);
                                k(i3);
                            }
                        }
                    }
                    z2 = true;
                    if (!z2) {
                    }
                } else if (this.i.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    AtomicInteger atomicInteger = co.a;
                    co.c.k(this);
                }
                this.w = -1;
                this.p = false;
                v();
                this.D.j(0);
                this.j.onRelease();
                this.k.onRelease();
            } else if (actionMasked == 2) {
                int findPointerIndex = motionEvent.findPointerIndex(this.w);
                if (findPointerIndex == -1) {
                    StringBuilder J0 = ze0.J0("Invalid pointerId=");
                    J0.append(this.w);
                    J0.append(" in onTouchEvent");
                    Log.e("NestedScrollView", J0.toString());
                } else {
                    int y2 = (int) motionEvent.getY(findPointerIndex);
                    int i4 = this.l - y2;
                    float x2 = motionEvent.getX(findPointerIndex) / ((float) getWidth());
                    float height = ((float) i4) / ((float) getHeight());
                    if (ek.C(this.j) != Utils.FLOAT_EPSILON) {
                        Y = -ek.Y(this.j, -height, x2);
                        if (ek.C(this.j) == Utils.FLOAT_EPSILON) {
                            this.j.onRelease();
                        }
                    } else {
                        if (ek.C(this.k) != Utils.FLOAT_EPSILON) {
                            Y = ek.Y(this.k, height, 1.0f - x2);
                            if (ek.C(this.k) == Utils.FLOAT_EPSILON) {
                                this.k.onRelease();
                            }
                        }
                        round = Math.round(f * ((float) getHeight()));
                        if (round != 0) {
                            invalidate();
                        }
                        i2 = i4 - round;
                        if (!this.p && Math.abs(i2) > this.t) {
                            parent2 = getParent();
                            if (parent2 != null) {
                                parent2.requestDisallowInterceptTouchEvent(true);
                            }
                            this.p = true;
                            i2 = i2 <= 0 ? i2 - this.t : i2 + this.t;
                        }
                        int i5 = i2;
                        if (this.p) {
                            if (e(0, i5, this.y, this.x, 0)) {
                                i5 -= this.y[1];
                                this.z += this.x[1];
                            }
                            this.l = y2 - this.x[1];
                            int scrollY = getScrollY();
                            int scrollRange = getScrollRange();
                            int overScrollMode = getOverScrollMode();
                            boolean z4 = overScrollMode == 0 || (overScrollMode == 1 && scrollRange > 0);
                            boolean z5 = u(0, i5, 0, getScrollY(), 0, scrollRange, 0, 0) && !p(0);
                            int scrollY2 = getScrollY() - scrollY;
                            int[] iArr = this.y;
                            iArr[1] = 0;
                            this.D.f(0, scrollY2, 0, i5 - scrollY2, this.x, 0, iArr);
                            int i6 = this.l;
                            int[] iArr2 = this.x;
                            this.l = i6 - iArr2[1];
                            this.z += iArr2[1];
                            if (z4) {
                                int i7 = i5 - this.y[1];
                                int i8 = scrollY + i7;
                                if (i8 < 0) {
                                    ek.Y(this.j, ((float) (-i7)) / ((float) getHeight()), motionEvent.getX(findPointerIndex) / ((float) getWidth()));
                                    if (!this.k.isFinished()) {
                                        this.k.onRelease();
                                    }
                                } else if (i8 > scrollRange) {
                                    ek.Y(this.k, ((float) i7) / ((float) getHeight()), 1.0f - (motionEvent.getX(findPointerIndex) / ((float) getWidth())));
                                    if (!this.j.isFinished()) {
                                        this.j.onRelease();
                                    }
                                }
                                if (!this.j.isFinished() || !this.k.isFinished()) {
                                    AtomicInteger atomicInteger2 = co.a;
                                    co.c.k(this);
                                    if (z3) {
                                        this.q.clear();
                                    }
                                }
                            }
                            z3 = z5;
                            if (z3) {
                            }
                        }
                    }
                    f = Y;
                    round = Math.round(f * ((float) getHeight()));
                    if (round != 0) {
                    }
                    i2 = i4 - round;
                    parent2 = getParent();
                    if (parent2 != null) {
                    }
                    this.p = true;
                    if (i2 <= 0) {
                    }
                    int i52 = i2;
                    if (this.p) {
                    }
                }
            } else if (actionMasked == 3) {
                if (this.p && getChildCount() > 0 && this.i.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    AtomicInteger atomicInteger3 = co.a;
                    co.c.k(this);
                }
                this.w = -1;
                this.p = false;
                v();
                this.D.j(0);
                this.j.onRelease();
                this.k.onRelease();
            } else if (actionMasked == 5) {
                int actionIndex = motionEvent.getActionIndex();
                this.l = (int) motionEvent.getY(actionIndex);
                this.w = motionEvent.getPointerId(actionIndex);
            } else if (actionMasked == 6) {
                t(motionEvent);
                this.l = (int) motionEvent.getY(motionEvent.findPointerIndex(this.w));
            }
        } else if (getChildCount() == 0) {
            return false;
        } else {
            if (this.p && (parent = getParent()) != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
            if (!this.i.isFinished()) {
                a();
            }
            this.l = (int) motionEvent.getY();
            this.w = motionEvent.getPointerId(0);
            A(2, 0);
        }
        VelocityTracker velocityTracker2 = this.q;
        if (velocityTracker2 != null) {
            velocityTracker2.addMovement(obtain);
        }
        obtain.recycle();
        return true;
    }

    public boolean p(int i2) {
        return this.D.g(i2) != null;
    }

    public final boolean r(View view, int i2, int i3) {
        view.getDrawingRect(this.h);
        offsetDescendantRectToMyCoords(view, this.h);
        return this.h.bottom + i2 >= getScrollY() && this.h.top - i2 <= getScrollY() + i3;
    }

    public void requestChildFocus(View view, View view2) {
        if (!this.m) {
            y(view2);
        } else {
            this.o = view2;
        }
        super.requestChildFocus(view, view2);
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z2) {
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        int d = d(rect);
        boolean z3 = d != 0;
        if (z3) {
            if (z2) {
                scrollBy(0, d);
            } else {
                z(0, d, 250, false);
            }
        }
        return z3;
    }

    public void requestDisallowInterceptTouchEvent(boolean z2) {
        if (z2) {
            v();
        }
        super.requestDisallowInterceptTouchEvent(z2);
    }

    public void requestLayout() {
        this.m = true;
        super.requestLayout();
    }

    public final void s(int i2, int i3, int[] iArr) {
        int scrollY = getScrollY();
        scrollBy(0, i2);
        int scrollY2 = getScrollY() - scrollY;
        if (iArr != null) {
            iArr[1] = iArr[1] + scrollY2;
        }
        this.D.d(0, scrollY2, 0, i2 - scrollY2, null, i3, iArr);
    }

    public void scrollTo(int i2, int i3) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int c2 = c(i2, (getWidth() - getPaddingLeft()) - getPaddingRight(), childAt.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin);
            int c3 = c(i3, (getHeight() - getPaddingTop()) - getPaddingBottom(), childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin);
            if (c2 != getScrollX() || c3 != getScrollY()) {
                super.scrollTo(c2, c3);
            }
        }
    }

    public void setFillViewport(boolean z2) {
        if (z2 != this.r) {
            this.r = z2;
            requestLayout();
        }
    }

    public void setNestedScrollingEnabled(boolean z2) {
        rn rnVar = this.D;
        if (rnVar.d) {
            View view = rnVar.c;
            AtomicInteger atomicInteger = co.a;
            co.h.z(view);
        }
        rnVar.d = z2;
    }

    public void setOnScrollChangeListener(b bVar) {
        this.F = bVar;
    }

    public void setSmoothScrollingEnabled(boolean z2) {
        this.s = z2;
    }

    public boolean shouldDelayChildPressedState() {
        return true;
    }

    public boolean startNestedScroll(int i2) {
        return this.D.i(i2, 0);
    }

    public void stopNestedScroll() {
        this.D.j(0);
    }

    public final void t(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.w) {
            int i2 = actionIndex == 0 ? 1 : 0;
            this.l = (int) motionEvent.getY(i2);
            this.w = motionEvent.getPointerId(i2);
            VelocityTracker velocityTracker = this.q;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:34:0x0057  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x005a  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x0083 A[ADDED_TO_REGION] */
    public boolean u(int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9) {
        boolean z2;
        boolean z3;
        int overScrollMode = getOverScrollMode();
        boolean z4 = computeHorizontalScrollRange() > computeHorizontalScrollExtent();
        boolean z5 = computeVerticalScrollRange() > computeVerticalScrollExtent();
        boolean z6 = overScrollMode == 0 || (overScrollMode == 1 && z4);
        boolean z7 = overScrollMode == 0 || (overScrollMode == 1 && z5);
        int i10 = i4 + i2;
        int i11 = !z6 ? 0 : i8;
        int i12 = i5 + i3;
        int i13 = !z7 ? 0 : i9;
        int i14 = -i11;
        int i15 = i11 + i6;
        int i16 = -i13;
        int i17 = i13 + i7;
        if (i10 > i15) {
            i10 = i15;
        } else if (i10 < i14) {
            i10 = i14;
        } else {
            z2 = false;
            if (i12 <= i17) {
                i12 = i17;
            } else if (i12 < i16) {
                i12 = i16;
            } else {
                z3 = false;
                if (z3 && !p(1)) {
                    this.i.springBack(i10, i12, 0, 0, 0, getScrollRange());
                }
                onOverScrolled(i10, i12, z2, z3);
                if (!z2 || z3) {
                    return true;
                }
                return false;
            }
            z3 = true;
            this.i.springBack(i10, i12, 0, 0, 0, getScrollRange());
            onOverScrolled(i10, i12, z2, z3);
            if (!z2) {
            }
            return true;
        }
        z2 = true;
        if (i12 <= i17) {
        }
        z3 = true;
        this.i.springBack(i10, i12, 0, 0, 0, getScrollRange());
        onOverScrolled(i10, i12, z2, z3);
        if (!z2) {
        }
        return true;
    }

    public final void v() {
        VelocityTracker velocityTracker = this.q;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.q = null;
        }
    }

    public final void w(boolean z2) {
        if (z2) {
            A(2, 1);
        } else {
            this.D.j(1);
        }
        this.A = getScrollY();
        AtomicInteger atomicInteger = co.a;
        co.c.k(this);
    }

    public final boolean x(int i2, int i3, int i4) {
        boolean z2;
        int height = getHeight();
        int scrollY = getScrollY();
        int i5 = height + scrollY;
        boolean z3 = i2 == 33;
        ArrayList focusables = getFocusables(2);
        int size = focusables.size();
        View view = null;
        boolean z4 = false;
        for (int i6 = 0; i6 < size; i6++) {
            View view2 = (View) focusables.get(i6);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i3 < bottom && top < i4) {
                boolean z5 = i3 < top && bottom < i4;
                if (view == null) {
                    view = view2;
                    z4 = z5;
                } else {
                    boolean z6 = (z3 && top < view.getTop()) || (!z3 && bottom > view.getBottom());
                    if (z4) {
                        if (z5) {
                            if (!z6) {
                            }
                        }
                    } else if (z5) {
                        view = view2;
                        z4 = true;
                    } else if (!z6) {
                    }
                    view = view2;
                }
            }
        }
        if (view == null) {
            view = this;
        }
        if (i3 < scrollY || i4 > i5) {
            f(z3 ? i3 - scrollY : i4 - i5);
            z2 = true;
        } else {
            z2 = false;
        }
        if (view != findFocus()) {
            view.requestFocus(i2);
        }
        return z2;
    }

    public final void y(View view) {
        view.getDrawingRect(this.h);
        offsetDescendantRectToMyCoords(view, this.h);
        int d = d(this.h);
        if (d != 0) {
            scrollBy(0, d);
        }
    }

    public final void z(int i2, int i3, int i4, boolean z2) {
        if (getChildCount() != 0) {
            if (AnimationUtils.currentAnimationTimeMillis() - this.g > 250) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                int scrollY = getScrollY();
                OverScroller overScroller = this.i;
                int scrollX = getScrollX();
                overScroller.startScroll(scrollX, scrollY, 0, Math.max(0, Math.min(i3 + scrollY, Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom())))) - scrollY, i4);
                w(z2);
            } else {
                if (!this.i.isFinished()) {
                    a();
                }
                scrollBy(i2, i3);
            }
            this.g = AnimationUtils.currentAnimationTimeMillis();
        }
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i2) {
        if (getChildCount() <= 0) {
            super.addView(view, i2);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    @Override // android.view.ViewGroup
    public void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, i2, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }
}
