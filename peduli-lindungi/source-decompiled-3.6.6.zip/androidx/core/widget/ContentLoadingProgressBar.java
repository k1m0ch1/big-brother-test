package androidx.core.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ProgressBar;

public class ContentLoadingProgressBar extends ProgressBar {
    public long g = -1;
    public boolean h = false;
    public boolean i = false;
    public boolean j = false;
    public final Runnable k = new oo(this);
    public final Runnable l = new qo(this);

    public ContentLoadingProgressBar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
    }

    public void a() {
        post(new po(this));
    }

    public void b() {
        post(new ro(this));
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        removeCallbacks(this.k);
        removeCallbacks(this.l);
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.k);
        removeCallbacks(this.l);
    }
}
