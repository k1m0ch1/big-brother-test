package androidx.core.content;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public abstract class UnusedAppRestrictionsBackportService extends Service {
    public vk g = new a();

    public class a extends vk {
        public a() {
        }
    }

    public abstract void a(xk xkVar);

    public IBinder onBind(Intent intent) {
        return this.g;
    }
}
