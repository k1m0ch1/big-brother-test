package androidx.core.net;

public class ParseException extends RuntimeException {
}
