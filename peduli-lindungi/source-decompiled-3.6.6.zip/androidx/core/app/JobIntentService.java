package androidx.core.app;

import android.app.Service;
import android.app.job.JobParameters;
import android.app.job.JobServiceEngine;
import android.app.job.JobWorkItem;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import java.util.ArrayList;
import java.util.HashMap;

@Deprecated
public abstract class JobIntentService extends Service {
    public static final HashMap<ComponentName, g> l = new HashMap<>();
    public b g;
    public g h;
    public a i;
    public boolean j = false;
    public final ArrayList<d> k;

    public final class a extends AsyncTask<Void, Void, Void> {
        public a() {
        }

        /* Return type fixed from 'java.lang.Object' to match base method */
        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object[]] */
        /* JADX WARNING: Removed duplicated region for block: B:28:0x004c A[LOOP:0: B:1:0x0002->B:28:0x004c, LOOP_END] */
        /* JADX WARNING: Removed duplicated region for block: B:33:0x0059 A[SYNTHETIC] */
        @Override // android.os.AsyncTask
        public Void doInBackground(Void[] voidArr) {
            d dVar;
            while (true) {
                JobIntentService jobIntentService = JobIntentService.this;
                b bVar = jobIntentService.g;
                if (bVar != null) {
                    f fVar = (f) bVar;
                    synchronized (fVar.b) {
                        JobParameters jobParameters = fVar.c;
                        if (jobParameters != null) {
                            JobWorkItem dequeueWork = jobParameters.dequeueWork();
                            if (dequeueWork != null) {
                                dequeueWork.getIntent().setExtrasClassLoader(fVar.a.getClassLoader());
                                dVar = new f.a(dequeueWork);
                                if (dVar == null) {
                                    return null;
                                }
                                JobIntentService.this.b(dVar.getIntent());
                                dVar.a();
                            }
                        }
                    }
                } else {
                    synchronized (jobIntentService.k) {
                        if (jobIntentService.k.size() > 0) {
                            dVar = jobIntentService.k.remove(0);
                        }
                    }
                    if (dVar == null) {
                    }
                }
                dVar = null;
                if (dVar == null) {
                }
            }
        }

        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object] */
        @Override // android.os.AsyncTask
        public void onCancelled(Void r1) {
            JobIntentService.this.c();
        }

        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object] */
        @Override // android.os.AsyncTask
        public void onPostExecute(Void r1) {
            JobIntentService.this.c();
        }
    }

    public interface b {
    }

    public static final class c extends g {
        public final PowerManager.WakeLock b;
        public final PowerManager.WakeLock c;
        public boolean d;

        public c(Context context, ComponentName componentName) {
            super(componentName);
            context.getApplicationContext();
            PowerManager powerManager = (PowerManager) context.getSystemService("power");
            PowerManager.WakeLock newWakeLock = powerManager.newWakeLock(1, componentName.getClassName() + ":launch");
            this.b = newWakeLock;
            newWakeLock.setReferenceCounted(false);
            PowerManager.WakeLock newWakeLock2 = powerManager.newWakeLock(1, componentName.getClassName() + ":run");
            this.c = newWakeLock2;
            newWakeLock2.setReferenceCounted(false);
        }

        @Override // androidx.core.app.JobIntentService.g
        public void a() {
            synchronized (this) {
                if (this.d) {
                    this.d = false;
                    this.c.release();
                }
            }
        }

        @Override // androidx.core.app.JobIntentService.g
        public void b() {
            synchronized (this) {
                if (!this.d) {
                    this.d = true;
                    this.c.acquire(600000);
                    this.b.release();
                }
            }
        }

        @Override // androidx.core.app.JobIntentService.g
        public void c() {
            synchronized (this) {
            }
        }
    }

    public final class d implements e {
        public final Intent a;
        public final int b;

        public d(Intent intent, int i) {
            this.a = intent;
            this.b = i;
        }

        @Override // androidx.core.app.JobIntentService.e
        public void a() {
            JobIntentService.this.stopSelf(this.b);
        }

        @Override // androidx.core.app.JobIntentService.e
        public Intent getIntent() {
            return this.a;
        }
    }

    public interface e {
        void a();

        Intent getIntent();
    }

    public static final class f extends JobServiceEngine implements b {
        public final JobIntentService a;
        public final Object b = new Object();
        public JobParameters c;

        public final class a implements e {
            public final JobWorkItem a;

            public a(JobWorkItem jobWorkItem) {
                this.a = jobWorkItem;
            }

            @Override // androidx.core.app.JobIntentService.e
            public void a() {
                synchronized (f.this.b) {
                    JobParameters jobParameters = f.this.c;
                    if (jobParameters != null) {
                        jobParameters.completeWork(this.a);
                    }
                }
            }

            @Override // androidx.core.app.JobIntentService.e
            public Intent getIntent() {
                return this.a.getIntent();
            }
        }

        public f(JobIntentService jobIntentService) {
            super(jobIntentService);
            this.a = jobIntentService;
        }

        public boolean onStartJob(JobParameters jobParameters) {
            this.c = jobParameters;
            this.a.a(false);
            return true;
        }

        public boolean onStopJob(JobParameters jobParameters) {
            a aVar = this.a.i;
            if (aVar != null) {
                aVar.cancel(false);
            }
            synchronized (this.b) {
                this.c = null;
            }
            return true;
        }
    }

    public static abstract class g {
        public final ComponentName a;

        public g(ComponentName componentName) {
            this.a = componentName;
        }

        public void a() {
        }

        public void b() {
        }

        public void c() {
        }
    }

    public JobIntentService() {
        if (Build.VERSION.SDK_INT >= 26) {
            this.k = null;
        } else {
            this.k = new ArrayList<>();
        }
    }

    public void a(boolean z) {
        if (this.i == null) {
            this.i = new a();
            g gVar = this.h;
            if (gVar != null && z) {
                gVar.b();
            }
            this.i.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
        }
    }

    public abstract void b(Intent intent);

    public void c() {
        ArrayList<d> arrayList = this.k;
        if (arrayList != null) {
            synchronized (arrayList) {
                this.i = null;
                ArrayList<d> arrayList2 = this.k;
                if (arrayList2 != null && arrayList2.size() > 0) {
                    a(false);
                } else if (!this.j) {
                    this.h.a();
                }
            }
        }
    }

    public IBinder onBind(Intent intent) {
        b bVar = this.g;
        if (bVar != null) {
            return ((f) bVar).getBinder();
        }
        return null;
    }

    public void onCreate() {
        super.onCreate();
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 26) {
            this.g = new f(this);
            this.h = null;
            return;
        }
        this.g = null;
        ComponentName componentName = new ComponentName(this, getClass());
        HashMap<ComponentName, g> hashMap = l;
        g gVar = hashMap.get(componentName);
        if (gVar == null) {
            if (i2 < 26) {
                gVar = new c(this, componentName);
                hashMap.put(componentName, gVar);
            } else {
                throw new IllegalArgumentException("Can't be here without a job id");
            }
        }
        this.h = gVar;
    }

    public void onDestroy() {
        super.onDestroy();
        ArrayList<d> arrayList = this.k;
        if (arrayList != null) {
            synchronized (arrayList) {
                this.j = true;
                this.h.a();
            }
        }
    }

    public int onStartCommand(Intent intent, int i2, int i3) {
        if (this.k == null) {
            return 2;
        }
        this.h.c();
        synchronized (this.k) {
            ArrayList<d> arrayList = this.k;
            if (intent == null) {
                intent = new Intent();
            }
            arrayList.add(new d(intent, i3));
            a(true);
        }
        return 3;
    }
}
