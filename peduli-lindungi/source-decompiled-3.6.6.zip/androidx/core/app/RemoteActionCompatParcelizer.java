package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import androidx.versionedparcelable.VersionedParcel;
import java.util.Objects;

public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(VersionedParcel versionedParcel) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        q10 q10 = remoteActionCompat.a;
        if (versionedParcel.i(1)) {
            q10 = versionedParcel.o();
        }
        remoteActionCompat.a = (IconCompat) q10;
        CharSequence charSequence = remoteActionCompat.b;
        if (versionedParcel.i(2)) {
            charSequence = versionedParcel.h();
        }
        remoteActionCompat.b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.c;
        if (versionedParcel.i(3)) {
            charSequence2 = versionedParcel.h();
        }
        remoteActionCompat.c = charSequence2;
        remoteActionCompat.d = (PendingIntent) versionedParcel.m(remoteActionCompat.d, 4);
        boolean z = remoteActionCompat.e;
        if (versionedParcel.i(5)) {
            z = versionedParcel.f();
        }
        remoteActionCompat.e = z;
        boolean z2 = remoteActionCompat.f;
        if (versionedParcel.i(6)) {
            z2 = versionedParcel.f();
        }
        remoteActionCompat.f = z2;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, VersionedParcel versionedParcel) {
        Objects.requireNonNull(versionedParcel);
        IconCompat iconCompat = remoteActionCompat.a;
        versionedParcel.p(1);
        versionedParcel.w(iconCompat);
        CharSequence charSequence = remoteActionCompat.b;
        versionedParcel.p(2);
        versionedParcel.s(charSequence);
        CharSequence charSequence2 = remoteActionCompat.c;
        versionedParcel.p(3);
        versionedParcel.s(charSequence2);
        PendingIntent pendingIntent = remoteActionCompat.d;
        versionedParcel.p(4);
        versionedParcel.u(pendingIntent);
        boolean z = remoteActionCompat.e;
        versionedParcel.p(5);
        versionedParcel.q(z);
        boolean z2 = remoteActionCompat.f;
        versionedParcel.p(6);
        versionedParcel.q(z2);
    }
}
