package androidx.constraintlayout.widget;

import android.content.Context;
import android.util.AttributeSet;
import androidx.constraintlayout.widget.ConstraintLayout;

public class Group extends nj {
    public Group(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    @Override // defpackage.nj
    public void k(AttributeSet attributeSet) {
        super.k(attributeSet);
    }

    @Override // defpackage.nj
    public void n(ConstraintLayout constraintLayout) {
        ConstraintLayout.a aVar = (ConstraintLayout.a) getLayoutParams();
        aVar.l0.P(0);
        aVar.l0.K(0);
    }

    @Override // defpackage.nj
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        h();
    }

    public void setElevation(float f) {
        super.setElevation(f);
        h();
    }

    public void setVisibility(int i) {
        super.setVisibility(i);
        h();
    }
}
