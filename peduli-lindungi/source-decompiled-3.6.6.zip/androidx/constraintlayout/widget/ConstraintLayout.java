package androidx.constraintlayout.widget;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import com.github.mikephil.charting.utils.Utils;
import com.google.maps.android.R;
import defpackage.ni;
import defpackage.oi;
import defpackage.yi;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Objects;

public class ConstraintLayout extends ViewGroup {
    public SparseArray<View> g = new SparseArray<>();
    public ArrayList<nj> h = new ArrayList<>(4);
    public pi i = new pi();
    public int j = 0;
    public int k = 0;
    public int l = Integer.MAX_VALUE;
    public int m = Integer.MAX_VALUE;
    public boolean n = true;
    public int o = 257;
    public pj p = null;
    public oj q = null;
    public int r = -1;
    public HashMap<String, Integer> s = new HashMap<>();
    public int t = -1;
    public int u = -1;
    public SparseArray<oi> v = new SparseArray<>();
    public b w = new b(this);
    public int x = 0;
    public int y = 0;

    public class b implements yi.b {
        public ConstraintLayout a;
        public int b;
        public int c;
        public int d;
        public int e;
        public int f;
        public int g;

        public b(ConstraintLayout constraintLayout) {
            this.a = constraintLayout;
        }

        public final boolean a(int i, int i2, int i3) {
            if (i == i2) {
                return true;
            }
            int mode = View.MeasureSpec.getMode(i);
            View.MeasureSpec.getSize(i);
            int mode2 = View.MeasureSpec.getMode(i2);
            int size = View.MeasureSpec.getSize(i2);
            if (mode2 != 1073741824) {
                return false;
            }
            if ((mode == Integer.MIN_VALUE || mode == 0) && i3 == size) {
                return true;
            }
            return false;
        }

        /* JADX WARNING: Removed duplicated region for block: B:114:0x0197  */
        /* JADX WARNING: Removed duplicated region for block: B:119:0x01a8  */
        /* JADX WARNING: Removed duplicated region for block: B:123:0x01bd  */
        /* JADX WARNING: Removed duplicated region for block: B:124:0x01bf  */
        /* JADX WARNING: Removed duplicated region for block: B:126:0x01c2  */
        /* JADX WARNING: Removed duplicated region for block: B:127:0x01c4  */
        /* JADX WARNING: Removed duplicated region for block: B:130:0x01c9 A[ADDED_TO_REGION] */
        /* JADX WARNING: Removed duplicated region for block: B:134:0x01d1 A[ADDED_TO_REGION] */
        /* JADX WARNING: Removed duplicated region for block: B:139:0x01da  */
        /* JADX WARNING: Removed duplicated region for block: B:144:0x01e5  */
        /* JADX WARNING: Removed duplicated region for block: B:149:0x01f0 A[RETURN] */
        /* JADX WARNING: Removed duplicated region for block: B:150:0x01f1  */
        /* JADX WARNING: Removed duplicated region for block: B:56:0x00c1  */
        /* JADX WARNING: Removed duplicated region for block: B:94:0x013c  */
        @SuppressLint({"WrongCall"})
        public final void b(oi oiVar, yi.a aVar) {
            int i;
            int ordinal;
            int i2;
            int i3;
            int i4;
            int i5;
            int i6;
            int i7;
            int i8;
            int i9;
            int i10;
            int i11;
            oi.a aVar2 = oi.a.FIXED;
            if (oiVar != null) {
                if (oiVar.j0 == 8 && !oiVar.B) {
                    aVar.e = 0;
                    aVar.f = 0;
                    aVar.g = 0;
                } else if (oiVar.R != null) {
                    oi.a aVar3 = aVar.a;
                    oi.a aVar4 = aVar.b;
                    int i12 = aVar.c;
                    int i13 = aVar.d;
                    int i14 = this.b + this.c;
                    int i15 = this.d;
                    View view = (View) oiVar.h0;
                    int ordinal2 = aVar3.ordinal();
                    if (ordinal2 == 0) {
                        i11 = View.MeasureSpec.makeMeasureSpec(i12, 1073741824);
                    } else if (ordinal2 == 1) {
                        i11 = ViewGroup.getChildMeasureSpec(this.f, i15, -2);
                    } else if (ordinal2 != 2) {
                        if (ordinal2 != 3) {
                            i = 0;
                        } else {
                            int i16 = this.f;
                            ni niVar = oiVar.F;
                            int i17 = niVar != null ? niVar.g + 0 : 0;
                            ni niVar2 = oiVar.H;
                            if (niVar2 != null) {
                                i17 += niVar2.g;
                            }
                            i = ViewGroup.getChildMeasureSpec(i16, i15 + i17, -1);
                        }
                        ordinal = aVar4.ordinal();
                        if (ordinal != 0) {
                            i10 = View.MeasureSpec.makeMeasureSpec(i13, 1073741824);
                        } else if (ordinal == 1) {
                            i10 = ViewGroup.getChildMeasureSpec(this.g, i14, -2);
                        } else if (ordinal == 2) {
                            i10 = ViewGroup.getChildMeasureSpec(this.g, i14, -2);
                            boolean z = oiVar.m == 1;
                            int i18 = aVar.j;
                            if (i18 == 1 || i18 == 2) {
                                if (aVar.j == 2 || !z || (z && (view.getMeasuredWidth() == oiVar.u())) || (view instanceof rj) || oiVar.D()) {
                                    i10 = View.MeasureSpec.makeMeasureSpec(oiVar.o(), 1073741824);
                                }
                            }
                        } else if (ordinal != 3) {
                            i2 = 0;
                            pi piVar = (pi) oiVar.R;
                            if (piVar != null && ui.b(ConstraintLayout.this.o, RecyclerView.b0.FLAG_TMP_DETACHED) && view.getMeasuredWidth() == oiVar.u() && view.getMeasuredWidth() < piVar.u() && view.getMeasuredHeight() == oiVar.o() && view.getMeasuredHeight() < piVar.o() && view.getBaseline() == oiVar.c0 && !oiVar.B()) {
                                if (!a(oiVar.D, i, oiVar.u()) && a(oiVar.E, i2, oiVar.o())) {
                                    aVar.e = oiVar.u();
                                    aVar.f = oiVar.o();
                                    aVar.g = oiVar.c0;
                                    return;
                                }
                            }
                            oi.a aVar5 = oi.a.MATCH_CONSTRAINT;
                            boolean z2 = aVar3 == aVar5;
                            boolean z3 = aVar4 == aVar5;
                            oi.a aVar6 = oi.a.MATCH_PARENT;
                            boolean z4 = aVar4 != aVar6 || aVar4 == aVar2;
                            boolean z5 = aVar3 != aVar6 || aVar3 == aVar2;
                            boolean z6 = !z2 && oiVar.U > Utils.FLOAT_EPSILON;
                            boolean z7 = !z3 && oiVar.U > Utils.FLOAT_EPSILON;
                            if (view != null) {
                                a aVar7 = (a) view.getLayoutParams();
                                int i19 = aVar.j;
                                if (i19 == 1 || i19 == 2 || !z2 || oiVar.l != 0 || !z3 || oiVar.m != 0) {
                                    if (!(view instanceof vj) || !(oiVar instanceof vi)) {
                                        view.measure(i, i2);
                                    } else {
                                        vi viVar = (vi) oiVar;
                                        ((vj) view).s();
                                    }
                                    oiVar.D = i;
                                    oiVar.E = i2;
                                    oiVar.g = false;
                                    int measuredWidth = view.getMeasuredWidth();
                                    int measuredHeight = view.getMeasuredHeight();
                                    i5 = view.getBaseline();
                                    int i20 = oiVar.o;
                                    i4 = i20 > 0 ? Math.max(i20, measuredWidth) : measuredWidth;
                                    int i21 = oiVar.p;
                                    if (i21 > 0) {
                                        i4 = Math.min(i21, i4);
                                    }
                                    int i22 = oiVar.r;
                                    if (i22 > 0) {
                                        i3 = Math.max(i22, measuredHeight);
                                        i7 = i;
                                    } else {
                                        i7 = i;
                                        i3 = measuredHeight;
                                    }
                                    int i23 = oiVar.s;
                                    if (i23 > 0) {
                                        i3 = Math.min(i23, i3);
                                    }
                                    if (!ui.b(ConstraintLayout.this.o, 1)) {
                                        if (z6 && z4) {
                                            i4 = (int) ((((float) i3) * oiVar.U) + 0.5f);
                                        } else if (z7 && z5) {
                                            i3 = (int) ((((float) i4) / oiVar.U) + 0.5f);
                                        }
                                    }
                                    if (measuredWidth == i4 && measuredHeight == i3) {
                                        i6 = -1;
                                    } else {
                                        if (measuredWidth != i4) {
                                            i9 = 1073741824;
                                            i8 = View.MeasureSpec.makeMeasureSpec(i4, 1073741824);
                                        } else {
                                            i9 = 1073741824;
                                            i8 = i7;
                                        }
                                        if (measuredHeight != i3) {
                                            i2 = View.MeasureSpec.makeMeasureSpec(i3, i9);
                                        }
                                        view.measure(i8, i2);
                                        oiVar.D = i8;
                                        oiVar.E = i2;
                                        oiVar.g = false;
                                        i4 = view.getMeasuredWidth();
                                        i3 = view.getMeasuredHeight();
                                        i5 = view.getBaseline();
                                        i6 = -1;
                                    }
                                } else {
                                    i6 = -1;
                                    i5 = 0;
                                    i4 = 0;
                                    i3 = 0;
                                }
                                boolean z8 = i5 != i6;
                                aVar.i = (i4 == aVar.c && i3 == aVar.d) ? false : true;
                                if (aVar7.X) {
                                    z8 = true;
                                }
                                if (!(!z8 || i5 == -1 || oiVar.c0 == i5)) {
                                    aVar.i = true;
                                }
                                aVar.e = i4;
                                aVar.f = i3;
                                aVar.h = z8;
                                aVar.g = i5;
                                return;
                            }
                            return;
                        } else {
                            int i24 = this.g;
                            int i25 = oiVar.F != null ? oiVar.G.g + 0 : 0;
                            if (oiVar.H != null) {
                                i25 += oiVar.I.g;
                            }
                            i10 = ViewGroup.getChildMeasureSpec(i24, i14 + i25, -1);
                        }
                        i2 = i10;
                        pi piVar2 = (pi) oiVar.R;
                        if (!a(oiVar.D, i, oiVar.u()) && a(oiVar.E, i2, oiVar.o())) {
                        }
                        oi.a aVar52 = oi.a.MATCH_CONSTRAINT;
                        if (aVar3 == aVar52) {
                        }
                        if (aVar4 == aVar52) {
                        }
                        oi.a aVar62 = oi.a.MATCH_PARENT;
                        if (aVar4 != aVar62) {
                        }
                        if (aVar3 != aVar62) {
                        }
                        if (!z2) {
                        }
                        if (!z3) {
                        }
                        if (view != null) {
                        }
                    } else {
                        i11 = ViewGroup.getChildMeasureSpec(this.f, i15, -2);
                        boolean z9 = oiVar.l == 1;
                        int i26 = aVar.j;
                        if (i26 == 1 || i26 == 2) {
                            if (aVar.j == 2 || !z9 || (z9 && (view.getMeasuredHeight() == oiVar.o())) || (view instanceof rj) || oiVar.C()) {
                                i11 = View.MeasureSpec.makeMeasureSpec(oiVar.u(), 1073741824);
                            }
                        }
                    }
                    i = i11;
                    ordinal = aVar4.ordinal();
                    if (ordinal != 0) {
                    }
                    i2 = i10;
                    pi piVar22 = (pi) oiVar.R;
                    if (!a(oiVar.D, i, oiVar.u()) && a(oiVar.E, i2, oiVar.o())) {
                    }
                    oi.a aVar522 = oi.a.MATCH_CONSTRAINT;
                    if (aVar3 == aVar522) {
                    }
                    if (aVar4 == aVar522) {
                    }
                    oi.a aVar622 = oi.a.MATCH_PARENT;
                    if (aVar4 != aVar622) {
                    }
                    if (aVar3 != aVar622) {
                    }
                    if (!z2) {
                    }
                    if (!z3) {
                    }
                    if (view != null) {
                    }
                }
            }
        }
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        g(attributeSet, 0, 0);
    }

    private int getPaddingWidth() {
        int max = Math.max(0, getPaddingRight()) + Math.max(0, getPaddingLeft());
        int max2 = Math.max(0, getPaddingEnd()) + Math.max(0, getPaddingStart());
        return max2 > 0 ? max2 : max;
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        super.addView(view, i2, layoutParams);
    }

    /* JADX WARNING: Removed duplicated region for block: B:150:0x0317  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x00e3  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x00fa  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x0117  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x0130  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x0152  */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x016b  */
    /* JADX WARNING: Removed duplicated region for block: B:65:0x018d  */
    /* JADX WARNING: Removed duplicated region for block: B:73:0x01dc  */
    /* JADX WARNING: Removed duplicated region for block: B:76:0x01e6  */
    public void b(boolean z, View view, oi oiVar, a aVar, SparseArray<oi> sparseArray) {
        int i2;
        int i3;
        int i4;
        float f;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        float f2;
        oi oiVar2;
        oi oiVar3;
        oi oiVar4;
        oi.a aVar2 = oi.a.MATCH_PARENT;
        oi.a aVar3 = oi.a.WRAP_CONTENT;
        oi.a aVar4 = oi.a.FIXED;
        oi.a aVar5 = oi.a.MATCH_CONSTRAINT;
        ni.a aVar6 = ni.a.RIGHT;
        ni.a aVar7 = ni.a.LEFT;
        ni.a aVar8 = ni.a.BOTTOM;
        ni.a aVar9 = ni.a.TOP;
        aVar.a();
        oiVar.j0 = view.getVisibility();
        if (aVar.a0) {
            oiVar.B = true;
            oiVar.j0 = 8;
        }
        oiVar.h0 = view;
        if (view instanceof nj) {
            ((nj) view).m(oiVar, this.i.L0);
        }
        if (aVar.Y) {
            ri riVar = (ri) oiVar;
            int i10 = aVar.i0;
            int i11 = aVar.j0;
            float f3 = aVar.k0;
            int i12 = (f3 > -1.0f ? 1 : (f3 == -1.0f ? 0 : -1));
            if (i12 != 0) {
                if (i12 > 0) {
                    riVar.H0 = f3;
                    riVar.I0 = -1;
                    riVar.J0 = -1;
                }
            } else if (i10 != -1) {
                if (i10 > -1) {
                    riVar.H0 = -1.0f;
                    riVar.I0 = i10;
                    riVar.J0 = -1;
                }
            } else if (i11 != -1 && i11 > -1) {
                riVar.H0 = -1.0f;
                riVar.I0 = -1;
                riVar.J0 = i11;
            }
        } else {
            int i13 = aVar.b0;
            int i14 = aVar.c0;
            int i15 = aVar.d0;
            int i16 = aVar.e0;
            int i17 = aVar.f0;
            int i18 = aVar.g0;
            float f4 = aVar.h0;
            int i19 = aVar.m;
            if (i19 != -1) {
                oi oiVar5 = sparseArray.get(i19);
                if (oiVar5 != null) {
                    float f5 = aVar.o;
                    int i20 = aVar.n;
                    ni.a aVar10 = ni.a.CENTER;
                    oiVar.l(aVar10).a(oiVar5.l(aVar10), i20, 0, true);
                    oiVar.z = f5;
                }
            } else {
                if (i13 != -1) {
                    oi oiVar6 = sparseArray.get(i13);
                    if (oiVar6 != null) {
                        oiVar.l(aVar7).a(oiVar6.l(aVar7), ((ViewGroup.MarginLayoutParams) aVar).leftMargin, i17, true);
                    }
                } else {
                    i6 = -1;
                    if (i14 != -1) {
                        oi oiVar7 = sparseArray.get(i14);
                        if (oiVar7 != null) {
                            oiVar.l(aVar7).a(oiVar7.l(aVar6), ((ViewGroup.MarginLayoutParams) aVar).leftMargin, i17, true);
                        }
                    }
                    if (i15 == i6) {
                        oi oiVar8 = sparseArray.get(i15);
                        if (oiVar8 != null) {
                            oiVar.l(aVar6).a(oiVar8.l(aVar7), ((ViewGroup.MarginLayoutParams) aVar).rightMargin, i18, true);
                        }
                    } else if (!(i16 == i6 || (oiVar4 = sparseArray.get(i16)) == null)) {
                        oiVar.l(aVar6).a(oiVar4.l(aVar6), ((ViewGroup.MarginLayoutParams) aVar).rightMargin, i18, true);
                    }
                    i7 = aVar.h;
                    if (i7 == -1) {
                        oi oiVar9 = sparseArray.get(i7);
                        if (oiVar9 != null) {
                            oiVar.l(aVar9).a(oiVar9.l(aVar9), ((ViewGroup.MarginLayoutParams) aVar).topMargin, aVar.u, true);
                        }
                    } else {
                        int i21 = aVar.i;
                        if (!(i21 == -1 || (oiVar3 = sparseArray.get(i21)) == null)) {
                            oiVar.l(aVar9).a(oiVar3.l(aVar8), ((ViewGroup.MarginLayoutParams) aVar).topMargin, aVar.u, true);
                        }
                    }
                    i8 = aVar.j;
                    if (i8 == -1) {
                        oi oiVar10 = sparseArray.get(i8);
                        if (oiVar10 != null) {
                            oiVar.l(aVar8).a(oiVar10.l(aVar9), ((ViewGroup.MarginLayoutParams) aVar).bottomMargin, aVar.w, true);
                        }
                    } else {
                        int i22 = aVar.k;
                        if (!(i22 == -1 || (oiVar2 = sparseArray.get(i22)) == null)) {
                            oiVar.l(aVar8).a(oiVar2.l(aVar8), ((ViewGroup.MarginLayoutParams) aVar).bottomMargin, aVar.w, true);
                        }
                    }
                    i9 = aVar.l;
                    if (i9 != -1) {
                        View view2 = this.g.get(i9);
                        oi oiVar11 = sparseArray.get(aVar.l);
                        if (!(oiVar11 == null || view2 == null || !(view2.getLayoutParams() instanceof a))) {
                            a aVar11 = (a) view2.getLayoutParams();
                            aVar.X = true;
                            aVar11.X = true;
                            ni.a aVar12 = ni.a.BASELINE;
                            oiVar.l(aVar12).a(oiVar11.l(aVar12), 0, -1, true);
                            oiVar.A = true;
                            aVar11.l0.A = true;
                            oiVar.l(aVar9).j();
                            oiVar.l(aVar8).j();
                        }
                    }
                    if (f4 >= Utils.FLOAT_EPSILON) {
                        oiVar.f0 = f4;
                    }
                    f2 = aVar.A;
                    if (f2 >= Utils.FLOAT_EPSILON) {
                        oiVar.g0 = f2;
                    }
                }
                i6 = -1;
                if (i15 == i6) {
                }
                i7 = aVar.h;
                if (i7 == -1) {
                }
                i8 = aVar.j;
                if (i8 == -1) {
                }
                i9 = aVar.l;
                if (i9 != -1) {
                }
                if (f4 >= Utils.FLOAT_EPSILON) {
                }
                f2 = aVar.A;
                if (f2 >= Utils.FLOAT_EPSILON) {
                }
            }
            if (z && !((i5 = aVar.P) == -1 && aVar.Q == -1)) {
                int i23 = aVar.Q;
                oiVar.W = i5;
                oiVar.X = i23;
            }
            if (aVar.V) {
                oiVar.Q[0] = aVar4;
                oiVar.P(((ViewGroup.MarginLayoutParams) aVar).width);
                if (((ViewGroup.MarginLayoutParams) aVar).width == -2) {
                    oiVar.Q[0] = aVar3;
                }
            } else if (((ViewGroup.MarginLayoutParams) aVar).width == -1) {
                if (aVar.S) {
                    oiVar.Q[0] = aVar5;
                } else {
                    oiVar.Q[0] = aVar2;
                }
                oiVar.l(aVar7).g = ((ViewGroup.MarginLayoutParams) aVar).leftMargin;
                oiVar.l(aVar6).g = ((ViewGroup.MarginLayoutParams) aVar).rightMargin;
            } else {
                oiVar.Q[0] = aVar5;
                oiVar.P(0);
            }
            if (aVar.W) {
                oiVar.Q[1] = aVar4;
                oiVar.K(((ViewGroup.MarginLayoutParams) aVar).height);
                if (((ViewGroup.MarginLayoutParams) aVar).height == -2) {
                    oiVar.Q[1] = aVar3;
                }
            } else if (((ViewGroup.MarginLayoutParams) aVar).height == -1) {
                if (aVar.T) {
                    oiVar.Q[1] = aVar5;
                } else {
                    oiVar.Q[1] = aVar2;
                }
                oiVar.l(aVar9).g = ((ViewGroup.MarginLayoutParams) aVar).topMargin;
                oiVar.l(aVar8).g = ((ViewGroup.MarginLayoutParams) aVar).bottomMargin;
            } else {
                oiVar.Q[1] = aVar5;
                oiVar.K(0);
            }
            String str = aVar.B;
            if (str == null || str.length() == 0) {
                oiVar.U = Utils.FLOAT_EPSILON;
            } else {
                int length = str.length();
                int indexOf = str.indexOf(44);
                if (indexOf <= 0 || indexOf >= length - 1) {
                    i3 = 1;
                    i4 = 0;
                    i2 = -1;
                } else {
                    String substring = str.substring(0, indexOf);
                    if (substring.equalsIgnoreCase("W")) {
                        i3 = 1;
                        i2 = 0;
                    } else if (substring.equalsIgnoreCase("H")) {
                        i3 = 1;
                        i2 = 1;
                    } else {
                        i3 = 1;
                        i2 = -1;
                    }
                    i4 = indexOf + i3;
                }
                int indexOf2 = str.indexOf(58);
                if (indexOf2 < 0 || indexOf2 >= length - i3) {
                    String substring2 = str.substring(i4);
                    if (substring2.length() > 0) {
                        f = Float.parseFloat(substring2);
                        if (f > Utils.FLOAT_EPSILON) {
                            oiVar.U = f;
                            oiVar.V = i2;
                        }
                    }
                } else {
                    String substring3 = str.substring(i4, indexOf2);
                    String substring4 = str.substring(indexOf2 + i3);
                    if (substring3.length() > 0 && substring4.length() > 0) {
                        try {
                            float parseFloat = Float.parseFloat(substring3);
                            float parseFloat2 = Float.parseFloat(substring4);
                            if (parseFloat > Utils.FLOAT_EPSILON && parseFloat2 > Utils.FLOAT_EPSILON) {
                                f = i2 == 1 ? Math.abs(parseFloat2 / parseFloat) : Math.abs(parseFloat / parseFloat2);
                                if (f > Utils.FLOAT_EPSILON) {
                                }
                            }
                        } catch (NumberFormatException unused) {
                        }
                    }
                }
                f = Utils.FLOAT_EPSILON;
                if (f > Utils.FLOAT_EPSILON) {
                }
            }
            float f6 = aVar.D;
            float[] fArr = oiVar.A0;
            int i24 = 0;
            fArr[0] = f6;
            fArr[1] = aVar.E;
            oiVar.w0 = aVar.F;
            oiVar.x0 = aVar.G;
            int i25 = aVar.H;
            int i26 = aVar.J;
            int i27 = aVar.L;
            float f7 = aVar.N;
            oiVar.l = i25;
            oiVar.o = i26;
            if (i27 == Integer.MAX_VALUE) {
                i27 = 0;
            }
            oiVar.p = i27;
            oiVar.q = f7;
            if (f7 > Utils.FLOAT_EPSILON && f7 < 1.0f && i25 == 0) {
                oiVar.l = 2;
            }
            int i28 = aVar.I;
            int i29 = aVar.K;
            int i30 = aVar.M;
            float f8 = aVar.O;
            oiVar.m = i28;
            oiVar.r = i29;
            if (i30 != Integer.MAX_VALUE) {
                i24 = i30;
            }
            oiVar.s = i24;
            oiVar.t = f8;
            if (f8 > Utils.FLOAT_EPSILON && f8 < 1.0f && i28 == 0) {
                oiVar.m = 2;
            }
        }
    }

    /* renamed from: c */
    public a generateDefaultLayoutParams() {
        return new a(-2, -2);
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof a;
    }

    public Object d(int i2, Object obj) {
        if (i2 != 0 || !(obj instanceof String)) {
            return null;
        }
        String str = (String) obj;
        HashMap<String, Integer> hashMap = this.s;
        if (hashMap == null || !hashMap.containsKey(str)) {
            return null;
        }
        return this.s.get(str);
    }

    public void dispatchDraw(Canvas canvas) {
        Object tag;
        int size;
        ArrayList<nj> arrayList = this.h;
        if (arrayList != null && (size = arrayList.size()) > 0) {
            for (int i2 = 0; i2 < size; i2++) {
                this.h.get(i2).p();
            }
        }
        super.dispatchDraw(canvas);
        if (isInEditMode()) {
            int childCount = getChildCount();
            float width = (float) getWidth();
            float height = (float) getHeight();
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = getChildAt(i3);
                if (!(childAt.getVisibility() == 8 || (tag = childAt.getTag()) == null || !(tag instanceof String))) {
                    String[] split = ((String) tag).split(",");
                    if (split.length == 4) {
                        int parseInt = Integer.parseInt(split[0]);
                        int parseInt2 = Integer.parseInt(split[1]);
                        int parseInt3 = Integer.parseInt(split[2]);
                        int i4 = (int) ((((float) parseInt) / 1080.0f) * width);
                        int i5 = (int) ((((float) parseInt2) / 1920.0f) * height);
                        Paint paint = new Paint();
                        paint.setColor(-65536);
                        float f = (float) i4;
                        float f2 = (float) i5;
                        float f3 = (float) (i4 + ((int) ((((float) parseInt3) / 1080.0f) * width)));
                        canvas.drawLine(f, f2, f3, f2, paint);
                        float parseInt4 = (float) (i5 + ((int) ((((float) Integer.parseInt(split[3])) / 1920.0f) * height)));
                        canvas.drawLine(f3, f2, f3, parseInt4, paint);
                        canvas.drawLine(f3, parseInt4, f, parseInt4, paint);
                        canvas.drawLine(f, parseInt4, f, f2, paint);
                        paint.setColor(-16711936);
                        canvas.drawLine(f, f2, f3, parseInt4, paint);
                        canvas.drawLine(f, parseInt4, f3, f2, paint);
                    }
                }
            }
        }
    }

    public View e(int i2) {
        return this.g.get(i2);
    }

    public final oi f(View view) {
        if (view == this) {
            return this.i;
        }
        if (view == null) {
            return null;
        }
        return ((a) view.getLayoutParams()).l0;
    }

    public void forceLayout() {
        this.n = true;
        this.t = -1;
        this.u = -1;
        super.forceLayout();
    }

    public final void g(AttributeSet attributeSet, int i2, int i3) {
        pi piVar = this.i;
        piVar.h0 = this;
        piVar.c0(this.w);
        this.g.put(getId(), this);
        this.p = null;
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, tj.b, i2, i3);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i4 = 0; i4 < indexCount; i4++) {
                int index = obtainStyledAttributes.getIndex(i4);
                if (index == 9) {
                    this.j = obtainStyledAttributes.getDimensionPixelOffset(index, this.j);
                } else if (index == 10) {
                    this.k = obtainStyledAttributes.getDimensionPixelOffset(index, this.k);
                } else if (index == 7) {
                    this.l = obtainStyledAttributes.getDimensionPixelOffset(index, this.l);
                } else if (index == 8) {
                    this.m = obtainStyledAttributes.getDimensionPixelOffset(index, this.m);
                } else if (index == 90) {
                    this.o = obtainStyledAttributes.getInt(index, this.o);
                } else if (index == 39) {
                    int resourceId = obtainStyledAttributes.getResourceId(index, 0);
                    if (resourceId != 0) {
                        try {
                            l(resourceId);
                        } catch (Resources.NotFoundException unused) {
                            this.q = null;
                        }
                    }
                } else if (index == 18) {
                    int resourceId2 = obtainStyledAttributes.getResourceId(index, 0);
                    try {
                        pj pjVar = new pj();
                        this.p = pjVar;
                        pjVar.j(getContext(), resourceId2);
                    } catch (Resources.NotFoundException unused2) {
                        this.p = null;
                    }
                    this.r = resourceId2;
                }
            }
            obtainStyledAttributes.recycle();
        }
        this.i.d0(this.o);
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new a(getContext(), attributeSet);
    }

    public int getMaxHeight() {
        return this.m;
    }

    public int getMaxWidth() {
        return this.l;
    }

    public int getMinHeight() {
        return this.k;
    }

    public int getMinWidth() {
        return this.j;
    }

    public int getOptimizationLevel() {
        return this.i.T0;
    }

    public boolean k() {
        if (!((getContext().getApplicationInfo().flags & 4194304) != 0) || 1 != getLayoutDirection()) {
            return false;
        }
        return true;
    }

    public void l(int i2) {
        this.q = new oj(getContext(), this, i2);
    }

    public void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        View content;
        int childCount = getChildCount();
        boolean isInEditMode = isInEditMode();
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            a aVar = (a) childAt.getLayoutParams();
            oi oiVar = aVar.l0;
            if ((childAt.getVisibility() != 8 || aVar.Y || aVar.Z || isInEditMode) && !aVar.a0) {
                int v2 = oiVar.v();
                int w2 = oiVar.w();
                int u2 = oiVar.u() + v2;
                int o2 = oiVar.o() + w2;
                childAt.layout(v2, w2, u2, o2);
                if ((childAt instanceof rj) && (content = ((rj) childAt).getContent()) != null) {
                    content.setVisibility(0);
                    content.layout(v2, w2, u2, o2);
                }
            }
        }
        int size = this.h.size();
        if (size > 0) {
            for (int i7 = 0; i7 < size; i7++) {
                this.h.get(i7).n(this);
            }
        }
    }

    public void onMeasure(int i2, int i3) {
        boolean z;
        String str;
        int i4;
        oi oiVar;
        if (!this.n) {
            int childCount = getChildCount();
            int i5 = 0;
            while (true) {
                if (i5 >= childCount) {
                    break;
                } else if (getChildAt(i5).isLayoutRequested()) {
                    this.n = true;
                    break;
                } else {
                    i5++;
                }
            }
        }
        if (!this.n) {
            int i6 = this.x;
            if (i6 == i2 && this.y == i3) {
                int u2 = this.i.u();
                int o2 = this.i.o();
                pi piVar = this.i;
                p(i2, i3, u2, o2, piVar.U0, piVar.V0);
                return;
            } else if (i6 == i2 && View.MeasureSpec.getMode(i2) == 1073741824 && View.MeasureSpec.getMode(i3) == Integer.MIN_VALUE && View.MeasureSpec.getMode(this.y) == Integer.MIN_VALUE && View.MeasureSpec.getSize(i3) >= this.i.o()) {
                this.x = i2;
                this.y = i3;
                int u3 = this.i.u();
                int o3 = this.i.o();
                pi piVar2 = this.i;
                p(i2, i3, u3, o3, piVar2.U0, piVar2.V0);
                return;
            }
        }
        this.x = i2;
        this.y = i3;
        this.i.L0 = k();
        if (this.n) {
            this.n = false;
            int childCount2 = getChildCount();
            int i7 = 0;
            while (true) {
                if (i7 >= childCount2) {
                    z = false;
                    break;
                } else if (getChildAt(i7).isLayoutRequested()) {
                    z = true;
                    break;
                } else {
                    i7++;
                }
            }
            if (z) {
                boolean isInEditMode = isInEditMode();
                int childCount3 = getChildCount();
                for (int i8 = 0; i8 < childCount3; i8++) {
                    oi f = f(getChildAt(i8));
                    if (f != null) {
                        f.E();
                    }
                }
                if (isInEditMode) {
                    for (int i9 = 0; i9 < childCount3; i9++) {
                        View childAt = getChildAt(i9);
                        try {
                            String resourceName = getResources().getResourceName(childAt.getId());
                            r(0, resourceName, Integer.valueOf(childAt.getId()));
                            int indexOf = resourceName.indexOf(47);
                            if (indexOf != -1) {
                                resourceName = resourceName.substring(indexOf + 1);
                            }
                            int id = childAt.getId();
                            if (id == 0) {
                                oiVar = this.i;
                            } else {
                                View view = this.g.get(id);
                                if (view == null && (view = findViewById(id)) != null && view != this && view.getParent() == this) {
                                    onViewAdded(view);
                                }
                                oiVar = view == this ? this.i : view == null ? null : ((a) view.getLayoutParams()).l0;
                            }
                            oiVar.k0 = resourceName;
                        } catch (Resources.NotFoundException unused) {
                        }
                    }
                }
                if (this.r != -1) {
                    for (int i10 = 0; i10 < childCount3; i10++) {
                        View childAt2 = getChildAt(i10);
                        if (childAt2.getId() == this.r && (childAt2 instanceof Constraints)) {
                            this.p = ((Constraints) childAt2).getConstraintSet();
                        }
                    }
                }
                pj pjVar = this.p;
                if (pjVar != null) {
                    pjVar.c(this, true);
                }
                this.i.H0.clear();
                int size = this.h.size();
                if (size > 0) {
                    for (int i11 = 0; i11 < size; i11++) {
                        nj njVar = this.h.get(i11);
                        if (njVar.isInEditMode()) {
                            njVar.setIds(njVar.k);
                        }
                        si siVar = njVar.j;
                        if (siVar != null) {
                            siVar.c();
                            for (int i12 = 0; i12 < njVar.h; i12++) {
                                int i13 = njVar.g[i12];
                                View e = e(i13);
                                if (e == null && (i4 = njVar.i(this, (str = njVar.n.get(Integer.valueOf(i13))))) != 0) {
                                    njVar.g[i12] = i4;
                                    njVar.n.put(Integer.valueOf(i4), str);
                                    e = e(i4);
                                }
                                if (e != null) {
                                    njVar.j.a(f(e));
                                }
                            }
                            njVar.j.b(this.i);
                        }
                    }
                }
                for (int i14 = 0; i14 < childCount3; i14++) {
                    View childAt3 = getChildAt(i14);
                    if (childAt3 instanceof rj) {
                        rj rjVar = (rj) childAt3;
                        if (rjVar.g == -1 && !rjVar.isInEditMode()) {
                            rjVar.setVisibility(rjVar.i);
                        }
                        View findViewById = findViewById(rjVar.g);
                        rjVar.h = findViewById;
                        if (findViewById != null) {
                            ((a) findViewById.getLayoutParams()).a0 = true;
                            rjVar.h.setVisibility(0);
                            rjVar.setVisibility(0);
                        }
                    }
                }
                this.v.clear();
                this.v.put(0, this.i);
                this.v.put(getId(), this.i);
                for (int i15 = 0; i15 < childCount3; i15++) {
                    View childAt4 = getChildAt(i15);
                    this.v.put(childAt4.getId(), f(childAt4));
                }
                for (int i16 = 0; i16 < childCount3; i16++) {
                    View childAt5 = getChildAt(i16);
                    oi f2 = f(childAt5);
                    if (f2 != null) {
                        a aVar = (a) childAt5.getLayoutParams();
                        pi piVar3 = this.i;
                        piVar3.H0.add(f2);
                        oi oiVar2 = f2.R;
                        if (oiVar2 != null) {
                            ((wi) oiVar2).H0.remove(f2);
                            f2.E();
                        }
                        f2.R = piVar3;
                        b(isInEditMode, childAt5, f2, aVar, this.v);
                    }
                }
            }
            if (z) {
                pi piVar4 = this.i;
                piVar4.I0.c(piVar4);
            }
        }
        q(this.i, this.o, i2, i3);
        int u4 = this.i.u();
        int o4 = this.i.o();
        pi piVar5 = this.i;
        p(i2, i3, u4, o4, piVar5.U0, piVar5.V0);
    }

    public void onViewAdded(View view) {
        super.onViewAdded(view);
        oi f = f(view);
        if ((view instanceof Guideline) && !(f instanceof ri)) {
            a aVar = (a) view.getLayoutParams();
            ri riVar = new ri();
            aVar.l0 = riVar;
            aVar.Y = true;
            riVar.T(aVar.R);
        }
        if (view instanceof nj) {
            nj njVar = (nj) view;
            njVar.r();
            ((a) view.getLayoutParams()).Z = true;
            if (!this.h.contains(njVar)) {
                this.h.add(njVar);
            }
        }
        this.g.put(view.getId(), view);
        this.n = true;
    }

    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        this.g.remove(view.getId());
        oi f = f(view);
        this.i.H0.remove(f);
        f.E();
        this.h.remove(view);
        this.n = true;
    }

    public void p(int i2, int i3, int i4, int i5, boolean z, boolean z2) {
        b bVar = this.w;
        int i6 = bVar.e;
        int resolveSizeAndState = ViewGroup.resolveSizeAndState(i4 + bVar.d, i2, 0);
        int min = Math.min(this.l, resolveSizeAndState & 16777215);
        int min2 = Math.min(this.m, ViewGroup.resolveSizeAndState(i5 + i6, i3, 0) & 16777215);
        if (z) {
            min |= 16777216;
        }
        if (z2) {
            min2 |= 16777216;
        }
        setMeasuredDimension(min, min2);
        this.t = min;
        this.u = min2;
    }

    /* JADX WARNING: Removed duplicated region for block: B:197:0x04a8  */
    /* JADX WARNING: Removed duplicated region for block: B:199:0x04bc  */
    /* JADX WARNING: Removed duplicated region for block: B:203:0x04c3  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x00b0  */
    /* JADX WARNING: Removed duplicated region for block: B:257:0x055b  */
    /* JADX WARNING: Removed duplicated region for block: B:270:0x05a4  */
    /* JADX WARNING: Removed duplicated region for block: B:273:0x05b6  */
    /* JADX WARNING: Removed duplicated region for block: B:275:0x05bb  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x00dc  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x015c  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x0168  */
    /* JADX WARNING: Removed duplicated region for block: B:82:0x01cb A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:88:0x01d6  */
    public void q(pi piVar, int i2, int i3, int i4) {
        oi.a aVar;
        int i5;
        oi.a aVar2;
        oi.a aVar3;
        int i6;
        oi.a aVar4;
        int size;
        boolean z;
        boolean z2;
        int i7;
        boolean z3;
        int i8;
        oi.a aVar5;
        yi yiVar;
        int i9;
        yi.b bVar;
        ni.a aVar6;
        ni.a aVar7;
        boolean z4;
        boolean z5;
        int i10;
        yi yiVar2;
        int size2;
        int i11;
        int i12;
        boolean z6;
        boolean z7;
        int i13;
        int i14;
        boolean z8;
        int i15;
        ni.a aVar8;
        ni.a aVar9;
        yi.b bVar2;
        boolean z9;
        yi yiVar3;
        hj hjVar;
        jj jjVar;
        int i16;
        int i17;
        boolean z10;
        int i18;
        int i19;
        boolean z11;
        boolean z12;
        int i20;
        pi piVar2 = piVar;
        oi.a aVar10 = oi.a.FIXED;
        int mode = View.MeasureSpec.getMode(i3);
        int size3 = View.MeasureSpec.getSize(i3);
        int mode2 = View.MeasureSpec.getMode(i4);
        int size4 = View.MeasureSpec.getSize(i4);
        int max = Math.max(0, getPaddingTop());
        int max2 = Math.max(0, getPaddingBottom());
        int i21 = max + max2;
        int paddingWidth = getPaddingWidth();
        b bVar3 = this.w;
        bVar3.b = max;
        bVar3.c = max2;
        bVar3.d = paddingWidth;
        bVar3.e = i21;
        bVar3.f = i3;
        bVar3.g = i4;
        int max3 = Math.max(0, getPaddingStart());
        int max4 = Math.max(0, getPaddingEnd());
        if (max3 <= 0 && max4 <= 0) {
            max3 = Math.max(0, getPaddingLeft());
        } else if (k()) {
            max3 = max4;
        }
        int i22 = size3 - paddingWidth;
        int i23 = size4 - i21;
        oi.a aVar11 = oi.a.WRAP_CONTENT;
        b bVar4 = this.w;
        int i24 = bVar4.e;
        int i25 = bVar4.d;
        int childCount = getChildCount();
        if (mode != Integer.MIN_VALUE) {
            if (mode != 0) {
                if (mode != 1073741824) {
                    aVar2 = aVar10;
                    i5 = 0;
                } else {
                    aVar = aVar10;
                    i5 = Math.min(this.l - i25, i22);
                    aVar2 = aVar;
                    if (mode2 != Integer.MIN_VALUE) {
                        if (mode2 != 0) {
                            if (mode2 != 1073741824) {
                                aVar4 = aVar;
                                i6 = 0;
                            } else {
                                i6 = Math.min(this.m - i24, i23);
                                aVar3 = aVar11;
                                aVar4 = aVar;
                            }
                        } else if (childCount == 0) {
                            aVar3 = aVar11;
                            aVar4 = aVar3;
                            i6 = Math.max(0, this.k);
                        } else {
                            i6 = 0;
                            aVar4 = aVar11;
                        }
                        aVar3 = aVar11;
                    } else {
                        i6 = childCount == 0 ? Math.max(0, this.k) : i23;
                        aVar3 = aVar11;
                        aVar4 = aVar3;
                    }
                    if (!(i5 == piVar.u() && i6 == piVar.o())) {
                        piVar2.J0.c = true;
                    }
                    piVar2.W = 0;
                    piVar2.X = 0;
                    int[] iArr = piVar2.y;
                    iArr[0] = this.l - i25;
                    iArr[1] = this.m - i24;
                    piVar2.N(0);
                    piVar2.M(0);
                    piVar2.Q[0] = aVar2;
                    piVar2.P(i5);
                    piVar2.Q[1] = aVar4;
                    piVar2.K(i6);
                    piVar2.N(this.j - i25);
                    piVar2.M(this.k - i24);
                    piVar2.N0 = max3;
                    piVar2.O0 = max;
                    yi yiVar4 = piVar2.I0;
                    Objects.requireNonNull(yiVar4);
                    ni.a aVar12 = ni.a.BOTTOM;
                    ni.a aVar13 = ni.a.RIGHT;
                    oi.a aVar14 = oi.a.MATCH_CONSTRAINT;
                    yi.b bVar5 = piVar2.K0;
                    size = piVar2.H0.size();
                    int u2 = piVar.u();
                    int o2 = piVar.o();
                    boolean b2 = ui.b(i2, RecyclerView.b0.FLAG_IGNORE);
                    z = !b2 || ui.b(i2, 64);
                    if (z) {
                        int i26 = 0;
                        while (true) {
                            if (i26 >= size) {
                                break;
                            }
                            oi oiVar = piVar2.H0.get(i26);
                            boolean z13 = (oiVar.p() == aVar14) && (oiVar.t() == aVar14) && oiVar.U > Utils.FLOAT_EPSILON;
                            if ((!oiVar.z() || !z13) && ((!oiVar.A() || !z13) && !(oiVar instanceof vi) && !oiVar.z() && !oiVar.A())) {
                                i26++;
                                z = z;
                            }
                        }
                        i7 = 1073741824;
                        z2 = false;
                        z3 = z2 & ((mode != i7 && mode2 == i7) || b2);
                        if (!z3) {
                            int min = Math.min(piVar2.y[0], i22);
                            int min2 = Math.min(piVar2.y[1], i23);
                            if (mode == 1073741824 && piVar.u() != min) {
                                piVar2.P(min);
                                piVar.Z();
                            }
                            if (mode2 == 1073741824 && piVar.o() != min2) {
                                piVar2.K(min2);
                                piVar.Z();
                            }
                            if (mode == 1073741824 && mode2 == 1073741824) {
                                bj bjVar = piVar2.J0;
                                oi.a aVar15 = oi.a.MATCH_PARENT;
                                boolean z14 = b2 & true;
                                if (bjVar.b || bjVar.c) {
                                    for (Iterator<oi> it = bjVar.a.H0.iterator(); it.hasNext(); it = it) {
                                        oi next = it.next();
                                        next.k();
                                        next.a = false;
                                        next.d.n();
                                        next.e.m();
                                        z3 = z3;
                                    }
                                    z4 = z3;
                                    bjVar.a.k();
                                    pi piVar3 = bjVar.a;
                                    i19 = 0;
                                    piVar3.a = false;
                                    piVar3.d.n();
                                    bjVar.a.e.m();
                                    bjVar.c = false;
                                } else {
                                    z4 = z3;
                                    i19 = 0;
                                }
                                bjVar.b(bjVar.d);
                                pi piVar4 = bjVar.a;
                                piVar4.W = i19;
                                piVar4.X = i19;
                                oi.a n2 = piVar4.n(i19);
                                aVar7 = aVar12;
                                oi.a n3 = bjVar.a.n(1);
                                if (bjVar.b) {
                                    bjVar.c();
                                }
                                int v2 = bjVar.a.v();
                                aVar6 = aVar13;
                                int w2 = bjVar.a.w();
                                bVar = bVar5;
                                bjVar.a.d.h.c(v2);
                                bjVar.a.e.h.c(w2);
                                bjVar.g();
                                if (n2 == aVar3 || n3 == aVar3) {
                                    if (z14) {
                                        Iterator<lj> it2 = bjVar.e.iterator();
                                        while (true) {
                                            if (it2.hasNext()) {
                                                if (!it2.next().k()) {
                                                    z12 = false;
                                                    break;
                                                }
                                            } else {
                                                break;
                                            }
                                        }
                                    }
                                    z12 = z14;
                                    if (!z12 || n2 != aVar3) {
                                        yiVar = yiVar4;
                                        i8 = u2;
                                        i9 = o2;
                                    } else {
                                        i8 = u2;
                                        pi piVar5 = bjVar.a;
                                        i9 = o2;
                                        yiVar = yiVar4;
                                        piVar5.Q[0] = aVar;
                                        piVar5.P(bjVar.d(piVar5, 0));
                                        pi piVar6 = bjVar.a;
                                        piVar6.d.e.c(piVar6.u());
                                    }
                                    if (z12 && n3 == aVar3) {
                                        pi piVar7 = bjVar.a;
                                        piVar7.Q[1] = aVar;
                                        piVar7.K(bjVar.d(piVar7, 1));
                                        pi piVar8 = bjVar.a;
                                        piVar8.e.e.c(piVar8.o());
                                    }
                                } else {
                                    yiVar = yiVar4;
                                    i8 = u2;
                                    i9 = o2;
                                }
                                pi piVar9 = bjVar.a;
                                oi.a[] aVarArr = piVar9.Q;
                                aVar5 = aVar3;
                                if (aVarArr[0] == aVar || aVarArr[0] == aVar15) {
                                    int u3 = piVar9.u() + v2;
                                    bjVar.a.d.i.c(u3);
                                    bjVar.a.d.e.c(u3 - v2);
                                    bjVar.g();
                                    pi piVar10 = bjVar.a;
                                    oi.a[] aVarArr2 = piVar10.Q;
                                    if (aVarArr2[1] == aVar || aVarArr2[1] == aVar15) {
                                        int o3 = piVar10.o() + w2;
                                        bjVar.a.e.i.c(o3);
                                        bjVar.a.e.e.c(o3 - w2);
                                    }
                                    bjVar.g();
                                    z11 = true;
                                } else {
                                    z11 = false;
                                }
                                Iterator<lj> it3 = bjVar.e.iterator();
                                while (it3.hasNext()) {
                                    lj next2 = it3.next();
                                    if (next2.b != bjVar.a || next2.g) {
                                        next2.e();
                                    }
                                }
                                Iterator<lj> it4 = bjVar.e.iterator();
                                while (true) {
                                    if (!it4.hasNext()) {
                                        z5 = true;
                                        break;
                                    }
                                    lj next3 = it4.next();
                                    if ((z11 || next3.b != bjVar.a) && (!next3.h.j || ((!next3.i.j && !(next3 instanceof fj)) || (!next3.e.j && !(next3 instanceof zi) && !(next3 instanceof fj))))) {
                                        z5 = false;
                                    }
                                }
                                z5 = false;
                                bjVar.a.L(n2);
                                bjVar.a.O(n3);
                                i16 = 1073741824;
                                i10 = 2;
                            } else {
                                aVar5 = aVar3;
                                z4 = z3;
                                yiVar = yiVar4;
                                aVar7 = aVar12;
                                aVar6 = aVar13;
                                bVar = bVar5;
                                i8 = u2;
                                i9 = o2;
                                bj bjVar2 = piVar2.J0;
                                if (bjVar2.b) {
                                    Iterator<oi> it5 = bjVar2.a.H0.iterator();
                                    while (it5.hasNext()) {
                                        oi next4 = it5.next();
                                        next4.k();
                                        next4.a = false;
                                        hj hjVar2 = next4.d;
                                        hjVar2.e.j = false;
                                        hjVar2.g = false;
                                        hjVar2.n();
                                        jj jjVar2 = next4.e;
                                        jjVar2.e.j = false;
                                        jjVar2.g = false;
                                        jjVar2.m();
                                    }
                                    i17 = 0;
                                    bjVar2.a.k();
                                    pi piVar11 = bjVar2.a;
                                    piVar11.a = false;
                                    hj hjVar3 = piVar11.d;
                                    hjVar3.e.j = false;
                                    hjVar3.g = false;
                                    hjVar3.n();
                                    jj jjVar3 = bjVar2.a.e;
                                    jjVar3.e.j = false;
                                    jjVar3.g = false;
                                    jjVar3.m();
                                    bjVar2.c();
                                } else {
                                    i17 = 0;
                                }
                                bjVar2.b(bjVar2.d);
                                pi piVar12 = bjVar2.a;
                                piVar12.W = i17;
                                piVar12.X = i17;
                                piVar12.d.h.c(i17);
                                bjVar2.a.e.h.c(i17);
                                i16 = 1073741824;
                                if (mode == 1073741824) {
                                    i18 = 1;
                                    z10 = piVar2.Y(b2, i17) & true;
                                    i10 = 1;
                                } else {
                                    i18 = 1;
                                    i10 = 0;
                                    z10 = true;
                                }
                                if (mode2 == 1073741824) {
                                    z5 = z10 & piVar2.Y(b2, i18);
                                    i10++;
                                } else {
                                    z5 = z10;
                                }
                            }
                            if (z5) {
                                piVar2.Q(mode == i16, mode2 == i16);
                            }
                        } else {
                            aVar5 = aVar3;
                            z4 = z3;
                            yiVar = yiVar4;
                            aVar7 = aVar12;
                            aVar6 = aVar13;
                            bVar = bVar5;
                            i8 = u2;
                            i9 = o2;
                            i10 = 0;
                            z5 = false;
                        }
                        if (z5 || i10 != 2) {
                            int i27 = piVar2.T0;
                            if (size <= 0) {
                                int size5 = piVar2.H0.size();
                                boolean b0 = piVar2.b0(64);
                                yi.b bVar6 = piVar2.K0;
                                int i28 = 0;
                                while (i28 < size5) {
                                    oi oiVar2 = piVar2.H0.get(i28);
                                    if (!(oiVar2 instanceof ri) && !(oiVar2 instanceof li) && !oiVar2.C && (!b0 || (hjVar = oiVar2.d) == null || (jjVar = oiVar2.e) == null || !hjVar.e.j || !jjVar.e.j)) {
                                        oi.a n4 = oiVar2.n(0);
                                        oi.a n5 = oiVar2.n(1);
                                        boolean z15 = n4 == aVar14 && oiVar2.l != 1 && n5 == aVar14 && oiVar2.m != 1;
                                        if (!z15 && piVar2.b0(1) && !(oiVar2 instanceof vi)) {
                                            if (n4 == aVar14 && oiVar2.l == 0 && n5 != aVar14 && !oiVar2.z()) {
                                                z15 = true;
                                            }
                                            if (n5 == aVar14 && oiVar2.m == 0 && n4 != aVar14 && !oiVar2.z()) {
                                                z15 = true;
                                            }
                                            if (n4 == aVar14 || n5 == aVar14) {
                                                if (oiVar2.U > Utils.FLOAT_EPSILON) {
                                                    z15 = true;
                                                }
                                                if (!z15) {
                                                    yiVar3 = yiVar;
                                                    yiVar3.a(bVar6, oiVar2, 0);
                                                    i28++;
                                                    yiVar = yiVar3;
                                                }
                                            }
                                        }
                                        if (!z15) {
                                        }
                                    }
                                    yiVar3 = yiVar;
                                    i28++;
                                    yiVar = yiVar3;
                                }
                                yiVar2 = yiVar;
                                b bVar7 = (b) bVar6;
                                int childCount2 = bVar7.a.getChildCount();
                                for (int i29 = 0; i29 < childCount2; i29++) {
                                    View childAt = bVar7.a.getChildAt(i29);
                                    if (childAt instanceof rj) {
                                        ((rj) childAt).a();
                                    }
                                }
                                int size6 = bVar7.a.h.size();
                                if (size6 > 0) {
                                    for (int i30 = 0; i30 < size6; i30++) {
                                        bVar7.a.h.get(i30).o();
                                    }
                                }
                            } else {
                                yiVar2 = yiVar;
                            }
                            yiVar2.c(piVar2);
                            size2 = yiVar2.a.size();
                            int i31 = i8;
                            int i32 = i9;
                            if (size > 0) {
                                yiVar2.b(piVar2, i31, i32);
                            }
                            if (size2 > 0) {
                                boolean z16 = piVar.p() == aVar5;
                                boolean z17 = piVar.t() == aVar5;
                                int max5 = Math.max(piVar.u(), yiVar2.c.d0);
                                int max6 = Math.max(piVar.o(), yiVar2.c.e0);
                                int i33 = 0;
                                boolean z18 = false;
                                while (i33 < size2) {
                                    oi oiVar3 = yiVar2.a.get(i33);
                                    if (!(oiVar3 instanceof vi)) {
                                        i15 = i27;
                                        aVar8 = aVar7;
                                        aVar9 = aVar6;
                                        bVar2 = bVar;
                                    } else {
                                        int u4 = oiVar3.u();
                                        int o4 = oiVar3.o();
                                        i15 = i27;
                                        bVar2 = bVar;
                                        boolean a2 = z18 | yiVar2.a(bVar2, oiVar3, 1);
                                        int u5 = oiVar3.u();
                                        int o5 = oiVar3.o();
                                        if (u5 != u4) {
                                            oiVar3.P(u5);
                                            if (!z16 || oiVar3.s() <= max5) {
                                                aVar9 = aVar6;
                                            } else {
                                                aVar9 = aVar6;
                                                max5 = Math.max(max5, oiVar3.l(aVar9).d() + oiVar3.s());
                                            }
                                            z9 = true;
                                        } else {
                                            aVar9 = aVar6;
                                            z9 = a2;
                                        }
                                        if (o5 != o4) {
                                            oiVar3.K(o5);
                                            if (!z17 || oiVar3.m() <= max6) {
                                                aVar8 = aVar7;
                                            } else {
                                                aVar8 = aVar7;
                                                max6 = Math.max(max6, oiVar3.l(aVar8).d() + oiVar3.m());
                                            }
                                            z9 = true;
                                        } else {
                                            aVar8 = aVar7;
                                        }
                                        z18 = ((vi) oiVar3).J0 | z9;
                                    }
                                    i33++;
                                    bVar = bVar2;
                                    aVar6 = aVar9;
                                    aVar7 = aVar8;
                                    i27 = i15;
                                }
                                int i34 = 0;
                                int i35 = 2;
                                while (true) {
                                    if (i34 >= i35) {
                                        i11 = i31;
                                        i12 = i32;
                                        break;
                                    }
                                    boolean z19 = z18;
                                    int i36 = 0;
                                    while (i36 < size2) {
                                        oi oiVar4 = yiVar2.a.get(i36);
                                        if ((!(oiVar4 instanceof si) || (oiVar4 instanceof vi)) && !(oiVar4 instanceof ri) && oiVar4.j0 != 8 && ((!z4 || !oiVar4.d.e.j || !oiVar4.e.e.j) && !(oiVar4 instanceof vi))) {
                                            int u6 = oiVar4.u();
                                            int o6 = oiVar4.o();
                                            i13 = i31;
                                            int i37 = oiVar4.c0;
                                            i14 = i32;
                                            int i38 = 1;
                                            if (i34 == 1) {
                                                i38 = 2;
                                            }
                                            boolean a3 = yiVar2.a(bVar, oiVar4, i38) | z19;
                                            int u7 = oiVar4.u();
                                            int o7 = oiVar4.o();
                                            if (u7 != u6) {
                                                oiVar4.P(u7);
                                                if (z16 && oiVar4.s() > max5) {
                                                    max5 = Math.max(max5, oiVar4.l(aVar6).d() + oiVar4.s());
                                                }
                                                z8 = true;
                                            } else {
                                                z8 = a3;
                                            }
                                            if (o7 != o6) {
                                                oiVar4.K(o7);
                                                if (z17 && oiVar4.m() > max6) {
                                                    max6 = Math.max(max6, oiVar4.l(aVar7).d() + oiVar4.m());
                                                }
                                                z8 = true;
                                            }
                                            z19 = (!oiVar4.A || i37 == oiVar4.c0) ? z8 : true;
                                        } else {
                                            i13 = i31;
                                            i14 = i32;
                                        }
                                        i36++;
                                        size2 = size2;
                                        i31 = i13;
                                        i32 = i14;
                                    }
                                    if (!z19) {
                                        piVar2 = piVar;
                                        i11 = i31;
                                        i12 = i32;
                                        z18 = z19;
                                        break;
                                    }
                                    piVar2 = piVar;
                                    yiVar2.b(piVar2, i31, i32);
                                    i34++;
                                    i32 = i32;
                                    i35 = 2;
                                    z18 = false;
                                    i31 = i31;
                                    size2 = size2;
                                }
                                if (z18) {
                                    yiVar2.b(piVar2, i11, i12);
                                    if (piVar.u() < max5) {
                                        piVar2.P(max5);
                                        z6 = true;
                                    } else {
                                        z6 = false;
                                    }
                                    if (piVar.o() < max6) {
                                        piVar2.K(max6);
                                        z7 = true;
                                    } else {
                                        z7 = z6;
                                    }
                                    if (z7) {
                                        yiVar2.b(piVar2, i11, i12);
                                    }
                                }
                                i27 = i27;
                            }
                            piVar2.d0(i27);
                        }
                        return;
                    }
                    z2 = z;
                    i7 = 1073741824;
                    z3 = z2 & ((mode != i7 && mode2 == i7) || b2);
                    if (!z3) {
                    }
                    if (z5) {
                    }
                    int i272 = piVar2.T0;
                    if (size <= 0) {
                    }
                    yiVar2.c(piVar2);
                    size2 = yiVar2.a.size();
                    int i312 = i8;
                    int i322 = i9;
                    if (size > 0) {
                    }
                    if (size2 > 0) {
                    }
                    piVar2.d0(i272);
                }
            } else if (childCount == 0) {
                i20 = Math.max(0, this.j);
            } else {
                i5 = 0;
                aVar2 = aVar11;
            }
            aVar = aVar10;
            if (mode2 != Integer.MIN_VALUE) {
            }
            piVar2.J0.c = true;
            piVar2.W = 0;
            piVar2.X = 0;
            int[] iArr2 = piVar2.y;
            iArr2[0] = this.l - i25;
            iArr2[1] = this.m - i24;
            piVar2.N(0);
            piVar2.M(0);
            piVar2.Q[0] = aVar2;
            piVar2.P(i5);
            piVar2.Q[1] = aVar4;
            piVar2.K(i6);
            piVar2.N(this.j - i25);
            piVar2.M(this.k - i24);
            piVar2.N0 = max3;
            piVar2.O0 = max;
            yi yiVar42 = piVar2.I0;
            Objects.requireNonNull(yiVar42);
            ni.a aVar122 = ni.a.BOTTOM;
            ni.a aVar132 = ni.a.RIGHT;
            oi.a aVar142 = oi.a.MATCH_CONSTRAINT;
            yi.b bVar52 = piVar2.K0;
            size = piVar2.H0.size();
            int u22 = piVar.u();
            int o22 = piVar.o();
            boolean b22 = ui.b(i2, RecyclerView.b0.FLAG_IGNORE);
            if (!b22) {
            }
            if (z) {
            }
            z2 = z;
            i7 = 1073741824;
            z3 = z2 & ((mode != i7 && mode2 == i7) || b22);
            if (!z3) {
            }
            if (z5) {
            }
            int i2722 = piVar2.T0;
            if (size <= 0) {
            }
            yiVar2.c(piVar2);
            size2 = yiVar2.a.size();
            int i3122 = i8;
            int i3222 = i9;
            if (size > 0) {
            }
            if (size2 > 0) {
            }
            piVar2.d0(i2722);
        }
        i20 = childCount == 0 ? Math.max(0, this.j) : i22;
        aVar = aVar10;
        i5 = i20;
        aVar2 = aVar11;
        if (mode2 != Integer.MIN_VALUE) {
        }
        piVar2.J0.c = true;
        piVar2.W = 0;
        piVar2.X = 0;
        int[] iArr22 = piVar2.y;
        iArr22[0] = this.l - i25;
        iArr22[1] = this.m - i24;
        piVar2.N(0);
        piVar2.M(0);
        piVar2.Q[0] = aVar2;
        piVar2.P(i5);
        piVar2.Q[1] = aVar4;
        piVar2.K(i6);
        piVar2.N(this.j - i25);
        piVar2.M(this.k - i24);
        piVar2.N0 = max3;
        piVar2.O0 = max;
        yi yiVar422 = piVar2.I0;
        Objects.requireNonNull(yiVar422);
        ni.a aVar1222 = ni.a.BOTTOM;
        ni.a aVar1322 = ni.a.RIGHT;
        oi.a aVar1422 = oi.a.MATCH_CONSTRAINT;
        yi.b bVar522 = piVar2.K0;
        size = piVar2.H0.size();
        int u222 = piVar.u();
        int o222 = piVar.o();
        boolean b222 = ui.b(i2, RecyclerView.b0.FLAG_IGNORE);
        if (!b222) {
        }
        if (z) {
        }
        z2 = z;
        i7 = 1073741824;
        z3 = z2 & ((mode != i7 && mode2 == i7) || b222);
        if (!z3) {
        }
        if (z5) {
        }
        int i27222 = piVar2.T0;
        if (size <= 0) {
        }
        yiVar2.c(piVar2);
        size2 = yiVar2.a.size();
        int i31222 = i8;
        int i32222 = i9;
        if (size > 0) {
        }
        if (size2 > 0) {
        }
        piVar2.d0(i27222);
    }

    public void r(int i2, Object obj, Object obj2) {
        if (i2 == 0 && (obj instanceof String) && (obj2 instanceof Integer)) {
            if (this.s == null) {
                this.s = new HashMap<>();
            }
            String str = (String) obj;
            int indexOf = str.indexOf("/");
            if (indexOf != -1) {
                str = str.substring(indexOf + 1);
            }
            this.s.put(str, Integer.valueOf(((Integer) obj2).intValue()));
        }
    }

    public void removeView(View view) {
        super.removeView(view);
    }

    public void requestLayout() {
        this.n = true;
        this.t = -1;
        this.u = -1;
        super.requestLayout();
    }

    public void setConstraintSet(pj pjVar) {
        this.p = pjVar;
    }

    public void setId(int i2) {
        this.g.remove(getId());
        super.setId(i2);
        this.g.put(getId(), this);
    }

    public void setMaxHeight(int i2) {
        if (i2 != this.m) {
            this.m = i2;
            requestLayout();
        }
    }

    public void setMaxWidth(int i2) {
        if (i2 != this.l) {
            this.l = i2;
            requestLayout();
        }
    }

    public void setMinHeight(int i2) {
        if (i2 != this.k) {
            this.k = i2;
            requestLayout();
        }
    }

    public void setMinWidth(int i2) {
        if (i2 != this.j) {
            this.j = i2;
            requestLayout();
        }
    }

    public void setOnConstraintsChanged(qj qjVar) {
        oj ojVar = this.q;
        if (ojVar != null) {
            Objects.requireNonNull(ojVar);
        }
    }

    public void setOptimizationLevel(int i2) {
        this.o = i2;
        pi piVar = this.i;
        piVar.T0 = i2;
        hi.p = piVar.b0(RecyclerView.b0.FLAG_ADAPTER_POSITION_UNKNOWN);
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new a(layoutParams);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        g(attributeSet, i2, 0);
    }

    public static class a extends ViewGroup.MarginLayoutParams {
        public float A = 0.5f;
        public String B = null;
        public int C = 1;
        public float D = -1.0f;
        public float E = -1.0f;
        public int F = 0;
        public int G = 0;
        public int H = 0;
        public int I = 0;
        public int J = 0;
        public int K = 0;
        public int L = 0;
        public int M = 0;
        public float N = 1.0f;
        public float O = 1.0f;
        public int P = -1;
        public int Q = -1;
        public int R = -1;
        public boolean S = false;
        public boolean T = false;
        public String U = null;
        public boolean V = true;
        public boolean W = true;
        public boolean X = false;
        public boolean Y = false;
        public boolean Z = false;
        public int a = -1;
        public boolean a0 = false;
        public int b = -1;
        public int b0 = -1;
        public float c = -1.0f;
        public int c0 = -1;
        public int d = -1;
        public int d0 = -1;
        public int e = -1;
        public int e0 = -1;
        public int f = -1;
        public int f0 = -1;
        public int g = -1;
        public int g0 = -1;
        public int h = -1;
        public float h0 = 0.5f;
        public int i = -1;
        public int i0;
        public int j = -1;
        public int j0;
        public int k = -1;
        public float k0;
        public int l = -1;
        public oi l0 = new oi();
        public int m = -1;
        public int n = 0;
        public float o = Utils.FLOAT_EPSILON;
        public int p = -1;
        public int q = -1;
        public int r = -1;
        public int s = -1;
        public int t = -1;
        public int u = -1;
        public int v = -1;
        public int w = -1;
        public int x = -1;
        public int y = -1;
        public float z = 0.5f;

        /* renamed from: androidx.constraintlayout.widget.ConstraintLayout$a$a  reason: collision with other inner class name */
        public static class C0002a {
            public static final SparseIntArray a;

            static {
                SparseIntArray sparseIntArray = new SparseIntArray();
                a = sparseIntArray;
                sparseIntArray.append(64, 8);
                sparseIntArray.append(65, 9);
                sparseIntArray.append(67, 10);
                sparseIntArray.append(68, 11);
                sparseIntArray.append(74, 12);
                sparseIntArray.append(73, 13);
                sparseIntArray.append(46, 14);
                sparseIntArray.append(45, 15);
                sparseIntArray.append(43, 16);
                sparseIntArray.append(47, 2);
                sparseIntArray.append(49, 3);
                sparseIntArray.append(48, 4);
                sparseIntArray.append(82, 49);
                sparseIntArray.append(83, 50);
                sparseIntArray.append(53, 5);
                sparseIntArray.append(54, 6);
                sparseIntArray.append(55, 7);
                sparseIntArray.append(0, 1);
                sparseIntArray.append(69, 17);
                sparseIntArray.append(70, 18);
                sparseIntArray.append(52, 19);
                sparseIntArray.append(51, 20);
                sparseIntArray.append(86, 21);
                sparseIntArray.append(89, 22);
                sparseIntArray.append(87, 23);
                sparseIntArray.append(84, 24);
                sparseIntArray.append(88, 25);
                sparseIntArray.append(85, 26);
                sparseIntArray.append(60, 29);
                sparseIntArray.append(75, 30);
                sparseIntArray.append(50, 44);
                sparseIntArray.append(62, 45);
                sparseIntArray.append(77, 46);
                sparseIntArray.append(61, 47);
                sparseIntArray.append(76, 48);
                sparseIntArray.append(41, 27);
                sparseIntArray.append(40, 28);
                sparseIntArray.append(78, 31);
                sparseIntArray.append(56, 32);
                sparseIntArray.append(80, 33);
                sparseIntArray.append(79, 34);
                sparseIntArray.append(81, 35);
                sparseIntArray.append(58, 36);
                sparseIntArray.append(57, 37);
                sparseIntArray.append(59, 38);
                sparseIntArray.append(63, 39);
                sparseIntArray.append(72, 40);
                sparseIntArray.append(66, 41);
                sparseIntArray.append(44, 42);
                sparseIntArray.append(42, 43);
                sparseIntArray.append(71, 51);
            }
        }

        public a(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            int i2;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, tj.b);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i3 = 0; i3 < indexCount; i3++) {
                int index = obtainStyledAttributes.getIndex(i3);
                int i4 = C0002a.a.get(index);
                switch (i4) {
                    case 1:
                        this.R = obtainStyledAttributes.getInt(index, this.R);
                        break;
                    case 2:
                        int resourceId = obtainStyledAttributes.getResourceId(index, this.m);
                        this.m = resourceId;
                        if (resourceId == -1) {
                            this.m = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 3:
                        this.n = obtainStyledAttributes.getDimensionPixelSize(index, this.n);
                        break;
                    case 4:
                        float f2 = obtainStyledAttributes.getFloat(index, this.o) % 360.0f;
                        this.o = f2;
                        if (f2 < Utils.FLOAT_EPSILON) {
                            this.o = (360.0f - f2) % 360.0f;
                            break;
                        } else {
                            break;
                        }
                    case 5:
                        this.a = obtainStyledAttributes.getDimensionPixelOffset(index, this.a);
                        break;
                    case 6:
                        this.b = obtainStyledAttributes.getDimensionPixelOffset(index, this.b);
                        break;
                    case 7:
                        this.c = obtainStyledAttributes.getFloat(index, this.c);
                        break;
                    case 8:
                        int resourceId2 = obtainStyledAttributes.getResourceId(index, this.d);
                        this.d = resourceId2;
                        if (resourceId2 == -1) {
                            this.d = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 9:
                        int resourceId3 = obtainStyledAttributes.getResourceId(index, this.e);
                        this.e = resourceId3;
                        if (resourceId3 == -1) {
                            this.e = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 10:
                        int resourceId4 = obtainStyledAttributes.getResourceId(index, this.f);
                        this.f = resourceId4;
                        if (resourceId4 == -1) {
                            this.f = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 11:
                        int resourceId5 = obtainStyledAttributes.getResourceId(index, this.g);
                        this.g = resourceId5;
                        if (resourceId5 == -1) {
                            this.g = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 12:
                        int resourceId6 = obtainStyledAttributes.getResourceId(index, this.h);
                        this.h = resourceId6;
                        if (resourceId6 == -1) {
                            this.h = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 13:
                        int resourceId7 = obtainStyledAttributes.getResourceId(index, this.i);
                        this.i = resourceId7;
                        if (resourceId7 == -1) {
                            this.i = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 14:
                        int resourceId8 = obtainStyledAttributes.getResourceId(index, this.j);
                        this.j = resourceId8;
                        if (resourceId8 == -1) {
                            this.j = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 15:
                        int resourceId9 = obtainStyledAttributes.getResourceId(index, this.k);
                        this.k = resourceId9;
                        if (resourceId9 == -1) {
                            this.k = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 16:
                        int resourceId10 = obtainStyledAttributes.getResourceId(index, this.l);
                        this.l = resourceId10;
                        if (resourceId10 == -1) {
                            this.l = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 17:
                        int resourceId11 = obtainStyledAttributes.getResourceId(index, this.p);
                        this.p = resourceId11;
                        if (resourceId11 == -1) {
                            this.p = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 18:
                        int resourceId12 = obtainStyledAttributes.getResourceId(index, this.q);
                        this.q = resourceId12;
                        if (resourceId12 == -1) {
                            this.q = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 19:
                        int resourceId13 = obtainStyledAttributes.getResourceId(index, this.r);
                        this.r = resourceId13;
                        if (resourceId13 == -1) {
                            this.r = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 20:
                        int resourceId14 = obtainStyledAttributes.getResourceId(index, this.s);
                        this.s = resourceId14;
                        if (resourceId14 == -1) {
                            this.s = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 21:
                        this.t = obtainStyledAttributes.getDimensionPixelSize(index, this.t);
                        break;
                    case 22:
                        this.u = obtainStyledAttributes.getDimensionPixelSize(index, this.u);
                        break;
                    case 23:
                        this.v = obtainStyledAttributes.getDimensionPixelSize(index, this.v);
                        break;
                    case 24:
                        this.w = obtainStyledAttributes.getDimensionPixelSize(index, this.w);
                        break;
                    case 25:
                        this.x = obtainStyledAttributes.getDimensionPixelSize(index, this.x);
                        break;
                    case 26:
                        this.y = obtainStyledAttributes.getDimensionPixelSize(index, this.y);
                        break;
                    case 27:
                        this.S = obtainStyledAttributes.getBoolean(index, this.S);
                        break;
                    case 28:
                        this.T = obtainStyledAttributes.getBoolean(index, this.T);
                        break;
                    case 29:
                        this.z = obtainStyledAttributes.getFloat(index, this.z);
                        break;
                    case R.styleable.AppCompatTheme_actionOverflowButtonStyle /*{ENCODED_INT: 30}*/:
                        this.A = obtainStyledAttributes.getFloat(index, this.A);
                        break;
                    case R.styleable.AppCompatTheme_actionOverflowMenuStyle /*{ENCODED_INT: 31}*/:
                        int i5 = obtainStyledAttributes.getInt(index, 0);
                        this.H = i5;
                        if (i5 == 1) {
                            Log.e("ConstraintLayout", "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead.");
                            break;
                        } else {
                            break;
                        }
                    case 32:
                        int i6 = obtainStyledAttributes.getInt(index, 0);
                        this.I = i6;
                        if (i6 == 1) {
                            Log.e("ConstraintLayout", "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead.");
                            break;
                        } else {
                            break;
                        }
                    case R.styleable.AppCompatTheme_alertDialogButtonGroupStyle /*{ENCODED_INT: 33}*/:
                        try {
                            this.J = obtainStyledAttributes.getDimensionPixelSize(index, this.J);
                            break;
                        } catch (Exception unused) {
                            if (obtainStyledAttributes.getInt(index, this.J) == -2) {
                                this.J = -2;
                                break;
                            } else {
                                break;
                            }
                        }
                    case R.styleable.AppCompatTheme_alertDialogCenterButtons /*{ENCODED_INT: 34}*/:
                        try {
                            this.L = obtainStyledAttributes.getDimensionPixelSize(index, this.L);
                            break;
                        } catch (Exception unused2) {
                            if (obtainStyledAttributes.getInt(index, this.L) == -2) {
                                this.L = -2;
                                break;
                            } else {
                                break;
                            }
                        }
                    case R.styleable.AppCompatTheme_alertDialogStyle /*{ENCODED_INT: 35}*/:
                        this.N = Math.max((float) Utils.FLOAT_EPSILON, obtainStyledAttributes.getFloat(index, this.N));
                        this.H = 2;
                        break;
                    case R.styleable.AppCompatTheme_alertDialogTheme /*{ENCODED_INT: 36}*/:
                        try {
                            this.K = obtainStyledAttributes.getDimensionPixelSize(index, this.K);
                            break;
                        } catch (Exception unused3) {
                            if (obtainStyledAttributes.getInt(index, this.K) == -2) {
                                this.K = -2;
                                break;
                            } else {
                                break;
                            }
                        }
                    case R.styleable.AppCompatTheme_autoCompleteTextViewStyle /*{ENCODED_INT: 37}*/:
                        try {
                            this.M = obtainStyledAttributes.getDimensionPixelSize(index, this.M);
                            break;
                        } catch (Exception unused4) {
                            if (obtainStyledAttributes.getInt(index, this.M) == -2) {
                                this.M = -2;
                                break;
                            } else {
                                break;
                            }
                        }
                    case R.styleable.AppCompatTheme_borderlessButtonStyle /*{ENCODED_INT: 38}*/:
                        this.O = Math.max((float) Utils.FLOAT_EPSILON, obtainStyledAttributes.getFloat(index, this.O));
                        this.I = 2;
                        break;
                    default:
                        switch (i4) {
                            case R.styleable.AppCompatTheme_buttonStyle /*{ENCODED_INT: 44}*/:
                                String string = obtainStyledAttributes.getString(index);
                                this.B = string;
                                this.C = -1;
                                if (string == null) {
                                    break;
                                } else {
                                    int length = string.length();
                                    int indexOf = this.B.indexOf(44);
                                    if (indexOf <= 0 || indexOf >= length - 1) {
                                        i2 = 0;
                                    } else {
                                        String substring = this.B.substring(0, indexOf);
                                        if (substring.equalsIgnoreCase("W")) {
                                            this.C = 0;
                                        } else if (substring.equalsIgnoreCase("H")) {
                                            this.C = 1;
                                        }
                                        i2 = indexOf + 1;
                                    }
                                    int indexOf2 = this.B.indexOf(58);
                                    if (indexOf2 >= 0 && indexOf2 < length - 1) {
                                        String substring2 = this.B.substring(i2, indexOf2);
                                        String substring3 = this.B.substring(indexOf2 + 1);
                                        if (substring2.length() > 0 && substring3.length() > 0) {
                                            try {
                                                float parseFloat = Float.parseFloat(substring2);
                                                float parseFloat2 = Float.parseFloat(substring3);
                                                if (parseFloat > Utils.FLOAT_EPSILON && parseFloat2 > Utils.FLOAT_EPSILON) {
                                                    if (this.C == 1) {
                                                        Math.abs(parseFloat2 / parseFloat);
                                                        break;
                                                    } else {
                                                        Math.abs(parseFloat / parseFloat2);
                                                        break;
                                                    }
                                                }
                                            } catch (NumberFormatException unused5) {
                                                break;
                                            }
                                        }
                                    } else {
                                        String substring4 = this.B.substring(i2);
                                        if (substring4.length() <= 0) {
                                            break;
                                        } else {
                                            Float.parseFloat(substring4);
                                            continue;
                                        }
                                    }
                                }
                                break;
                            case R.styleable.AppCompatTheme_buttonStyleSmall /*{ENCODED_INT: 45}*/:
                                this.D = obtainStyledAttributes.getFloat(index, this.D);
                                continue;
                            case R.styleable.AppCompatTheme_checkboxStyle /*{ENCODED_INT: 46}*/:
                                this.E = obtainStyledAttributes.getFloat(index, this.E);
                                continue;
                            case R.styleable.AppCompatTheme_checkedTextViewStyle /*{ENCODED_INT: 47}*/:
                                this.F = obtainStyledAttributes.getInt(index, 0);
                                continue;
                            case R.styleable.AppCompatTheme_colorAccent /*{ENCODED_INT: 48}*/:
                                this.G = obtainStyledAttributes.getInt(index, 0);
                                continue;
                            case R.styleable.AppCompatTheme_colorBackgroundFloating /*{ENCODED_INT: 49}*/:
                                this.P = obtainStyledAttributes.getDimensionPixelOffset(index, this.P);
                                continue;
                            case R.styleable.AppCompatTheme_colorButtonNormal /*{ENCODED_INT: 50}*/:
                                this.Q = obtainStyledAttributes.getDimensionPixelOffset(index, this.Q);
                                continue;
                            case R.styleable.AppCompatTheme_colorControlActivated /*{ENCODED_INT: 51}*/:
                                this.U = obtainStyledAttributes.getString(index);
                                continue;
                        }
                }
            }
            obtainStyledAttributes.recycle();
            a();
        }

        public void a() {
            this.Y = false;
            this.V = true;
            this.W = true;
            int i2 = ((ViewGroup.MarginLayoutParams) this).width;
            if (i2 == -2 && this.S) {
                this.V = false;
                if (this.H == 0) {
                    this.H = 1;
                }
            }
            int i3 = ((ViewGroup.MarginLayoutParams) this).height;
            if (i3 == -2 && this.T) {
                this.W = false;
                if (this.I == 0) {
                    this.I = 1;
                }
            }
            if (i2 == 0 || i2 == -1) {
                this.V = false;
                if (i2 == 0 && this.H == 1) {
                    ((ViewGroup.MarginLayoutParams) this).width = -2;
                    this.S = true;
                }
            }
            if (i3 == 0 || i3 == -1) {
                this.W = false;
                if (i3 == 0 && this.I == 1) {
                    ((ViewGroup.MarginLayoutParams) this).height = -2;
                    this.T = true;
                }
            }
            if (this.c != -1.0f || this.a != -1 || this.b != -1) {
                this.Y = true;
                this.V = true;
                this.W = true;
                if (!(this.l0 instanceof ri)) {
                    this.l0 = new ri();
                }
                ((ri) this.l0).T(this.R);
            }
        }

        /* JADX WARNING: Removed duplicated region for block: B:15:0x004c  */
        /* JADX WARNING: Removed duplicated region for block: B:18:0x0053  */
        /* JADX WARNING: Removed duplicated region for block: B:21:0x005a  */
        /* JADX WARNING: Removed duplicated region for block: B:24:0x0060  */
        /* JADX WARNING: Removed duplicated region for block: B:27:0x0066  */
        /* JADX WARNING: Removed duplicated region for block: B:34:0x0078  */
        /* JADX WARNING: Removed duplicated region for block: B:35:0x0080  */
        @TargetApi(17)
        public void resolveLayoutDirection(int i2) {
            int i3;
            int i4;
            int i5;
            int i6;
            int i7 = ((ViewGroup.MarginLayoutParams) this).leftMargin;
            int i8 = ((ViewGroup.MarginLayoutParams) this).rightMargin;
            super.resolveLayoutDirection(i2);
            boolean z2 = false;
            boolean z3 = 1 == getLayoutDirection();
            this.d0 = -1;
            this.e0 = -1;
            this.b0 = -1;
            this.c0 = -1;
            this.f0 = -1;
            this.g0 = -1;
            this.f0 = this.t;
            this.g0 = this.v;
            float f2 = this.z;
            this.h0 = f2;
            int i9 = this.a;
            this.i0 = i9;
            int i10 = this.b;
            this.j0 = i10;
            float f3 = this.c;
            this.k0 = f3;
            if (z3) {
                int i11 = this.p;
                if (i11 != -1) {
                    this.d0 = i11;
                } else {
                    int i12 = this.q;
                    if (i12 != -1) {
                        this.e0 = i12;
                    }
                    i3 = this.r;
                    if (i3 != -1) {
                        this.c0 = i3;
                        z2 = true;
                    }
                    i4 = this.s;
                    if (i4 != -1) {
                        this.b0 = i4;
                        z2 = true;
                    }
                    i5 = this.x;
                    if (i5 != -1) {
                        this.g0 = i5;
                    }
                    i6 = this.y;
                    if (i6 != -1) {
                        this.f0 = i6;
                    }
                    if (z2) {
                        this.h0 = 1.0f - f2;
                    }
                    if (this.Y && this.R == 1) {
                        if (f3 == -1.0f) {
                            this.k0 = 1.0f - f3;
                            this.i0 = -1;
                            this.j0 = -1;
                        } else if (i9 != -1) {
                            this.j0 = i9;
                            this.i0 = -1;
                            this.k0 = -1.0f;
                        } else if (i10 != -1) {
                            this.i0 = i10;
                            this.j0 = -1;
                            this.k0 = -1.0f;
                        }
                    }
                }
                z2 = true;
                i3 = this.r;
                if (i3 != -1) {
                }
                i4 = this.s;
                if (i4 != -1) {
                }
                i5 = this.x;
                if (i5 != -1) {
                }
                i6 = this.y;
                if (i6 != -1) {
                }
                if (z2) {
                }
                if (f3 == -1.0f) {
                }
            } else {
                int i13 = this.p;
                if (i13 != -1) {
                    this.c0 = i13;
                }
                int i14 = this.q;
                if (i14 != -1) {
                    this.b0 = i14;
                }
                int i15 = this.r;
                if (i15 != -1) {
                    this.d0 = i15;
                }
                int i16 = this.s;
                if (i16 != -1) {
                    this.e0 = i16;
                }
                int i17 = this.x;
                if (i17 != -1) {
                    this.f0 = i17;
                }
                int i18 = this.y;
                if (i18 != -1) {
                    this.g0 = i18;
                }
            }
            if (this.r == -1 && this.s == -1 && this.q == -1 && this.p == -1) {
                int i19 = this.f;
                if (i19 != -1) {
                    this.d0 = i19;
                    if (((ViewGroup.MarginLayoutParams) this).rightMargin <= 0 && i8 > 0) {
                        ((ViewGroup.MarginLayoutParams) this).rightMargin = i8;
                    }
                } else {
                    int i20 = this.g;
                    if (i20 != -1) {
                        this.e0 = i20;
                        if (((ViewGroup.MarginLayoutParams) this).rightMargin <= 0 && i8 > 0) {
                            ((ViewGroup.MarginLayoutParams) this).rightMargin = i8;
                        }
                    }
                }
                int i21 = this.d;
                if (i21 != -1) {
                    this.b0 = i21;
                    if (((ViewGroup.MarginLayoutParams) this).leftMargin <= 0 && i7 > 0) {
                        ((ViewGroup.MarginLayoutParams) this).leftMargin = i7;
                        return;
                    }
                    return;
                }
                int i22 = this.e;
                if (i22 != -1) {
                    this.c0 = i22;
                    if (((ViewGroup.MarginLayoutParams) this).leftMargin <= 0 && i7 > 0) {
                        ((ViewGroup.MarginLayoutParams) this).leftMargin = i7;
                    }
                }
            }
        }

        public a(int i2, int i3) {
            super(i2, i3);
        }

        public a(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }
}
