package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.SparseArray;
import androidx.constraintlayout.widget.ConstraintLayout;
import defpackage.pj;

public class Barrier extends nj {
    public int o;
    public int p;
    public li q;

    public Barrier(Context context) {
        super(context);
        super.setVisibility(8);
    }

    public int getMargin() {
        return this.q.L0;
    }

    public int getType() {
        return this.o;
    }

    @Override // defpackage.nj
    public void k(AttributeSet attributeSet) {
        super.k(attributeSet);
        this.q = new li();
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, tj.b);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 15) {
                    setType(obtainStyledAttributes.getInt(index, 0));
                } else if (index == 14) {
                    this.q.K0 = obtainStyledAttributes.getBoolean(index, true);
                } else if (index == 16) {
                    this.q.L0 = obtainStyledAttributes.getDimensionPixelSize(index, 0);
                }
            }
            obtainStyledAttributes.recycle();
        }
        this.j = this.q;
        r();
    }

    @Override // defpackage.nj
    public void l(pj.a aVar, ti tiVar, ConstraintLayout.a aVar2, SparseArray<oi> sparseArray) {
        super.l(aVar, tiVar, aVar2, sparseArray);
        if (tiVar instanceof li) {
            li liVar = (li) tiVar;
            s(liVar, aVar.d.b0, ((pi) tiVar.R).L0);
            pj.b bVar = aVar.d;
            liVar.K0 = bVar.j0;
            liVar.L0 = bVar.c0;
        }
    }

    @Override // defpackage.nj
    public void m(oi oiVar, boolean z) {
        s(oiVar, this.o, z);
    }

    public final void s(oi oiVar, int i, boolean z) {
        this.p = i;
        if (z) {
            int i2 = this.o;
            if (i2 == 5) {
                this.p = 1;
            } else if (i2 == 6) {
                this.p = 0;
            }
        } else {
            int i3 = this.o;
            if (i3 == 5) {
                this.p = 0;
            } else if (i3 == 6) {
                this.p = 1;
            }
        }
        if (oiVar instanceof li) {
            ((li) oiVar).J0 = this.p;
        }
    }

    public void setAllowsGoneWidget(boolean z) {
        this.q.K0 = z;
    }

    public void setDpMargin(int i) {
        this.q.L0 = (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    public void setMargin(int i) {
        this.q.L0 = i;
    }

    public void setType(int i) {
        this.o = i;
    }

    public Barrier(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        super.setVisibility(8);
    }
}
