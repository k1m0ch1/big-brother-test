package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.github.mikephil.charting.utils.Utils;
import defpackage.pj;
import java.util.Objects;

public class Constraints extends ViewGroup {
    public pj g;

    public Constraints(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        a();
        super.setVisibility(8);
    }

    public final void a() {
        Log.v("Constraints", " ################# init");
    }

    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new a(-2, -2);
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new a(getContext(), attributeSet);
    }

    public pj getConstraintSet() {
        if (this.g == null) {
            this.g = new pj();
        }
        pj pjVar = this.g;
        Objects.requireNonNull(pjVar);
        int childCount = getChildCount();
        pjVar.c.clear();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            a aVar = (a) childAt.getLayoutParams();
            int id = childAt.getId();
            if (!pjVar.b || id != -1) {
                if (!pjVar.c.containsKey(Integer.valueOf(id))) {
                    pjVar.c.put(Integer.valueOf(id), new pj.a());
                }
                pj.a aVar2 = pjVar.c.get(Integer.valueOf(id));
                if (childAt instanceof nj) {
                    nj njVar = (nj) childAt;
                    aVar2.c(id, aVar);
                    if (njVar instanceof Barrier) {
                        pj.b bVar = aVar2.d;
                        bVar.d0 = 1;
                        Barrier barrier = (Barrier) njVar;
                        bVar.b0 = barrier.getType();
                        aVar2.d.e0 = barrier.getReferencedIds();
                        aVar2.d.c0 = barrier.getMargin();
                    }
                }
                aVar2.c(id, aVar);
            } else {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            }
        }
        return this.g;
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new ConstraintLayout.a(layoutParams);
    }

    public static class a extends ConstraintLayout.a {
        public float m0;
        public boolean n0;
        public float o0;
        public float p0;
        public float q0;
        public float r0;
        public float s0;
        public float t0;
        public float u0;
        public float v0;
        public float w0;
        public float x0;
        public float y0;

        public a(int i, int i2) {
            super(i, i2);
            this.m0 = 1.0f;
            this.n0 = false;
            this.o0 = Utils.FLOAT_EPSILON;
            this.p0 = Utils.FLOAT_EPSILON;
            this.q0 = Utils.FLOAT_EPSILON;
            this.r0 = Utils.FLOAT_EPSILON;
            this.s0 = 1.0f;
            this.t0 = 1.0f;
            this.u0 = Utils.FLOAT_EPSILON;
            this.v0 = Utils.FLOAT_EPSILON;
            this.w0 = Utils.FLOAT_EPSILON;
            this.x0 = Utils.FLOAT_EPSILON;
            this.y0 = Utils.FLOAT_EPSILON;
        }

        public a(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.m0 = 1.0f;
            this.n0 = false;
            this.o0 = Utils.FLOAT_EPSILON;
            this.p0 = Utils.FLOAT_EPSILON;
            this.q0 = Utils.FLOAT_EPSILON;
            this.r0 = Utils.FLOAT_EPSILON;
            this.s0 = 1.0f;
            this.t0 = 1.0f;
            this.u0 = Utils.FLOAT_EPSILON;
            this.v0 = Utils.FLOAT_EPSILON;
            this.w0 = Utils.FLOAT_EPSILON;
            this.x0 = Utils.FLOAT_EPSILON;
            this.y0 = Utils.FLOAT_EPSILON;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, tj.c);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 15) {
                    this.m0 = obtainStyledAttributes.getFloat(index, this.m0);
                } else if (index == 28) {
                    this.o0 = obtainStyledAttributes.getFloat(index, this.o0);
                    this.n0 = true;
                } else if (index == 23) {
                    this.q0 = obtainStyledAttributes.getFloat(index, this.q0);
                } else if (index == 24) {
                    this.r0 = obtainStyledAttributes.getFloat(index, this.r0);
                } else if (index == 22) {
                    this.p0 = obtainStyledAttributes.getFloat(index, this.p0);
                } else if (index == 20) {
                    this.s0 = obtainStyledAttributes.getFloat(index, this.s0);
                } else if (index == 21) {
                    this.t0 = obtainStyledAttributes.getFloat(index, this.t0);
                } else if (index == 16) {
                    this.u0 = obtainStyledAttributes.getFloat(index, this.u0);
                } else if (index == 17) {
                    this.v0 = obtainStyledAttributes.getFloat(index, this.v0);
                } else if (index == 18) {
                    this.w0 = obtainStyledAttributes.getFloat(index, this.w0);
                } else if (index == 19) {
                    this.x0 = obtainStyledAttributes.getFloat(index, this.x0);
                } else if (index == 27) {
                    this.y0 = obtainStyledAttributes.getFloat(index, this.y0);
                }
            }
            obtainStyledAttributes.recycle();
        }
    }
}
