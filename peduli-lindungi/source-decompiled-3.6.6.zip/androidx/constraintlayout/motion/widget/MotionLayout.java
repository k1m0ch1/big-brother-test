package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import androidx.constraintlayout.widget.Barrier;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Constraints;
import androidx.core.widget.NestedScrollView;
import com.github.mikephil.charting.utils.Utils;
import com.google.maps.android.BuildConfig;
import defpackage.oi;
import defpackage.oj;
import defpackage.pj;
import defpackage.uj;
import defpackage.yh;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Objects;

public class MotionLayout extends ConstraintLayout implements tn {
    public static boolean K0;
    public Interpolator A;
    public float A0;
    public float B = Utils.FLOAT_EPSILON;
    public lh B0;
    public int C = -1;
    public boolean C0;
    public int D = -1;
    public g D0;
    public int E = -1;
    public i E0;
    public int F;
    public d F0;
    public int G;
    public boolean G0;
    public boolean H;
    public RectF H0;
    public HashMap<View, uh> I;
    public View I0;
    public long J;
    public ArrayList<Integer> J0;
    public float K;
    public float L;
    public float M;
    public long N;
    public float O;
    public boolean P;
    public boolean Q;
    public h R;
    public float S;
    public float T;
    public int U;
    public c V;
    public boolean W;
    public hh a0;
    public b b0;
    public ih c0;
    public int d0;
    public int e0;
    public boolean f0;
    public float g0;
    public float h0;
    public long i0;
    public float j0;
    public boolean k0;
    public ArrayList<vh> l0;
    public ArrayList<vh> m0;
    public ArrayList<h> n0;
    public int o0;
    public long p0;
    public float q0;
    public int r0;
    public float s0;
    public boolean t0;
    public int u0;
    public int v0;
    public int w0;
    public int x0;
    public int y0;
    public yh z;
    public int z0;

    public class a implements Runnable {
        public final /* synthetic */ View g;

        public a(MotionLayout motionLayout, View view) {
            this.g = view;
        }

        public void run() {
            this.g.setNestedScrollingEnabled(true);
        }
    }

    public class b extends wh {
        public float a = Utils.FLOAT_EPSILON;
        public float b = Utils.FLOAT_EPSILON;
        public float c;

        public b() {
        }

        @Override // defpackage.wh
        public float a() {
            return MotionLayout.this.B;
        }

        public float getInterpolation(float f) {
            float f2 = this.a;
            if (f2 > Utils.FLOAT_EPSILON) {
                float f3 = this.c;
                if (f2 / f3 < f) {
                    f = f2 / f3;
                }
                MotionLayout.this.B = f2 - (f3 * f);
                return ((f2 * f) - (((f3 * f) * f) / 2.0f)) + this.b;
            }
            float f4 = this.c;
            if ((-f2) / f4 < f) {
                f = (-f2) / f4;
            }
            MotionLayout.this.B = (f4 * f) + f2;
            return (((f4 * f) * f) / 2.0f) + (f2 * f) + this.b;
        }
    }

    public class c {
        public float[] a;
        public int[] b;
        public float[] c;
        public Path d;
        public Paint e;
        public Paint f;
        public Paint g;
        public Paint h;
        public Paint i;
        public float[] j;
        public DashPathEffect k;
        public int l;
        public Rect m = new Rect();
        public int n = 1;

        public c() {
            Paint paint = new Paint();
            this.e = paint;
            paint.setAntiAlias(true);
            this.e.setColor(-21965);
            this.e.setStrokeWidth(2.0f);
            this.e.setStyle(Paint.Style.STROKE);
            Paint paint2 = new Paint();
            this.f = paint2;
            paint2.setAntiAlias(true);
            this.f.setColor(-2067046);
            this.f.setStrokeWidth(2.0f);
            this.f.setStyle(Paint.Style.STROKE);
            Paint paint3 = new Paint();
            this.g = paint3;
            paint3.setAntiAlias(true);
            this.g.setColor(-13391360);
            this.g.setStrokeWidth(2.0f);
            this.g.setStyle(Paint.Style.STROKE);
            Paint paint4 = new Paint();
            this.h = paint4;
            paint4.setAntiAlias(true);
            this.h.setColor(-13391360);
            this.h.setTextSize(MotionLayout.this.getContext().getResources().getDisplayMetrics().density * 12.0f);
            this.j = new float[8];
            Paint paint5 = new Paint();
            this.i = paint5;
            paint5.setAntiAlias(true);
            DashPathEffect dashPathEffect = new DashPathEffect(new float[]{4.0f, 8.0f}, Utils.FLOAT_EPSILON);
            this.k = dashPathEffect;
            this.g.setPathEffect(dashPathEffect);
            this.c = new float[100];
            this.b = new int[50];
        }

        public void a(Canvas canvas, int i2, int i3, uh uhVar) {
            int i4;
            int i5;
            int i6;
            float f2;
            float f3;
            if (i2 == 4) {
                boolean z = false;
                boolean z2 = false;
                for (int i7 = 0; i7 < this.l; i7++) {
                    int[] iArr = this.b;
                    if (iArr[i7] == 1) {
                        z = true;
                    }
                    if (iArr[i7] == 2) {
                        z2 = true;
                    }
                }
                if (z) {
                    d(canvas);
                }
                if (z2) {
                    b(canvas);
                }
            }
            if (i2 == 2) {
                d(canvas);
            }
            if (i2 == 3) {
                b(canvas);
            }
            canvas.drawLines(this.a, this.e);
            View view = uhVar.a;
            if (view != null) {
                i5 = view.getWidth();
                i4 = uhVar.a.getHeight();
            } else {
                i5 = 0;
                i4 = 0;
            }
            int i8 = 1;
            while (i8 < i3 - 1) {
                if (i2 == 4 && this.b[i8 - 1] == 0) {
                    i6 = i8;
                } else {
                    float[] fArr = this.c;
                    int i9 = i8 * 2;
                    float f4 = fArr[i9];
                    float f5 = fArr[i9 + 1];
                    this.d.reset();
                    this.d.moveTo(f4, f5 + 10.0f);
                    this.d.lineTo(f4 + 10.0f, f5);
                    this.d.lineTo(f4, f5 - 10.0f);
                    this.d.lineTo(f4 - 10.0f, f5);
                    this.d.close();
                    int i10 = i8 - 1;
                    uhVar.t.get(i10);
                    if (i2 == 4) {
                        int[] iArr2 = this.b;
                        if (iArr2[i10] == 1) {
                            e(canvas, f4 - Utils.FLOAT_EPSILON, f5 - Utils.FLOAT_EPSILON);
                        } else if (iArr2[i10] == 2) {
                            c(canvas, f4 - Utils.FLOAT_EPSILON, f5 - Utils.FLOAT_EPSILON);
                        } else if (iArr2[i10] == 3) {
                            f2 = f5;
                            f3 = f4;
                            i6 = i8;
                            f(canvas, f4 - Utils.FLOAT_EPSILON, f5 - Utils.FLOAT_EPSILON, i5, i4);
                            canvas.drawPath(this.d, this.i);
                        }
                        f2 = f5;
                        f3 = f4;
                        i6 = i8;
                        canvas.drawPath(this.d, this.i);
                    } else {
                        f2 = f5;
                        f3 = f4;
                        i6 = i8;
                    }
                    if (i2 == 2) {
                        e(canvas, f3 - Utils.FLOAT_EPSILON, f2 - Utils.FLOAT_EPSILON);
                    }
                    if (i2 == 3) {
                        c(canvas, f3 - Utils.FLOAT_EPSILON, f2 - Utils.FLOAT_EPSILON);
                    }
                    if (i2 == 6) {
                        f(canvas, f3 - Utils.FLOAT_EPSILON, f2 - Utils.FLOAT_EPSILON, i5, i4);
                    }
                    canvas.drawPath(this.d, this.i);
                }
                i8 = i6 + 1;
            }
            float[] fArr2 = this.a;
            if (fArr2.length > 1) {
                canvas.drawCircle(fArr2[0], fArr2[1], 8.0f, this.f);
                float[] fArr3 = this.a;
                canvas.drawCircle(fArr3[fArr3.length - 2], fArr3[fArr3.length - 1], 8.0f, this.f);
            }
        }

        public final void b(Canvas canvas) {
            float[] fArr = this.a;
            float f2 = fArr[0];
            float f3 = fArr[1];
            float f4 = fArr[fArr.length - 2];
            float f5 = fArr[fArr.length - 1];
            canvas.drawLine(Math.min(f2, f4), Math.max(f3, f5), Math.max(f2, f4), Math.max(f3, f5), this.g);
            canvas.drawLine(Math.min(f2, f4), Math.min(f3, f5), Math.min(f2, f4), Math.max(f3, f5), this.g);
        }

        public final void c(Canvas canvas, float f2, float f3) {
            float[] fArr = this.a;
            float f4 = fArr[0];
            float f5 = fArr[1];
            float f6 = fArr[fArr.length - 2];
            float f7 = fArr[fArr.length - 1];
            float min = Math.min(f4, f6);
            float max = Math.max(f5, f7);
            float min2 = f2 - Math.min(f4, f6);
            float max2 = Math.max(f5, f7) - f3;
            StringBuilder J0 = ze0.J0("");
            J0.append(((float) ((int) (((double) ((min2 * 100.0f) / Math.abs(f6 - f4))) + 0.5d))) / 100.0f);
            String sb = J0.toString();
            g(sb, this.h);
            canvas.drawText(sb, ((min2 / 2.0f) - ((float) (this.m.width() / 2))) + min, f3 - 20.0f, this.h);
            canvas.drawLine(f2, f3, Math.min(f4, f6), f3, this.g);
            StringBuilder J02 = ze0.J0("");
            J02.append(((float) ((int) (((double) ((max2 * 100.0f) / Math.abs(f7 - f5))) + 0.5d))) / 100.0f);
            String sb2 = J02.toString();
            g(sb2, this.h);
            canvas.drawText(sb2, f2 + 5.0f, max - ((max2 / 2.0f) - ((float) (this.m.height() / 2))), this.h);
            canvas.drawLine(f2, f3, f2, Math.max(f5, f7), this.g);
        }

        public final void d(Canvas canvas) {
            float[] fArr = this.a;
            canvas.drawLine(fArr[0], fArr[1], fArr[fArr.length - 2], fArr[fArr.length - 1], this.g);
        }

        public final void e(Canvas canvas, float f2, float f3) {
            float[] fArr = this.a;
            float f4 = fArr[0];
            float f5 = fArr[1];
            float f6 = fArr[fArr.length - 2];
            float f7 = fArr[fArr.length - 1];
            float hypot = (float) Math.hypot((double) (f4 - f6), (double) (f5 - f7));
            float f8 = f6 - f4;
            float f9 = f7 - f5;
            float f10 = (((f3 - f5) * f9) + ((f2 - f4) * f8)) / (hypot * hypot);
            float f11 = f4 + (f8 * f10);
            float f12 = f5 + (f10 * f9);
            Path path = new Path();
            path.moveTo(f2, f3);
            path.lineTo(f11, f12);
            float hypot2 = (float) Math.hypot((double) (f11 - f2), (double) (f12 - f3));
            StringBuilder J0 = ze0.J0("");
            J0.append(((float) ((int) ((hypot2 * 100.0f) / hypot))) / 100.0f);
            String sb = J0.toString();
            g(sb, this.h);
            canvas.drawTextOnPath(sb, path, (hypot2 / 2.0f) - ((float) (this.m.width() / 2)), -20.0f, this.h);
            canvas.drawLine(f2, f3, f11, f12, this.g);
        }

        public final void f(Canvas canvas, float f2, float f3, int i2, int i3) {
            StringBuilder J0 = ze0.J0("");
            J0.append(((float) ((int) (((double) (((f2 - ((float) (i2 / 2))) * 100.0f) / ((float) (MotionLayout.this.getWidth() - i2)))) + 0.5d))) / 100.0f);
            String sb = J0.toString();
            g(sb, this.h);
            canvas.drawText(sb, ((f2 / 2.0f) - ((float) (this.m.width() / 2))) + Utils.FLOAT_EPSILON, f3 - 20.0f, this.h);
            canvas.drawLine(f2, f3, Math.min((float) Utils.FLOAT_EPSILON, 1.0f), f3, this.g);
            StringBuilder J02 = ze0.J0("");
            J02.append(((float) ((int) (((double) (((f3 - ((float) (i3 / 2))) * 100.0f) / ((float) (MotionLayout.this.getHeight() - i3)))) + 0.5d))) / 100.0f);
            String sb2 = J02.toString();
            g(sb2, this.h);
            canvas.drawText(sb2, f2 + 5.0f, Utils.FLOAT_EPSILON - ((f3 / 2.0f) - ((float) (this.m.height() / 2))), this.h);
            canvas.drawLine(f2, f3, f2, Math.max((float) Utils.FLOAT_EPSILON, 1.0f), this.g);
        }

        public void g(String str, Paint paint) {
            paint.getTextBounds(str, 0, str.length(), this.m);
        }
    }

    public class d {
        public pi a = new pi();
        public pi b = new pi();
        public pj c = null;
        public pj d = null;
        public int e;
        public int f;

        public d() {
        }

        public void a() {
            int childCount = MotionLayout.this.getChildCount();
            MotionLayout.this.I.clear();
            for (int i = 0; i < childCount; i++) {
                View childAt = MotionLayout.this.getChildAt(i);
                MotionLayout.this.I.put(childAt, new uh(childAt));
            }
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt2 = MotionLayout.this.getChildAt(i2);
                uh uhVar = MotionLayout.this.I.get(childAt2);
                if (uhVar != null) {
                    if (this.c != null) {
                        oi c2 = c(this.a, childAt2);
                        if (c2 != null) {
                            pj pjVar = this.c;
                            xh xhVar = uhVar.d;
                            xhVar.i = Utils.FLOAT_EPSILON;
                            xhVar.j = Utils.FLOAT_EPSILON;
                            uhVar.c(xhVar);
                            uhVar.d.m((float) c2.v(), (float) c2.w(), (float) c2.u(), (float) c2.o());
                            pj.a i3 = pjVar.i(uhVar.b);
                            uhVar.d.a(i3);
                            uhVar.j = i3.c.f;
                            uhVar.f.d(c2, pjVar, uhVar.b);
                        } else if (MotionLayout.this.U != 0) {
                            Log.e("MotionLayout", fg.e() + "no widget for  " + fg.g(childAt2) + " (" + childAt2.getClass().getName() + ")");
                        }
                    }
                    if (this.d != null) {
                        oi c3 = c(this.b, childAt2);
                        if (c3 != null) {
                            pj pjVar2 = this.d;
                            xh xhVar2 = uhVar.e;
                            xhVar2.i = 1.0f;
                            xhVar2.j = 1.0f;
                            uhVar.c(xhVar2);
                            uhVar.e.m((float) c3.v(), (float) c3.w(), (float) c3.u(), (float) c3.o());
                            uhVar.e.a(pjVar2.i(uhVar.b));
                            uhVar.g.d(c3, pjVar2, uhVar.b);
                        } else if (MotionLayout.this.U != 0) {
                            Log.e("MotionLayout", fg.e() + "no widget for  " + fg.g(childAt2) + " (" + childAt2.getClass().getName() + ")");
                        }
                    }
                }
            }
        }

        public void b(pi piVar, pi piVar2) {
            oi oiVar;
            ArrayList<oi> arrayList = piVar.H0;
            HashMap<oi, oi> hashMap = new HashMap<>();
            hashMap.put(piVar, piVar2);
            piVar2.H0.clear();
            piVar2.i(piVar, hashMap);
            Iterator<oi> it = arrayList.iterator();
            while (it.hasNext()) {
                oi next = it.next();
                if (next instanceof li) {
                    oiVar = new li();
                } else if (next instanceof ri) {
                    oiVar = new ri();
                } else if (next instanceof qi) {
                    oiVar = new qi();
                } else if (next instanceof si) {
                    oiVar = new ti();
                } else {
                    oiVar = new oi();
                }
                piVar2.H0.add(oiVar);
                oi oiVar2 = oiVar.R;
                if (oiVar2 != null) {
                    ((wi) oiVar2).H0.remove(oiVar);
                    oiVar.E();
                }
                oiVar.R = piVar2;
                hashMap.put(next, oiVar);
            }
            Iterator<oi> it2 = arrayList.iterator();
            while (it2.hasNext()) {
                oi next2 = it2.next();
                hashMap.get(next2).i(next2, hashMap);
            }
        }

        public oi c(pi piVar, View view) {
            if (piVar.h0 == view) {
                return piVar;
            }
            ArrayList<oi> arrayList = piVar.H0;
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                oi oiVar = arrayList.get(i);
                if (oiVar.h0 == view) {
                    return oiVar;
                }
            }
            return null;
        }

        public void d(pj pjVar, pj pjVar2) {
            oi.a aVar = oi.a.WRAP_CONTENT;
            this.c = pjVar;
            this.d = pjVar2;
            this.a = new pi();
            this.b = new pi();
            pi piVar = this.a;
            MotionLayout motionLayout = MotionLayout.this;
            boolean z = MotionLayout.K0;
            piVar.c0(motionLayout.i.K0);
            this.b.c0(MotionLayout.this.i.K0);
            this.a.H0.clear();
            this.b.H0.clear();
            b(MotionLayout.this.i, this.a);
            b(MotionLayout.this.i, this.b);
            if (((double) MotionLayout.this.M) > 0.5d) {
                if (pjVar != null) {
                    f(this.a, pjVar);
                }
                f(this.b, pjVar2);
            } else {
                f(this.b, pjVar2);
                if (pjVar != null) {
                    f(this.a, pjVar);
                }
            }
            this.a.L0 = MotionLayout.this.k();
            pi piVar2 = this.a;
            piVar2.I0.c(piVar2);
            this.b.L0 = MotionLayout.this.k();
            pi piVar3 = this.b;
            piVar3.I0.c(piVar3);
            ViewGroup.LayoutParams layoutParams = MotionLayout.this.getLayoutParams();
            if (layoutParams != null) {
                if (layoutParams.width == -2) {
                    this.a.Q[0] = aVar;
                    this.b.Q[0] = aVar;
                }
                if (layoutParams.height == -2) {
                    this.a.Q[1] = aVar;
                    this.b.Q[1] = aVar;
                }
            }
        }

        public void e() {
            MotionLayout motionLayout = MotionLayout.this;
            int i = motionLayout.F;
            int i2 = motionLayout.G;
            int mode = View.MeasureSpec.getMode(i);
            int mode2 = View.MeasureSpec.getMode(i2);
            MotionLayout motionLayout2 = MotionLayout.this;
            motionLayout2.y0 = mode;
            motionLayout2.z0 = mode2;
            int optimizationLevel = motionLayout2.getOptimizationLevel();
            MotionLayout motionLayout3 = MotionLayout.this;
            if (motionLayout3.D == motionLayout3.getStartState()) {
                MotionLayout.this.q(this.b, optimizationLevel, i, i2);
                if (this.c != null) {
                    MotionLayout.this.q(this.a, optimizationLevel, i, i2);
                }
            } else {
                if (this.c != null) {
                    MotionLayout.this.q(this.a, optimizationLevel, i, i2);
                }
                MotionLayout.this.q(this.b, optimizationLevel, i, i2);
            }
            int i3 = 0;
            boolean z = true;
            if (((MotionLayout.this.getParent() instanceof MotionLayout) && mode == 1073741824 && mode2 == 1073741824) ? false : true) {
                MotionLayout motionLayout4 = MotionLayout.this;
                motionLayout4.y0 = mode;
                motionLayout4.z0 = mode2;
                if (motionLayout4.D == motionLayout4.getStartState()) {
                    MotionLayout.this.q(this.b, optimizationLevel, i, i2);
                    if (this.c != null) {
                        MotionLayout.this.q(this.a, optimizationLevel, i, i2);
                    }
                } else {
                    if (this.c != null) {
                        MotionLayout.this.q(this.a, optimizationLevel, i, i2);
                    }
                    MotionLayout.this.q(this.b, optimizationLevel, i, i2);
                }
                MotionLayout.this.u0 = this.a.u();
                MotionLayout.this.v0 = this.a.o();
                MotionLayout.this.w0 = this.b.u();
                MotionLayout.this.x0 = this.b.o();
                MotionLayout motionLayout5 = MotionLayout.this;
                motionLayout5.t0 = (motionLayout5.u0 == motionLayout5.w0 && motionLayout5.v0 == motionLayout5.x0) ? false : true;
            }
            MotionLayout motionLayout6 = MotionLayout.this;
            int i4 = motionLayout6.u0;
            int i5 = motionLayout6.v0;
            int i6 = motionLayout6.y0;
            if (i6 == Integer.MIN_VALUE || i6 == 0) {
                i4 = (int) ((motionLayout6.A0 * ((float) (motionLayout6.w0 - i4))) + ((float) i4));
            }
            int i7 = motionLayout6.z0;
            if (i7 == Integer.MIN_VALUE || i7 == 0) {
                i5 = (int) ((motionLayout6.A0 * ((float) (motionLayout6.x0 - i5))) + ((float) i5));
            }
            pi piVar = this.a;
            motionLayout6.p(i, i2, i4, i5, piVar.U0 || this.b.U0, piVar.V0 || this.b.V0);
            MotionLayout motionLayout7 = MotionLayout.this;
            int childCount = motionLayout7.getChildCount();
            motionLayout7.F0.a();
            motionLayout7.Q = true;
            int width = motionLayout7.getWidth();
            int height = motionLayout7.getHeight();
            yh.b bVar = motionLayout7.z.c;
            int i8 = bVar != null ? bVar.p : -1;
            if (i8 != -1) {
                for (int i9 = 0; i9 < childCount; i9++) {
                    uh uhVar = motionLayout7.I.get(motionLayout7.getChildAt(i9));
                    if (uhVar != null) {
                        uhVar.A = i8;
                    }
                }
            }
            for (int i10 = 0; i10 < childCount; i10++) {
                uh uhVar2 = motionLayout7.I.get(motionLayout7.getChildAt(i10));
                if (uhVar2 != null) {
                    motionLayout7.z.g(uhVar2);
                    uhVar2.d(width, height, motionLayout7.getNanoTime());
                }
            }
            yh.b bVar2 = motionLayout7.z.c;
            float f2 = bVar2 != null ? bVar2.i : Utils.FLOAT_EPSILON;
            if (f2 != Utils.FLOAT_EPSILON) {
                boolean z2 = ((double) f2) < Utils.DOUBLE_EPSILON;
                float abs = Math.abs(f2);
                float f3 = -3.4028235E38f;
                float f4 = Float.MAX_VALUE;
                int i11 = 0;
                float f5 = Float.MAX_VALUE;
                float f6 = -3.4028235E38f;
                while (true) {
                    if (i11 >= childCount) {
                        z = false;
                        break;
                    }
                    uh uhVar3 = motionLayout7.I.get(motionLayout7.getChildAt(i11));
                    if (!Float.isNaN(uhVar3.j)) {
                        break;
                    }
                    xh xhVar = uhVar3.e;
                    float f7 = xhVar.k;
                    float f8 = xhVar.l;
                    float f9 = z2 ? f8 - f7 : f8 + f7;
                    f5 = Math.min(f5, f9);
                    f6 = Math.max(f6, f9);
                    i11++;
                }
                if (z) {
                    for (int i12 = 0; i12 < childCount; i12++) {
                        uh uhVar4 = motionLayout7.I.get(motionLayout7.getChildAt(i12));
                        if (!Float.isNaN(uhVar4.j)) {
                            f4 = Math.min(f4, uhVar4.j);
                            f3 = Math.max(f3, uhVar4.j);
                        }
                    }
                    while (i3 < childCount) {
                        uh uhVar5 = motionLayout7.I.get(motionLayout7.getChildAt(i3));
                        if (!Float.isNaN(uhVar5.j)) {
                            uhVar5.l = 1.0f / (1.0f - abs);
                            if (z2) {
                                uhVar5.k = abs - (((f3 - uhVar5.j) / (f3 - f4)) * abs);
                            } else {
                                uhVar5.k = abs - (((uhVar5.j - f4) * abs) / (f3 - f4));
                            }
                        }
                        i3++;
                    }
                    return;
                }
                while (i3 < childCount) {
                    uh uhVar6 = motionLayout7.I.get(motionLayout7.getChildAt(i3));
                    xh xhVar2 = uhVar6.e;
                    float f10 = xhVar2.k;
                    float f11 = xhVar2.l;
                    float f12 = z2 ? f11 - f10 : f11 + f10;
                    uhVar6.l = 1.0f / (1.0f - abs);
                    uhVar6.k = abs - (((f12 - f5) * abs) / (f6 - f5));
                    i3++;
                }
            }
        }

        public final void f(pi piVar, pj pjVar) {
            SparseArray<oi> sparseArray = new SparseArray<>();
            Constraints.a aVar = new Constraints.a(-2, -2);
            sparseArray.clear();
            sparseArray.put(0, piVar);
            sparseArray.put(MotionLayout.this.getId(), piVar);
            Iterator<oi> it = piVar.H0.iterator();
            while (it.hasNext()) {
                oi next = it.next();
                sparseArray.put(((View) next.h0).getId(), next);
            }
            Iterator<oi> it2 = piVar.H0.iterator();
            while (it2.hasNext()) {
                oi next2 = it2.next();
                View view = (View) next2.h0;
                int id = view.getId();
                if (pjVar.c.containsKey(Integer.valueOf(id))) {
                    pjVar.c.get(Integer.valueOf(id)).a(aVar);
                }
                next2.P(pjVar.i(view.getId()).d.c);
                next2.K(pjVar.i(view.getId()).d.d);
                if (view instanceof nj) {
                    nj njVar = (nj) view;
                    int id2 = njVar.getId();
                    if (pjVar.c.containsKey(Integer.valueOf(id2))) {
                        pj.a aVar2 = pjVar.c.get(Integer.valueOf(id2));
                        if (next2 instanceof ti) {
                            njVar.l(aVar2, (ti) next2, aVar, sparseArray);
                        }
                    }
                    if (view instanceof Barrier) {
                        ((Barrier) view).r();
                    }
                }
                aVar.resolveLayoutDirection(MotionLayout.this.getLayoutDirection());
                MotionLayout motionLayout = MotionLayout.this;
                boolean z = MotionLayout.K0;
                motionLayout.b(false, view, next2, aVar, sparseArray);
                if (pjVar.i(view.getId()).b.c == 1) {
                    next2.j0 = view.getVisibility();
                } else {
                    next2.j0 = pjVar.i(view.getId()).b.b;
                }
            }
            Iterator<oi> it3 = piVar.H0.iterator();
            while (it3.hasNext()) {
                oi next3 = it3.next();
                if (next3 instanceof vi) {
                    si siVar = (si) next3;
                    ((nj) next3.h0).q(siVar, sparseArray);
                    ((vi) siVar).T();
                }
            }
        }
    }

    public interface e {
    }

    public static class f implements e {
        public static f b = new f();
        public VelocityTracker a;
    }

    public class g {
        public float a = Float.NaN;
        public float b = Float.NaN;
        public int c = -1;
        public int d = -1;

        public g() {
        }

        public void a() {
            pj pjVar;
            oj.a aVar;
            int a2;
            i iVar = i.SETUP;
            int i = this.c;
            if (!(i == -1 && this.d == -1)) {
                if (i == -1) {
                    MotionLayout.this.D(this.d);
                } else {
                    int i2 = this.d;
                    if (i2 == -1) {
                        MotionLayout motionLayout = MotionLayout.this;
                        motionLayout.setState(iVar);
                        motionLayout.D = i;
                        motionLayout.C = -1;
                        motionLayout.E = -1;
                        oj ojVar = motionLayout.q;
                        pj pjVar2 = null;
                        if (ojVar != null) {
                            float f = (float) -1;
                            int i3 = ojVar.b;
                            if (i3 == i) {
                                if (i == -1) {
                                    aVar = ojVar.d.valueAt(0);
                                } else {
                                    aVar = ojVar.d.get(i3);
                                }
                                int i4 = ojVar.c;
                                if ((i4 == -1 || !aVar.b.get(i4).a(f, f)) && ojVar.c != (a2 = aVar.a(f, f))) {
                                    if (a2 != -1) {
                                        pjVar2 = aVar.b.get(a2).f;
                                    }
                                    if (a2 != -1) {
                                        int i5 = aVar.b.get(a2).e;
                                    }
                                    if (pjVar2 != null) {
                                        ojVar.c = a2;
                                        pjVar2.b(ojVar.a);
                                    }
                                }
                            } else {
                                ojVar.b = i;
                                oj.a aVar2 = ojVar.d.get(i);
                                int a3 = aVar2.a(f, f);
                                if (a3 == -1) {
                                    pjVar = aVar2.d;
                                } else {
                                    pjVar = aVar2.b.get(a3).f;
                                }
                                if (a3 != -1) {
                                    int i6 = aVar2.b.get(a3).e;
                                }
                                if (pjVar == null) {
                                    Log.v("ConstraintLayoutStates", "NO Constraint set found ! id=" + i + ", dim =" + f + ", " + f);
                                } else {
                                    ojVar.c = a3;
                                    pjVar.b(ojVar.a);
                                }
                            }
                        } else {
                            yh yhVar = motionLayout.z;
                            if (yhVar != null) {
                                yhVar.b(i).c(motionLayout, true);
                                motionLayout.setConstraintSet(null);
                                motionLayout.requestLayout();
                            }
                        }
                    } else {
                        MotionLayout.this.B(i, i2);
                    }
                }
                MotionLayout.this.setState(iVar);
            }
            if (!Float.isNaN(this.b)) {
                MotionLayout motionLayout2 = MotionLayout.this;
                float f2 = this.a;
                float f3 = this.b;
                if (!motionLayout2.isAttachedToWindow()) {
                    if (motionLayout2.D0 == null) {
                        motionLayout2.D0 = new g();
                    }
                    g gVar = motionLayout2.D0;
                    gVar.a = f2;
                    gVar.b = f3;
                } else {
                    motionLayout2.setProgress(f2);
                    motionLayout2.setState(i.MOVING);
                    motionLayout2.B = f3;
                    motionLayout2.s(1.0f);
                }
                this.a = Float.NaN;
                this.b = Float.NaN;
                this.c = -1;
                this.d = -1;
            } else if (!Float.isNaN(this.a)) {
                MotionLayout.this.setProgress(this.a);
            }
        }
    }

    public interface h {
        void a(MotionLayout motionLayout, int i, int i2, float f);

        void b(MotionLayout motionLayout, int i, int i2);

        void c(MotionLayout motionLayout, int i, boolean z, float f);

        void d(MotionLayout motionLayout, int i);
    }

    public enum i {
        UNDEFINED,
        SETUP,
        MOVING,
        FINISHED
    }

    public MotionLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        yh yhVar;
        String str;
        String str2;
        this.F = 0;
        this.G = 0;
        this.H = true;
        this.I = new HashMap<>();
        this.J = 0;
        this.K = 1.0f;
        this.L = Utils.FLOAT_EPSILON;
        this.M = Utils.FLOAT_EPSILON;
        this.O = Utils.FLOAT_EPSILON;
        this.Q = false;
        this.U = 0;
        this.W = false;
        this.a0 = new hh();
        this.b0 = new b();
        this.f0 = false;
        this.k0 = false;
        this.l0 = null;
        this.m0 = null;
        this.n0 = null;
        this.o0 = 0;
        this.p0 = -1;
        this.q0 = Utils.FLOAT_EPSILON;
        this.r0 = 0;
        this.s0 = Utils.FLOAT_EPSILON;
        this.t0 = false;
        this.B0 = new lh();
        this.C0 = false;
        this.E0 = i.UNDEFINED;
        this.F0 = new d();
        this.G0 = false;
        this.H0 = new RectF();
        this.I0 = null;
        this.J0 = new ArrayList<>();
        K0 = isInEditMode();
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, tj.m);
            int indexCount = obtainStyledAttributes.getIndexCount();
            boolean z2 = true;
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                int i3 = 2;
                if (index == 2) {
                    this.z = new yh(getContext(), this, obtainStyledAttributes.getResourceId(index, -1));
                } else if (index == 1) {
                    this.D = obtainStyledAttributes.getResourceId(index, -1);
                } else if (index == 4) {
                    this.O = obtainStyledAttributes.getFloat(index, Utils.FLOAT_EPSILON);
                    this.Q = true;
                } else if (index == 0) {
                    z2 = obtainStyledAttributes.getBoolean(index, z2);
                } else if (index == 5) {
                    if (this.U == 0) {
                        this.U = !obtainStyledAttributes.getBoolean(index, false) ? 0 : i3;
                    }
                } else if (index == 3) {
                    this.U = obtainStyledAttributes.getInt(index, 0);
                }
            }
            obtainStyledAttributes.recycle();
            if (this.z == null) {
                Log.e("MotionLayout", "WARNING NO app:layoutDescription tag");
            }
            if (!z2) {
                this.z = null;
            }
        }
        if (this.U != 0) {
            yh yhVar2 = this.z;
            if (yhVar2 == null) {
                Log.e("MotionLayout", "CHECK: motion scene not set! set \"app:layoutDescription=\"@xml/file\"");
            } else {
                int i4 = yhVar2.i();
                yh yhVar3 = this.z;
                pj b2 = yhVar3.b(yhVar3.i());
                String f2 = fg.f(getContext(), i4);
                int childCount = getChildCount();
                for (int i5 = 0; i5 < childCount; i5++) {
                    View childAt = getChildAt(i5);
                    int id = childAt.getId();
                    if (id == -1) {
                        StringBuilder O0 = ze0.O0("CHECK: ", f2, " ALL VIEWS SHOULD HAVE ID's ");
                        O0.append(childAt.getClass().getName());
                        O0.append(" does not!");
                        Log.w("MotionLayout", O0.toString());
                    }
                    if ((b2.c.containsKey(Integer.valueOf(id)) ? b2.c.get(Integer.valueOf(id)) : null) == null) {
                        StringBuilder O02 = ze0.O0("CHECK: ", f2, " NO CONSTRAINTS for ");
                        O02.append(fg.g(childAt));
                        Log.w("MotionLayout", O02.toString());
                    }
                }
                Integer[] numArr = (Integer[]) b2.c.keySet().toArray(new Integer[0]);
                int length = numArr.length;
                int[] iArr = new int[length];
                for (int i6 = 0; i6 < length; i6++) {
                    iArr[i6] = numArr[i6].intValue();
                }
                for (int i7 = 0; i7 < length; i7++) {
                    int i8 = iArr[i7];
                    String f3 = fg.f(getContext(), i8);
                    if (findViewById(iArr[i7]) == null) {
                        Log.w("MotionLayout", "CHECK: " + f2 + " NO View matches id " + f3);
                    }
                    if (b2.i(i8).d.d == -1) {
                        Log.w("MotionLayout", "CHECK: " + f2 + "(" + f3 + ") no LAYOUT_HEIGHT");
                    }
                    if (b2.i(i8).d.c == -1) {
                        Log.w("MotionLayout", "CHECK: " + f2 + "(" + f3 + ") no LAYOUT_HEIGHT");
                    }
                }
                SparseIntArray sparseIntArray = new SparseIntArray();
                SparseIntArray sparseIntArray2 = new SparseIntArray();
                Iterator<yh.b> it = this.z.d.iterator();
                while (it.hasNext()) {
                    yh.b next = it.next();
                    if (next == this.z.c) {
                        Log.v("MotionLayout", "CHECK: CURRENT");
                    }
                    StringBuilder J02 = ze0.J0("CHECK: transition = ");
                    Context context2 = getContext();
                    if (next.d == -1) {
                        str = BuildConfig.TRAVIS;
                    } else {
                        str = context2.getResources().getResourceEntryName(next.d);
                    }
                    if (next.c == -1) {
                        str2 = ze0.r0(str, " -> null");
                    } else {
                        StringBuilder N0 = ze0.N0(str, " -> ");
                        N0.append(context2.getResources().getResourceEntryName(next.c));
                        str2 = N0.toString();
                    }
                    J02.append(str2);
                    Log.v("MotionLayout", J02.toString());
                    Log.v("MotionLayout", "CHECK: transition.setDuration = " + next.h);
                    if (next.d == next.c) {
                        Log.e("MotionLayout", "CHECK: start and end constraint set should not be the same!");
                    }
                    int i9 = next.d;
                    int i10 = next.c;
                    String f4 = fg.f(getContext(), i9);
                    String f5 = fg.f(getContext(), i10);
                    if (sparseIntArray.get(i9) == i10) {
                        Log.e("MotionLayout", "CHECK: two transitions with the same start and end " + f4 + "->" + f5);
                    }
                    if (sparseIntArray2.get(i10) == i9) {
                        Log.e("MotionLayout", "CHECK: you can't have reverse transitions" + f4 + "->" + f5);
                    }
                    sparseIntArray.put(i9, i10);
                    sparseIntArray2.put(i10, i9);
                    if (this.z.b(i9) == null) {
                        Log.e("MotionLayout", " no such constraintSetStart " + f4);
                    }
                    if (this.z.b(i10) == null) {
                        Log.e("MotionLayout", " no such constraintSetEnd " + f4);
                    }
                }
            }
        }
        if (this.D == -1 && (yhVar = this.z) != null) {
            this.D = yhVar.i();
            this.C = this.z.i();
            this.E = this.z.d();
        }
    }

    public void A() {
        this.F0.e();
        invalidate();
    }

    public void B(int i2, int i3) {
        if (!isAttachedToWindow()) {
            if (this.D0 == null) {
                this.D0 = new g();
            }
            g gVar = this.D0;
            gVar.c = i2;
            gVar.d = i3;
            return;
        }
        yh yhVar = this.z;
        if (yhVar != null) {
            this.C = i2;
            this.E = i3;
            yhVar.m(i2, i3);
            this.F0.d(this.z.b(i2), this.z.b(i3));
            A();
            this.M = Utils.FLOAT_EPSILON;
            s(Utils.FLOAT_EPSILON);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0054, code lost:
        if ((((r15 * r6) - (((r1 * r6) * r6) / 2.0f)) + r13) > 1.0f) goto L_0x0068;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0064, code lost:
        if ((((((r1 * r3) * r3) / 2.0f) + (r15 * r3)) + r13) < com.github.mikephil.charting.utils.Utils.FLOAT_EPSILON) goto L_0x0068;
     */
    public void C(int i2, float f2, float f3) {
        di diVar;
        di diVar2;
        if (this.z != null && this.M != f2) {
            boolean z2 = true;
            this.W = true;
            this.J = getNanoTime();
            float c2 = ((float) this.z.c()) / 1000.0f;
            this.K = c2;
            this.O = f2;
            this.Q = true;
            if (i2 == 0 || i2 == 1 || i2 == 2) {
                if (i2 == 1) {
                    f2 = Utils.FLOAT_EPSILON;
                } else if (i2 == 2) {
                    f2 = 1.0f;
                }
                hh hhVar = this.a0;
                float f4 = this.M;
                float h2 = this.z.h();
                yh.b bVar = this.z.c;
                hhVar.b(f4, f2, f3, c2, h2, (bVar == null || (diVar = bVar.l) == null) ? Utils.FLOAT_EPSILON : diVar.p);
                int i3 = this.D;
                this.O = f2;
                this.D = i3;
                this.A = this.a0;
            } else if (i2 == 4) {
                b bVar2 = this.b0;
                float f5 = this.M;
                float h3 = this.z.h();
                bVar2.a = f3;
                bVar2.b = f5;
                bVar2.c = h3;
                this.A = this.b0;
            } else if (i2 == 5) {
                float f6 = this.M;
                float h4 = this.z.h();
                if (f3 > Utils.FLOAT_EPSILON) {
                    float f7 = f3 / h4;
                } else {
                    float f8 = (-f3) / h4;
                }
                z2 = false;
                if (z2) {
                    b bVar3 = this.b0;
                    float f9 = this.M;
                    float h5 = this.z.h();
                    bVar3.a = f3;
                    bVar3.b = f9;
                    bVar3.c = h5;
                    this.A = this.b0;
                } else {
                    hh hhVar2 = this.a0;
                    float f10 = this.M;
                    float f11 = this.K;
                    float h6 = this.z.h();
                    yh.b bVar4 = this.z.c;
                    hhVar2.b(f10, f2, f3, f11, h6, (bVar4 == null || (diVar2 = bVar4.l) == null) ? Utils.FLOAT_EPSILON : diVar2.p);
                    this.B = Utils.FLOAT_EPSILON;
                    int i4 = this.D;
                    this.O = f2;
                    this.D = i4;
                    this.A = this.a0;
                }
            }
            this.P = false;
            this.J = getNanoTime();
            invalidate();
        }
    }

    public void D(int i2) {
        uj ujVar;
        if (!isAttachedToWindow()) {
            if (this.D0 == null) {
                this.D0 = new g();
            }
            this.D0.d = i2;
            return;
        }
        yh yhVar = this.z;
        if (!(yhVar == null || (ujVar = yhVar.b) == null)) {
            int i3 = this.D;
            float f2 = (float) -1;
            uj.a aVar = ujVar.b.get(i2);
            if (aVar == null) {
                i3 = i2;
            } else {
                int i4 = (f2 > -1.0f ? 1 : (f2 == -1.0f ? 0 : -1));
                if (i4 != 0 && i4 != 0) {
                    Iterator<uj.b> it = aVar.b.iterator();
                    uj.b bVar = null;
                    while (true) {
                        if (it.hasNext()) {
                            uj.b next = it.next();
                            if (next.a(f2, f2)) {
                                if (i3 == next.e) {
                                    break;
                                }
                                bVar = next;
                            }
                        } else {
                            i3 = bVar != null ? bVar.e : aVar.c;
                        }
                    }
                } else if (aVar.c != i3) {
                    Iterator<uj.b> it2 = aVar.b.iterator();
                    while (true) {
                        if (it2.hasNext()) {
                            if (i3 == it2.next().e) {
                                break;
                            }
                        } else {
                            i3 = aVar.c;
                            break;
                        }
                    }
                }
            }
            if (i3 != -1) {
                i2 = i3;
            }
        }
        int i5 = this.D;
        if (i5 != i2) {
            if (this.C == i2) {
                s(Utils.FLOAT_EPSILON);
            } else if (this.E == i2) {
                s(1.0f);
            } else {
                this.E = i2;
                if (i5 != -1) {
                    B(i5, i2);
                    s(1.0f);
                    this.M = Utils.FLOAT_EPSILON;
                    s(1.0f);
                    return;
                }
                this.W = false;
                this.O = 1.0f;
                this.L = Utils.FLOAT_EPSILON;
                this.M = Utils.FLOAT_EPSILON;
                this.N = getNanoTime();
                this.J = getNanoTime();
                this.P = false;
                this.A = null;
                this.K = ((float) this.z.c()) / 1000.0f;
                this.C = -1;
                this.z.m(-1, this.E);
                this.z.i();
                int childCount = getChildCount();
                this.I.clear();
                for (int i6 = 0; i6 < childCount; i6++) {
                    View childAt = getChildAt(i6);
                    this.I.put(childAt, new uh(childAt));
                }
                this.Q = true;
                this.F0.d(null, this.z.b(i2));
                A();
                this.F0.a();
                int childCount2 = getChildCount();
                for (int i7 = 0; i7 < childCount2; i7++) {
                    View childAt2 = getChildAt(i7);
                    uh uhVar = this.I.get(childAt2);
                    if (uhVar != null) {
                        xh xhVar = uhVar.d;
                        xhVar.i = Utils.FLOAT_EPSILON;
                        xhVar.j = Utils.FLOAT_EPSILON;
                        xhVar.m(childAt2.getX(), childAt2.getY(), (float) childAt2.getWidth(), (float) childAt2.getHeight());
                        th thVar = uhVar.f;
                        Objects.requireNonNull(thVar);
                        childAt2.getX();
                        childAt2.getY();
                        childAt2.getWidth();
                        childAt2.getHeight();
                        thVar.i = childAt2.getVisibility();
                        thVar.g = childAt2.getVisibility() != 0 ? Utils.FLOAT_EPSILON : childAt2.getAlpha();
                        thVar.j = childAt2.getElevation();
                        thVar.k = childAt2.getRotation();
                        thVar.l = childAt2.getRotationX();
                        thVar.m = childAt2.getRotationY();
                        thVar.n = childAt2.getScaleX();
                        thVar.o = childAt2.getScaleY();
                        thVar.p = childAt2.getPivotX();
                        thVar.q = childAt2.getPivotY();
                        thVar.r = childAt2.getTranslationX();
                        thVar.s = childAt2.getTranslationY();
                        thVar.t = childAt2.getTranslationZ();
                    }
                }
                int width = getWidth();
                int height = getHeight();
                for (int i8 = 0; i8 < childCount; i8++) {
                    uh uhVar2 = this.I.get(getChildAt(i8));
                    this.z.g(uhVar2);
                    uhVar2.d(width, height, getNanoTime());
                }
                yh.b bVar2 = this.z.c;
                float f3 = bVar2 != null ? bVar2.i : Utils.FLOAT_EPSILON;
                if (f3 != Utils.FLOAT_EPSILON) {
                    float f4 = Float.MAX_VALUE;
                    float f5 = -3.4028235E38f;
                    for (int i9 = 0; i9 < childCount; i9++) {
                        xh xhVar2 = this.I.get(getChildAt(i9)).e;
                        float f6 = xhVar2.l + xhVar2.k;
                        f4 = Math.min(f4, f6);
                        f5 = Math.max(f5, f6);
                    }
                    for (int i10 = 0; i10 < childCount; i10++) {
                        uh uhVar3 = this.I.get(getChildAt(i10));
                        xh xhVar3 = uhVar3.e;
                        float f7 = xhVar3.k;
                        float f8 = xhVar3.l;
                        uhVar3.l = 1.0f / (1.0f - f3);
                        uhVar3.k = f3 - ((((f7 + f8) - f4) * f3) / (f5 - f4));
                    }
                }
                this.L = Utils.FLOAT_EPSILON;
                this.M = Utils.FLOAT_EPSILON;
                this.Q = true;
                invalidate();
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:110:0x02dd  */
    /* JADX WARNING: Removed duplicated region for block: B:114:0x02f7  */
    /* JADX WARNING: Removed duplicated region for block: B:117:0x0307  */
    /* JADX WARNING: Removed duplicated region for block: B:122:0x031c  */
    /* JADX WARNING: Removed duplicated region for block: B:123:0x0326  */
    /* JADX WARNING: Removed duplicated region for block: B:126:0x0333  */
    /* JADX WARNING: Removed duplicated region for block: B:127:0x033f  */
    /* JADX WARNING: Removed duplicated region for block: B:99:0x02b0  */
    @Override // androidx.constraintlayout.widget.ConstraintLayout
    public void dispatchDraw(Canvas canvas) {
        Iterator<uh> it;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        float f2;
        dh dhVar;
        Iterator<xh> it2;
        double d2;
        ch chVar;
        String str;
        char c2 = 0;
        t(false);
        super.dispatchDraw(canvas);
        if (this.z != null) {
            if ((this.U & 1) == 1 && !isInEditMode()) {
                this.o0++;
                long nanoTime = getNanoTime();
                long j = this.p0;
                if (j != -1) {
                    long j2 = nanoTime - j;
                    if (j2 > 200000000) {
                        this.q0 = ((float) ((int) ((((float) this.o0) / (((float) j2) * 1.0E-9f)) * 100.0f))) / 100.0f;
                        this.o0 = 0;
                        this.p0 = nanoTime;
                    }
                } else {
                    this.p0 = nanoTime;
                }
                Paint paint = new Paint();
                paint.setTextSize(42.0f);
                StringBuilder J02 = ze0.J0(this.q0 + " fps " + fg.h(this, this.C) + " -> ");
                J02.append(fg.h(this, this.E));
                J02.append(" (progress: ");
                J02.append(((float) ((int) (getProgress() * 1000.0f))) / 10.0f);
                J02.append(" ) state=");
                int i7 = this.D;
                if (i7 == -1) {
                    str = "undefined";
                } else {
                    str = fg.h(this, i7);
                }
                J02.append(str);
                String sb = J02.toString();
                paint.setColor(-16777216);
                canvas.drawText(sb, 11.0f, (float) (getHeight() - 29), paint);
                paint.setColor(-7864184);
                canvas.drawText(sb, 10.0f, (float) (getHeight() - 30), paint);
            }
            if (this.U > 1) {
                if (this.V == null) {
                    this.V = new c();
                }
                c cVar = this.V;
                HashMap<View, uh> hashMap = this.I;
                int c3 = this.z.c();
                int i8 = this.U;
                Objects.requireNonNull(cVar);
                if (!(hashMap == null || hashMap.size() == 0)) {
                    canvas.save();
                    if (!MotionLayout.this.isInEditMode() && (i8 & 1) == 2) {
                        String str2 = MotionLayout.this.getContext().getResources().getResourceName(MotionLayout.this.E) + ":" + MotionLayout.this.getProgress();
                        canvas.drawText(str2, 10.0f, (float) (MotionLayout.this.getHeight() - 30), cVar.h);
                        canvas.drawText(str2, 11.0f, (float) (MotionLayout.this.getHeight() - 29), cVar.e);
                    }
                    Iterator<uh> it3 = hashMap.values().iterator();
                    Canvas canvas2 = canvas;
                    Canvas canvas3 = canvas2;
                    while (it3.hasNext()) {
                        uh next = it3.next();
                        int i9 = next.d.h;
                        Iterator<xh> it4 = next.t.iterator();
                        while (it4.hasNext()) {
                            i9 = Math.max(i9, it4.next().h);
                        }
                        int max = Math.max(i9, next.e.h);
                        if (i8 > 0 && max == 0) {
                            max = 1;
                        }
                        if (max != 0) {
                            float[] fArr = cVar.c;
                            int[] iArr = cVar.b;
                            if (fArr != null) {
                                double[] f3 = next.h[c2].f();
                                if (iArr != null) {
                                    Iterator<xh> it5 = next.t.iterator();
                                    int i10 = 0;
                                    while (it5.hasNext()) {
                                        iArr[i10] = it5.next().r;
                                        i10++;
                                    }
                                }
                                int i11 = 0;
                                int i12 = 0;
                                while (i11 < f3.length) {
                                    next.h[c2].c(f3[i11], next.n);
                                    next.d.d(next.m, next.n, fArr, i12);
                                    i12 += 2;
                                    i11++;
                                    c2 = 0;
                                    it3 = it3;
                                }
                                it = it3;
                                i2 = i12 / 2;
                            } else {
                                it = it3;
                                i2 = 0;
                            }
                            cVar.l = i2;
                            if (max >= 1) {
                                int i13 = c3 / 16;
                                float[] fArr2 = cVar.a;
                                if (fArr2 == null || fArr2.length != i13 * 2) {
                                    cVar.a = new float[(i13 * 2)];
                                    cVar.d = new Path();
                                }
                                float f4 = (float) cVar.n;
                                canvas2.translate(f4, f4);
                                cVar.e.setColor(1996488704);
                                cVar.i.setColor(1996488704);
                                cVar.f.setColor(1996488704);
                                cVar.g.setColor(1996488704);
                                float[] fArr3 = cVar.a;
                                float f5 = 1.0f / ((float) (i13 - 1));
                                HashMap<String, zh> hashMap2 = next.x;
                                zh zhVar = hashMap2 == null ? null : hashMap2.get("translationX");
                                HashMap<String, zh> hashMap3 = next.x;
                                zh zhVar2 = hashMap3 == null ? null : hashMap3.get("translationY");
                                HashMap<String, nh> hashMap4 = next.y;
                                nh nhVar = hashMap4 == null ? null : hashMap4.get("translationX");
                                HashMap<String, nh> hashMap5 = next.y;
                                nh nhVar2 = hashMap5 == null ? null : hashMap5.get("translationY");
                                int i14 = 0;
                                while (true) {
                                    float f6 = Utils.FLOAT_EPSILON;
                                    if (i14 >= i13) {
                                        break;
                                    }
                                    float f7 = ((float) i14) * f5;
                                    float f8 = next.l;
                                    if (f8 != 1.0f) {
                                        f2 = f5;
                                        float f9 = next.k;
                                        if (f7 < f9) {
                                            f7 = Utils.FLOAT_EPSILON;
                                        }
                                        if (f7 > f9) {
                                            i6 = c3;
                                            i5 = i8;
                                            if (((double) f7) < 1.0d) {
                                                f7 = (f7 - f9) * f8;
                                            }
                                            double d3 = (double) f7;
                                            dhVar = next.d.g;
                                            it2 = next.t.iterator();
                                            float f10 = Float.NaN;
                                            while (it2.hasNext()) {
                                                xh next2 = it2.next();
                                                dh dhVar2 = next2.g;
                                                if (dhVar2 != null) {
                                                    float f11 = next2.i;
                                                    if (f11 < f7) {
                                                        dhVar = dhVar2;
                                                        f6 = f11;
                                                    } else if (Float.isNaN(f10)) {
                                                        f10 = next2.i;
                                                    }
                                                }
                                                it2 = it2;
                                                d3 = d3;
                                            }
                                            if (dhVar == null) {
                                                if (Float.isNaN(f10)) {
                                                    f10 = 1.0f;
                                                }
                                                float f12 = f10 - f6;
                                                d2 = (double) ((((float) dhVar.a((double) ((f7 - f6) / f12))) * f12) + f6);
                                            } else {
                                                d2 = d3;
                                            }
                                            next.h[0].c(d2, next.n);
                                            chVar = next.i;
                                            if (chVar != null) {
                                                double[] dArr = next.n;
                                                if (dArr.length > 0) {
                                                    chVar.c(d2, dArr);
                                                }
                                            }
                                            int i15 = i14 * 2;
                                            next.d.d(next.m, next.n, fArr3, i15);
                                            if (nhVar == null) {
                                                fArr3[i15] = nhVar.a(f7) + fArr3[i15];
                                            } else if (zhVar != null) {
                                                fArr3[i15] = zhVar.a(f7) + fArr3[i15];
                                            }
                                            if (nhVar2 == null) {
                                                int i16 = i15 + 1;
                                                fArr3[i16] = nhVar2.a(f7) + fArr3[i16];
                                            } else if (zhVar2 != null) {
                                                int i17 = i15 + 1;
                                                fArr3[i17] = zhVar2.a(f7) + fArr3[i17];
                                            }
                                            i14++;
                                            i13 = i13;
                                            f5 = f2;
                                            c3 = i6;
                                            i8 = i5;
                                        }
                                    } else {
                                        f2 = f5;
                                    }
                                    i6 = c3;
                                    i5 = i8;
                                    double d32 = (double) f7;
                                    dhVar = next.d.g;
                                    it2 = next.t.iterator();
                                    float f102 = Float.NaN;
                                    while (it2.hasNext()) {
                                    }
                                    if (dhVar == null) {
                                    }
                                    next.h[0].c(d2, next.n);
                                    chVar = next.i;
                                    if (chVar != null) {
                                    }
                                    int i152 = i14 * 2;
                                    next.d.d(next.m, next.n, fArr3, i152);
                                    if (nhVar == null) {
                                    }
                                    if (nhVar2 == null) {
                                    }
                                    i14++;
                                    i13 = i13;
                                    f5 = f2;
                                    c3 = i6;
                                    i8 = i5;
                                }
                                i4 = c3;
                                i3 = i8;
                                cVar.a(canvas3, max, cVar.l, next);
                                cVar.e.setColor(-21965);
                                cVar.f.setColor(-2067046);
                                cVar.i.setColor(-2067046);
                                cVar.g.setColor(-13391360);
                                float f13 = (float) (-cVar.n);
                                canvas3.translate(f13, f13);
                                cVar.a(canvas3, max, cVar.l, next);
                                if (max == 5) {
                                    cVar.d.reset();
                                    for (int i18 = 0; i18 <= 50; i18++) {
                                        float[] fArr4 = cVar.j;
                                        next.h[0].c((double) next.a(((float) i18) / ((float) 50), null), next.n);
                                        xh xhVar = next.d;
                                        int[] iArr2 = next.m;
                                        double[] dArr2 = next.n;
                                        float f14 = xhVar.k;
                                        float f15 = xhVar.l;
                                        float f16 = xhVar.m;
                                        float f17 = xhVar.n;
                                        for (int i19 = 0; i19 < iArr2.length; i19++) {
                                            float f18 = (float) dArr2[i19];
                                            int i20 = iArr2[i19];
                                            if (i20 == 1) {
                                                f14 = f18;
                                            } else if (i20 == 2) {
                                                f15 = f18;
                                            } else if (i20 == 3) {
                                                f16 = f18;
                                            } else if (i20 == 4) {
                                                f17 = f18;
                                            }
                                        }
                                        float f19 = f16 + f14;
                                        float f20 = f17 + f15;
                                        Float.isNaN(Float.NaN);
                                        Float.isNaN(Float.NaN);
                                        float f21 = f14 + Utils.FLOAT_EPSILON;
                                        float f22 = f15 + Utils.FLOAT_EPSILON;
                                        float f23 = f19 + Utils.FLOAT_EPSILON;
                                        float f24 = f20 + Utils.FLOAT_EPSILON;
                                        fArr4[0] = f21;
                                        fArr4[1] = f22;
                                        fArr4[2] = f23;
                                        fArr4[3] = f22;
                                        fArr4[4] = f23;
                                        fArr4[5] = f24;
                                        fArr4[6] = f21;
                                        fArr4[7] = f24;
                                        Path path = cVar.d;
                                        float[] fArr5 = cVar.j;
                                        path.moveTo(fArr5[0], fArr5[1]);
                                        Path path2 = cVar.d;
                                        float[] fArr6 = cVar.j;
                                        path2.lineTo(fArr6[2], fArr6[3]);
                                        Path path3 = cVar.d;
                                        float[] fArr7 = cVar.j;
                                        path3.lineTo(fArr7[4], fArr7[5]);
                                        Path path4 = cVar.d;
                                        float[] fArr8 = cVar.j;
                                        path4.lineTo(fArr8[6], fArr8[7]);
                                        cVar.d.close();
                                    }
                                    cVar.e.setColor(1140850688);
                                    canvas.translate(2.0f, 2.0f);
                                    canvas.drawPath(cVar.d, cVar.e);
                                    canvas.translate(-2.0f, -2.0f);
                                    cVar.e.setColor(-65536);
                                    canvas.drawPath(cVar.d, cVar.e);
                                    canvas3 = canvas;
                                }
                                canvas2 = canvas3;
                            } else {
                                i4 = c3;
                                i3 = i8;
                            }
                            c2 = 0;
                            it3 = it;
                            c3 = i4;
                            i8 = i3;
                        }
                    }
                    canvas.restore();
                }
            }
        }
    }

    public int[] getConstraintSetIds() {
        yh yhVar = this.z;
        if (yhVar == null) {
            return null;
        }
        int size = yhVar.g.size();
        int[] iArr = new int[size];
        for (int i2 = 0; i2 < size; i2++) {
            iArr[i2] = yhVar.g.keyAt(i2);
        }
        return iArr;
    }

    public int getCurrentState() {
        return this.D;
    }

    public ArrayList<yh.b> getDefinedTransitions() {
        yh yhVar = this.z;
        if (yhVar == null) {
            return null;
        }
        return yhVar.d;
    }

    public ih getDesignTool() {
        if (this.c0 == null) {
            this.c0 = new ih(this);
        }
        return this.c0;
    }

    public int getEndState() {
        return this.E;
    }

    public long getNanoTime() {
        return System.nanoTime();
    }

    public float getProgress() {
        return this.M;
    }

    public int getStartState() {
        return this.C;
    }

    public float getTargetPosition() {
        return this.O;
    }

    public Bundle getTransitionState() {
        if (this.D0 == null) {
            this.D0 = new g();
        }
        g gVar = this.D0;
        MotionLayout motionLayout = MotionLayout.this;
        gVar.d = motionLayout.E;
        gVar.c = motionLayout.C;
        gVar.b = motionLayout.getVelocity();
        gVar.a = MotionLayout.this.getProgress();
        g gVar2 = this.D0;
        Objects.requireNonNull(gVar2);
        Bundle bundle = new Bundle();
        bundle.putFloat("motion.progress", gVar2.a);
        bundle.putFloat("motion.velocity", gVar2.b);
        bundle.putInt("motion.StartState", gVar2.c);
        bundle.putInt("motion.EndState", gVar2.d);
        return bundle;
    }

    public long getTransitionTimeMs() {
        yh yhVar = this.z;
        if (yhVar != null) {
            this.K = ((float) yhVar.c()) / 1000.0f;
        }
        return (long) (this.K * 1000.0f);
    }

    public float getVelocity() {
        return this.B;
    }

    @Override // defpackage.sn
    public void h(View view, View view2, int i2, int i3) {
    }

    @Override // defpackage.sn
    public void i(View view, int i2) {
        di diVar;
        float f2;
        yh yhVar = this.z;
        if (yhVar != null) {
            float f3 = this.g0;
            float f4 = this.j0;
            float f5 = f3 / f4;
            float f6 = this.h0 / f4;
            yh.b bVar = yhVar.c;
            if (bVar != null && (diVar = bVar.l) != null) {
                boolean z2 = false;
                diVar.k = false;
                float progress = diVar.o.getProgress();
                diVar.o.w(diVar.d, progress, diVar.h, diVar.g, diVar.l);
                float f7 = diVar.i;
                float[] fArr = diVar.l;
                float f8 = fArr[0];
                float f9 = diVar.j;
                float f10 = fArr[1];
                float f11 = Utils.FLOAT_EPSILON;
                if (f7 != Utils.FLOAT_EPSILON) {
                    f2 = (f5 * f7) / fArr[0];
                } else {
                    f2 = (f6 * f9) / fArr[1];
                }
                if (!Float.isNaN(f2)) {
                    progress += f2 / 3.0f;
                }
                if (progress != Utils.FLOAT_EPSILON) {
                    boolean z3 = progress != 1.0f;
                    int i3 = diVar.c;
                    if (i3 != 3) {
                        z2 = true;
                    }
                    if (z2 && z3) {
                        MotionLayout motionLayout = diVar.o;
                        if (((double) progress) >= 0.5d) {
                            f11 = 1.0f;
                        }
                        motionLayout.C(i3, f11, f2);
                    }
                }
            }
        }
    }

    public boolean isAttachedToWindow() {
        return super.isAttachedToWindow();
    }

    @Override // defpackage.sn
    public void j(View view, int i2, int i3, int[] iArr, int i4) {
        yh.b bVar;
        boolean z2;
        di diVar;
        float f2;
        float f3;
        di diVar2;
        di diVar3;
        int i5;
        yh yhVar = this.z;
        if (yhVar != null && (bVar = yhVar.c) != null && (!bVar.o)) {
            if (!z2 || (diVar3 = bVar.l) == null || (i5 = diVar3.e) == -1 || view.getId() == i5) {
                yh yhVar2 = this.z;
                if (yhVar2 != null) {
                    yh.b bVar2 = yhVar2.c;
                    if ((bVar2 == null || (diVar2 = bVar2.l) == null) ? false : diVar2.r) {
                        float f4 = this.L;
                        if ((f4 == 1.0f || f4 == Utils.FLOAT_EPSILON) && view.canScrollVertically(-1)) {
                            return;
                        }
                    }
                }
                if (bVar.l != null) {
                    di diVar4 = this.z.c.l;
                    if ((diVar4.t & 1) != 0) {
                        float f5 = (float) i2;
                        float f6 = (float) i3;
                        diVar4.o.w(diVar4.d, diVar4.o.getProgress(), diVar4.h, diVar4.g, diVar4.l);
                        float f7 = diVar4.i;
                        if (f7 != Utils.FLOAT_EPSILON) {
                            float[] fArr = diVar4.l;
                            if (fArr[0] == Utils.FLOAT_EPSILON) {
                                fArr[0] = 1.0E-7f;
                            }
                            f3 = (f5 * f7) / fArr[0];
                        } else {
                            float[] fArr2 = diVar4.l;
                            if (fArr2[1] == Utils.FLOAT_EPSILON) {
                                fArr2[1] = 1.0E-7f;
                            }
                            f3 = (f6 * diVar4.j) / fArr2[1];
                        }
                        float f8 = this.M;
                        if ((f8 <= Utils.FLOAT_EPSILON && f3 < Utils.FLOAT_EPSILON) || (f8 >= 1.0f && f3 > Utils.FLOAT_EPSILON)) {
                            view.setNestedScrollingEnabled(false);
                            view.post(new a(this, view));
                            return;
                        }
                    }
                }
                float f9 = this.L;
                long nanoTime = getNanoTime();
                float f10 = (float) i2;
                this.g0 = f10;
                float f11 = (float) i3;
                this.h0 = f11;
                this.j0 = (float) (((double) (nanoTime - this.i0)) * 1.0E-9d);
                this.i0 = nanoTime;
                yh.b bVar3 = this.z.c;
                if (!(bVar3 == null || (diVar = bVar3.l) == null)) {
                    float progress = diVar.o.getProgress();
                    if (!diVar.k) {
                        diVar.k = true;
                        diVar.o.setProgress(progress);
                    }
                    diVar.o.w(diVar.d, progress, diVar.h, diVar.g, diVar.l);
                    float f12 = diVar.i;
                    float[] fArr3 = diVar.l;
                    if (((double) Math.abs((diVar.j * fArr3[1]) + (f12 * fArr3[0]))) < 0.01d) {
                        float[] fArr4 = diVar.l;
                        fArr4[0] = 0.01f;
                        fArr4[1] = 0.01f;
                    }
                    float f13 = diVar.i;
                    if (f13 != Utils.FLOAT_EPSILON) {
                        f2 = (f10 * f13) / diVar.l[0];
                    } else {
                        f2 = (f11 * diVar.j) / diVar.l[1];
                    }
                    float max = Math.max(Math.min(progress + f2, 1.0f), (float) Utils.FLOAT_EPSILON);
                    if (max != diVar.o.getProgress()) {
                        diVar.o.setProgress(max);
                    }
                }
                if (f9 != this.L) {
                    iArr[0] = i2;
                    iArr[1] = i3;
                }
                t(false);
                if (iArr[0] != 0 || iArr[1] != 0) {
                    this.f0 = true;
                }
            }
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout
    public void l(int i2) {
        this.q = null;
    }

    @Override // defpackage.tn
    public void m(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        if (!(!this.f0 && i2 == 0 && i3 == 0)) {
            iArr[0] = iArr[0] + i4;
            iArr[1] = iArr[1] + i5;
        }
        this.f0 = false;
    }

    @Override // defpackage.sn
    public void n(View view, int i2, int i3, int i4, int i5, int i6) {
    }

    @Override // defpackage.sn
    public boolean o(View view, View view2, int i2, int i3) {
        yh.b bVar;
        di diVar;
        yh yhVar = this.z;
        return (yhVar == null || (bVar = yhVar.c) == null || (diVar = bVar.l) == null || (diVar.t & 2) != 0) ? false : true;
    }

    public void onAttachedToWindow() {
        yh.b bVar;
        int i2;
        boolean z2;
        super.onAttachedToWindow();
        yh yhVar = this.z;
        if (!(yhVar == null || (i2 = this.D) == -1)) {
            pj b2 = yhVar.b(i2);
            yh yhVar2 = this.z;
            int i3 = 0;
            while (true) {
                if (i3 < yhVar2.g.size()) {
                    int keyAt = yhVar2.g.keyAt(i3);
                    int i4 = yhVar2.i.get(keyAt);
                    int size = yhVar2.i.size();
                    while (true) {
                        if (i4 <= 0) {
                            z2 = false;
                            break;
                        } else if (i4 == keyAt) {
                            break;
                        } else {
                            int i5 = size - 1;
                            if (size < 0) {
                                break;
                            }
                            i4 = yhVar2.i.get(i4);
                            size = i5;
                        }
                    }
                    z2 = true;
                    if (z2) {
                        Log.e("MotionScene", "Cannot be derived from yourself");
                        break;
                    } else {
                        yhVar2.l(keyAt);
                        i3++;
                    }
                } else {
                    for (int i6 = 0; i6 < yhVar2.g.size(); i6++) {
                        pj valueAt = yhVar2.g.valueAt(i6);
                        Objects.requireNonNull(valueAt);
                        int childCount = getChildCount();
                        for (int i7 = 0; i7 < childCount; i7++) {
                            View childAt = getChildAt(i7);
                            ConstraintLayout.a aVar = (ConstraintLayout.a) childAt.getLayoutParams();
                            int id = childAt.getId();
                            if (!valueAt.b || id != -1) {
                                if (!valueAt.c.containsKey(Integer.valueOf(id))) {
                                    valueAt.c.put(Integer.valueOf(id), new pj.a());
                                }
                                pj.a aVar2 = valueAt.c.get(Integer.valueOf(id));
                                if (!aVar2.d.b) {
                                    aVar2.b(id, aVar);
                                    if (childAt instanceof nj) {
                                        aVar2.d.e0 = ((nj) childAt).getReferencedIds();
                                        if (childAt instanceof Barrier) {
                                            Barrier barrier = (Barrier) childAt;
                                            pj.b bVar2 = aVar2.d;
                                            bVar2.j0 = barrier.q.K0;
                                            bVar2.b0 = barrier.getType();
                                            aVar2.d.c0 = barrier.getMargin();
                                        }
                                    }
                                    aVar2.d.b = true;
                                }
                                pj.d dVar = aVar2.b;
                                if (!dVar.a) {
                                    dVar.b = childAt.getVisibility();
                                    aVar2.b.d = childAt.getAlpha();
                                    aVar2.b.a = true;
                                }
                                pj.e eVar = aVar2.e;
                                if (!eVar.a) {
                                    eVar.a = true;
                                    eVar.b = childAt.getRotation();
                                    aVar2.e.c = childAt.getRotationX();
                                    aVar2.e.d = childAt.getRotationY();
                                    aVar2.e.e = childAt.getScaleX();
                                    aVar2.e.f = childAt.getScaleY();
                                    float pivotX = childAt.getPivotX();
                                    float pivotY = childAt.getPivotY();
                                    if (!(((double) pivotX) == Utils.DOUBLE_EPSILON && ((double) pivotY) == Utils.DOUBLE_EPSILON)) {
                                        pj.e eVar2 = aVar2.e;
                                        eVar2.g = pivotX;
                                        eVar2.h = pivotY;
                                    }
                                    aVar2.e.i = childAt.getTranslationX();
                                    aVar2.e.j = childAt.getTranslationY();
                                    aVar2.e.k = childAt.getTranslationZ();
                                    pj.e eVar3 = aVar2.e;
                                    if (eVar3.l) {
                                        eVar3.m = childAt.getElevation();
                                    }
                                }
                            } else {
                                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
                            }
                        }
                    }
                }
            }
            if (b2 != null) {
                b2.c(this, true);
                setConstraintSet(null);
                requestLayout();
            }
            this.C = this.D;
        }
        y();
        g gVar = this.D0;
        if (gVar != null) {
            gVar.a();
            return;
        }
        yh yhVar3 = this.z;
        if (!(yhVar3 == null || (bVar = yhVar3.c) == null || bVar.n != 4)) {
            s(1.0f);
            setState(i.SETUP);
            setState(i.MOVING);
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        yh.b bVar;
        di diVar;
        int i2;
        RectF a2;
        yh yhVar = this.z;
        if (yhVar != null && this.H && (bVar = yhVar.c) != null && (!bVar.o) && (diVar = bVar.l) != null && ((motionEvent.getAction() != 0 || (a2 = diVar.a(this, new RectF())) == null || a2.contains(motionEvent.getX(), motionEvent.getY())) && (i2 = diVar.e) != -1)) {
            View view = this.I0;
            if (view == null || view.getId() != i2) {
                this.I0 = findViewById(i2);
            }
            View view2 = this.I0;
            if (view2 != null) {
                this.H0.set((float) view2.getLeft(), (float) this.I0.getTop(), (float) this.I0.getRight(), (float) this.I0.getBottom());
                if (this.H0.contains(motionEvent.getX(), motionEvent.getY()) && !x(Utils.FLOAT_EPSILON, Utils.FLOAT_EPSILON, this.I0, motionEvent)) {
                    return onTouchEvent(motionEvent);
                }
            }
        }
        return false;
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        this.C0 = true;
        try {
            if (this.z == null) {
                super.onLayout(z2, i2, i3, i4, i5);
                return;
            }
            int i6 = i4 - i2;
            int i7 = i5 - i3;
            if (!(this.d0 == i6 && this.e0 == i7)) {
                A();
                t(true);
            }
            this.d0 = i6;
            this.e0 = i7;
            this.C0 = false;
        } finally {
            this.C0 = false;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:24:0x004e, code lost:
        if (((r6 == r3.e && r7 == r3.f) ? false : true) != false) goto L_0x0050;
     */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x00e5  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x00f2  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x00fa  */
    /* JADX WARNING: Removed duplicated region for block: B:62:0x011c  */
    /* JADX WARNING: Removed duplicated region for block: B:63:0x0127  */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x014b  */
    /* JADX WARNING: Removed duplicated region for block: B:80:0x016a  */
    /* JADX WARNING: Removed duplicated region for block: B:85:? A[RETURN, SYNTHETIC] */
    @Override // androidx.constraintlayout.widget.ConstraintLayout
    public void onMeasure(int i2, int i3) {
        boolean z2;
        float f2;
        int i4;
        int childCount;
        if (this.z == null) {
            super.onMeasure(i2, i3);
            return;
        }
        boolean z3 = true;
        boolean z4 = (this.F == i2 && this.G == i3) ? false : true;
        if (this.G0) {
            this.G0 = false;
            y();
            z();
            z4 = true;
        }
        if (this.n) {
            z4 = true;
        }
        this.F = i2;
        this.G = i3;
        int i5 = this.z.i();
        int d2 = this.z.d();
        if (!z4) {
            d dVar = this.F0;
        }
        if (this.C != -1) {
            super.onMeasure(i2, i3);
            this.F0.d(this.z.b(i5), this.z.b(d2));
            this.F0.e();
            d dVar2 = this.F0;
            dVar2.e = i5;
            dVar2.f = d2;
            z2 = false;
            if (this.t0 || z2) {
                int paddingBottom = getPaddingBottom() + getPaddingTop();
                int u = this.i.u() + getPaddingRight() + getPaddingLeft();
                int o = this.i.o() + paddingBottom;
                int i6 = this.y0;
                if (i6 == Integer.MIN_VALUE || i6 == 0) {
                    int i7 = this.u0;
                    u = (int) ((this.A0 * ((float) (this.w0 - i7))) + ((float) i7));
                    requestLayout();
                }
                int i8 = this.z0;
                if (i8 == Integer.MIN_VALUE || i8 == 0) {
                    int i9 = this.v0;
                    o = (int) ((this.A0 * ((float) (this.x0 - i9))) + ((float) i9));
                    requestLayout();
                }
                setMeasuredDimension(u, o);
            }
            float signum = Math.signum(this.O - this.M);
            long nanoTime = getNanoTime();
            Interpolator interpolator = this.A;
            f2 = this.M + (interpolator instanceof hh ? ((((float) (nanoTime - this.N)) * signum) * 1.0E-9f) / this.K : Utils.FLOAT_EPSILON);
            if (this.P) {
                f2 = this.O;
            }
            i4 = (signum > Utils.FLOAT_EPSILON ? 1 : (signum == Utils.FLOAT_EPSILON ? 0 : -1));
            if ((i4 > 0 || f2 < this.O) && (signum > Utils.FLOAT_EPSILON || f2 > this.O)) {
                z3 = false;
            } else {
                f2 = this.O;
            }
            if (interpolator != null && !z3) {
                if (!this.W) {
                    f2 = interpolator.getInterpolation(((float) (nanoTime - this.J)) * 1.0E-9f);
                } else {
                    f2 = interpolator.getInterpolation(f2);
                }
            }
            if ((i4 > 0 && f2 >= this.O) || (signum <= Utils.FLOAT_EPSILON && f2 <= this.O)) {
                f2 = this.O;
            }
            this.A0 = f2;
            childCount = getChildCount();
            long nanoTime2 = getNanoTime();
            for (int i10 = 0; i10 < childCount; i10++) {
                View childAt = getChildAt(i10);
                uh uhVar = this.I.get(childAt);
                if (uhVar != null) {
                    uhVar.b(childAt, f2, nanoTime2, this.B0);
                }
            }
            if (!this.t0) {
                requestLayout();
                return;
            }
            return;
        }
        z2 = true;
        int paddingBottom2 = getPaddingBottom() + getPaddingTop();
        int u2 = this.i.u() + getPaddingRight() + getPaddingLeft();
        int o2 = this.i.o() + paddingBottom2;
        int i62 = this.y0;
        int i72 = this.u0;
        u2 = (int) ((this.A0 * ((float) (this.w0 - i72))) + ((float) i72));
        requestLayout();
        int i82 = this.z0;
        int i92 = this.v0;
        o2 = (int) ((this.A0 * ((float) (this.x0 - i92))) + ((float) i92));
        requestLayout();
        setMeasuredDimension(u2, o2);
        float signum2 = Math.signum(this.O - this.M);
        long nanoTime3 = getNanoTime();
        Interpolator interpolator2 = this.A;
        f2 = this.M + (interpolator2 instanceof hh ? ((((float) (nanoTime3 - this.N)) * signum2) * 1.0E-9f) / this.K : Utils.FLOAT_EPSILON);
        if (this.P) {
        }
        i4 = (signum2 > Utils.FLOAT_EPSILON ? 1 : (signum2 == Utils.FLOAT_EPSILON ? 0 : -1));
        if (i4 > 0) {
        }
        z3 = false;
        if (!this.W) {
        }
        f2 = this.O;
        this.A0 = f2;
        childCount = getChildCount();
        long nanoTime22 = getNanoTime();
        while (i10 < childCount) {
        }
        if (!this.t0) {
        }
    }

    public boolean onNestedFling(View view, float f2, float f3, boolean z2) {
        return false;
    }

    public boolean onNestedPreFling(View view, float f2, float f3) {
        return false;
    }

    public void onRtlPropertiesChanged(int i2) {
        di diVar;
        yh yhVar = this.z;
        if (yhVar != null) {
            boolean k = k();
            yhVar.p = k;
            yh.b bVar = yhVar.c;
            if (bVar != null && (diVar = bVar.l) != null) {
                diVar.b(k);
            }
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        e eVar;
        e eVar2;
        di diVar;
        char c2;
        char c3;
        float f2;
        int i2;
        char c4;
        char c5;
        char c6;
        char c7;
        float f3;
        RectF rectF;
        View findViewById;
        MotionEvent motionEvent2;
        yh.b bVar;
        int i3;
        di diVar2;
        RectF a2;
        yh yhVar = this.z;
        if (yhVar == null || !this.H || !yhVar.n()) {
            return super.onTouchEvent(motionEvent);
        }
        yh yhVar2 = this.z;
        yh.b bVar2 = yhVar2.c;
        if (bVar2 != null && !(!bVar2.o)) {
            return super.onTouchEvent(motionEvent);
        }
        int currentState = getCurrentState();
        Objects.requireNonNull(yhVar2);
        RectF rectF2 = new RectF();
        if (yhVar2.o == null) {
            Objects.requireNonNull(yhVar2.a);
            f.b.a = VelocityTracker.obtain();
            yhVar2.o = f.b;
        }
        VelocityTracker velocityTracker = ((f) yhVar2.o).a;
        if (velocityTracker != null) {
            velocityTracker.addMovement(motionEvent);
        }
        if (currentState != -1) {
            int action = motionEvent.getAction();
            if (action == 0) {
                yhVar2.q = motionEvent.getRawX();
                yhVar2.r = motionEvent.getRawY();
                yhVar2.l = motionEvent;
                yhVar2.m = false;
                di diVar3 = yhVar2.c.l;
                if (diVar3 == null) {
                    return true;
                }
                MotionLayout motionLayout = yhVar2.a;
                int i4 = diVar3.f;
                if (i4 == -1 || (findViewById = motionLayout.findViewById(i4)) == null) {
                    rectF = null;
                } else {
                    rectF2.set((float) findViewById.getLeft(), (float) findViewById.getTop(), (float) findViewById.getRight(), (float) findViewById.getBottom());
                    rectF = rectF2;
                }
                if (rectF == null || rectF.contains(yhVar2.l.getX(), yhVar2.l.getY())) {
                    RectF a3 = yhVar2.c.l.a(yhVar2.a, rectF2);
                    if (a3 == null || a3.contains(yhVar2.l.getX(), yhVar2.l.getY())) {
                        yhVar2.n = false;
                    } else {
                        yhVar2.n = true;
                    }
                    di diVar4 = yhVar2.c.l;
                    float f4 = yhVar2.q;
                    float f5 = yhVar2.r;
                    diVar4.m = f4;
                    diVar4.n = f5;
                    return true;
                }
                yhVar2.l = null;
                yhVar2.m = true;
                return true;
            } else if (action == 2 && !yhVar2.m) {
                float rawY = motionEvent.getRawY() - yhVar2.r;
                float rawX = motionEvent.getRawX() - yhVar2.q;
                if ((((double) rawX) == Utils.DOUBLE_EPSILON && ((double) rawY) == Utils.DOUBLE_EPSILON) || (motionEvent2 = yhVar2.l) == null) {
                    return true;
                }
                if (currentState != -1) {
                    uj ujVar = yhVar2.b;
                    if (ujVar == null || (i3 = ujVar.a(currentState, -1, -1)) == -1) {
                        i3 = currentState;
                    }
                    ArrayList arrayList = new ArrayList();
                    Iterator<yh.b> it = yhVar2.d.iterator();
                    while (it.hasNext()) {
                        yh.b next = it.next();
                        if (next.d == i3 || next.c == i3) {
                            arrayList.add(next);
                        }
                    }
                    RectF rectF3 = new RectF();
                    Iterator it2 = arrayList.iterator();
                    float f6 = Utils.FLOAT_EPSILON;
                    bVar = null;
                    while (it2.hasNext()) {
                        yh.b bVar3 = (yh.b) it2.next();
                        if (!bVar3.o && (diVar2 = bVar3.l) != null) {
                            diVar2.b(yhVar2.p);
                            RectF a4 = bVar3.l.a(yhVar2.a, rectF3);
                            if ((a4 == null || a4.contains(motionEvent2.getX(), motionEvent2.getY())) && ((a2 = bVar3.l.a(yhVar2.a, rectF3)) == null || a2.contains(motionEvent2.getX(), motionEvent2.getY()))) {
                                di diVar5 = bVar3.l;
                                float f7 = ((diVar5.j * rawY) + (diVar5.i * rawX)) * (bVar3.c == currentState ? -1.0f : 1.1f);
                                if (f7 > f6) {
                                    f6 = f7;
                                    bVar = bVar3;
                                }
                            }
                        }
                    }
                } else {
                    bVar = yhVar2.c;
                }
                if (bVar != null) {
                    setTransition(bVar);
                    RectF a5 = yhVar2.c.l.a(yhVar2.a, rectF2);
                    yhVar2.n = a5 != null && !a5.contains(yhVar2.l.getX(), yhVar2.l.getY());
                    di diVar6 = yhVar2.c.l;
                    float f8 = yhVar2.q;
                    float f9 = yhVar2.r;
                    diVar6.m = f8;
                    diVar6.n = f9;
                    diVar6.k = false;
                }
            }
        }
        if (yhVar2.m) {
            return true;
        }
        yh.b bVar4 = yhVar2.c;
        if (!(bVar4 == null || (diVar = bVar4.l) == null || yhVar2.n)) {
            e eVar3 = yhVar2.o;
            i iVar = i.FINISHED;
            f fVar = (f) eVar3;
            VelocityTracker velocityTracker2 = fVar.a;
            if (velocityTracker2 != null) {
                velocityTracker2.addMovement(motionEvent);
            }
            int action2 = motionEvent.getAction();
            if (action2 == 0) {
                diVar.m = motionEvent.getRawX();
                diVar.n = motionEvent.getRawY();
                diVar.k = false;
            } else if (action2 == 1) {
                diVar.k = false;
                VelocityTracker velocityTracker3 = fVar.a;
                if (velocityTracker3 != null) {
                    velocityTracker3.computeCurrentVelocity(vf0.DEFAULT_IMAGE_TIMEOUT_MS);
                }
                VelocityTracker velocityTracker4 = fVar.a;
                float xVelocity = velocityTracker4 != null ? velocityTracker4.getXVelocity() : Utils.FLOAT_EPSILON;
                VelocityTracker velocityTracker5 = fVar.a;
                float yVelocity = velocityTracker5 != null ? velocityTracker5.getYVelocity() : Utils.FLOAT_EPSILON;
                float progress = diVar.o.getProgress();
                int i5 = diVar.d;
                if (i5 != -1) {
                    diVar.o.w(i5, progress, diVar.h, diVar.g, diVar.l);
                    c3 = 0;
                    c2 = 1;
                } else {
                    float min = (float) Math.min(diVar.o.getWidth(), diVar.o.getHeight());
                    float[] fArr = diVar.l;
                    c2 = 1;
                    fArr[1] = diVar.j * min;
                    c3 = 0;
                    fArr[0] = min * diVar.i;
                }
                float f10 = diVar.i;
                float[] fArr2 = diVar.l;
                float f11 = fArr2[c3];
                float f12 = fArr2[c2];
                if (f10 != Utils.FLOAT_EPSILON) {
                    f2 = xVelocity / fArr2[c3];
                } else {
                    f2 = yVelocity / fArr2[c2];
                }
                float f13 = !Float.isNaN(f2) ? (f2 / 3.0f) + progress : progress;
                if (f13 != Utils.FLOAT_EPSILON && f13 != 1.0f && (i2 = diVar.c) != 3) {
                    diVar.o.C(i2, ((double) f13) < 0.5d ? Utils.FLOAT_EPSILON : 1.0f, f2);
                    if (Utils.FLOAT_EPSILON >= progress || 1.0f <= progress) {
                        diVar.o.setState(iVar);
                    }
                } else if (Utils.FLOAT_EPSILON >= f13 || 1.0f <= f13) {
                    diVar.o.setState(iVar);
                }
            } else if (action2 == 2) {
                float rawY2 = motionEvent.getRawY() - diVar.n;
                float rawX2 = motionEvent.getRawX() - diVar.m;
                if (Math.abs((diVar.j * rawY2) + (diVar.i * rawX2)) > diVar.u || diVar.k) {
                    float progress2 = diVar.o.getProgress();
                    if (!diVar.k) {
                        diVar.k = true;
                        diVar.o.setProgress(progress2);
                    }
                    int i6 = diVar.d;
                    if (i6 != -1) {
                        diVar.o.w(i6, progress2, diVar.h, diVar.g, diVar.l);
                        c5 = 0;
                        c4 = 1;
                    } else {
                        float min2 = (float) Math.min(diVar.o.getWidth(), diVar.o.getHeight());
                        float[] fArr3 = diVar.l;
                        c4 = 1;
                        fArr3[1] = diVar.j * min2;
                        c5 = 0;
                        fArr3[0] = min2 * diVar.i;
                    }
                    float f14 = diVar.i;
                    float[] fArr4 = diVar.l;
                    if (((double) Math.abs(((diVar.j * fArr4[c4]) + (f14 * fArr4[c5])) * diVar.s)) < 0.01d) {
                        float[] fArr5 = diVar.l;
                        c7 = 0;
                        fArr5[0] = 0.01f;
                        c6 = 1;
                        fArr5[1] = 0.01f;
                    } else {
                        c7 = 0;
                        c6 = 1;
                    }
                    if (diVar.i != Utils.FLOAT_EPSILON) {
                        f3 = rawX2 / diVar.l[c7];
                    } else {
                        f3 = rawY2 / diVar.l[c6];
                    }
                    float max = Math.max(Math.min(progress2 + f3, 1.0f), (float) Utils.FLOAT_EPSILON);
                    if (max != diVar.o.getProgress()) {
                        diVar.o.setProgress(max);
                        VelocityTracker velocityTracker6 = fVar.a;
                        if (velocityTracker6 != null) {
                            velocityTracker6.computeCurrentVelocity(vf0.DEFAULT_IMAGE_TIMEOUT_MS);
                        }
                        VelocityTracker velocityTracker7 = fVar.a;
                        float xVelocity2 = velocityTracker7 != null ? velocityTracker7.getXVelocity() : Utils.FLOAT_EPSILON;
                        VelocityTracker velocityTracker8 = fVar.a;
                        diVar.o.B = diVar.i != Utils.FLOAT_EPSILON ? xVelocity2 / diVar.l[0] : (velocityTracker8 != null ? velocityTracker8.getYVelocity() : Utils.FLOAT_EPSILON) / diVar.l[1];
                    } else {
                        diVar.o.B = Utils.FLOAT_EPSILON;
                    }
                    diVar.m = motionEvent.getRawX();
                    diVar.n = motionEvent.getRawY();
                }
            }
        }
        yhVar2.q = motionEvent.getRawX();
        yhVar2.r = motionEvent.getRawY();
        if (motionEvent.getAction() != 1 || (eVar = yhVar2.o) == null) {
            return true;
        }
        f fVar2 = (f) eVar;
        VelocityTracker velocityTracker9 = fVar2.a;
        if (velocityTracker9 != null) {
            velocityTracker9.recycle();
            eVar2 = null;
            fVar2.a = null;
        } else {
            eVar2 = null;
        }
        yhVar2.o = eVar2;
        int i7 = this.D;
        if (i7 == -1) {
            return true;
        }
        yhVar2.a(this, i7);
        return true;
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout
    public void onViewAdded(View view) {
        super.onViewAdded(view);
        if (view instanceof vh) {
            vh vhVar = (vh) view;
            if (this.n0 == null) {
                this.n0 = new ArrayList<>();
            }
            this.n0.add(vhVar);
            if (vhVar.o) {
                if (this.l0 == null) {
                    this.l0 = new ArrayList<>();
                }
                this.l0.add(vhVar);
            }
            if (vhVar.p) {
                if (this.m0 == null) {
                    this.m0 = new ArrayList<>();
                }
                this.m0.add(vhVar);
            }
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout
    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        ArrayList<vh> arrayList = this.l0;
        if (arrayList != null) {
            arrayList.remove(view);
        }
        ArrayList<vh> arrayList2 = this.m0;
        if (arrayList2 != null) {
            arrayList2.remove(view);
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout
    public void requestLayout() {
        yh yhVar;
        yh.b bVar;
        if (this.t0 || this.D != -1 || (yhVar = this.z) == null || (bVar = yhVar.c) == null || bVar.q != 0) {
            super.requestLayout();
        }
    }

    public void s(float f2) {
        yh yhVar = this.z;
        if (yhVar != null) {
            float f3 = this.M;
            float f4 = this.L;
            if (f3 != f4 && this.P) {
                this.M = f4;
            }
            float f5 = this.M;
            if (f5 != f2) {
                this.W = false;
                this.O = f2;
                this.K = ((float) yhVar.c()) / 1000.0f;
                setProgress(this.O);
                this.A = this.z.f();
                this.P = false;
                this.J = getNanoTime();
                this.Q = true;
                this.L = f5;
                this.M = f5;
                invalidate();
            }
        }
    }

    public void setDebugMode(int i2) {
        this.U = i2;
        invalidate();
    }

    public void setInteractionEnabled(boolean z2) {
        this.H = z2;
    }

    public void setInterpolatedProgress(float f2) {
        if (this.z != null) {
            setState(i.MOVING);
            Interpolator f3 = this.z.f();
            if (f3 != null) {
                setProgress(f3.getInterpolation(f2));
                return;
            }
        }
        setProgress(f2);
    }

    public void setOnHide(float f2) {
        ArrayList<vh> arrayList = this.m0;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i2 = 0; i2 < size; i2++) {
                this.m0.get(i2).setProgress(f2);
            }
        }
    }

    public void setOnShow(float f2) {
        ArrayList<vh> arrayList = this.l0;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i2 = 0; i2 < size; i2++) {
                this.l0.get(i2).setProgress(f2);
            }
        }
    }

    public void setProgress(float f2) {
        i iVar = i.FINISHED;
        int i2 = (f2 > Utils.FLOAT_EPSILON ? 1 : (f2 == Utils.FLOAT_EPSILON ? 0 : -1));
        if (i2 < 0 || f2 > 1.0f) {
            Log.w("MotionLayout", "Warning! Progress is defined for values between 0.0 and 1.0 inclusive");
        }
        if (!isAttachedToWindow()) {
            if (this.D0 == null) {
                this.D0 = new g();
            }
            this.D0.a = f2;
            return;
        }
        if (i2 <= 0) {
            this.D = this.C;
            if (this.M == Utils.FLOAT_EPSILON) {
                setState(iVar);
            }
        } else if (f2 >= 1.0f) {
            this.D = this.E;
            if (this.M == 1.0f) {
                setState(iVar);
            }
        } else {
            this.D = -1;
            setState(i.MOVING);
        }
        if (this.z != null) {
            this.P = true;
            this.O = f2;
            this.L = f2;
            this.N = -1;
            this.J = -1;
            this.A = null;
            this.Q = true;
            invalidate();
        }
    }

    public void setScene(yh yhVar) {
        di diVar;
        this.z = yhVar;
        boolean k = k();
        yhVar.p = k;
        yh.b bVar = yhVar.c;
        if (!(bVar == null || (diVar = bVar.l) == null)) {
            diVar.b(k);
        }
        A();
    }

    public void setState(i iVar) {
        i iVar2 = i.FINISHED;
        if (iVar != iVar2 || this.D != -1) {
            i iVar3 = this.E0;
            this.E0 = iVar;
            i iVar4 = i.MOVING;
            if (iVar3 == iVar4 && iVar == iVar4) {
                u();
            }
            int ordinal = iVar3.ordinal();
            if (ordinal == 0 || ordinal == 1) {
                if (iVar == iVar4) {
                    u();
                }
                if (iVar == iVar2) {
                    v();
                }
            } else if (ordinal == 2 && iVar == iVar2) {
                v();
            }
        }
    }

    public void setTransition(int i2) {
        yh.b bVar;
        yh yhVar = this.z;
        if (yhVar != null) {
            Iterator<yh.b> it = yhVar.d.iterator();
            while (true) {
                if (!it.hasNext()) {
                    bVar = null;
                    break;
                }
                bVar = it.next();
                if (bVar.a == i2) {
                    break;
                }
            }
            this.C = bVar.d;
            this.E = bVar.c;
            if (!isAttachedToWindow()) {
                if (this.D0 == null) {
                    this.D0 = new g();
                }
                g gVar = this.D0;
                gVar.c = this.C;
                gVar.d = this.E;
                return;
            }
            float f2 = Float.NaN;
            int i3 = this.D;
            if (i3 == this.C) {
                f2 = Utils.FLOAT_EPSILON;
            } else if (i3 == this.E) {
                f2 = 1.0f;
            }
            yh yhVar2 = this.z;
            yhVar2.c = bVar;
            di diVar = bVar.l;
            if (diVar != null) {
                diVar.b(yhVar2.p);
            }
            this.F0.d(this.z.b(this.C), this.z.b(this.E));
            A();
            this.M = Float.isNaN(f2) ? Utils.FLOAT_EPSILON : f2;
            if (Float.isNaN(f2)) {
                Log.v("MotionLayout", fg.e() + " transitionToStart ");
                s(Utils.FLOAT_EPSILON);
                return;
            }
            setProgress(f2);
        }
    }

    public void setTransitionDuration(int i2) {
        yh yhVar = this.z;
        if (yhVar == null) {
            Log.e("MotionLayout", "MotionScene not defined");
            return;
        }
        yh.b bVar = yhVar.c;
        if (bVar != null) {
            bVar.h = i2;
        } else {
            yhVar.j = i2;
        }
    }

    public void setTransitionListener(h hVar) {
        this.R = hVar;
    }

    public void setTransitionState(Bundle bundle) {
        if (this.D0 == null) {
            this.D0 = new g();
        }
        g gVar = this.D0;
        Objects.requireNonNull(gVar);
        gVar.a = bundle.getFloat("motion.progress");
        gVar.b = bundle.getFloat("motion.velocity");
        gVar.c = bundle.getInt("motion.StartState");
        gVar.d = bundle.getInt("motion.EndState");
        if (isAttachedToWindow()) {
            this.D0.a();
        }
    }

    public void t(boolean z2) {
        float f2;
        boolean z3;
        int i2;
        int i3;
        float f3;
        i iVar = i.FINISHED;
        if (this.N == -1) {
            this.N = getNanoTime();
        }
        float f4 = this.M;
        if (f4 > Utils.FLOAT_EPSILON && f4 < 1.0f) {
            this.D = -1;
        }
        boolean z4 = true;
        boolean z5 = false;
        if (this.k0 || (this.Q && (z2 || this.O != f4))) {
            float signum = Math.signum(this.O - f4);
            long nanoTime = getNanoTime();
            Interpolator interpolator = this.A;
            if (!(interpolator instanceof wh)) {
                f2 = ((((float) (nanoTime - this.N)) * signum) * 1.0E-9f) / this.K;
                this.B = f2;
            } else {
                f2 = Utils.FLOAT_EPSILON;
            }
            float f5 = this.M + f2;
            if (this.P) {
                f5 = this.O;
            }
            int i4 = (signum > Utils.FLOAT_EPSILON ? 1 : (signum == Utils.FLOAT_EPSILON ? 0 : -1));
            if ((i4 <= 0 || f5 < this.O) && (signum > Utils.FLOAT_EPSILON || f5 > this.O)) {
                z3 = false;
            } else {
                f5 = this.O;
                this.Q = false;
                z3 = true;
            }
            this.M = f5;
            this.L = f5;
            this.N = nanoTime;
            if (interpolator != null && !z3) {
                if (this.W) {
                    f3 = interpolator.getInterpolation(((float) (nanoTime - this.J)) * 1.0E-9f);
                    this.M = f3;
                    this.N = nanoTime;
                    Interpolator interpolator2 = this.A;
                    if (interpolator2 instanceof wh) {
                        float a2 = ((wh) interpolator2).a();
                        this.B = a2;
                        if (Math.abs(a2) * this.K <= 1.0E-5f) {
                            this.Q = false;
                        }
                        if (a2 > Utils.FLOAT_EPSILON && f3 >= 1.0f) {
                            this.M = 1.0f;
                            this.Q = false;
                            f3 = 1.0f;
                        }
                        if (a2 < Utils.FLOAT_EPSILON && f3 <= Utils.FLOAT_EPSILON) {
                            this.M = Utils.FLOAT_EPSILON;
                            this.Q = false;
                            f5 = Utils.FLOAT_EPSILON;
                        }
                    }
                } else {
                    f3 = interpolator.getInterpolation(f5);
                    Interpolator interpolator3 = this.A;
                    if (interpolator3 instanceof wh) {
                        this.B = ((wh) interpolator3).a();
                    } else {
                        this.B = ((interpolator3.getInterpolation(f5 + f2) - f3) * signum) / f2;
                    }
                }
                f5 = f3;
            }
            if (Math.abs(this.B) > 1.0E-5f) {
                setState(i.MOVING);
            }
            if ((i4 > 0 && f5 >= this.O) || (signum <= Utils.FLOAT_EPSILON && f5 <= this.O)) {
                f5 = this.O;
                this.Q = false;
            }
            int i5 = (f5 > 1.0f ? 1 : (f5 == 1.0f ? 0 : -1));
            if (i5 >= 0 || f5 <= Utils.FLOAT_EPSILON) {
                this.Q = false;
                setState(iVar);
            }
            int childCount = getChildCount();
            this.k0 = false;
            long nanoTime2 = getNanoTime();
            this.A0 = f5;
            for (int i6 = 0; i6 < childCount; i6++) {
                View childAt = getChildAt(i6);
                uh uhVar = this.I.get(childAt);
                if (uhVar != null) {
                    this.k0 = uhVar.b(childAt, f5, nanoTime2, this.B0) | this.k0;
                }
            }
            boolean z6 = (i4 > 0 && f5 >= this.O) || (signum <= Utils.FLOAT_EPSILON && f5 <= this.O);
            if (!this.k0 && !this.Q && z6) {
                setState(iVar);
            }
            if (this.t0) {
                requestLayout();
            }
            this.k0 = (!z6) | this.k0;
            if (f5 > Utils.FLOAT_EPSILON || (i3 = this.C) == -1 || this.D == i3) {
                z5 = false;
            } else {
                this.D = i3;
                this.z.b(i3).a(this);
                setState(iVar);
                z5 = true;
            }
            if (((double) f5) >= 1.0d && this.D != (i2 = this.E)) {
                this.D = i2;
                this.z.b(i2).a(this);
                setState(iVar);
                z5 = true;
            }
            if (this.k0 || this.Q) {
                invalidate();
            } else if ((i4 > 0 && i5 == 0) || (signum < Utils.FLOAT_EPSILON && f5 == Utils.FLOAT_EPSILON)) {
                setState(iVar);
            }
            if ((!this.k0 && this.Q && i4 > 0 && i5 == 0) || (signum < Utils.FLOAT_EPSILON && f5 == Utils.FLOAT_EPSILON)) {
                y();
            }
        }
        float f6 = this.M;
        if (f6 >= 1.0f) {
            int i7 = this.D;
            int i8 = this.E;
            if (i7 == i8) {
                z4 = z5;
            }
            this.D = i8;
        } else {
            if (f6 <= Utils.FLOAT_EPSILON) {
                int i9 = this.D;
                int i10 = this.C;
                if (i9 == i10) {
                    z4 = z5;
                }
                this.D = i10;
            }
            this.G0 |= z5;
            if (z5 && !this.C0) {
                requestLayout();
            }
            this.L = this.M;
        }
        z5 = z4;
        this.G0 |= z5;
        requestLayout();
        this.L = this.M;
    }

    public String toString() {
        Context context = getContext();
        return fg.f(context, this.C) + "->" + fg.f(context, this.E) + " (pos:" + this.M + " Dpos/Dt:" + this.B;
    }

    public final void u() {
        ArrayList<h> arrayList;
        if ((this.R != null || ((arrayList = this.n0) != null && !arrayList.isEmpty())) && this.s0 != this.L) {
            if (this.r0 != -1) {
                h hVar = this.R;
                if (hVar != null) {
                    hVar.b(this, this.C, this.E);
                }
                ArrayList<h> arrayList2 = this.n0;
                if (arrayList2 != null) {
                    Iterator<h> it = arrayList2.iterator();
                    while (it.hasNext()) {
                        it.next().b(this, this.C, this.E);
                    }
                }
            }
            this.r0 = -1;
            float f2 = this.L;
            this.s0 = f2;
            h hVar2 = this.R;
            if (hVar2 != null) {
                hVar2.a(this, this.C, this.E, f2);
            }
            ArrayList<h> arrayList3 = this.n0;
            if (arrayList3 != null) {
                Iterator<h> it2 = arrayList3.iterator();
                while (it2.hasNext()) {
                    it2.next().a(this, this.C, this.E, this.L);
                }
            }
        }
    }

    public void v() {
        int i2;
        ArrayList<h> arrayList;
        if ((this.R != null || ((arrayList = this.n0) != null && !arrayList.isEmpty())) && this.r0 == -1) {
            this.r0 = this.D;
            if (!this.J0.isEmpty()) {
                ArrayList<Integer> arrayList2 = this.J0;
                i2 = arrayList2.get(arrayList2.size() - 1).intValue();
            } else {
                i2 = -1;
            }
            int i3 = this.D;
            if (!(i2 == i3 || i3 == -1)) {
                this.J0.add(Integer.valueOf(i3));
            }
        }
        z();
    }

    public void w(int i2, float f2, float f3, float f4, float[] fArr) {
        String str;
        double[] dArr;
        HashMap<View, uh> hashMap = this.I;
        View view = this.g.get(i2);
        uh uhVar = hashMap.get(view);
        if (uhVar != null) {
            float a2 = uhVar.a(f2, uhVar.u);
            ch[] chVarArr = uhVar.h;
            int i3 = 0;
            if (chVarArr != null) {
                double d2 = (double) a2;
                chVarArr[0].e(d2, uhVar.o);
                uhVar.h[0].c(d2, uhVar.n);
                float f5 = uhVar.u[0];
                while (true) {
                    dArr = uhVar.o;
                    if (i3 >= dArr.length) {
                        break;
                    }
                    dArr[i3] = dArr[i3] * ((double) f5);
                    i3++;
                }
                ch chVar = uhVar.i;
                if (chVar != null) {
                    double[] dArr2 = uhVar.n;
                    if (dArr2.length > 0) {
                        chVar.c(d2, dArr2);
                        uhVar.i.e(d2, uhVar.o);
                        uhVar.d.r(f3, f4, fArr, uhVar.m, uhVar.o, uhVar.n);
                    }
                } else {
                    uhVar.d.r(f3, f4, fArr, uhVar.m, dArr, uhVar.n);
                }
            } else {
                xh xhVar = uhVar.e;
                float f6 = xhVar.k;
                xh xhVar2 = uhVar.d;
                float f7 = f6 - xhVar2.k;
                float f8 = xhVar.l - xhVar2.l;
                fArr[0] = (((xhVar.m - xhVar2.m) + f7) * f3) + ((1.0f - f3) * f7);
                fArr[1] = (((xhVar.n - xhVar2.n) + f8) * f4) + ((1.0f - f4) * f8);
            }
            float y = view.getY();
            this.S = f2;
            this.T = y;
            return;
        }
        if (view == null) {
            str = ze0.j0("", i2);
        } else {
            str = view.getContext().getResources().getResourceName(i2);
        }
        Log.w("MotionLayout", "WARNING could not find view id " + str);
    }

    public final boolean x(float f2, float f3, View view, MotionEvent motionEvent) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                if (x(((float) view.getLeft()) + f2, ((float) view.getTop()) + f3, viewGroup.getChildAt(i2), motionEvent)) {
                    return true;
                }
            }
        }
        this.H0.set(((float) view.getLeft()) + f2, ((float) view.getTop()) + f3, f2 + ((float) view.getRight()), f3 + ((float) view.getBottom()));
        if (motionEvent.getAction() == 0) {
            return this.H0.contains(motionEvent.getX(), motionEvent.getY()) && view.onTouchEvent(motionEvent);
        }
        if (view.onTouchEvent(motionEvent)) {
            return true;
        }
    }

    public void y() {
        yh.b bVar;
        di diVar;
        View view;
        yh yhVar = this.z;
        if (yhVar != null) {
            if (yhVar.a(this, this.D)) {
                requestLayout();
                return;
            }
            int i2 = this.D;
            if (i2 != -1) {
                yh yhVar2 = this.z;
                Iterator<yh.b> it = yhVar2.d.iterator();
                while (it.hasNext()) {
                    yh.b next = it.next();
                    if (next.m.size() > 0) {
                        Iterator<yh.b.a> it2 = next.m.iterator();
                        while (it2.hasNext()) {
                            it2.next().b(this);
                        }
                    }
                }
                Iterator<yh.b> it3 = yhVar2.f.iterator();
                while (it3.hasNext()) {
                    yh.b next2 = it3.next();
                    if (next2.m.size() > 0) {
                        Iterator<yh.b.a> it4 = next2.m.iterator();
                        while (it4.hasNext()) {
                            it4.next().b(this);
                        }
                    }
                }
                Iterator<yh.b> it5 = yhVar2.d.iterator();
                while (it5.hasNext()) {
                    yh.b next3 = it5.next();
                    if (next3.m.size() > 0) {
                        Iterator<yh.b.a> it6 = next3.m.iterator();
                        while (it6.hasNext()) {
                            it6.next().a(this, i2, next3);
                        }
                    }
                }
                Iterator<yh.b> it7 = yhVar2.f.iterator();
                while (it7.hasNext()) {
                    yh.b next4 = it7.next();
                    if (next4.m.size() > 0) {
                        Iterator<yh.b.a> it8 = next4.m.iterator();
                        while (it8.hasNext()) {
                            it8.next().a(this, i2, next4);
                        }
                    }
                }
            }
            if (this.z.n() && (bVar = this.z.c) != null && (diVar = bVar.l) != null) {
                int i3 = diVar.d;
                if (i3 != -1) {
                    view = diVar.o.findViewById(i3);
                    if (view == null) {
                        StringBuilder J02 = ze0.J0("cannot find TouchAnchorId @id/");
                        J02.append(fg.f(diVar.o.getContext(), diVar.d));
                        Log.e("TouchResponse", J02.toString());
                    }
                } else {
                    view = null;
                }
                if (view instanceof NestedScrollView) {
                    NestedScrollView nestedScrollView = (NestedScrollView) view;
                    nestedScrollView.setOnTouchListener(new bi(diVar));
                    nestedScrollView.setOnScrollChangeListener(new ci(diVar));
                }
            }
        }
    }

    public final void z() {
        ArrayList<h> arrayList;
        if (this.R != null || ((arrayList = this.n0) != null && !arrayList.isEmpty())) {
            Iterator<Integer> it = this.J0.iterator();
            while (it.hasNext()) {
                Integer next = it.next();
                h hVar = this.R;
                if (hVar != null) {
                    hVar.d(this, next.intValue());
                }
                ArrayList<h> arrayList2 = this.n0;
                if (arrayList2 != null) {
                    Iterator<h> it2 = arrayList2.iterator();
                    while (it2.hasNext()) {
                        it2.next().d(this, next.intValue());
                    }
                }
            }
            this.J0.clear();
        }
    }

    public void setTransition(yh.b bVar) {
        long j;
        di diVar;
        yh yhVar = this.z;
        yhVar.c = bVar;
        if (!(bVar == null || (diVar = bVar.l) == null)) {
            diVar.b(yhVar.p);
        }
        setState(i.SETUP);
        if (this.D == this.z.d()) {
            this.M = 1.0f;
            this.L = 1.0f;
            this.O = 1.0f;
        } else {
            this.M = Utils.FLOAT_EPSILON;
            this.L = Utils.FLOAT_EPSILON;
            this.O = Utils.FLOAT_EPSILON;
        }
        boolean z2 = true;
        if ((bVar.r & 1) == 0) {
            z2 = false;
        }
        if (z2) {
            j = -1;
        } else {
            j = getNanoTime();
        }
        this.N = j;
        int i2 = this.z.i();
        int d2 = this.z.d();
        if (i2 != this.C || d2 != this.E) {
            this.C = i2;
            this.E = d2;
            this.z.m(i2, d2);
            this.F0.d(this.z.b(this.C), this.z.b(this.E));
            d dVar = this.F0;
            int i3 = this.C;
            int i4 = this.E;
            dVar.e = i3;
            dVar.f = i4;
            dVar.e();
            A();
        }
    }
}
