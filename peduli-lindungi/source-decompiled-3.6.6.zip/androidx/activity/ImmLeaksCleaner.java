package androidx.activity;

import android.app.Activity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import defpackage.sr;
import java.lang.reflect.Field;

public final class ImmLeaksCleaner implements wr {
    public static int h;
    public static Field i;
    public static Field j;
    public static Field k;
    public Activity g;

    public ImmLeaksCleaner(Activity activity) {
        this.g = activity;
    }

    @Override // defpackage.wr
    public void c(yr yrVar, sr.a aVar) {
        if (aVar == sr.a.ON_DESTROY) {
            if (h == 0) {
                try {
                    h = 2;
                    Field declaredField = InputMethodManager.class.getDeclaredField("mServedView");
                    j = declaredField;
                    declaredField.setAccessible(true);
                    Field declaredField2 = InputMethodManager.class.getDeclaredField("mNextServedView");
                    k = declaredField2;
                    declaredField2.setAccessible(true);
                    Field declaredField3 = InputMethodManager.class.getDeclaredField("mH");
                    i = declaredField3;
                    declaredField3.setAccessible(true);
                    h = 1;
                } catch (NoSuchFieldException unused) {
                }
            }
            if (h == 1) {
                InputMethodManager inputMethodManager = (InputMethodManager) this.g.getSystemService("input_method");
                try {
                    Object obj = i.get(inputMethodManager);
                    if (obj != null) {
                        synchronized (obj) {
                            try {
                                View view = (View) j.get(inputMethodManager);
                                if (view != null) {
                                    if (!view.isAttachedToWindow()) {
                                        try {
                                            k.set(inputMethodManager, null);
                                            inputMethodManager.isActive();
                                        } catch (IllegalAccessException unused2) {
                                        }
                                    }
                                }
                            } catch (IllegalAccessException unused3) {
                            } catch (ClassCastException unused4) {
                            }
                        }
                    }
                } catch (IllegalAccessException unused5) {
                }
            }
        }
    }
}
