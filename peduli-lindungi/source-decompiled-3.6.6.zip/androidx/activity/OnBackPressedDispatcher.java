package androidx.activity;

import android.annotation.SuppressLint;
import defpackage.sr;
import java.util.ArrayDeque;
import java.util.Iterator;

public final class OnBackPressedDispatcher {
    public final Runnable a;
    public final ArrayDeque<g0> b = new ArrayDeque<>();

    public class LifecycleOnBackPressedCancellable implements wr, f0 {
        public final sr g;
        public final g0 h;
        public f0 i;

        public LifecycleOnBackPressedCancellable(sr srVar, g0 g0Var) {
            this.g = srVar;
            this.h = g0Var;
            srVar.a(this);
        }

        @Override // defpackage.wr
        public void c(yr yrVar, sr.a aVar) {
            if (aVar == sr.a.ON_START) {
                OnBackPressedDispatcher onBackPressedDispatcher = OnBackPressedDispatcher.this;
                g0 g0Var = this.h;
                onBackPressedDispatcher.b.add(g0Var);
                a aVar2 = new a(g0Var);
                g0Var.addCancellable(aVar2);
                this.i = aVar2;
            } else if (aVar == sr.a.ON_STOP) {
                f0 f0Var = this.i;
                if (f0Var != null) {
                    f0Var.cancel();
                }
            } else if (aVar == sr.a.ON_DESTROY) {
                cancel();
            }
        }

        @Override // defpackage.f0
        public void cancel() {
            as asVar = (as) this.g;
            asVar.d("removeObserver");
            asVar.b.m(this);
            this.h.removeCancellable(this);
            f0 f0Var = this.i;
            if (f0Var != null) {
                f0Var.cancel();
                this.i = null;
            }
        }
    }

    public class a implements f0 {
        public final g0 g;

        public a(g0 g0Var) {
            this.g = g0Var;
        }

        @Override // defpackage.f0
        public void cancel() {
            OnBackPressedDispatcher.this.b.remove(this.g);
            this.g.removeCancellable(this);
        }
    }

    public OnBackPressedDispatcher(Runnable runnable) {
        this.a = runnable;
    }

    @SuppressLint({"LambdaLast"})
    public void a(yr yrVar, g0 g0Var) {
        sr lifecycle = yrVar.getLifecycle();
        if (((as) lifecycle).c != sr.b.DESTROYED) {
            g0Var.addCancellable(new LifecycleOnBackPressedCancellable(lifecycle, g0Var));
        }
    }

    public void b() {
        Iterator<g0> descendingIterator = this.b.descendingIterator();
        while (descendingIterator.hasNext()) {
            g0 next = descendingIterator.next();
            if (next.isEnabled()) {
                next.handleOnBackPressed();
                return;
            }
        }
        Runnable runnable = this.a;
        if (runnable != null) {
            runnable.run();
        }
    }
}
