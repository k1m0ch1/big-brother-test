package androidx.activity;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import defpackage.os;
import defpackage.sr;

public class ComponentActivity extends fk implements yr, qs, pz, h0 {
    private int mContentLayoutId;
    private os.b mDefaultFactory;
    private final as mLifecycleRegistry;
    private final OnBackPressedDispatcher mOnBackPressedDispatcher;
    private final oz mSavedStateRegistryController;
    private ps mViewModelStore;

    public class a implements Runnable {
        public a() {
        }

        public void run() {
            ComponentActivity.super.onBackPressed();
        }
    }

    public static final class b {
        public Object a;
        public ps b;
    }

    public ComponentActivity() {
        this.mLifecycleRegistry = new as(this);
        this.mSavedStateRegistryController = new oz(this);
        this.mOnBackPressedDispatcher = new OnBackPressedDispatcher(new a());
        if (getLifecycle() != null) {
            int i = Build.VERSION.SDK_INT;
            getLifecycle().a(new wr() {
                /* class androidx.activity.ComponentActivity.AnonymousClass2 */

                @Override // defpackage.wr
                public void c(yr yrVar, sr.a aVar) {
                    if (aVar == sr.a.ON_STOP) {
                        Window window = ComponentActivity.this.getWindow();
                        View peekDecorView = window != null ? window.peekDecorView() : null;
                        if (peekDecorView != null) {
                            peekDecorView.cancelPendingInputEvents();
                        }
                    }
                }
            });
            getLifecycle().a(new wr() {
                /* class androidx.activity.ComponentActivity.AnonymousClass3 */

                @Override // defpackage.wr
                public void c(yr yrVar, sr.a aVar) {
                    if (aVar == sr.a.ON_DESTROY && !ComponentActivity.this.isChangingConfigurations()) {
                        ComponentActivity.this.getViewModelStore().a();
                    }
                }
            });
            if (i <= 23) {
                getLifecycle().a(new ImmLeaksCleaner(this));
                return;
            }
            return;
        }
        throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
    }

    public os.b getDefaultViewModelProviderFactory() {
        if (getApplication() != null) {
            if (this.mDefaultFactory == null) {
                this.mDefaultFactory = new ls(getApplication(), this, getIntent() != null ? getIntent().getExtras() : null);
            }
            return this.mDefaultFactory;
        }
        throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
    }

    @Deprecated
    public Object getLastCustomNonConfigurationInstance() {
        b bVar = (b) getLastNonConfigurationInstance();
        if (bVar != null) {
            return bVar.a;
        }
        return null;
    }

    @Override // defpackage.fk, defpackage.yr
    public sr getLifecycle() {
        return this.mLifecycleRegistry;
    }

    @Override // defpackage.h0
    public final OnBackPressedDispatcher getOnBackPressedDispatcher() {
        return this.mOnBackPressedDispatcher;
    }

    @Override // defpackage.pz
    public final nz getSavedStateRegistry() {
        return this.mSavedStateRegistryController.b;
    }

    @Override // defpackage.qs
    public ps getViewModelStore() {
        if (getApplication() != null) {
            if (this.mViewModelStore == null) {
                b bVar = (b) getLastNonConfigurationInstance();
                if (bVar != null) {
                    this.mViewModelStore = bVar.b;
                }
                if (this.mViewModelStore == null) {
                    this.mViewModelStore = new ps();
                }
            }
            return this.mViewModelStore;
        }
        throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
    }

    public void onBackPressed() {
        this.mOnBackPressedDispatcher.b();
    }

    @Override // defpackage.fk
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.mSavedStateRegistryController.a(bundle);
        js.c(this);
        int i = this.mContentLayoutId;
        if (i != 0) {
            setContentView(i);
        }
    }

    @Deprecated
    public Object onRetainCustomNonConfigurationInstance() {
        return null;
    }

    public final Object onRetainNonConfigurationInstance() {
        b bVar;
        Object onRetainCustomNonConfigurationInstance = onRetainCustomNonConfigurationInstance();
        ps psVar = this.mViewModelStore;
        if (psVar == null && (bVar = (b) getLastNonConfigurationInstance()) != null) {
            psVar = bVar.b;
        }
        if (psVar == null && onRetainCustomNonConfigurationInstance == null) {
            return null;
        }
        b bVar2 = new b();
        bVar2.a = onRetainCustomNonConfigurationInstance;
        bVar2.b = psVar;
        return bVar2;
    }

    @Override // defpackage.fk
    public void onSaveInstanceState(Bundle bundle) {
        sr lifecycle = getLifecycle();
        if (lifecycle instanceof as) {
            as asVar = (as) lifecycle;
            sr.b bVar = sr.b.CREATED;
            asVar.d("setCurrentState");
            asVar.g(bVar);
        }
        super.onSaveInstanceState(bundle);
        this.mSavedStateRegistryController.b(bundle);
    }

    public ComponentActivity(int i) {
        this();
        this.mContentLayoutId = i;
    }
}
