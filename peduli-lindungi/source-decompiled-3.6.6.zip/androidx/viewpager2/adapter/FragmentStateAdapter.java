package androidx.viewpager2.adapter;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import defpackage.co;
import defpackage.hq;
import defpackage.sr;
import java.util.Iterator;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class FragmentStateAdapter extends RecyclerView.e<z10> implements a20 {
    public final sr a;
    public final iq b;
    public final qg<Fragment> c;
    public final qg<Fragment.f> d;
    public final qg<Integer> e;
    public b f;
    public boolean g;
    public boolean h;

    public static abstract class a extends RecyclerView.g {
        public a(u10 u10) {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        public final void b(int i, int i2) {
            a();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        public final void c(int i, int i2, Object obj) {
            a();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        public final void d(int i, int i2) {
            a();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        public final void e(int i, int i2, int i3) {
            a();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        public final void f(int i, int i2) {
            a();
        }
    }

    public class b {
        public ViewPager2.e a;
        public RecyclerView.g b;
        public wr c;
        public ViewPager2 d;
        public long e = -1;

        public b() {
        }

        public final ViewPager2 a(RecyclerView recyclerView) {
            ViewParent parent = recyclerView.getParent();
            if (parent instanceof ViewPager2) {
                return (ViewPager2) parent;
            }
            throw new IllegalStateException("Expected ViewPager2 instance. Got: " + parent);
        }

        public void b(boolean z) {
            int currentItem;
            Fragment g;
            if (!FragmentStateAdapter.this.k() && this.d.getScrollState() == 0 && !FragmentStateAdapter.this.c.i() && FragmentStateAdapter.this.getItemCount() != 0 && (currentItem = this.d.getCurrentItem()) < FragmentStateAdapter.this.getItemCount()) {
                Objects.requireNonNull(FragmentStateAdapter.this);
                long j = (long) currentItem;
                if ((j != this.e || z) && (g = FragmentStateAdapter.this.c.g(j)) != null && g.isAdded()) {
                    this.e = j;
                    sp spVar = new sp(FragmentStateAdapter.this.b);
                    Fragment fragment = null;
                    for (int i = 0; i < FragmentStateAdapter.this.c.n(); i++) {
                        long j2 = FragmentStateAdapter.this.c.j(i);
                        Fragment o = FragmentStateAdapter.this.c.o(i);
                        if (o.isAdded()) {
                            if (j2 != this.e) {
                                spVar.i(o, sr.b.STARTED);
                            } else {
                                fragment = o;
                            }
                            o.setMenuVisibility(j2 == this.e);
                        }
                    }
                    if (fragment != null) {
                        spVar.i(fragment, sr.b.RESUMED);
                    }
                    if (!spVar.a.isEmpty()) {
                        spVar.d();
                    }
                }
            }
        }
    }

    public FragmentStateAdapter(Fragment fragment) {
        this(fragment.getChildFragmentManager(), fragment.getLifecycle());
    }

    public static boolean g(String str, String str2) {
        return str.startsWith(str2) && str.length() > str2.length();
    }

    @Override // defpackage.a20
    public final Parcelable a() {
        Bundle bundle = new Bundle(this.d.n() + this.c.n());
        for (int i = 0; i < this.c.n(); i++) {
            long j = this.c.j(i);
            Fragment g2 = this.c.g(j);
            if (g2 != null && g2.isAdded()) {
                this.b.b0(bundle, ze0.m0("f#", j), g2);
            }
        }
        for (int i2 = 0; i2 < this.d.n(); i2++) {
            long j2 = this.d.j(i2);
            if (d(j2)) {
                bundle.putParcelable(ze0.m0("s#", j2), this.d.g(j2));
            }
        }
        return bundle;
    }

    @Override // defpackage.a20
    public final void b(Parcelable parcelable) {
        if (!this.d.i() || !this.c.i()) {
            throw new IllegalStateException("Expected the adapter to be 'fresh' while restoring state.");
        }
        Bundle bundle = (Bundle) parcelable;
        if (bundle.getClassLoader() == null) {
            bundle.setClassLoader(getClass().getClassLoader());
        }
        for (String str : bundle.keySet()) {
            if (g(str, "f#")) {
                this.c.k(Long.parseLong(str.substring(2)), this.b.K(bundle, str));
            } else if (g(str, "s#")) {
                long parseLong = Long.parseLong(str.substring(2));
                Fragment.f fVar = (Fragment.f) bundle.getParcelable(str);
                if (d(parseLong)) {
                    this.d.k(parseLong, fVar);
                }
            } else {
                throw new IllegalArgumentException(ze0.r0("Unexpected key in savedState: ", str));
            }
        }
        if (!this.c.i()) {
            this.h = true;
            this.g = true;
            f();
            final Handler handler = new Handler(Looper.getMainLooper());
            final w10 w10 = new w10(this);
            this.a.a(new wr(this) {
                /* class androidx.viewpager2.adapter.FragmentStateAdapter.AnonymousClass5 */

                @Override // defpackage.wr
                public void c(yr yrVar, sr.a aVar) {
                    if (aVar == sr.a.ON_DESTROY) {
                        handler.removeCallbacks(w10);
                        as asVar = (as) yrVar.getLifecycle();
                        asVar.d("removeObserver");
                        asVar.b.m(this);
                    }
                }
            });
            handler.postDelayed(w10, 10000);
        }
    }

    public void c(View view, FrameLayout frameLayout) {
        if (frameLayout.getChildCount() > 1) {
            throw new IllegalStateException("Design assumption violated.");
        } else if (view.getParent() != frameLayout) {
            if (frameLayout.getChildCount() > 0) {
                frameLayout.removeAllViews();
            }
            if (view.getParent() != null) {
                ((ViewGroup) view.getParent()).removeView(view);
            }
            frameLayout.addView(view);
        }
    }

    public boolean d(long j) {
        return j >= 0 && j < ((long) getItemCount());
    }

    public abstract Fragment e(int i);

    public void f() {
        Fragment h2;
        View view;
        if (this.h && !k()) {
            og ogVar = new og(0);
            for (int i = 0; i < this.c.n(); i++) {
                long j = this.c.j(i);
                if (!d(j)) {
                    ogVar.add(Long.valueOf(j));
                    this.e.l(j);
                }
            }
            if (!this.g) {
                this.h = false;
                for (int i2 = 0; i2 < this.c.n(); i2++) {
                    long j2 = this.c.j(i2);
                    boolean z = true;
                    if (!this.e.e(j2) && ((h2 = this.c.h(j2, null)) == null || (view = h2.getView()) == null || view.getParent() == null)) {
                        z = false;
                    }
                    if (!z) {
                        ogVar.add(Long.valueOf(j2));
                    }
                }
            }
            Iterator it = ogVar.iterator();
            while (it.hasNext()) {
                j(((Long) it.next()).longValue());
            }
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.e
    public long getItemId(int i) {
        return (long) i;
    }

    public final Long h(int i) {
        Long l = null;
        for (int i2 = 0; i2 < this.e.n(); i2++) {
            if (this.e.o(i2).intValue() == i) {
                if (l == null) {
                    l = Long.valueOf(this.e.j(i2));
                } else {
                    throw new IllegalStateException("Design assumption violated: a ViewHolder can only be bound to one item at a time.");
                }
            }
        }
        return l;
    }

    public void i(final z10 z10) {
        Fragment g2 = this.c.g(z10.getItemId());
        if (g2 != null) {
            FrameLayout frameLayout = (FrameLayout) z10.itemView;
            View view = g2.getView();
            if (!g2.isAdded() && view != null) {
                throw new IllegalStateException("Design assumption violated.");
            } else if (g2.isAdded() && view == null) {
                this.b.l.a.add(new hq.a(new v10(this, g2, frameLayout), false));
            } else if (!g2.isAdded() || view.getParent() == null) {
                if (g2.isAdded()) {
                    c(view, frameLayout);
                } else if (!k()) {
                    this.b.l.a.add(new hq.a(new v10(this, g2, frameLayout), false));
                    sp spVar = new sp(this.b);
                    StringBuilder J0 = ze0.J0("f");
                    J0.append(z10.getItemId());
                    spVar.f(0, g2, J0.toString(), 1);
                    spVar.i(g2, sr.b.STARTED);
                    spVar.d();
                    this.f.b(false);
                } else if (!this.b.w) {
                    this.a.a(new wr() {
                        /* class androidx.viewpager2.adapter.FragmentStateAdapter.AnonymousClass2 */

                        @Override // defpackage.wr
                        public void c(yr yrVar, sr.a aVar) {
                            if (!FragmentStateAdapter.this.k()) {
                                as asVar = (as) yrVar.getLifecycle();
                                asVar.d("removeObserver");
                                asVar.b.m(this);
                                AtomicInteger atomicInteger = co.a;
                                if (co.f.b((FrameLayout) z10.itemView)) {
                                    FragmentStateAdapter.this.i(z10);
                                }
                            }
                        }
                    });
                }
            } else if (view.getParent() != frameLayout) {
                c(view, frameLayout);
            }
        } else {
            throw new IllegalStateException("Design assumption violated.");
        }
    }

    public final void j(long j) {
        ViewParent parent;
        Fragment h2 = this.c.h(j, null);
        if (h2 != null) {
            if (!(h2.getView() == null || (parent = h2.getView().getParent()) == null)) {
                ((FrameLayout) parent).removeAllViews();
            }
            if (!d(j)) {
                this.d.l(j);
            }
            if (!h2.isAdded()) {
                this.c.l(j);
            } else if (k()) {
                this.h = true;
            } else {
                if (h2.isAdded() && d(j)) {
                    this.d.k(j, this.b.h0(h2));
                }
                sp spVar = new sp(this.b);
                spVar.g(h2);
                spVar.d();
                this.c.l(j);
            }
        }
    }

    public boolean k() {
        return this.b.S();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.e
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        ek.g(this.f == null);
        b bVar = new b();
        this.f = bVar;
        ViewPager2 a2 = bVar.a(recyclerView);
        bVar.d = a2;
        x10 x10 = new x10(bVar);
        bVar.a = x10;
        a2.i.a.add(x10);
        y10 y10 = new y10(bVar);
        bVar.b = y10;
        FragmentStateAdapter.this.registerAdapterDataObserver(y10);
        FragmentStateAdapter$FragmentMaxLifecycleEnforcer$3 fragmentStateAdapter$FragmentMaxLifecycleEnforcer$3 = new FragmentStateAdapter$FragmentMaxLifecycleEnforcer$3(bVar);
        bVar.c = fragmentStateAdapter$FragmentMaxLifecycleEnforcer$3;
        FragmentStateAdapter.this.a.a(fragmentStateAdapter$FragmentMaxLifecycleEnforcer$3);
    }

    /* JADX DEBUG: Method arguments types fixed to match base method, original types: [androidx.recyclerview.widget.RecyclerView$b0, int] */
    @Override // androidx.recyclerview.widget.RecyclerView.e
    public void onBindViewHolder(z10 z10, int i) {
        z10 z102 = z10;
        long itemId = z102.getItemId();
        int id = ((FrameLayout) z102.itemView).getId();
        Long h2 = h(id);
        if (!(h2 == null || h2.longValue() == itemId)) {
            j(h2.longValue());
            this.e.l(h2.longValue());
        }
        this.e.k(itemId, Integer.valueOf(id));
        long j = (long) i;
        if (!this.c.e(j)) {
            Fragment e2 = e(i);
            e2.setInitialSavedState(this.d.g(j));
            this.c.k(j, e2);
        }
        FrameLayout frameLayout = (FrameLayout) z102.itemView;
        AtomicInteger atomicInteger = co.a;
        if (co.f.b(frameLayout)) {
            if (frameLayout.getParent() == null) {
                frameLayout.addOnLayoutChangeListener(new u10(this, frameLayout, z102));
            } else {
                throw new IllegalStateException("Design assumption violated.");
            }
        }
        f();
    }

    /* Return type fixed from 'androidx.recyclerview.widget.RecyclerView$b0' to match base method */
    @Override // androidx.recyclerview.widget.RecyclerView.e
    public z10 onCreateViewHolder(ViewGroup viewGroup, int i) {
        int i2 = z10.a;
        FrameLayout frameLayout = new FrameLayout(viewGroup.getContext());
        frameLayout.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        AtomicInteger atomicInteger = co.a;
        frameLayout.setId(co.d.a());
        frameLayout.setSaveEnabled(false);
        return new z10(frameLayout);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.e
    public void onDetachedFromRecyclerView(RecyclerView recyclerView) {
        b bVar = this.f;
        ViewPager2 a2 = bVar.a(recyclerView);
        a2.i.a.remove(bVar.a);
        FragmentStateAdapter.this.unregisterAdapterDataObserver(bVar.b);
        FragmentStateAdapter.this.a.b(bVar.c);
        bVar.d = null;
        this.f = null;
    }

    /* JADX DEBUG: Method arguments types fixed to match base method, original types: [androidx.recyclerview.widget.RecyclerView$b0] */
    @Override // androidx.recyclerview.widget.RecyclerView.e
    public /* bridge */ /* synthetic */ boolean onFailedToRecycleView(z10 z10) {
        return true;
    }

    /* JADX DEBUG: Method arguments types fixed to match base method, original types: [androidx.recyclerview.widget.RecyclerView$b0] */
    @Override // androidx.recyclerview.widget.RecyclerView.e
    public void onViewAttachedToWindow(z10 z10) {
        i(z10);
        f();
    }

    /* JADX DEBUG: Method arguments types fixed to match base method, original types: [androidx.recyclerview.widget.RecyclerView$b0] */
    @Override // androidx.recyclerview.widget.RecyclerView.e
    public void onViewRecycled(z10 z10) {
        Long h2 = h(((FrameLayout) z10.itemView).getId());
        if (h2 != null) {
            j(h2.longValue());
            this.e.l(h2.longValue());
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.e
    public final void setHasStableIds(boolean z) {
        throw new UnsupportedOperationException("Stable Ids are required for the adapter to function properly, and the adapter takes care of setting the flag.");
    }

    public FragmentStateAdapter(iq iqVar, sr srVar) {
        this.c = new qg<>(10);
        this.d = new qg<>(10);
        this.e = new qg<>(10);
        this.g = false;
        this.h = false;
        this.b = iqVar;
        this.a = srVar;
        super.setHasStableIds(true);
    }
}
