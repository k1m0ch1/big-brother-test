package androidx.viewpager2.adapter;

import androidx.viewpager2.adapter.FragmentStateAdapter;
import defpackage.sr;

public class FragmentStateAdapter$FragmentMaxLifecycleEnforcer$3 implements wr {
    public final /* synthetic */ FragmentStateAdapter.b g;

    public FragmentStateAdapter$FragmentMaxLifecycleEnforcer$3(FragmentStateAdapter.b bVar) {
        this.g = bVar;
    }

    @Override // defpackage.wr
    public void c(yr yrVar, sr.a aVar) {
        this.g.b(false);
    }
}
