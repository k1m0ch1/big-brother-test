package androidx.viewpager2.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import defpackage.co;
import defpackage.g20;
import defpackage.lo;
import defpackage.no;
import java.util.ArrayList;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public final class ViewPager2 extends ViewGroup {
    public final Rect g = new Rect();
    public final Rect h = new Rect();
    public d20 i = new d20(3);
    public int j;
    public boolean k = false;
    public RecyclerView.g l = new a();
    public LinearLayoutManager m;
    public int n = -1;
    public Parcelable o;
    public RecyclerView p;
    public ry q;
    public g20 r;
    public d20 s;
    public e20 t;
    public f20 u;
    public RecyclerView.j v = null;
    public boolean w = false;
    public boolean x = true;
    public int y = -1;
    public b z = new f();

    public class a extends c {
        public a() {
            super(null);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        public void a() {
            ViewPager2 viewPager2 = ViewPager2.this;
            viewPager2.k = true;
            viewPager2.r.l = true;
        }
    }

    public abstract class b {
        public b(ViewPager2 viewPager2, a aVar) {
        }

        public abstract void a(d20 d20, RecyclerView recyclerView);

        public abstract void b();
    }

    public static abstract class c extends RecyclerView.g {
        public c(a aVar) {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        public final void b(int i, int i2) {
            a();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        public final void c(int i, int i2, Object obj) {
            a();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        public final void d(int i, int i2) {
            a();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        public final void e(int i, int i2, int i3) {
            a();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        public final void f(int i, int i2) {
            a();
        }
    }

    public class d extends LinearLayoutManager {
        public d(Context context) {
            super(1, false);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.m
        public boolean C0(RecyclerView.t tVar, RecyclerView.y yVar, int i, Bundle bundle) {
            Objects.requireNonNull(ViewPager2.this.z);
            return super.C0(tVar, yVar, i, bundle);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.m
        public boolean J0(RecyclerView recyclerView, View view, Rect rect, boolean z, boolean z2) {
            return false;
        }

        @Override // androidx.recyclerview.widget.LinearLayoutManager
        public void Z0(RecyclerView.y yVar, int[] iArr) {
            int offscreenPageLimit = ViewPager2.this.getOffscreenPageLimit();
            if (offscreenPageLimit == -1) {
                super.Z0(yVar, iArr);
                return;
            }
            int pageSize = ViewPager2.this.getPageSize() * offscreenPageLimit;
            iArr[0] = pageSize;
            iArr[1] = pageSize;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.m
        public void k0(RecyclerView.t tVar, RecyclerView.y yVar, lo loVar) {
            super.k0(tVar, yVar, loVar);
            Objects.requireNonNull(ViewPager2.this.z);
        }
    }

    public static abstract class e {
        public void a(int i) {
        }

        public void b(int i, float f, int i2) {
        }

        public void c(int i) {
        }
    }

    public class f extends b {
        public final no a = new a();
        public final no b = new b();
        public RecyclerView.g c;

        public class a implements no {
            public a() {
            }

            @Override // defpackage.no
            public boolean a(View view, no.a aVar) {
                f.this.c(((ViewPager2) view).getCurrentItem() + 1);
                return true;
            }
        }

        public class b implements no {
            public b() {
            }

            @Override // defpackage.no
            public boolean a(View view, no.a aVar) {
                f.this.c(((ViewPager2) view).getCurrentItem() - 1);
                return true;
            }
        }

        public class c extends c {
            public c() {
                super(null);
            }

            @Override // androidx.recyclerview.widget.RecyclerView.g
            public void a() {
                f.this.d();
            }
        }

        public f() {
            super(ViewPager2.this, null);
        }

        @Override // androidx.viewpager2.widget.ViewPager2.b
        public void a(d20 d20, RecyclerView recyclerView) {
            AtomicInteger atomicInteger = co.a;
            co.c.s(recyclerView, 2);
            this.c = new c();
            if (co.c.c(ViewPager2.this) == 0) {
                co.c.s(ViewPager2.this, 1);
            }
        }

        @Override // androidx.viewpager2.widget.ViewPager2.b
        public void b() {
            d();
        }

        public void c(int i) {
            ViewPager2 viewPager2 = ViewPager2.this;
            if (viewPager2.x) {
                viewPager2.d(i, true);
            }
        }

        public void d() {
            int itemCount;
            ViewPager2 viewPager2 = ViewPager2.this;
            int i = 16908360;
            co.q(viewPager2, 16908360);
            co.q(viewPager2, 16908361);
            co.q(viewPager2, 16908358);
            co.q(viewPager2, 16908359);
            if (ViewPager2.this.getAdapter() != null && (itemCount = ViewPager2.this.getAdapter().getItemCount()) != 0) {
                ViewPager2 viewPager22 = ViewPager2.this;
                if (viewPager22.x) {
                    if (viewPager22.getOrientation() == 0) {
                        boolean a2 = ViewPager2.this.a();
                        int i2 = a2 ? 16908360 : 16908361;
                        if (a2) {
                            i = 16908361;
                        }
                        if (ViewPager2.this.j < itemCount - 1) {
                            co.s(viewPager2, new lo.a(i2, null), null, this.a);
                        }
                        if (ViewPager2.this.j > 0) {
                            co.s(viewPager2, new lo.a(i, null), null, this.b);
                            return;
                        }
                        return;
                    }
                    if (ViewPager2.this.j < itemCount - 1) {
                        co.s(viewPager2, new lo.a(16908359, null), null, this.a);
                    }
                    if (ViewPager2.this.j > 0) {
                        co.s(viewPager2, new lo.a(16908358, null), null, this.b);
                    }
                }
            }
        }
    }

    public interface g {
        void a(View view, float f);
    }

    public class h extends ry {
        public h() {
        }

        @Override // defpackage.wy, defpackage.ry
        public View c(RecyclerView.m mVar) {
            if (ViewPager2.this.t.a.m) {
                return null;
            }
            return super.c(mVar);
        }
    }

    public class i extends RecyclerView {
        public i(Context context) {
            super(context, null);
        }

        @Override // androidx.recyclerview.widget.RecyclerView
        public CharSequence getAccessibilityClassName() {
            Objects.requireNonNull(ViewPager2.this.z);
            return super.getAccessibilityClassName();
        }

        public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
            super.onInitializeAccessibilityEvent(accessibilityEvent);
            accessibilityEvent.setFromIndex(ViewPager2.this.j);
            accessibilityEvent.setToIndex(ViewPager2.this.j);
            accessibilityEvent.setSource(ViewPager2.this);
            accessibilityEvent.setClassName("androidx.viewpager.widget.ViewPager");
        }

        @Override // androidx.recyclerview.widget.RecyclerView
        public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
            return ViewPager2.this.x && super.onInterceptTouchEvent(motionEvent);
        }

        @Override // androidx.recyclerview.widget.RecyclerView
        @SuppressLint({"ClickableViewAccessibility"})
        public boolean onTouchEvent(MotionEvent motionEvent) {
            return ViewPager2.this.x && super.onTouchEvent(motionEvent);
        }
    }

    public static class k implements Runnable {
        public final int g;
        public final RecyclerView h;

        public k(int i, RecyclerView recyclerView) {
            this.g = i;
            this.h = recyclerView;
        }

        public void run() {
            this.h.n0(this.g);
        }
    }

    /* JADX INFO: finally extract failed */
    public ViewPager2(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        i iVar = new i(context);
        this.p = iVar;
        AtomicInteger atomicInteger = co.a;
        iVar.setId(co.d.a());
        this.p.setDescendantFocusability(131072);
        d dVar = new d(context);
        this.m = dVar;
        this.p.setLayoutManager(dVar);
        this.p.setScrollingTouchSlop(1);
        int[] iArr = t10.a;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr);
        if (Build.VERSION.SDK_INT >= 29) {
            saveAttributeDataForStyleable(context, iArr, attributeSet, obtainStyledAttributes, 0, 0);
        }
        try {
            setOrientation(obtainStyledAttributes.getInt(0, 0));
            obtainStyledAttributes.recycle();
            this.p.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
            RecyclerView recyclerView = this.p;
            j20 j20 = new j20(this);
            if (recyclerView.J == null) {
                recyclerView.J = new ArrayList();
            }
            recyclerView.J.add(j20);
            g20 g20 = new g20(this);
            this.r = g20;
            this.t = new e20(this, g20, this.p);
            h hVar = new h();
            this.q = hVar;
            hVar.a(this.p);
            this.p.h(this.r);
            d20 d20 = new d20(3);
            this.s = d20;
            this.r.a = d20;
            h20 h20 = new h20(this);
            i20 i20 = new i20(this);
            d20.a.add(h20);
            this.s.a.add(i20);
            this.z.a(this.s, this.p);
            d20 d202 = this.s;
            d202.a.add(this.i);
            f20 f20 = new f20(this.m);
            this.u = f20;
            this.s.a.add(f20);
            RecyclerView recyclerView2 = this.p;
            attachViewToParent(recyclerView2, 0, recyclerView2.getLayoutParams());
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    public boolean a() {
        return this.m.J() == 1;
    }

    public final void b() {
        RecyclerView.e adapter;
        if (this.n != -1 && (adapter = getAdapter()) != null) {
            Parcelable parcelable = this.o;
            if (parcelable != null) {
                if (adapter instanceof a20) {
                    ((a20) adapter).b(parcelable);
                }
                this.o = null;
            }
            int max = Math.max(0, Math.min(this.n, adapter.getItemCount() - 1));
            this.j = max;
            this.n = -1;
            this.p.k0(max);
            ((f) this.z).d();
        }
    }

    public void c(int i2, boolean z2) {
        if (!this.t.a.m) {
            d(i2, z2);
            return;
        }
        throw new IllegalStateException("Cannot change current item when ViewPager2 is fake dragging");
    }

    public boolean canScrollHorizontally(int i2) {
        return this.p.canScrollHorizontally(i2);
    }

    public boolean canScrollVertically(int i2) {
        return this.p.canScrollVertically(i2);
    }

    public void d(int i2, boolean z2) {
        RecyclerView.e adapter = getAdapter();
        boolean z3 = false;
        if (adapter == null) {
            if (this.n != -1) {
                this.n = Math.max(i2, 0);
            }
        } else if (adapter.getItemCount() > 0) {
            int min = Math.min(Math.max(i2, 0), adapter.getItemCount() - 1);
            int i3 = this.j;
            if (min == i3) {
                if (this.r.f == 0) {
                    return;
                }
            }
            if (min != i3 || !z2) {
                double d2 = (double) i3;
                this.j = min;
                ((f) this.z).d();
                g20 g20 = this.r;
                if (!(g20.f == 0)) {
                    g20.d();
                    g20.a aVar = g20.g;
                    d2 = ((double) aVar.a) + ((double) aVar.b);
                }
                g20 g202 = this.r;
                g202.e = z2 ? 2 : 3;
                g202.m = false;
                if (g202.i != min) {
                    z3 = true;
                }
                g202.i = min;
                g202.b(2);
                if (z3) {
                    g202.a(min);
                }
                if (!z2) {
                    this.p.k0(min);
                    return;
                }
                double d3 = (double) min;
                if (Math.abs(d3 - d2) > 3.0d) {
                    this.p.k0(d3 > d2 ? min - 3 : min + 3);
                    RecyclerView recyclerView = this.p;
                    recyclerView.post(new k(min, recyclerView));
                    return;
                }
                this.p.n0(min);
            }
        }
    }

    @Override // android.view.View, android.view.ViewGroup
    public void dispatchRestoreInstanceState(SparseArray<Parcelable> sparseArray) {
        Parcelable parcelable = sparseArray.get(getId());
        if (parcelable instanceof j) {
            int i2 = ((j) parcelable).g;
            sparseArray.put(this.p.getId(), sparseArray.get(i2));
            sparseArray.remove(i2);
        }
        super.dispatchRestoreInstanceState(sparseArray);
        b();
    }

    public void e() {
        ry ryVar = this.q;
        if (ryVar != null) {
            View c2 = ryVar.c(this.m);
            if (c2 != null) {
                int Q = this.m.Q(c2);
                if (Q != this.j && getScrollState() == 0) {
                    this.s.c(Q);
                }
                this.k = false;
                return;
            }
            return;
        }
        throw new IllegalStateException("Design assumption violated.");
    }

    public CharSequence getAccessibilityClassName() {
        Objects.requireNonNull(this.z);
        Objects.requireNonNull(this.z);
        return "androidx.viewpager.widget.ViewPager";
    }

    public RecyclerView.e getAdapter() {
        return this.p.getAdapter();
    }

    public int getCurrentItem() {
        return this.j;
    }

    public int getItemDecorationCount() {
        return this.p.getItemDecorationCount();
    }

    public int getOffscreenPageLimit() {
        return this.y;
    }

    public int getOrientation() {
        return this.m.r;
    }

    public int getPageSize() {
        int i2;
        int i3;
        RecyclerView recyclerView = this.p;
        if (getOrientation() == 0) {
            i2 = recyclerView.getWidth() - recyclerView.getPaddingLeft();
            i3 = recyclerView.getPaddingRight();
        } else {
            i2 = recyclerView.getHeight() - recyclerView.getPaddingTop();
            i3 = recyclerView.getPaddingBottom();
        }
        return i2 - i3;
    }

    public int getScrollState() {
        return this.r.f;
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x0054  */
    /* JADX WARNING: Removed duplicated region for block: B:24:? A[RETURN, SYNTHETIC] */
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        int i2;
        int i3;
        RecyclerView.e adapter;
        int itemCount;
        ViewPager2 viewPager2;
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        f fVar = (f) this.z;
        if (ViewPager2.this.getAdapter() == null) {
            i3 = 0;
        } else if (ViewPager2.this.getOrientation() == 1) {
            i3 = ViewPager2.this.getAdapter().getItemCount();
        } else {
            i2 = ViewPager2.this.getAdapter().getItemCount();
            i3 = 0;
            accessibilityNodeInfo.setCollectionInfo((AccessibilityNodeInfo.CollectionInfo) lo.b.a(i3, i2, false, 0).a);
            adapter = ViewPager2.this.getAdapter();
            if (adapter != null && (itemCount = adapter.getItemCount()) != 0) {
                viewPager2 = ViewPager2.this;
                if (!viewPager2.x) {
                    if (viewPager2.j > 0) {
                        accessibilityNodeInfo.addAction(RecyclerView.b0.FLAG_BOUNCED_FROM_HIDDEN_LIST);
                    }
                    if (ViewPager2.this.j < itemCount - 1) {
                        accessibilityNodeInfo.addAction(4096);
                    }
                    accessibilityNodeInfo.setScrollable(true);
                    return;
                }
                return;
            }
            return;
        }
        i2 = 0;
        accessibilityNodeInfo.setCollectionInfo((AccessibilityNodeInfo.CollectionInfo) lo.b.a(i3, i2, false, 0).a);
        adapter = ViewPager2.this.getAdapter();
        if (adapter != null) {
            viewPager2 = ViewPager2.this;
            if (!viewPager2.x) {
            }
        }
    }

    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int measuredWidth = this.p.getMeasuredWidth();
        int measuredHeight = this.p.getMeasuredHeight();
        this.g.left = getPaddingLeft();
        this.g.right = (i4 - i2) - getPaddingRight();
        this.g.top = getPaddingTop();
        this.g.bottom = (i5 - i3) - getPaddingBottom();
        Gravity.apply(8388659, measuredWidth, measuredHeight, this.g, this.h);
        RecyclerView recyclerView = this.p;
        Rect rect = this.h;
        recyclerView.layout(rect.left, rect.top, rect.right, rect.bottom);
        if (this.k) {
            e();
        }
    }

    public void onMeasure(int i2, int i3) {
        measureChild(this.p, i2, i3);
        int measuredWidth = this.p.getMeasuredWidth();
        int measuredHeight = this.p.getMeasuredHeight();
        int measuredState = this.p.getMeasuredState();
        int paddingRight = getPaddingRight() + getPaddingLeft() + measuredWidth;
        int paddingTop = getPaddingTop();
        setMeasuredDimension(ViewGroup.resolveSizeAndState(Math.max(paddingRight, getSuggestedMinimumWidth()), i2, measuredState), ViewGroup.resolveSizeAndState(Math.max(getPaddingBottom() + paddingTop + measuredHeight, getSuggestedMinimumHeight()), i3, measuredState << 16));
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof j)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        j jVar = (j) parcelable;
        super.onRestoreInstanceState(jVar.getSuperState());
        this.n = jVar.h;
        this.o = jVar.i;
    }

    public Parcelable onSaveInstanceState() {
        j jVar = new j(super.onSaveInstanceState());
        jVar.g = this.p.getId();
        int i2 = this.n;
        if (i2 == -1) {
            i2 = this.j;
        }
        jVar.h = i2;
        Parcelable parcelable = this.o;
        if (parcelable != null) {
            jVar.i = parcelable;
        } else {
            RecyclerView.e adapter = this.p.getAdapter();
            if (adapter instanceof a20) {
                jVar.i = ((a20) adapter).a();
            }
        }
        return jVar;
    }

    public void onViewAdded(View view) {
        throw new IllegalStateException(ViewPager2.class.getSimpleName() + " does not support direct child views");
    }

    public boolean performAccessibilityAction(int i2, Bundle bundle) {
        int i3;
        Objects.requireNonNull((f) this.z);
        boolean z2 = false;
        if (!(i2 == 8192 || i2 == 4096)) {
            return super.performAccessibilityAction(i2, bundle);
        }
        f fVar = (f) this.z;
        Objects.requireNonNull(fVar);
        if (i2 == 8192 || i2 == 4096) {
            z2 = true;
        }
        if (z2) {
            if (i2 == 8192) {
                i3 = ViewPager2.this.getCurrentItem() - 1;
            } else {
                i3 = ViewPager2.this.getCurrentItem() + 1;
            }
            fVar.c(i3);
            return true;
        }
        throw new IllegalStateException();
    }

    public void setAdapter(RecyclerView.e eVar) {
        RecyclerView.e adapter = this.p.getAdapter();
        f fVar = (f) this.z;
        Objects.requireNonNull(fVar);
        if (adapter != null) {
            adapter.unregisterAdapterDataObserver(fVar.c);
        }
        if (adapter != null) {
            adapter.unregisterAdapterDataObserver(this.l);
        }
        this.p.setAdapter(eVar);
        this.j = 0;
        b();
        f fVar2 = (f) this.z;
        fVar2.d();
        if (eVar != null) {
            eVar.registerAdapterDataObserver(fVar2.c);
        }
        if (eVar != null) {
            eVar.registerAdapterDataObserver(this.l);
        }
    }

    public void setCurrentItem(int i2) {
        c(i2, true);
    }

    public void setLayoutDirection(int i2) {
        super.setLayoutDirection(i2);
        ((f) this.z).d();
    }

    public void setOffscreenPageLimit(int i2) {
        if (i2 >= 1 || i2 == -1) {
            this.y = i2;
            this.p.requestLayout();
            return;
        }
        throw new IllegalArgumentException("Offscreen page limit must be OFFSCREEN_PAGE_LIMIT_DEFAULT or a number > 0");
    }

    public void setOrientation(int i2) {
        this.m.C1(i2);
        ((f) this.z).d();
    }

    public void setPageTransformer(g gVar) {
        if (gVar != null) {
            if (!this.w) {
                this.v = this.p.getItemAnimator();
                this.w = true;
            }
            this.p.setItemAnimator(null);
        } else if (this.w) {
            this.p.setItemAnimator(this.v);
            this.v = null;
            this.w = false;
        }
        f20 f20 = this.u;
        if (gVar != f20.b) {
            f20.b = gVar;
            if (gVar != null) {
                g20 g20 = this.r;
                g20.d();
                g20.a aVar = g20.g;
                double d2 = ((double) aVar.a) + ((double) aVar.b);
                int i2 = (int) d2;
                float f2 = (float) (d2 - ((double) i2));
                this.u.b(i2, f2, Math.round(((float) getPageSize()) * f2));
            }
        }
    }

    public void setUserInputEnabled(boolean z2) {
        this.x = z2;
        ((f) this.z).d();
    }

    public static class j extends View.BaseSavedState {
        public static final Parcelable.Creator<j> CREATOR = new a();
        public int g;
        public int h;
        public Parcelable i;

        public static class a implements Parcelable.ClassLoaderCreator<j> {
            @Override // android.os.Parcelable.Creator
            public Object createFromParcel(Parcel parcel) {
                return Build.VERSION.SDK_INT >= 24 ? new j(parcel, null) : new j(parcel);
            }

            @Override // android.os.Parcelable.Creator
            public Object[] newArray(int i) {
                return new j[i];
            }

            /* Return type fixed from 'java.lang.Object' to match base method */
            @Override // android.os.Parcelable.ClassLoaderCreator
            public j createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return Build.VERSION.SDK_INT >= 24 ? new j(parcel, classLoader) : new j(parcel);
            }
        }

        public j(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.g = parcel.readInt();
            this.h = parcel.readInt();
            this.i = parcel.readParcelable(classLoader);
        }

        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeInt(this.g);
            parcel.writeInt(this.h);
            parcel.writeParcelable(this.i, i2);
        }

        public j(Parcel parcel) {
            super(parcel);
            this.g = parcel.readInt();
            this.h = parcel.readInt();
            this.i = parcel.readParcelable(null);
        }

        public j(Parcelable parcelable) {
            super(parcelable);
        }
    }
}
