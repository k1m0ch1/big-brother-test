package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import com.telkom.tracencare.R;
import defpackage.co;
import defpackage.k2;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public class ListMenuItemView extends LinearLayout implements k2.a, AbsListView.SelectionBoundsAdjuster {
    public f2 g;
    public ImageView h;
    public RadioButton i;
    public TextView j;
    public CheckBox k;
    public TextView l;
    public ImageView m;
    public ImageView n;
    public LinearLayout o;
    public Drawable p;
    public int q;
    public Context r;
    public boolean s;
    public Drawable t;
    public boolean u;
    public LayoutInflater v;
    public boolean w;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        f4 r2 = f4.r(getContext(), attributeSet, j0.r, R.attr.listMenuViewStyle, 0);
        this.p = r2.g(5);
        this.q = r2.m(1, -1);
        this.s = r2.a(7, false);
        this.r = context;
        this.t = r2.g(8);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{16843049}, R.attr.dropDownListViewStyle, 0);
        this.u = obtainStyledAttributes.hasValue(0);
        r2.b.recycle();
        obtainStyledAttributes.recycle();
    }

    private LayoutInflater getInflater() {
        if (this.v == null) {
            this.v = LayoutInflater.from(getContext());
        }
        return this.v;
    }

    private void setSubMenuArrowVisible(boolean z) {
        ImageView imageView = this.m;
        if (imageView != null) {
            imageView.setVisibility(z ? 0 : 8);
        }
    }

    public final void a() {
        CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, (ViewGroup) this, false);
        this.k = checkBox;
        LinearLayout linearLayout = this.o;
        if (linearLayout != null) {
            linearLayout.addView(checkBox, -1);
        } else {
            addView(checkBox, -1);
        }
    }

    public void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.n;
        if (imageView != null && imageView.getVisibility() == 0) {
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.n.getLayoutParams();
            rect.top = this.n.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
        }
    }

    public final void b() {
        RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, (ViewGroup) this, false);
        this.i = radioButton;
        LinearLayout linearLayout = this.o;
        if (linearLayout != null) {
            linearLayout.addView(radioButton, -1);
        } else {
            addView(radioButton, -1);
        }
    }

    public void c(boolean z) {
        String str;
        int i2 = (!z || !this.g.n()) ? 8 : 0;
        if (i2 == 0) {
            TextView textView = this.l;
            f2 f2Var = this.g;
            char e = f2Var.e();
            if (e == 0) {
                str = "";
            } else {
                Resources resources = f2Var.n.a.getResources();
                StringBuilder sb = new StringBuilder();
                if (ViewConfiguration.get(f2Var.n.a).hasPermanentMenuKey()) {
                    sb.append(resources.getString(R.string.abc_prepend_shortcut_label));
                }
                int i3 = f2Var.n.n() ? f2Var.k : f2Var.i;
                f2.c(sb, i3, 65536, resources.getString(R.string.abc_menu_meta_shortcut_label));
                f2.c(sb, i3, 4096, resources.getString(R.string.abc_menu_ctrl_shortcut_label));
                f2.c(sb, i3, 2, resources.getString(R.string.abc_menu_alt_shortcut_label));
                f2.c(sb, i3, 1, resources.getString(R.string.abc_menu_shift_shortcut_label));
                f2.c(sb, i3, 4, resources.getString(R.string.abc_menu_sym_shortcut_label));
                f2.c(sb, i3, 8, resources.getString(R.string.abc_menu_function_shortcut_label));
                if (e == '\b') {
                    sb.append(resources.getString(R.string.abc_menu_delete_shortcut_label));
                } else if (e == '\n') {
                    sb.append(resources.getString(R.string.abc_menu_enter_shortcut_label));
                } else if (e != ' ') {
                    sb.append(e);
                } else {
                    sb.append(resources.getString(R.string.abc_menu_space_shortcut_label));
                }
                str = sb.toString();
            }
            textView.setText(str);
        }
        if (this.l.getVisibility() != i2) {
            this.l.setVisibility(i2);
        }
    }

    @Override // defpackage.k2.a
    public void d(f2 f2Var, int i2) {
        this.g = f2Var;
        setVisibility(f2Var.isVisible() ? 0 : 8);
        setTitle(f2Var.e);
        setCheckable(f2Var.isCheckable());
        boolean n2 = f2Var.n();
        f2Var.e();
        c(n2);
        setIcon(f2Var.getIcon());
        setEnabled(f2Var.isEnabled());
        setSubMenuArrowVisible(f2Var.hasSubMenu());
        setContentDescription(f2Var.q);
    }

    @Override // defpackage.k2.a
    public f2 getItemData() {
        return this.g;
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        Drawable drawable = this.p;
        AtomicInteger atomicInteger = co.a;
        co.c.q(this, drawable);
        TextView textView = (TextView) findViewById(R.id.title);
        this.j = textView;
        int i2 = this.q;
        if (i2 != -1) {
            textView.setTextAppearance(this.r, i2);
        }
        this.l = (TextView) findViewById(R.id.shortcut);
        ImageView imageView = (ImageView) findViewById(R.id.submenuarrow);
        this.m = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.t);
        }
        this.n = (ImageView) findViewById(R.id.group_divider);
        this.o = (LinearLayout) findViewById(R.id.content);
    }

    public void onMeasure(int i2, int i3) {
        if (this.h != null && this.s) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.h.getLayoutParams();
            int i4 = layoutParams.height;
            if (i4 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i4;
            }
        }
        super.onMeasure(i2, i3);
    }

    public void setCheckable(boolean z) {
        CompoundButton compoundButton;
        CompoundButton compoundButton2;
        if (z || this.i != null || this.k != null) {
            if (this.g.h()) {
                if (this.i == null) {
                    b();
                }
                compoundButton2 = this.i;
                compoundButton = this.k;
            } else {
                if (this.k == null) {
                    a();
                }
                compoundButton2 = this.k;
                compoundButton = this.i;
            }
            if (z) {
                compoundButton2.setChecked(this.g.isChecked());
                if (compoundButton2.getVisibility() != 0) {
                    compoundButton2.setVisibility(0);
                }
                if (compoundButton != null && compoundButton.getVisibility() != 8) {
                    compoundButton.setVisibility(8);
                    return;
                }
                return;
            }
            CheckBox checkBox = this.k;
            if (checkBox != null) {
                checkBox.setVisibility(8);
            }
            RadioButton radioButton = this.i;
            if (radioButton != null) {
                radioButton.setVisibility(8);
            }
        }
    }

    public void setChecked(boolean z) {
        CompoundButton compoundButton;
        if (this.g.h()) {
            if (this.i == null) {
                b();
            }
            compoundButton = this.i;
        } else {
            if (this.k == null) {
                a();
            }
            compoundButton = this.k;
        }
        compoundButton.setChecked(z);
    }

    public void setForceShowIcon(boolean z) {
        this.w = z;
        this.s = z;
    }

    public void setGroupDividerEnabled(boolean z) {
        ImageView imageView = this.n;
        if (imageView != null) {
            imageView.setVisibility((this.u || !z) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        Objects.requireNonNull(this.g.n);
        boolean z = this.w;
        if (z || this.s) {
            ImageView imageView = this.h;
            if (imageView != null || drawable != null || this.s) {
                if (imageView == null) {
                    ImageView imageView2 = (ImageView) getInflater().inflate(R.layout.abc_list_menu_item_icon, (ViewGroup) this, false);
                    this.h = imageView2;
                    LinearLayout linearLayout = this.o;
                    if (linearLayout != null) {
                        linearLayout.addView(imageView2, 0);
                    } else {
                        addView(imageView2, 0);
                    }
                }
                if (drawable != null || this.s) {
                    ImageView imageView3 = this.h;
                    if (!z) {
                        drawable = null;
                    }
                    imageView3.setImageDrawable(drawable);
                    if (this.h.getVisibility() != 0) {
                        this.h.setVisibility(0);
                        return;
                    }
                    return;
                }
                this.h.setVisibility(8);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (charSequence != null) {
            this.j.setText(charSequence);
            if (this.j.getVisibility() != 0) {
                this.j.setVisibility(0);
            }
        } else if (this.j.getVisibility() != 8) {
            this.j.setVisibility(8);
        }
    }
}
