package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.AppCompatTextView;
import defpackage.d2;
import defpackage.k2;
import defpackage.s2;

public class ActionMenuItemView extends AppCompatTextView implements k2.a, View.OnClickListener, ActionMenuView.a {
    public f2 g;
    public CharSequence h;
    public Drawable i;
    public d2.b j;
    public p3 k;
    public b l;
    public boolean m = e();
    public boolean n;
    public int o;
    public int p;
    public int q;

    public class a extends p3 {
        public a() {
            super(ActionMenuItemView.this);
        }

        @Override // defpackage.p3
        public m2 b() {
            s2.a aVar;
            b bVar = ActionMenuItemView.this.l;
            if (bVar == null || (aVar = s2.this.B) == null) {
                return null;
            }
            return aVar.a();
        }

        @Override // defpackage.p3
        public boolean c() {
            m2 b;
            ActionMenuItemView actionMenuItemView = ActionMenuItemView.this;
            d2.b bVar = actionMenuItemView.j;
            if (bVar == null || !bVar.a(actionMenuItemView.g) || (b = b()) == null || !b.d()) {
                return false;
            }
            return true;
        }
    }

    public static abstract class b {
    }

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        Resources resources = context.getResources();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j0.c, 0, 0);
        this.o = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        obtainStyledAttributes.recycle();
        this.q = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.p = -1;
        setSaveEnabled(false);
    }

    @Override // androidx.appcompat.widget.ActionMenuView.a
    public boolean a() {
        return c();
    }

    @Override // androidx.appcompat.widget.ActionMenuView.a
    public boolean b() {
        return c() && this.g.getIcon() == null;
    }

    public boolean c() {
        return !TextUtils.isEmpty(getText());
    }

    @Override // defpackage.k2.a
    public void d(f2 f2Var, int i2) {
        this.g = f2Var;
        setIcon(f2Var.getIcon());
        setTitle(f2Var.getTitleCondensed());
        setId(f2Var.a);
        setVisibility(f2Var.isVisible() ? 0 : 8);
        setEnabled(f2Var.isEnabled());
        if (f2Var.hasSubMenu() && this.k == null) {
            this.k = new a();
        }
    }

    public final boolean e() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i2 = configuration.screenWidthDp;
        return i2 >= 480 || (i2 >= 640 && configuration.screenHeightDp >= 480) || configuration.orientation == 2;
    }

    public final void f() {
        CharSequence charSequence;
        boolean z = true;
        boolean z2 = !TextUtils.isEmpty(this.h);
        if (this.i != null) {
            if (!((this.g.y & 4) == 4) || (!this.m && !this.n)) {
                z = false;
            }
        }
        boolean z3 = z2 & z;
        CharSequence charSequence2 = null;
        setText(z3 ? this.h : null);
        CharSequence charSequence3 = this.g.q;
        if (TextUtils.isEmpty(charSequence3)) {
            if (z3) {
                charSequence = null;
            } else {
                charSequence = this.g.e;
            }
            setContentDescription(charSequence);
        } else {
            setContentDescription(charSequence3);
        }
        CharSequence charSequence4 = this.g.r;
        if (TextUtils.isEmpty(charSequence4)) {
            if (!z3) {
                charSequence2 = this.g.e;
            }
            i0.m(this, charSequence2);
            return;
        }
        i0.m(this, charSequence4);
    }

    @Override // defpackage.k2.a
    public f2 getItemData() {
        return this.g;
    }

    public void onClick(View view) {
        d2.b bVar = this.j;
        if (bVar != null) {
            bVar.a(this.g);
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.m = e();
        f();
    }

    @Override // androidx.appcompat.widget.AppCompatTextView
    public void onMeasure(int i2, int i3) {
        int i4;
        int i5;
        boolean c = c();
        if (c && (i5 = this.p) >= 0) {
            super.setPadding(i5, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i2, i3);
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        int measuredWidth = getMeasuredWidth();
        if (mode == Integer.MIN_VALUE) {
            i4 = Math.min(size, this.o);
        } else {
            i4 = this.o;
        }
        if (mode != 1073741824 && this.o > 0 && measuredWidth < i4) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(i4, 1073741824), i3);
        }
        if (!c && this.i != null) {
            super.setPadding((getMeasuredWidth() - this.i.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState(null);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        p3 p3Var;
        if (!this.g.hasSubMenu() || (p3Var = this.k) == null || !p3Var.onTouch(this, motionEvent)) {
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    public void setCheckable(boolean z) {
    }

    public void setChecked(boolean z) {
    }

    public void setExpandedFormat(boolean z) {
        if (this.n != z) {
            this.n = z;
            f2 f2Var = this.g;
            if (f2Var != null) {
                f2Var.n.p();
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.i = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            int i2 = this.q;
            if (intrinsicWidth > i2) {
                intrinsicHeight = (int) (((float) intrinsicHeight) * (((float) i2) / ((float) intrinsicWidth)));
                intrinsicWidth = i2;
            }
            if (intrinsicHeight > i2) {
                intrinsicWidth = (int) (((float) intrinsicWidth) * (((float) i2) / ((float) intrinsicHeight)));
            } else {
                i2 = intrinsicHeight;
            }
            drawable.setBounds(0, 0, intrinsicWidth, i2);
        }
        setCompoundDrawables(drawable, null, null, null);
        f();
    }

    public void setItemInvoker(d2.b bVar) {
        this.j = bVar;
    }

    public void setPadding(int i2, int i3, int i4, int i5) {
        this.p = i2;
        super.setPadding(i2, i3, i4, i5);
    }

    public void setPopupCallback(b bVar) {
        this.l = bVar;
    }

    public void setTitle(CharSequence charSequence) {
        this.h = charSequence;
        f();
    }
}
