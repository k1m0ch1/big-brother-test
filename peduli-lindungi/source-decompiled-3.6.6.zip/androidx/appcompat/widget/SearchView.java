package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.telkom.tracencare.R;
import defpackage.co;
import java.lang.reflect.Method;
import java.util.Objects;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class SearchView extends q3 implements q1 {
    public static final n w0 = (Build.VERSION.SDK_INT < 29 ? new n() : null);
    public final ImageView A;
    public final ImageView B;
    public final ImageView C;
    public final View D;
    public p E;
    public Rect F;
    public Rect G;
    public int[] H;
    public int[] I;
    public final ImageView J;
    public final Drawable K;
    public final int L;
    public final int M;
    public final Intent N;
    public final Intent O;
    public final CharSequence P;
    public l Q;
    public k R;
    public View.OnFocusChangeListener S;
    public m T;
    public View.OnClickListener U;
    public boolean V;
    public boolean W;
    public ap a0;
    public boolean b0;
    public CharSequence c0;
    public boolean d0;
    public boolean e0;
    public int f0;
    public boolean g0;
    public CharSequence h0;
    public CharSequence i0;
    public boolean j0;
    public int k0;
    public SearchableInfo l0;
    public Bundle m0;
    public final Runnable n0;
    public Runnable o0;
    public final WeakHashMap<String, Drawable.ConstantState> p0;
    public final View.OnClickListener q0;
    public View.OnKeyListener r0;
    public final TextView.OnEditorActionListener s0;
    public final AdapterView.OnItemClickListener t0;
    public final AdapterView.OnItemSelectedListener u0;
    public final SearchAutoComplete v;
    public TextWatcher v0;
    public final View w;
    public final View x;
    public final View y;
    public final ImageView z;

    public static class SearchAutoComplete extends t2 {
        public int j = getThreshold();
        public SearchView k;
        public boolean l;
        public final Runnable m = new a();

        public class a implements Runnable {
            public a() {
            }

            public void run() {
                SearchAutoComplete searchAutoComplete = SearchAutoComplete.this;
                if (searchAutoComplete.l) {
                    ((InputMethodManager) searchAutoComplete.getContext().getSystemService("input_method")).showSoftInput(searchAutoComplete, 0);
                    searchAutoComplete.l = false;
                }
            }
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet) {
            super(context, attributeSet, R.attr.autoCompleteTextViewStyle);
        }

        private int getSearchViewTextMinWidthDp() {
            Configuration configuration = getResources().getConfiguration();
            int i = configuration.screenWidthDp;
            int i2 = configuration.screenHeightDp;
            if (i >= 960 && i2 >= 720 && configuration.orientation == 2) {
                return RecyclerView.b0.FLAG_TMP_DETACHED;
            }
            if (i < 600) {
                return (i < 640 || i2 < 480) ? 160 : 192;
            }
            return 192;
        }

        public void a() {
            if (Build.VERSION.SDK_INT >= 29) {
                setInputMethodMode(1);
                if (enoughToFilter()) {
                    showDropDown();
                    return;
                }
                return;
            }
            n nVar = SearchView.w0;
            Objects.requireNonNull(nVar);
            n.a();
            Method method = nVar.c;
            if (method != null) {
                try {
                    method.invoke(this, Boolean.TRUE);
                } catch (Exception unused) {
                }
            }
        }

        public boolean enoughToFilter() {
            return this.j <= 0 || super.enoughToFilter();
        }

        @Override // defpackage.t2
        public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
            InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
            if (this.l) {
                removeCallbacks(this.m);
                post(this.m);
            }
            return onCreateInputConnection;
        }

        public void onFinishInflate() {
            super.onFinishInflate();
            setMinWidth((int) TypedValue.applyDimension(1, (float) getSearchViewTextMinWidthDp(), getResources().getDisplayMetrics()));
        }

        public void onFocusChanged(boolean z, int i, Rect rect) {
            super.onFocusChanged(z, i, rect);
            SearchView searchView = this.k;
            searchView.G(searchView.W);
            searchView.post(searchView.n0);
            if (searchView.v.hasFocus()) {
                searchView.s();
            }
        }

        public boolean onKeyPreIme(int i, KeyEvent keyEvent) {
            if (i == 4) {
                if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                    KeyEvent.DispatcherState keyDispatcherState = getKeyDispatcherState();
                    if (keyDispatcherState != null) {
                        keyDispatcherState.startTracking(keyEvent, this);
                    }
                    return true;
                } else if (keyEvent.getAction() == 1) {
                    KeyEvent.DispatcherState keyDispatcherState2 = getKeyDispatcherState();
                    if (keyDispatcherState2 != null) {
                        keyDispatcherState2.handleUpEvent(keyEvent);
                    }
                    if (keyEvent.isTracking() && !keyEvent.isCanceled()) {
                        this.k.clearFocus();
                        setImeVisibility(false);
                        return true;
                    }
                }
            }
            return super.onKeyPreIme(i, keyEvent);
        }

        public void onWindowFocusChanged(boolean z) {
            super.onWindowFocusChanged(z);
            if (z && this.k.hasFocus() && getVisibility() == 0) {
                boolean z2 = true;
                this.l = true;
                Context context = getContext();
                n nVar = SearchView.w0;
                if (context.getResources().getConfiguration().orientation != 2) {
                    z2 = false;
                }
                if (z2) {
                    a();
                }
            }
        }

        public void performCompletion() {
        }

        public void replaceText(CharSequence charSequence) {
        }

        public void setImeVisibility(boolean z) {
            InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");
            if (!z) {
                this.l = false;
                removeCallbacks(this.m);
                inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
            } else if (inputMethodManager.isActive(this)) {
                this.l = false;
                removeCallbacks(this.m);
                inputMethodManager.showSoftInput(this, 0);
            } else {
                this.l = true;
            }
        }

        public void setSearchView(SearchView searchView) {
            this.k = searchView;
        }

        public void setThreshold(int i) {
            super.setThreshold(i);
            this.j = i;
        }
    }

    public class a implements TextWatcher {
        public a() {
        }

        public void afterTextChanged(Editable editable) {
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            SearchView searchView = SearchView.this;
            Editable text = searchView.v.getText();
            searchView.i0 = text;
            boolean z = !TextUtils.isEmpty(text);
            searchView.F(z);
            searchView.H(!z);
            searchView.B();
            searchView.E();
            if (searchView.Q != null && !TextUtils.equals(charSequence, searchView.h0)) {
                searchView.Q.a(charSequence.toString());
            }
            searchView.h0 = charSequence.toString();
        }
    }

    public class b implements Runnable {
        public b() {
        }

        public void run() {
            SearchView.this.C();
        }
    }

    public class c implements Runnable {
        public c() {
        }

        public void run() {
            ap apVar = SearchView.this.a0;
            if (apVar instanceof z3) {
                apVar.b(null);
            }
        }
    }

    public class d implements View.OnFocusChangeListener {
        public d() {
        }

        public void onFocusChange(View view, boolean z) {
            SearchView searchView = SearchView.this;
            View.OnFocusChangeListener onFocusChangeListener = searchView.S;
            if (onFocusChangeListener != null) {
                onFocusChangeListener.onFocusChange(searchView, z);
            }
        }
    }

    public class e implements View.OnLayoutChangeListener {
        public e() {
        }

        public void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
            int i9;
            int i10;
            SearchView searchView = SearchView.this;
            if (searchView.D.getWidth() > 1) {
                Resources resources = searchView.getContext().getResources();
                int paddingLeft = searchView.x.getPaddingLeft();
                Rect rect = new Rect();
                boolean b = l4.b(searchView);
                if (searchView.V) {
                    i9 = resources.getDimensionPixelSize(R.dimen.abc_dropdownitem_text_padding_left) + resources.getDimensionPixelSize(R.dimen.abc_dropdownitem_icon_width);
                } else {
                    i9 = 0;
                }
                searchView.v.getDropDownBackground().getPadding(rect);
                if (b) {
                    i10 = -rect.left;
                } else {
                    i10 = paddingLeft - (rect.left + i9);
                }
                searchView.v.setDropDownHorizontalOffset(i10);
                searchView.v.setDropDownWidth((((searchView.D.getWidth() + rect.left) + rect.right) + i9) - paddingLeft);
            }
        }
    }

    public class f implements View.OnClickListener {
        public f() {
        }

        public void onClick(View view) {
            String str;
            SearchView searchView = SearchView.this;
            if (view == searchView.z) {
                searchView.y();
            } else if (view == searchView.B) {
                searchView.u();
            } else if (view == searchView.A) {
                searchView.z();
            } else if (view == searchView.C) {
                SearchableInfo searchableInfo = searchView.l0;
                if (searchableInfo != null) {
                    try {
                        if (searchableInfo.getVoiceSearchLaunchWebSearch()) {
                            Intent intent = new Intent(searchView.N);
                            ComponentName searchActivity = searchableInfo.getSearchActivity();
                            if (searchActivity == null) {
                                str = null;
                            } else {
                                str = searchActivity.flattenToShortString();
                            }
                            intent.putExtra("calling_package", str);
                            searchView.getContext().startActivity(intent);
                        } else if (searchableInfo.getVoiceSearchLaunchRecognizer()) {
                            searchView.getContext().startActivity(searchView.r(searchView.O, searchableInfo));
                        }
                    } catch (ActivityNotFoundException unused) {
                        Log.w("SearchView", "Could not find voice search activity");
                    }
                }
            } else if (view == searchView.v) {
                searchView.s();
            }
        }
    }

    public class g implements View.OnKeyListener {
        public g() {
        }

        public boolean onKey(View view, int i, KeyEvent keyEvent) {
            SearchView searchView = SearchView.this;
            if (searchView.l0 == null) {
                return false;
            }
            if (searchView.v.isPopupShowing() && SearchView.this.v.getListSelection() != -1) {
                return SearchView.this.A(i, keyEvent);
            }
            if ((TextUtils.getTrimmedLength(SearchView.this.v.getText()) == 0) || !keyEvent.hasNoModifiers() || keyEvent.getAction() != 1 || i != 66) {
                return false;
            }
            view.cancelLongPress();
            SearchView searchView2 = SearchView.this;
            searchView2.t(0, null, searchView2.v.getText().toString());
            return true;
        }
    }

    public class h implements TextView.OnEditorActionListener {
        public h() {
        }

        public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
            SearchView.this.z();
            return true;
        }
    }

    public class i implements AdapterView.OnItemClickListener {
        public i() {
        }

        @Override // android.widget.AdapterView.OnItemClickListener
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
            SearchView.this.v(i);
        }
    }

    public class j implements AdapterView.OnItemSelectedListener {
        public j() {
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
            SearchView.this.w(i);
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    public interface k {
        boolean a();
    }

    public interface l {
        boolean a(String str);

        boolean b(String str);
    }

    public interface m {
        boolean a(int i);

        boolean b(int i);
    }

    public static class n {
        public Method a = null;
        public Method b = null;
        public Method c = null;

        @SuppressLint({"DiscouragedPrivateApi", "SoonBlockedPrivateApi"})
        public n() {
            a();
            try {
                Method declaredMethod = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", new Class[0]);
                this.a = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException unused) {
            }
            try {
                Method declaredMethod2 = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", new Class[0]);
                this.b = declaredMethod2;
                declaredMethod2.setAccessible(true);
            } catch (NoSuchMethodException unused2) {
            }
            try {
                Method method = AutoCompleteTextView.class.getMethod("ensureImeVisible", Boolean.TYPE);
                this.c = method;
                method.setAccessible(true);
            } catch (NoSuchMethodException unused3) {
            }
        }

        public static void a() {
            if (Build.VERSION.SDK_INT >= 29) {
                throw new UnsupportedClassVersionError("This function can only be used for API Level < 29.");
            }
        }
    }

    public static class o extends dp {
        public static final Parcelable.Creator<o> CREATOR = new a();
        public boolean i;

        public class a implements Parcelable.ClassLoaderCreator<o> {
            /* Return type fixed from 'java.lang.Object' to match base method */
            @Override // android.os.Parcelable.ClassLoaderCreator
            public o createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new o(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            public Object[] newArray(int i) {
                return new o[i];
            }

            @Override // android.os.Parcelable.Creator
            public Object createFromParcel(Parcel parcel) {
                return new o(parcel, null);
            }
        }

        public o(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder J0 = ze0.J0("SearchView.SavedState{");
            J0.append(Integer.toHexString(System.identityHashCode(this)));
            J0.append(" isIconified=");
            J0.append(this.i);
            J0.append("}");
            return J0.toString();
        }

        @Override // defpackage.dp
        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeParcelable(this.g, i2);
            parcel.writeValue(Boolean.valueOf(this.i));
        }

        public o(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.i = ((Boolean) parcel.readValue(null)).booleanValue();
        }
    }

    public static class p extends TouchDelegate {
        public final View a;
        public final Rect b = new Rect();
        public final Rect c = new Rect();
        public final Rect d = new Rect();
        public final int e;
        public boolean f;

        public p(Rect rect, Rect rect2, View view) {
            super(rect, view);
            this.e = ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
            a(rect, rect2);
            this.a = view;
        }

        public void a(Rect rect, Rect rect2) {
            this.b.set(rect);
            this.d.set(rect);
            Rect rect3 = this.d;
            int i = this.e;
            rect3.inset(-i, -i);
            this.c.set(rect2);
        }

        /* JADX WARNING: Removed duplicated region for block: B:19:0x0041  */
        /* JADX WARNING: Removed duplicated region for block: B:26:? A[RETURN, SYNTHETIC] */
        public boolean onTouchEvent(MotionEvent motionEvent) {
            boolean z;
            boolean z2;
            int x = (int) motionEvent.getX();
            int y = (int) motionEvent.getY();
            int action = motionEvent.getAction();
            boolean z3 = true;
            if (action != 0) {
                if (action == 1 || action == 2) {
                    z2 = this.f;
                    if (z2 && !this.d.contains(x, y)) {
                        z3 = z2;
                        z = false;
                        if (z3) {
                            return false;
                        }
                        if (!z || this.c.contains(x, y)) {
                            Rect rect = this.c;
                            motionEvent.setLocation((float) (x - rect.left), (float) (y - rect.top));
                        } else {
                            motionEvent.setLocation((float) (this.a.getWidth() / 2), (float) (this.a.getHeight() / 2));
                        }
                        return this.a.dispatchTouchEvent(motionEvent);
                    }
                } else {
                    if (action == 3) {
                        z2 = this.f;
                        this.f = false;
                    }
                    z = true;
                    z3 = false;
                    if (z3) {
                    }
                }
                z3 = z2;
            } else {
                if (this.b.contains(x, y)) {
                    this.f = true;
                }
                z = true;
                z3 = false;
                if (z3) {
                }
            }
            z = true;
            if (z3) {
            }
        }
    }

    public SearchView(Context context) {
        this(context, null);
    }

    private int getPreferredHeight() {
        return getContext().getResources().getDimensionPixelSize(R.dimen.abc_search_view_preferred_height);
    }

    private int getPreferredWidth() {
        return getContext().getResources().getDimensionPixelSize(R.dimen.abc_search_view_preferred_width);
    }

    private void setQuery(CharSequence charSequence) {
        this.v.setText(charSequence);
        this.v.setSelection(TextUtils.isEmpty(charSequence) ? 0 : charSequence.length());
    }

    public boolean A(int i2, KeyEvent keyEvent) {
        int i3;
        if (this.l0 != null && this.a0 != null && keyEvent.getAction() == 0 && keyEvent.hasNoModifiers()) {
            if (i2 == 66 || i2 == 84 || i2 == 61) {
                return v(this.v.getListSelection());
            }
            if (i2 == 21 || i2 == 22) {
                if (i2 == 21) {
                    i3 = 0;
                } else {
                    i3 = this.v.length();
                }
                this.v.setSelection(i3);
                this.v.setListSelection(0);
                this.v.clearListSelection();
                this.v.a();
                return true;
            } else if (i2 != 19 || this.v.getListSelection() == 0) {
                return false;
            }
        }
        return false;
    }

    public final void B() {
        boolean z2 = true;
        boolean z3 = !TextUtils.isEmpty(this.v.getText());
        int i2 = 0;
        if (!z3 && (!this.V || this.j0)) {
            z2 = false;
        }
        ImageView imageView = this.B;
        if (!z2) {
            i2 = 8;
        }
        imageView.setVisibility(i2);
        Drawable drawable = this.B.getDrawable();
        if (drawable != null) {
            drawable.setState(z3 ? ViewGroup.ENABLED_STATE_SET : ViewGroup.EMPTY_STATE_SET);
        }
    }

    public void C() {
        int[] iArr = this.v.hasFocus() ? ViewGroup.FOCUSED_STATE_SET : ViewGroup.EMPTY_STATE_SET;
        Drawable background = this.x.getBackground();
        if (background != null) {
            background.setState(iArr);
        }
        Drawable background2 = this.y.getBackground();
        if (background2 != null) {
            background2.setState(iArr);
        }
        invalidate();
    }

    public final void D() {
        SpannableStringBuilder queryHint = getQueryHint();
        SearchAutoComplete searchAutoComplete = this.v;
        if (queryHint == null) {
            queryHint = "";
        }
        if (this.V && this.K != null) {
            int textSize = (int) (((double) searchAutoComplete.getTextSize()) * 1.25d);
            this.K.setBounds(0, 0, textSize, textSize);
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder("   ");
            spannableStringBuilder.setSpan(new ImageSpan(this.K), 1, 2, 33);
            spannableStringBuilder.append(queryHint);
            queryHint = spannableStringBuilder;
        }
        searchAutoComplete.setHint(queryHint);
    }

    public final void E() {
        int i2 = 0;
        if (!((this.b0 || this.g0) && !this.W) || !(this.A.getVisibility() == 0 || this.C.getVisibility() == 0)) {
            i2 = 8;
        }
        this.y.setVisibility(i2);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x001e, code lost:
        if (r2.g0 == false) goto L_0x0023;
     */
    public final void F(boolean z2) {
        boolean z3 = this.b0;
        int i2 = 0;
        if (z3) {
            if ((z3 || this.g0) && !this.W) {
                if (hasFocus()) {
                    if (!z2) {
                    }
                    this.A.setVisibility(i2);
                }
            }
        }
        i2 = 8;
        this.A.setVisibility(i2);
    }

    public final void G(boolean z2) {
        this.W = z2;
        int i2 = 0;
        int i3 = z2 ? 0 : 8;
        boolean z3 = !TextUtils.isEmpty(this.v.getText());
        this.z.setVisibility(i3);
        F(z3);
        this.w.setVisibility(z2 ? 8 : 0);
        if (this.J.getDrawable() == null || this.V) {
            i2 = 8;
        }
        this.J.setVisibility(i2);
        B();
        H(!z3);
        E();
    }

    public final void H(boolean z2) {
        int i2 = 8;
        if (this.g0 && !this.W && z2) {
            this.A.setVisibility(8);
            i2 = 0;
        }
        this.C.setVisibility(i2);
    }

    @Override // defpackage.q1
    public void c() {
        if (!this.j0) {
            this.j0 = true;
            int imeOptions = this.v.getImeOptions();
            this.k0 = imeOptions;
            this.v.setImeOptions(imeOptions | 33554432);
            this.v.setText("");
            setIconified(false);
        }
    }

    public void clearFocus() {
        this.e0 = true;
        super.clearFocus();
        this.v.clearFocus();
        this.v.setImeVisibility(false);
        this.e0 = false;
    }

    @Override // defpackage.q1
    public void e() {
        this.v.setText("");
        SearchAutoComplete searchAutoComplete = this.v;
        searchAutoComplete.setSelection(searchAutoComplete.length());
        this.i0 = "";
        clearFocus();
        G(true);
        this.v.setImeOptions(this.k0);
        this.j0 = false;
    }

    public int getImeOptions() {
        return this.v.getImeOptions();
    }

    public int getInputType() {
        return this.v.getInputType();
    }

    public int getMaxWidth() {
        return this.f0;
    }

    public CharSequence getQuery() {
        return this.v.getText();
    }

    public CharSequence getQueryHint() {
        CharSequence charSequence = this.c0;
        if (charSequence != null) {
            return charSequence;
        }
        SearchableInfo searchableInfo = this.l0;
        if (searchableInfo == null || searchableInfo.getHintId() == 0) {
            return this.P;
        }
        return getContext().getText(this.l0.getHintId());
    }

    public int getSuggestionCommitIconResId() {
        return this.M;
    }

    public int getSuggestionRowLayout() {
        return this.L;
    }

    public ap getSuggestionsAdapter() {
        return this.a0;
    }

    public void onDetachedFromWindow() {
        removeCallbacks(this.n0);
        post(this.o0);
        super.onDetachedFromWindow();
    }

    @Override // defpackage.q3
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        if (z2) {
            SearchAutoComplete searchAutoComplete = this.v;
            Rect rect = this.F;
            searchAutoComplete.getLocationInWindow(this.H);
            getLocationInWindow(this.I);
            int[] iArr = this.H;
            int i6 = iArr[1];
            int[] iArr2 = this.I;
            int i7 = i6 - iArr2[1];
            int i8 = iArr[0] - iArr2[0];
            rect.set(i8, i7, searchAutoComplete.getWidth() + i8, searchAutoComplete.getHeight() + i7);
            Rect rect2 = this.G;
            Rect rect3 = this.F;
            rect2.set(rect3.left, 0, rect3.right, i5 - i3);
            p pVar = this.E;
            if (pVar == null) {
                p pVar2 = new p(this.G, this.F, this.v);
                this.E = pVar2;
                setTouchDelegate(pVar2);
                return;
            }
            pVar.a(this.G, this.F);
        }
    }

    @Override // defpackage.q3
    public void onMeasure(int i2, int i3) {
        int i4;
        if (this.W) {
            super.onMeasure(i2, i3);
            return;
        }
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        if (mode == Integer.MIN_VALUE) {
            int i5 = this.f0;
            size = i5 > 0 ? Math.min(i5, size) : Math.min(getPreferredWidth(), size);
        } else if (mode == 0) {
            size = this.f0;
            if (size <= 0) {
                size = getPreferredWidth();
            }
        } else if (mode == 1073741824 && (i4 = this.f0) > 0) {
            size = Math.min(i4, size);
        }
        int mode2 = View.MeasureSpec.getMode(i3);
        int size2 = View.MeasureSpec.getSize(i3);
        if (mode2 == Integer.MIN_VALUE) {
            size2 = Math.min(getPreferredHeight(), size2);
        } else if (mode2 == 0) {
            size2 = getPreferredHeight();
        }
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(size, 1073741824), View.MeasureSpec.makeMeasureSpec(size2, 1073741824));
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof o)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        o oVar = (o) parcelable;
        super.onRestoreInstanceState(oVar.g);
        G(oVar.i);
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        o oVar = new o(super.onSaveInstanceState());
        oVar.i = this.W;
        return oVar;
    }

    public void onWindowFocusChanged(boolean z2) {
        super.onWindowFocusChanged(z2);
        post(this.n0);
    }

    public final Intent q(String str, Uri uri, String str2, String str3, int i2, String str4) {
        Intent intent = new Intent(str);
        intent.addFlags(268435456);
        if (uri != null) {
            intent.setData(uri);
        }
        intent.putExtra("user_query", this.i0);
        if (str3 != null) {
            intent.putExtra("query", str3);
        }
        if (str2 != null) {
            intent.putExtra("intent_extra_data_key", str2);
        }
        Bundle bundle = this.m0;
        if (bundle != null) {
            intent.putExtra("app_data", bundle);
        }
        if (i2 != 0) {
            intent.putExtra("action_key", i2);
            intent.putExtra("action_msg", str4);
        }
        intent.setComponent(this.l0.getSearchActivity());
        return intent;
    }

    public final Intent r(Intent intent, SearchableInfo searchableInfo) {
        ComponentName searchActivity = searchableInfo.getSearchActivity();
        Intent intent2 = new Intent("android.intent.action.SEARCH");
        intent2.setComponent(searchActivity);
        PendingIntent activity = PendingIntent.getActivity(getContext(), 0, intent2, 1073741824);
        Bundle bundle = new Bundle();
        Bundle bundle2 = this.m0;
        if (bundle2 != null) {
            bundle.putParcelable("app_data", bundle2);
        }
        Intent intent3 = new Intent(intent);
        int i2 = 1;
        Resources resources = getResources();
        String string = searchableInfo.getVoiceLanguageModeId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageModeId()) : "free_form";
        String str = null;
        String string2 = searchableInfo.getVoicePromptTextId() != 0 ? resources.getString(searchableInfo.getVoicePromptTextId()) : null;
        String string3 = searchableInfo.getVoiceLanguageId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageId()) : null;
        if (searchableInfo.getVoiceMaxResults() != 0) {
            i2 = searchableInfo.getVoiceMaxResults();
        }
        intent3.putExtra("android.speech.extra.LANGUAGE_MODEL", string);
        intent3.putExtra("android.speech.extra.PROMPT", string2);
        intent3.putExtra("android.speech.extra.LANGUAGE", string3);
        intent3.putExtra("android.speech.extra.MAX_RESULTS", i2);
        if (searchActivity != null) {
            str = searchActivity.flattenToShortString();
        }
        intent3.putExtra("calling_package", str);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", activity);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle);
        return intent3;
    }

    public boolean requestFocus(int i2, Rect rect) {
        if (this.e0 || !isFocusable()) {
            return false;
        }
        if (this.W) {
            return super.requestFocus(i2, rect);
        }
        boolean requestFocus = this.v.requestFocus(i2, rect);
        if (requestFocus) {
            G(false);
        }
        return requestFocus;
    }

    public void s() {
        if (Build.VERSION.SDK_INT >= 29) {
            this.v.refreshAutoCompleteResults();
            return;
        }
        n nVar = w0;
        SearchAutoComplete searchAutoComplete = this.v;
        Objects.requireNonNull(nVar);
        n.a();
        Method method = nVar.a;
        if (method != null) {
            try {
                method.invoke(searchAutoComplete, new Object[0]);
            } catch (Exception unused) {
            }
        }
        n nVar2 = w0;
        SearchAutoComplete searchAutoComplete2 = this.v;
        Objects.requireNonNull(nVar2);
        n.a();
        Method method2 = nVar2.b;
        if (method2 != null) {
            try {
                method2.invoke(searchAutoComplete2, new Object[0]);
            } catch (Exception unused2) {
            }
        }
    }

    public void setAppSearchData(Bundle bundle) {
        this.m0 = bundle;
    }

    public void setIconified(boolean z2) {
        if (z2) {
            u();
        } else {
            y();
        }
    }

    public void setIconifiedByDefault(boolean z2) {
        if (this.V != z2) {
            this.V = z2;
            G(z2);
            D();
        }
    }

    public void setImeOptions(int i2) {
        this.v.setImeOptions(i2);
    }

    public void setInputType(int i2) {
        this.v.setInputType(i2);
    }

    public void setMaxWidth(int i2) {
        this.f0 = i2;
        requestLayout();
    }

    public void setOnCloseListener(k kVar) {
        this.R = kVar;
    }

    public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener onFocusChangeListener) {
        this.S = onFocusChangeListener;
    }

    public void setOnQueryTextListener(l lVar) {
        this.Q = lVar;
    }

    public void setOnSearchClickListener(View.OnClickListener onClickListener) {
        this.U = onClickListener;
    }

    public void setOnSuggestionListener(m mVar) {
        this.T = mVar;
    }

    public void setQueryHint(CharSequence charSequence) {
        this.c0 = charSequence;
        D();
    }

    public void setQueryRefinementEnabled(boolean z2) {
        this.d0 = z2;
        ap apVar = this.a0;
        if (apVar instanceof z3) {
            ((z3) apVar).w = z2 ? 2 : 1;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:30:0x009c, code lost:
        if (getContext().getPackageManager().resolveActivity(r2, 65536) != null) goto L_0x00a0;
     */
    public void setSearchableInfo(SearchableInfo searchableInfo) {
        this.l0 = searchableInfo;
        boolean z2 = true;
        Intent intent = null;
        if (searchableInfo != null) {
            this.v.setThreshold(searchableInfo.getSuggestThreshold());
            this.v.setImeOptions(this.l0.getImeOptions());
            int inputType = this.l0.getInputType();
            if ((inputType & 15) == 1) {
                inputType &= -65537;
                if (this.l0.getSuggestAuthority() != null) {
                    inputType = inputType | 65536 | 524288;
                }
            }
            this.v.setInputType(inputType);
            ap apVar = this.a0;
            if (apVar != null) {
                apVar.b(null);
            }
            if (this.l0.getSuggestAuthority() != null) {
                z3 z3Var = new z3(getContext(), this, this.l0, this.p0);
                this.a0 = z3Var;
                this.v.setAdapter(z3Var);
                ((z3) this.a0).w = this.d0 ? 2 : 1;
            }
            D();
        }
        SearchableInfo searchableInfo2 = this.l0;
        if (searchableInfo2 != null && searchableInfo2.getVoiceSearchEnabled()) {
            if (this.l0.getVoiceSearchLaunchWebSearch()) {
                intent = this.N;
            } else if (this.l0.getVoiceSearchLaunchRecognizer()) {
                intent = this.O;
            }
            if (intent != null) {
            }
        }
        z2 = false;
        this.g0 = z2;
        if (z2) {
            this.v.setPrivateImeOptions("nm");
        }
        G(this.W);
    }

    public void setSubmitButtonEnabled(boolean z2) {
        this.b0 = z2;
        G(this.W);
    }

    public void setSuggestionsAdapter(ap apVar) {
        this.a0 = apVar;
        this.v.setAdapter(apVar);
    }

    public void t(int i2, String str, String str2) {
        getContext().startActivity(q("android.intent.action.SEARCH", null, null, str2, i2, null));
    }

    public void u() {
        if (!TextUtils.isEmpty(this.v.getText())) {
            this.v.setText("");
            this.v.requestFocus();
            this.v.setImeVisibility(true);
        } else if (this.V) {
            k kVar = this.R;
            if (kVar == null || !kVar.a()) {
                clearFocus();
                G(true);
            }
        }
    }

    public boolean v(int i2) {
        int i3;
        Uri uri;
        String h2;
        m mVar = this.T;
        if (mVar != null && mVar.b(i2)) {
            return false;
        }
        Cursor cursor = this.a0.i;
        if (cursor != null && cursor.moveToPosition(i2)) {
            Intent intent = null;
            try {
                int i4 = z3.E;
                String h3 = z3.h(cursor, cursor.getColumnIndex("suggest_intent_action"));
                if (h3 == null) {
                    h3 = this.l0.getSuggestIntentAction();
                }
                if (h3 == null) {
                    h3 = "android.intent.action.SEARCH";
                }
                String h4 = z3.h(cursor, cursor.getColumnIndex("suggest_intent_data"));
                if (h4 == null) {
                    h4 = this.l0.getSuggestIntentData();
                }
                if (!(h4 == null || (h2 = z3.h(cursor, cursor.getColumnIndex("suggest_intent_data_id"))) == null)) {
                    h4 = h4 + "/" + Uri.encode(h2);
                }
                if (h4 == null) {
                    uri = null;
                } else {
                    uri = Uri.parse(h4);
                }
                intent = q(h3, uri, z3.h(cursor, cursor.getColumnIndex("suggest_intent_extra_data")), z3.h(cursor, cursor.getColumnIndex("suggest_intent_query")), 0, null);
            } catch (RuntimeException e2) {
                try {
                    i3 = cursor.getPosition();
                } catch (RuntimeException unused) {
                    i3 = -1;
                }
                Log.w("SearchView", "Search suggestions cursor at row " + i3 + " returned exception.", e2);
            }
            if (intent != null) {
                try {
                    getContext().startActivity(intent);
                } catch (RuntimeException e3) {
                    Log.e("SearchView", "Failed launch activity: " + intent, e3);
                }
            }
        }
        this.v.setImeVisibility(false);
        this.v.dismissDropDown();
        return true;
    }

    public boolean w(int i2) {
        m mVar = this.T;
        if (mVar != null && mVar.a(i2)) {
            return false;
        }
        Editable text = this.v.getText();
        Cursor cursor = this.a0.i;
        if (cursor == null) {
            return true;
        }
        if (cursor.moveToPosition(i2)) {
            CharSequence c2 = this.a0.c(cursor);
            if (c2 != null) {
                setQuery(c2);
                return true;
            }
            setQuery(text);
            return true;
        }
        setQuery(text);
        return true;
    }

    public void x(CharSequence charSequence) {
        setQuery(charSequence);
    }

    public void y() {
        G(false);
        this.v.requestFocus();
        this.v.setImeVisibility(true);
        View.OnClickListener onClickListener = this.U;
        if (onClickListener != null) {
            onClickListener.onClick(this);
        }
    }

    public void z() {
        Editable text = this.v.getText();
        if (text != null && TextUtils.getTrimmedLength(text) > 0) {
            l lVar = this.Q;
            if (lVar == null || !lVar.b(text.toString())) {
                if (this.l0 != null) {
                    t(0, null, text.toString());
                }
                this.v.setImeVisibility(false);
                this.v.dismissDropDown();
            }
        }
    }

    public SearchView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.searchViewStyle);
    }

    public SearchView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.F = new Rect();
        this.G = new Rect();
        this.H = new int[2];
        this.I = new int[2];
        this.n0 = new b();
        this.o0 = new c();
        this.p0 = new WeakHashMap<>();
        f fVar = new f();
        this.q0 = fVar;
        this.r0 = new g();
        h hVar = new h();
        this.s0 = hVar;
        i iVar = new i();
        this.t0 = iVar;
        j jVar = new j();
        this.u0 = jVar;
        this.v0 = new a();
        f4 f4Var = new f4(context, context.obtainStyledAttributes(attributeSet, j0.u, i2, 0));
        LayoutInflater.from(context).inflate(f4Var.m(9, R.layout.abc_search_view), (ViewGroup) this, true);
        SearchAutoComplete searchAutoComplete = (SearchAutoComplete) findViewById(R.id.search_src_text);
        this.v = searchAutoComplete;
        searchAutoComplete.setSearchView(this);
        this.w = findViewById(R.id.search_edit_frame);
        View findViewById = findViewById(R.id.search_plate);
        this.x = findViewById;
        View findViewById2 = findViewById(R.id.submit_area);
        this.y = findViewById2;
        ImageView imageView = (ImageView) findViewById(R.id.search_button);
        this.z = imageView;
        ImageView imageView2 = (ImageView) findViewById(R.id.search_go_btn);
        this.A = imageView2;
        ImageView imageView3 = (ImageView) findViewById(R.id.search_close_btn);
        this.B = imageView3;
        ImageView imageView4 = (ImageView) findViewById(R.id.search_voice_btn);
        this.C = imageView4;
        ImageView imageView5 = (ImageView) findViewById(R.id.search_mag_icon);
        this.J = imageView5;
        Drawable g2 = f4Var.g(10);
        AtomicInteger atomicInteger = co.a;
        co.c.q(findViewById, g2);
        co.c.q(findViewById2, f4Var.g(14));
        imageView.setImageDrawable(f4Var.g(13));
        imageView2.setImageDrawable(f4Var.g(7));
        imageView3.setImageDrawable(f4Var.g(4));
        imageView4.setImageDrawable(f4Var.g(16));
        imageView5.setImageDrawable(f4Var.g(13));
        this.K = f4Var.g(12);
        i0.m(imageView, getResources().getString(R.string.abc_searchview_description_search));
        this.L = f4Var.m(15, R.layout.abc_search_dropdown_item_icons_2line);
        this.M = f4Var.m(5, 0);
        imageView.setOnClickListener(fVar);
        imageView3.setOnClickListener(fVar);
        imageView2.setOnClickListener(fVar);
        imageView4.setOnClickListener(fVar);
        searchAutoComplete.setOnClickListener(fVar);
        searchAutoComplete.addTextChangedListener(this.v0);
        searchAutoComplete.setOnEditorActionListener(hVar);
        searchAutoComplete.setOnItemClickListener(iVar);
        searchAutoComplete.setOnItemSelectedListener(jVar);
        searchAutoComplete.setOnKeyListener(this.r0);
        searchAutoComplete.setOnFocusChangeListener(new d());
        setIconifiedByDefault(f4Var.a(8, true));
        int f2 = f4Var.f(1, -1);
        if (f2 != -1) {
            setMaxWidth(f2);
        }
        this.P = f4Var.o(6);
        this.c0 = f4Var.o(11);
        int j2 = f4Var.j(3, -1);
        if (j2 != -1) {
            setImeOptions(j2);
        }
        int j3 = f4Var.j(2, -1);
        if (j3 != -1) {
            setInputType(j3);
        }
        setFocusable(f4Var.a(0, true));
        f4Var.b.recycle();
        Intent intent = new Intent("android.speech.action.WEB_SEARCH");
        this.N = intent;
        intent.addFlags(268435456);
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
        Intent intent2 = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        this.O = intent2;
        intent2.addFlags(268435456);
        View findViewById3 = findViewById(searchAutoComplete.getDropDownAnchor());
        this.D = findViewById3;
        if (findViewById3 != null) {
            findViewById3.addOnLayoutChangeListener(new e());
        }
        G(this.V);
        D();
    }
}
