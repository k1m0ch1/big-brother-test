package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Editable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.EditText;
import com.telkom.tracencare.R;

public class AppCompatEditText extends EditText {
    public final u2 g;
    public final i3 h;
    public final h3 i;

    public AppCompatEditText(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.editTextStyle);
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        u2 u2Var = this.g;
        if (u2Var != null) {
            u2Var.a();
        }
        i3 i3Var = this.h;
        if (i3Var != null) {
            i3Var.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        u2 u2Var = this.g;
        if (u2Var != null) {
            return u2Var.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        u2 u2Var = this.g;
        if (u2Var != null) {
            return u2Var.c();
        }
        return null;
    }

    public TextClassifier getTextClassifier() {
        h3 h3Var;
        if (Build.VERSION.SDK_INT >= 28 || (h3Var = this.i) == null) {
            return super.getTextClassifier();
        }
        return h3Var.a();
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        i0.k(onCreateInputConnection, editorInfo, this);
        return onCreateInputConnection;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        u2 u2Var = this.g;
        if (u2Var != null) {
            u2Var.e();
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        u2 u2Var = this.g;
        if (u2Var != null) {
            u2Var.f(i2);
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(ek.t0(this, callback));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        u2 u2Var = this.g;
        if (u2Var != null) {
            u2Var.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        u2 u2Var = this.g;
        if (u2Var != null) {
            u2Var.i(mode);
        }
    }

    public void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        i3 i3Var = this.h;
        if (i3Var != null) {
            i3Var.f(context, i2);
        }
    }

    public void setTextClassifier(TextClassifier textClassifier) {
        h3 h3Var;
        if (Build.VERSION.SDK_INT >= 28 || (h3Var = this.i) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            h3Var.b = textClassifier;
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppCompatEditText(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        c4.a(context);
        a4.a(this, getContext());
        u2 u2Var = new u2(this);
        this.g = u2Var;
        u2Var.d(attributeSet, i2);
        i3 i3Var = new i3(this);
        this.h = i3Var;
        i3Var.e(attributeSet, i2);
        i3Var.b();
        this.i = new h3(this);
    }

    @Override // android.widget.EditText, android.widget.EditText
    public Editable getText() {
        if (Build.VERSION.SDK_INT >= 28) {
            return super.getText();
        }
        return super.getEditableText();
    }
}
