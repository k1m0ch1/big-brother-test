package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.telkom.tracencare.R;
import defpackage.co;
import java.util.concurrent.atomic.AtomicInteger;

public class ActionBarContextView extends q2 {
    public CharSequence o;
    public CharSequence p;
    public View q;
    public View r;
    public LinearLayout s;
    public TextView t;
    public TextView u;
    public int v;
    public int w;
    public boolean x;
    public int y;

    public class a implements View.OnClickListener {
        public final /* synthetic */ p1 g;

        public a(ActionBarContextView actionBarContextView, p1 p1Var) {
            this.g = p1Var;
        }

        public void onClick(View view) {
            this.g.c();
        }
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.actionModeStyle);
        Drawable drawable;
        int resourceId;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j0.d, R.attr.actionModeStyle, 0);
        if (!obtainStyledAttributes.hasValue(0) || (resourceId = obtainStyledAttributes.getResourceId(0, 0)) == 0) {
            drawable = obtainStyledAttributes.getDrawable(0);
        } else {
            drawable = i1.b(context, resourceId);
        }
        AtomicInteger atomicInteger = co.a;
        co.c.q(this, drawable);
        this.v = obtainStyledAttributes.getResourceId(5, 0);
        this.w = obtainStyledAttributes.getResourceId(4, 0);
        this.k = obtainStyledAttributes.getLayoutDimension(3, 0);
        this.y = obtainStyledAttributes.getResourceId(2, R.layout.abc_action_mode_close_item_material);
        obtainStyledAttributes.recycle();
    }

    public void f(p1 p1Var) {
        View view = this.q;
        if (view == null) {
            View inflate = LayoutInflater.from(getContext()).inflate(this.y, (ViewGroup) this, false);
            this.q = inflate;
            addView(inflate);
        } else if (view.getParent() == null) {
            addView(this.q);
        }
        this.q.findViewById(R.id.action_mode_close_button).setOnClickListener(new a(this, p1Var));
        d2 d2Var = (d2) p1Var.e();
        s2 s2Var = this.j;
        if (s2Var != null) {
            s2Var.b();
        }
        s2 s2Var2 = new s2(getContext());
        this.j = s2Var2;
        s2Var2.s = true;
        s2Var2.t = true;
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
        d2Var.b(this.j, this.h);
        s2 s2Var3 = this.j;
        k2 k2Var = s2Var3.n;
        if (k2Var == null) {
            k2 k2Var2 = (k2) s2Var3.j.inflate(s2Var3.l, (ViewGroup) this, false);
            s2Var3.n = k2Var2;
            k2Var2.b(s2Var3.i);
            s2Var3.i(true);
        }
        k2 k2Var3 = s2Var3.n;
        if (k2Var != k2Var3) {
            ((ActionMenuView) k2Var3).setPresenter(s2Var3);
        }
        ActionMenuView actionMenuView = (ActionMenuView) k2Var3;
        this.i = actionMenuView;
        AtomicInteger atomicInteger = co.a;
        co.c.q(actionMenuView, null);
        addView(this.i, layoutParams);
    }

    public final void g() {
        if (this.s == null) {
            LayoutInflater.from(getContext()).inflate(R.layout.abc_action_bar_title_item, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.s = linearLayout;
            this.t = (TextView) linearLayout.findViewById(R.id.action_bar_title);
            this.u = (TextView) this.s.findViewById(R.id.action_bar_subtitle);
            if (this.v != 0) {
                this.t.setTextAppearance(getContext(), this.v);
            }
            if (this.w != 0) {
                this.u.setTextAppearance(getContext(), this.w);
            }
        }
        this.t.setText(this.o);
        this.u.setText(this.p);
        boolean z = !TextUtils.isEmpty(this.o);
        boolean z2 = !TextUtils.isEmpty(this.p);
        int i = 0;
        this.u.setVisibility(z2 ? 0 : 8);
        LinearLayout linearLayout2 = this.s;
        if (!z && !z2) {
            i = 8;
        }
        linearLayout2.setVisibility(i);
        if (this.s.getParent() == null) {
            addView(this.s);
        }
    }

    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    @Override // defpackage.q2
    public /* bridge */ /* synthetic */ int getAnimatedVisibility() {
        return super.getAnimatedVisibility();
    }

    @Override // defpackage.q2
    public /* bridge */ /* synthetic */ int getContentHeight() {
        return super.getContentHeight();
    }

    public CharSequence getSubtitle() {
        return this.p;
    }

    public CharSequence getTitle() {
        return this.o;
    }

    public void h() {
        removeAllViews();
        this.r = null;
        this.i = null;
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        s2 s2Var = this.j;
        if (s2Var != null) {
            s2Var.g();
            this.j.o();
        }
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        if (accessibilityEvent.getEventType() == 32) {
            accessibilityEvent.setSource(this);
            accessibilityEvent.setClassName(getClass().getName());
            accessibilityEvent.setPackageName(getContext().getPackageName());
            accessibilityEvent.setContentDescription(this.o);
            return;
        }
        super.onInitializeAccessibilityEvent(accessibilityEvent);
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        boolean b = l4.b(this);
        int paddingRight = b ? (i3 - i) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i4 - i2) - getPaddingTop()) - getPaddingBottom();
        View view = this.q;
        if (!(view == null || view.getVisibility() == 8)) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.q.getLayoutParams();
            int i5 = b ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            int i6 = b ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            int i7 = b ? paddingRight - i5 : paddingRight + i5;
            int d = i7 + d(this.q, i7, paddingTop, paddingTop2, b);
            paddingRight = b ? d - i6 : d + i6;
        }
        int i8 = paddingRight;
        LinearLayout linearLayout = this.s;
        if (!(linearLayout == null || this.r != null || linearLayout.getVisibility() == 8)) {
            i8 += d(this.s, i8, paddingTop, paddingTop2, b);
        }
        View view2 = this.r;
        if (view2 != null) {
            d(view2, i8, paddingTop, paddingTop2, b);
        }
        int paddingLeft = b ? getPaddingLeft() : (i3 - i) - getPaddingRight();
        ActionMenuView actionMenuView = this.i;
        if (actionMenuView != null) {
            d(actionMenuView, paddingLeft, paddingTop, paddingTop2, !b);
        }
    }

    public void onMeasure(int i, int i2) {
        int i3 = 1073741824;
        if (View.MeasureSpec.getMode(i) != 1073741824) {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
        } else if (View.MeasureSpec.getMode(i2) != 0) {
            int size = View.MeasureSpec.getSize(i);
            int i4 = this.k;
            if (i4 <= 0) {
                i4 = View.MeasureSpec.getSize(i2);
            }
            int paddingBottom = getPaddingBottom() + getPaddingTop();
            int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
            int i5 = i4 - paddingBottom;
            int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i5, Integer.MIN_VALUE);
            View view = this.q;
            if (view != null) {
                int c = c(view, paddingLeft, makeMeasureSpec, 0);
                ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.q.getLayoutParams();
                paddingLeft = c - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
            }
            ActionMenuView actionMenuView = this.i;
            if (actionMenuView != null && actionMenuView.getParent() == this) {
                paddingLeft = c(this.i, paddingLeft, makeMeasureSpec, 0);
            }
            LinearLayout linearLayout = this.s;
            if (linearLayout != null && this.r == null) {
                if (this.x) {
                    this.s.measure(View.MeasureSpec.makeMeasureSpec(0, 0), makeMeasureSpec);
                    int measuredWidth = this.s.getMeasuredWidth();
                    boolean z = measuredWidth <= paddingLeft;
                    if (z) {
                        paddingLeft -= measuredWidth;
                    }
                    this.s.setVisibility(z ? 0 : 8);
                } else {
                    paddingLeft = c(linearLayout, paddingLeft, makeMeasureSpec, 0);
                }
            }
            View view2 = this.r;
            if (view2 != null) {
                ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
                int i6 = layoutParams.width;
                int i7 = i6 != -2 ? 1073741824 : Integer.MIN_VALUE;
                if (i6 >= 0) {
                    paddingLeft = Math.min(i6, paddingLeft);
                }
                int i8 = layoutParams.height;
                if (i8 == -2) {
                    i3 = Integer.MIN_VALUE;
                }
                if (i8 >= 0) {
                    i5 = Math.min(i8, i5);
                }
                this.r.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i7), View.MeasureSpec.makeMeasureSpec(i5, i3));
            }
            if (this.k <= 0) {
                int childCount = getChildCount();
                int i9 = 0;
                for (int i10 = 0; i10 < childCount; i10++) {
                    int measuredHeight = getChildAt(i10).getMeasuredHeight() + paddingBottom;
                    if (measuredHeight > i9) {
                        i9 = measuredHeight;
                    }
                }
                setMeasuredDimension(size, i9);
                return;
            }
            setMeasuredDimension(size, i4);
        } else {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with android:layout_height=\"wrap_content\"");
        }
    }

    @Override // defpackage.q2
    public void setContentHeight(int i) {
        this.k = i;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.r;
        if (view2 != null) {
            removeView(view2);
        }
        this.r = view;
        if (!(view == null || (linearLayout = this.s) == null)) {
            removeView(linearLayout);
            this.s = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.p = charSequence;
        g();
    }

    public void setTitle(CharSequence charSequence) {
        this.o = charSequence;
        g();
    }

    public void setTitleOptional(boolean z) {
        if (z != this.x) {
            requestLayout();
        }
        this.x = z;
    }

    @Override // defpackage.q2
    public /* bridge */ /* synthetic */ void setVisibility(int i) {
        super.setVisibility(i);
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }
}
