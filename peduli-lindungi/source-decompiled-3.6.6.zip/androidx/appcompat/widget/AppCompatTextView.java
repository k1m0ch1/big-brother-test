package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import defpackage.bn;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class AppCompatTextView extends TextView implements zo, to {
    private final u2 mBackgroundTintHelper;
    private Future<bn> mPrecomputedTextFuture;
    private final h3 mTextClassifierHelper;
    private final i3 mTextHelper;

    public AppCompatTextView(Context context) {
        this(context, null);
    }

    private void consumeTextFutureAndSetBlocking() {
        Future<bn> future = this.mPrecomputedTextFuture;
        if (future != null) {
            try {
                this.mPrecomputedTextFuture = null;
                ek.h0(this, future.get());
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        u2 u2Var = this.mBackgroundTintHelper;
        if (u2Var != null) {
            u2Var.a();
        }
        i3 i3Var = this.mTextHelper;
        if (i3Var != null) {
            i3Var.b();
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (to.a) {
            return super.getAutoSizeMaxTextSize();
        }
        i3 i3Var = this.mTextHelper;
        if (i3Var != null) {
            return Math.round(i3Var.i.e);
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (to.a) {
            return super.getAutoSizeMinTextSize();
        }
        i3 i3Var = this.mTextHelper;
        if (i3Var != null) {
            return Math.round(i3Var.i.d);
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (to.a) {
            return super.getAutoSizeStepGranularity();
        }
        i3 i3Var = this.mTextHelper;
        if (i3Var != null) {
            return Math.round(i3Var.i.c);
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        if (to.a) {
            return super.getAutoSizeTextAvailableSizes();
        }
        i3 i3Var = this.mTextHelper;
        return i3Var != null ? i3Var.i.f : new int[0];
    }

    @SuppressLint({"WrongConstant"})
    public int getAutoSizeTextType() {
        if (!to.a) {
            i3 i3Var = this.mTextHelper;
            if (i3Var != null) {
                return i3Var.i.a;
            }
            return 0;
        } else if (super.getAutoSizeTextType() == 1) {
            return 1;
        } else {
            return 0;
        }
    }

    public int getFirstBaselineToTopHeight() {
        return getPaddingTop() - getPaint().getFontMetricsInt().top;
    }

    public int getLastBaselineToBottomHeight() {
        return getPaddingBottom() + getPaint().getFontMetricsInt().bottom;
    }

    public ColorStateList getSupportBackgroundTintList() {
        u2 u2Var = this.mBackgroundTintHelper;
        if (u2Var != null) {
            return u2Var.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        u2 u2Var = this.mBackgroundTintHelper;
        if (u2Var != null) {
            return u2Var.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        d4 d4Var = this.mTextHelper.h;
        if (d4Var != null) {
            return d4Var.a;
        }
        return null;
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        d4 d4Var = this.mTextHelper.h;
        if (d4Var != null) {
            return d4Var.b;
        }
        return null;
    }

    public CharSequence getText() {
        consumeTextFutureAndSetBlocking();
        return super.getText();
    }

    public TextClassifier getTextClassifier() {
        h3 h3Var;
        if (Build.VERSION.SDK_INT >= 28 || (h3Var = this.mTextClassifierHelper) == null) {
            return super.getTextClassifier();
        }
        return h3Var.a();
    }

    public bn.a getTextMetricsParamsCompat() {
        return ek.N(this);
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        i0.k(onCreateInputConnection, editorInfo, this);
        return onCreateInputConnection;
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        i3 i3Var = this.mTextHelper;
        if (i3Var != null && !to.a) {
            i3Var.i.a();
        }
    }

    public void onMeasure(int i, int i2) {
        consumeTextFutureAndSetBlocking();
        super.onMeasure(i, i2);
    }

    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        super.onTextChanged(charSequence, i, i2, i3);
        i3 i3Var = this.mTextHelper;
        if (i3Var != null && !to.a && i3Var.d()) {
            this.mTextHelper.i.a();
        }
    }

    public void setAutoSizeTextTypeUniformWithConfiguration(int i, int i2, int i3, int i4) {
        if (to.a) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i, i2, i3, i4);
            return;
        }
        i3 i3Var = this.mTextHelper;
        if (i3Var != null) {
            i3Var.g(i, i2, i3, i4);
        }
    }

    public void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i) {
        if (to.a) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i);
            return;
        }
        i3 i3Var = this.mTextHelper;
        if (i3Var != null) {
            i3Var.h(iArr, i);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i) {
        if (to.a) {
            super.setAutoSizeTextTypeWithDefaults(i);
            return;
        }
        i3 i3Var = this.mTextHelper;
        if (i3Var != null) {
            i3Var.i(i);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        u2 u2Var = this.mBackgroundTintHelper;
        if (u2Var != null) {
            u2Var.e();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        u2 u2Var = this.mBackgroundTintHelper;
        if (u2Var != null) {
            u2Var.f(i);
        }
    }

    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        i3 i3Var = this.mTextHelper;
        if (i3Var != null) {
            i3Var.b();
        }
    }

    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        i3 i3Var = this.mTextHelper;
        if (i3Var != null) {
            i3Var.b();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        i3 i3Var = this.mTextHelper;
        if (i3Var != null) {
            i3Var.b();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        i3 i3Var = this.mTextHelper;
        if (i3Var != null) {
            i3Var.b();
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(ek.t0(this, callback));
    }

    public void setFirstBaselineToTopHeight(int i) {
        if (Build.VERSION.SDK_INT >= 28) {
            super.setFirstBaselineToTopHeight(i);
        } else {
            ek.b0(this, i);
        }
    }

    public void setLastBaselineToBottomHeight(int i) {
        if (Build.VERSION.SDK_INT >= 28) {
            super.setLastBaselineToBottomHeight(i);
        } else {
            ek.d0(this, i);
        }
    }

    public void setLineHeight(int i) {
        ek.f0(this, i);
    }

    public void setPrecomputedText(bn bnVar) {
        ek.h0(this, bnVar);
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        u2 u2Var = this.mBackgroundTintHelper;
        if (u2Var != null) {
            u2Var.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        u2 u2Var = this.mBackgroundTintHelper;
        if (u2Var != null) {
            u2Var.i(mode);
        }
    }

    @Override // defpackage.zo
    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.mTextHelper.j(colorStateList);
        this.mTextHelper.b();
    }

    @Override // defpackage.zo
    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.mTextHelper.k(mode);
        this.mTextHelper.b();
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        i3 i3Var = this.mTextHelper;
        if (i3Var != null) {
            i3Var.f(context, i);
        }
    }

    public void setTextClassifier(TextClassifier textClassifier) {
        h3 h3Var;
        if (Build.VERSION.SDK_INT >= 28 || (h3Var = this.mTextClassifierHelper) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            h3Var.b = textClassifier;
        }
    }

    public void setTextFuture(Future<bn> future) {
        this.mPrecomputedTextFuture = future;
        if (future != null) {
            requestLayout();
        }
    }

    public void setTextMetricsParamsCompat(bn.a aVar) {
        int i = Build.VERSION.SDK_INT;
        TextDirectionHeuristic textDirectionHeuristic = aVar.b;
        int i2 = 1;
        if (!(textDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_RTL || textDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_LTR)) {
            if (textDirectionHeuristic == TextDirectionHeuristics.ANYRTL_LTR) {
                i2 = 2;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.LTR) {
                i2 = 3;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.RTL) {
                i2 = 4;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.LOCALE) {
                i2 = 5;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_LTR) {
                i2 = 6;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_RTL) {
                i2 = 7;
            }
        }
        setTextDirection(i2);
        if (i < 23) {
            float textScaleX = aVar.a.getTextScaleX();
            getPaint().set(aVar.a);
            if (textScaleX == getTextScaleX()) {
                setTextScaleX((textScaleX / 2.0f) + 1.0f);
            }
            setTextScaleX(textScaleX);
            return;
        }
        getPaint().set(aVar.a);
        setBreakStrategy(aVar.c);
        setHyphenationFrequency(aVar.d);
    }

    public void setTextSize(int i, float f) {
        boolean z = to.a;
        if (z) {
            super.setTextSize(i, f);
            return;
        }
        i3 i3Var = this.mTextHelper;
        if (i3Var != null && !z && !i3Var.d()) {
            i3Var.i.f(i, f);
        }
    }

    public void setTypeface(Typeface typeface, int i) {
        Typeface typeface2;
        if (typeface == null || i <= 0) {
            typeface2 = null;
        } else {
            Context context = getContext();
            ul ulVar = nl.a;
            if (context != null) {
                typeface2 = Typeface.create(typeface, i);
            } else {
                throw new IllegalArgumentException("Context cannot be null");
            }
        }
        if (typeface2 != null) {
            typeface = typeface2;
        }
        super.setTypeface(typeface, i);
    }

    public AppCompatTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842884);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppCompatTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        c4.a(context);
        a4.a(this, getContext());
        u2 u2Var = new u2(this);
        this.mBackgroundTintHelper = u2Var;
        u2Var.d(attributeSet, i);
        i3 i3Var = new i3(this);
        this.mTextHelper = i3Var;
        i3Var.e(attributeSet, i);
        i3Var.b();
        this.mTextClassifierHelper = new h3(this);
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        Context context = getContext();
        Drawable drawable = null;
        Drawable b = i != 0 ? i1.b(context, i) : null;
        Drawable b2 = i2 != 0 ? i1.b(context, i2) : null;
        Drawable b3 = i3 != 0 ? i1.b(context, i3) : null;
        if (i4 != 0) {
            drawable = i1.b(context, i4);
        }
        setCompoundDrawablesRelativeWithIntrinsicBounds(b, b2, b3, drawable);
        i3 i3Var = this.mTextHelper;
        if (i3Var != null) {
            i3Var.b();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        Context context = getContext();
        Drawable drawable = null;
        Drawable b = i != 0 ? i1.b(context, i) : null;
        Drawable b2 = i2 != 0 ? i1.b(context, i2) : null;
        Drawable b3 = i3 != 0 ? i1.b(context, i3) : null;
        if (i4 != 0) {
            drawable = i1.b(context, i4);
        }
        setCompoundDrawablesWithIntrinsicBounds(b, b2, b3, drawable);
        i3 i3Var = this.mTextHelper;
        if (i3Var != null) {
            i3Var.b();
        }
    }
}
