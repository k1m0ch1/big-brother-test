package androidx.appcompat.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import androidx.recyclerview.widget.RecyclerView;
import com.github.mikephil.charting.utils.Utils;
import com.telkom.tracencare.R;
import defpackage.co;
import defpackage.j2;
import defpackage.jo;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

@SuppressLint({"UnknownNullness"})
public class ActionBarOverlayLayout extends ViewGroup implements k3, sn, tn {
    public static final int[] L = {R.attr.actionBarSize, 16842841};
    public jo A;
    public jo B;
    public jo C;
    public jo D;
    public d E;
    public OverScroller F;
    public ViewPropertyAnimator G;
    public final AnimatorListenerAdapter H;
    public final Runnable I;
    public final Runnable J;
    public final un K;
    public int g;
    public int h = 0;
    public ContentFrameLayout i;
    public ActionBarContainer j;
    public l3 k;
    public Drawable l;
    public boolean m;
    public boolean n;
    public boolean o;
    public boolean p;
    public boolean q;
    public int r;
    public int s;
    public final Rect t = new Rect();
    public final Rect u = new Rect();
    public final Rect v = new Rect();
    public final Rect w = new Rect();
    public final Rect x = new Rect();
    public final Rect y = new Rect();
    public final Rect z = new Rect();

    public class a extends AnimatorListenerAdapter {
        public a() {
        }

        public void onAnimationCancel(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.G = null;
            actionBarOverlayLayout.q = false;
        }

        public void onAnimationEnd(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.G = null;
            actionBarOverlayLayout.q = false;
        }
    }

    public class b implements Runnable {
        public b() {
        }

        public void run() {
            ActionBarOverlayLayout.this.q();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.G = actionBarOverlayLayout.j.animate().translationY(Utils.FLOAT_EPSILON).setListener(ActionBarOverlayLayout.this.H);
        }
    }

    public class c implements Runnable {
        public c() {
        }

        public void run() {
            ActionBarOverlayLayout.this.q();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.G = actionBarOverlayLayout.j.animate().translationY((float) (-ActionBarOverlayLayout.this.j.getHeight())).setListener(ActionBarOverlayLayout.this.H);
        }
    }

    public interface d {
    }

    public static class e extends ViewGroup.MarginLayoutParams {
        public e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public e(int i, int i2) {
            super(i, i2);
        }

        public e(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        jo joVar = jo.b;
        this.A = joVar;
        this.B = joVar;
        this.C = joVar;
        this.D = joVar;
        this.H = new a();
        this.I = new b();
        this.J = new c();
        r(context);
        this.K = new un();
    }

    @Override // defpackage.k3
    public void a(Menu menu, j2.a aVar) {
        s();
        this.k.a(menu, aVar);
    }

    @Override // defpackage.k3
    public boolean b() {
        s();
        return this.k.b();
    }

    @Override // defpackage.k3
    public void c() {
        s();
        this.k.c();
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof e;
    }

    @Override // defpackage.k3
    public boolean d() {
        s();
        return this.k.d();
    }

    public void draw(Canvas canvas) {
        int i2;
        super.draw(canvas);
        if (this.l != null && !this.m) {
            if (this.j.getVisibility() == 0) {
                i2 = (int) (this.j.getTranslationY() + ((float) this.j.getBottom()) + 0.5f);
            } else {
                i2 = 0;
            }
            this.l.setBounds(0, i2, getWidth(), this.l.getIntrinsicHeight() + i2);
            this.l.draw(canvas);
        }
    }

    @Override // defpackage.k3
    public boolean e() {
        s();
        return this.k.e();
    }

    @Override // defpackage.k3
    public boolean f() {
        s();
        return this.k.f();
    }

    public boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    @Override // defpackage.k3
    public boolean g() {
        s();
        return this.k.g();
    }

    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new e(-1, -1);
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new e(getContext(), attributeSet);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.j;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    public int getNestedScrollAxes() {
        return this.K.a();
    }

    public CharSequence getTitle() {
        s();
        return this.k.getTitle();
    }

    @Override // defpackage.sn
    public void h(View view, View view2, int i2, int i3) {
        if (i3 == 0) {
            onNestedScrollAccepted(view, view2, i2);
        }
    }

    @Override // defpackage.sn
    public void i(View view, int i2) {
        if (i2 == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // defpackage.sn
    public void j(View view, int i2, int i3, int[] iArr, int i4) {
        if (i4 == 0) {
            onNestedPreScroll(view, i2, i3, iArr);
        }
    }

    @Override // defpackage.k3
    public void k(int i2) {
        s();
        if (i2 == 2) {
            this.k.u();
        } else if (i2 == 5) {
            this.k.v();
        } else if (i2 == 109) {
            setOverlayMode(true);
        }
    }

    @Override // defpackage.k3
    public void l() {
        s();
        this.k.h();
    }

    @Override // defpackage.tn
    public void m(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        if (i6 == 0) {
            onNestedScroll(view, i2, i3, i4, i5);
        }
    }

    @Override // defpackage.sn
    public void n(View view, int i2, int i3, int i4, int i5, int i6) {
        if (i6 == 0) {
            onNestedScroll(view, i2, i3, i4, i5);
        }
    }

    @Override // defpackage.sn
    public boolean o(View view, View view2, int i2, int i3) {
        return i3 == 0 && onStartNestedScroll(view, view2, i2);
    }

    public WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        s();
        jo j2 = jo.j(windowInsets, null);
        boolean p2 = p(this.j, new Rect(j2.b(), j2.d(), j2.c(), j2.a()), true, true, false, true);
        Rect rect = this.t;
        AtomicInteger atomicInteger = co.a;
        co.h.b(this, j2, rect);
        Rect rect2 = this.t;
        jo i2 = j2.a.i(rect2.left, rect2.top, rect2.right, rect2.bottom);
        this.A = i2;
        boolean z2 = true;
        if (!this.B.equals(i2)) {
            this.B = this.A;
            p2 = true;
        }
        if (!this.u.equals(this.t)) {
            this.u.set(this.t);
        } else {
            z2 = p2;
        }
        if (z2) {
            requestLayout();
        }
        return j2.a.a().a.c().a.b().h();
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        r(getContext());
        AtomicInteger atomicInteger = co.a;
        co.g.c(this);
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        q();
    }

    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i7 = ((ViewGroup.MarginLayoutParams) eVar).leftMargin + paddingLeft;
                int i8 = ((ViewGroup.MarginLayoutParams) eVar).topMargin + paddingTop;
                childAt.layout(i7, i8, measuredWidth + i7, measuredHeight + i8);
            }
        }
    }

    public void onMeasure(int i2, int i3) {
        int i4;
        jo.e eVar;
        s();
        measureChildWithMargins(this.j, i2, 0, i3, 0);
        e eVar2 = (e) this.j.getLayoutParams();
        int max = Math.max(0, this.j.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar2).leftMargin + ((ViewGroup.MarginLayoutParams) eVar2).rightMargin);
        int max2 = Math.max(0, this.j.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar2).topMargin + ((ViewGroup.MarginLayoutParams) eVar2).bottomMargin);
        int combineMeasuredStates = View.combineMeasuredStates(0, this.j.getMeasuredState());
        AtomicInteger atomicInteger = co.a;
        boolean z2 = (co.c.g(this) & RecyclerView.b0.FLAG_TMP_DETACHED) != 0;
        if (z2) {
            i4 = this.g;
            if (this.o && this.j.getTabContainer() != null) {
                i4 += this.g;
            }
        } else {
            i4 = this.j.getVisibility() != 8 ? this.j.getMeasuredHeight() : 0;
        }
        this.v.set(this.t);
        jo joVar = this.A;
        this.C = joVar;
        if (this.n || z2) {
            ll a2 = ll.a(joVar.b(), this.C.d() + i4, this.C.c(), this.C.a() + 0);
            jo joVar2 = this.C;
            int i5 = Build.VERSION.SDK_INT;
            if (i5 >= 30) {
                eVar = new jo.d(joVar2);
            } else if (i5 >= 29) {
                eVar = new jo.c(joVar2);
            } else {
                eVar = new jo.b(joVar2);
            }
            eVar.c(a2);
            this.C = eVar.a();
        } else {
            Rect rect = this.v;
            rect.top += i4;
            rect.bottom += 0;
            this.C = joVar.a.i(0, i4, 0, 0);
        }
        p(this.i, this.v, true, true, true, true);
        if (!this.D.equals(this.C)) {
            jo joVar3 = this.C;
            this.D = joVar3;
            co.e(this.i, joVar3);
        }
        measureChildWithMargins(this.i, i2, 0, i3, 0);
        e eVar3 = (e) this.i.getLayoutParams();
        int max3 = Math.max(max, this.i.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar3).leftMargin + ((ViewGroup.MarginLayoutParams) eVar3).rightMargin);
        int max4 = Math.max(max2, this.i.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar3).topMargin + ((ViewGroup.MarginLayoutParams) eVar3).bottomMargin);
        int combineMeasuredStates2 = View.combineMeasuredStates(combineMeasuredStates, this.i.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(getPaddingRight() + getPaddingLeft() + max3, getSuggestedMinimumWidth()), i2, combineMeasuredStates2), View.resolveSizeAndState(Math.max(getPaddingBottom() + getPaddingTop() + max4, getSuggestedMinimumHeight()), i3, combineMeasuredStates2 << 16));
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z2) {
        boolean z3 = false;
        if (!this.p || !z2) {
            return false;
        }
        this.F.fling(0, 0, 0, (int) f2, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        if (this.F.getFinalY() > this.j.getHeight()) {
            z3 = true;
        }
        if (z3) {
            q();
            this.J.run();
        } else {
            q();
            this.I.run();
        }
        this.q = true;
        return true;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        return false;
    }

    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
    }

    public void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        int i6 = this.r + i3;
        this.r = i6;
        setActionBarHideOffset(i6);
    }

    public void onNestedScrollAccepted(View view, View view2, int i2) {
        h1 h1Var;
        v1 v1Var;
        this.K.a = i2;
        this.r = getActionBarHideOffset();
        q();
        d dVar = this.E;
        if (dVar != null && (v1Var = (h1Var = (h1) dVar).t) != null) {
            v1Var.a();
            h1Var.t = null;
        }
    }

    public boolean onStartNestedScroll(View view, View view2, int i2) {
        if ((i2 & 2) == 0 || this.j.getVisibility() != 0) {
            return false;
        }
        return this.p;
    }

    public void onStopNestedScroll(View view) {
        if (this.p && !this.q) {
            if (this.r <= this.j.getHeight()) {
                q();
                postDelayed(this.I, 600);
            } else {
                q();
                postDelayed(this.J, 600);
            }
        }
        d dVar = this.E;
        if (dVar != null) {
            Objects.requireNonNull((h1) dVar);
        }
    }

    public void onWindowSystemUiVisibilityChanged(int i2) {
        super.onWindowSystemUiVisibilityChanged(i2);
        s();
        int i3 = this.s ^ i2;
        this.s = i2;
        boolean z2 = (i2 & 4) == 0;
        boolean z3 = (i2 & RecyclerView.b0.FLAG_TMP_DETACHED) != 0;
        d dVar = this.E;
        if (dVar != null) {
            ((h1) dVar).p = !z3;
            if (z2 || !z3) {
                h1 h1Var = (h1) dVar;
                if (h1Var.q) {
                    h1Var.q = false;
                    h1Var.x(true);
                }
            } else {
                h1 h1Var2 = (h1) dVar;
                if (!h1Var2.q) {
                    h1Var2.q = true;
                    h1Var2.x(true);
                }
            }
        }
        if ((i3 & RecyclerView.b0.FLAG_TMP_DETACHED) != 0 && this.E != null) {
            AtomicInteger atomicInteger = co.a;
            co.g.c(this);
        }
    }

    public void onWindowVisibilityChanged(int i2) {
        super.onWindowVisibilityChanged(i2);
        this.h = i2;
        d dVar = this.E;
        if (dVar != null) {
            ((h1) dVar).o = i2;
        }
    }

    public final boolean p(View view, Rect rect, boolean z2, boolean z3, boolean z4, boolean z5) {
        boolean z6;
        int i2;
        int i3;
        int i4;
        int i5;
        e eVar = (e) view.getLayoutParams();
        if (!z2 || ((ViewGroup.MarginLayoutParams) eVar).leftMargin == (i5 = rect.left)) {
            z6 = false;
        } else {
            ((ViewGroup.MarginLayoutParams) eVar).leftMargin = i5;
            z6 = true;
        }
        if (z3 && ((ViewGroup.MarginLayoutParams) eVar).topMargin != (i4 = rect.top)) {
            ((ViewGroup.MarginLayoutParams) eVar).topMargin = i4;
            z6 = true;
        }
        if (z5 && ((ViewGroup.MarginLayoutParams) eVar).rightMargin != (i3 = rect.right)) {
            ((ViewGroup.MarginLayoutParams) eVar).rightMargin = i3;
            z6 = true;
        }
        if (!z4 || ((ViewGroup.MarginLayoutParams) eVar).bottomMargin == (i2 = rect.bottom)) {
            return z6;
        }
        ((ViewGroup.MarginLayoutParams) eVar).bottomMargin = i2;
        return true;
    }

    public void q() {
        removeCallbacks(this.I);
        removeCallbacks(this.J);
        ViewPropertyAnimator viewPropertyAnimator = this.G;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public final void r(Context context) {
        TypedArray obtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(L);
        boolean z2 = false;
        this.g = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = obtainStyledAttributes.getDrawable(1);
        this.l = drawable;
        setWillNotDraw(drawable == null);
        obtainStyledAttributes.recycle();
        if (context.getApplicationInfo().targetSdkVersion < 19) {
            z2 = true;
        }
        this.m = z2;
        this.F = new OverScroller(context);
    }

    public void s() {
        l3 l3Var;
        if (this.i == null) {
            this.i = (ContentFrameLayout) findViewById(R.id.action_bar_activity_content);
            this.j = (ActionBarContainer) findViewById(R.id.action_bar_container);
            View findViewById = findViewById(R.id.action_bar);
            if (findViewById instanceof l3) {
                l3Var = (l3) findViewById;
            } else if (findViewById instanceof Toolbar) {
                l3Var = ((Toolbar) findViewById).getWrapper();
            } else {
                StringBuilder J0 = ze0.J0("Can't make a decor toolbar out of ");
                J0.append(findViewById.getClass().getSimpleName());
                throw new IllegalStateException(J0.toString());
            }
            this.k = l3Var;
        }
    }

    public void setActionBarHideOffset(int i2) {
        q();
        this.j.setTranslationY((float) (-Math.max(0, Math.min(i2, this.j.getHeight()))));
    }

    public void setActionBarVisibilityCallback(d dVar) {
        this.E = dVar;
        if (getWindowToken() != null) {
            ((h1) this.E).o = this.h;
            int i2 = this.s;
            if (i2 != 0) {
                onWindowSystemUiVisibilityChanged(i2);
                AtomicInteger atomicInteger = co.a;
                co.g.c(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z2) {
        this.o = z2;
    }

    public void setHideOnContentScrollEnabled(boolean z2) {
        if (z2 != this.p) {
            this.p = z2;
            if (!z2) {
                q();
                setActionBarHideOffset(0);
            }
        }
    }

    public void setIcon(int i2) {
        s();
        this.k.setIcon(i2);
    }

    public void setLogo(int i2) {
        s();
        this.k.r(i2);
    }

    public void setOverlayMode(boolean z2) {
        this.n = z2;
        this.m = z2 && getContext().getApplicationInfo().targetSdkVersion < 19;
    }

    public void setShowingForActionMode(boolean z2) {
    }

    public void setUiOptions(int i2) {
    }

    @Override // defpackage.k3
    public void setWindowCallback(Window.Callback callback) {
        s();
        this.k.setWindowCallback(callback);
    }

    @Override // defpackage.k3
    public void setWindowTitle(CharSequence charSequence) {
        s();
        this.k.setWindowTitle(charSequence);
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new e(layoutParams);
    }

    public void setIcon(Drawable drawable) {
        s();
        this.k.setIcon(drawable);
    }
}
