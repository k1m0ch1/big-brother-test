package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.ActionMenuView;
import com.google.maps.android.R;
import defpackage.co;
import defpackage.d2;
import defpackage.j2;
import defpackage.k0;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class Toolbar extends ViewGroup {
    public int A;
    public int B;
    public int C;
    public CharSequence D;
    public CharSequence E;
    public ColorStateList F;
    public ColorStateList G;
    public boolean H;
    public boolean I;
    public final ArrayList<View> J;
    public final ArrayList<View> K;
    public final int[] L;
    public f M;
    public final ActionMenuView.e N;
    public h4 O;
    public s2 P;
    public d Q;
    public j2.a R;
    public d2.a S;
    public boolean T;
    public final Runnable U;
    public ActionMenuView g;
    public TextView h;
    public TextView i;
    public ImageButton j;
    public ImageView k;
    public Drawable l;
    public CharSequence m;
    public ImageButton n;
    public View o;
    public Context p;
    public int q;
    public int r;
    public int s;
    public int t;
    public int u;
    public int v;
    public int w;
    public int x;
    public int y;
    public x3 z;

    public class a implements ActionMenuView.e {
        public a() {
        }
    }

    public class b implements Runnable {
        public b() {
        }

        public void run() {
            Toolbar.this.w();
        }
    }

    public class c implements View.OnClickListener {
        public c() {
        }

        public void onClick(View view) {
            f2 f2Var;
            d dVar = Toolbar.this.Q;
            if (dVar == null) {
                f2Var = null;
            } else {
                f2Var = dVar.h;
            }
            if (f2Var != null) {
                f2Var.collapseActionView();
            }
        }
    }

    public class d implements j2 {
        public d2 g;
        public f2 h;

        public d() {
        }

        @Override // defpackage.j2
        public int a() {
            return 0;
        }

        @Override // defpackage.j2
        public void c(d2 d2Var, boolean z) {
        }

        @Override // defpackage.j2
        public void e(Context context, d2 d2Var) {
            f2 f2Var;
            d2 d2Var2 = this.g;
            if (!(d2Var2 == null || (f2Var = this.h) == null)) {
                d2Var2.d(f2Var);
            }
            this.g = d2Var;
        }

        @Override // defpackage.j2
        public void f(Parcelable parcelable) {
        }

        @Override // defpackage.j2
        public boolean h(o2 o2Var) {
            return false;
        }

        @Override // defpackage.j2
        public void i(boolean z) {
            if (this.h != null) {
                d2 d2Var = this.g;
                boolean z2 = false;
                if (d2Var != null) {
                    int size = d2Var.size();
                    int i2 = 0;
                    while (true) {
                        if (i2 >= size) {
                            break;
                        } else if (this.g.getItem(i2) == this.h) {
                            z2 = true;
                            break;
                        } else {
                            i2++;
                        }
                    }
                }
                if (!z2) {
                    l(this.g, this.h);
                }
            }
        }

        @Override // defpackage.j2
        public boolean j() {
            return false;
        }

        @Override // defpackage.j2
        public Parcelable k() {
            return null;
        }

        @Override // defpackage.j2
        public boolean l(d2 d2Var, f2 f2Var) {
            View view = Toolbar.this.o;
            if (view instanceof q1) {
                ((q1) view).e();
            }
            Toolbar toolbar = Toolbar.this;
            toolbar.removeView(toolbar.o);
            Toolbar toolbar2 = Toolbar.this;
            toolbar2.removeView(toolbar2.n);
            Toolbar toolbar3 = Toolbar.this;
            toolbar3.o = null;
            int size = toolbar3.K.size();
            while (true) {
                size--;
                if (size >= 0) {
                    toolbar3.addView(toolbar3.K.get(size));
                } else {
                    toolbar3.K.clear();
                    this.h = null;
                    Toolbar.this.requestLayout();
                    f2Var.C = false;
                    f2Var.n.q(false);
                    return true;
                }
            }
        }

        @Override // defpackage.j2
        public boolean m(d2 d2Var, f2 f2Var) {
            Toolbar.this.c();
            ViewParent parent = Toolbar.this.n.getParent();
            Toolbar toolbar = Toolbar.this;
            if (parent != toolbar) {
                if (parent instanceof ViewGroup) {
                    ((ViewGroup) parent).removeView(toolbar.n);
                }
                Toolbar toolbar2 = Toolbar.this;
                toolbar2.addView(toolbar2.n);
            }
            Toolbar.this.o = f2Var.getActionView();
            this.h = f2Var;
            ViewParent parent2 = Toolbar.this.o.getParent();
            Toolbar toolbar3 = Toolbar.this;
            if (parent2 != toolbar3) {
                if (parent2 instanceof ViewGroup) {
                    ((ViewGroup) parent2).removeView(toolbar3.o);
                }
                e h2 = Toolbar.this.generateDefaultLayoutParams();
                Toolbar toolbar4 = Toolbar.this;
                h2.a = 8388611 | (toolbar4.t & R.styleable.AppCompatTheme_tooltipForegroundColor);
                h2.b = 2;
                toolbar4.o.setLayoutParams(h2);
                Toolbar toolbar5 = Toolbar.this;
                toolbar5.addView(toolbar5.o);
            }
            Toolbar toolbar6 = Toolbar.this;
            int childCount = toolbar6.getChildCount();
            while (true) {
                childCount--;
                if (childCount < 0) {
                    break;
                }
                View childAt = toolbar6.getChildAt(childCount);
                if (!(((e) childAt.getLayoutParams()).b == 2 || childAt == toolbar6.g)) {
                    toolbar6.removeViewAt(childCount);
                    toolbar6.K.add(childAt);
                }
            }
            Toolbar.this.requestLayout();
            f2Var.C = true;
            f2Var.n.q(false);
            View view = Toolbar.this.o;
            if (view instanceof q1) {
                ((q1) view).c();
            }
            return true;
        }
    }

    public interface f {
        boolean onMenuItemClick(MenuItem menuItem);
    }

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, com.telkom.tracencare.R.attr.toolbarStyle);
    }

    private MenuInflater getMenuInflater() {
        return new u1(getContext());
    }

    public final void a(List<View> list, int i2) {
        AtomicInteger atomicInteger = co.a;
        boolean z2 = co.d.d(this) == 1;
        int childCount = getChildCount();
        int absoluteGravity = Gravity.getAbsoluteGravity(i2, co.d.d(this));
        list.clear();
        if (z2) {
            for (int i3 = childCount - 1; i3 >= 0; i3--) {
                View childAt = getChildAt(i3);
                e eVar = (e) childAt.getLayoutParams();
                if (eVar.b == 0 && v(childAt) && j(eVar.a) == absoluteGravity) {
                    list.add(childAt);
                }
            }
            return;
        }
        for (int i4 = 0; i4 < childCount; i4++) {
            View childAt2 = getChildAt(i4);
            e eVar2 = (e) childAt2.getLayoutParams();
            if (eVar2.b == 0 && v(childAt2) && j(eVar2.a) == absoluteGravity) {
                list.add(childAt2);
            }
        }
    }

    public final void b(View view, boolean z2) {
        e eVar;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams == null) {
            eVar = generateDefaultLayoutParams();
        } else if (!checkLayoutParams(layoutParams)) {
            eVar = generateLayoutParams(layoutParams);
        } else {
            eVar = (e) layoutParams;
        }
        eVar.b = 1;
        if (!z2 || this.o == null) {
            addView(view, eVar);
            return;
        }
        view.setLayoutParams(eVar);
        this.K.add(view);
    }

    public void c() {
        if (this.n == null) {
            AppCompatImageButton appCompatImageButton = new AppCompatImageButton(getContext(), null, com.telkom.tracencare.R.attr.toolbarNavigationButtonStyle);
            this.n = appCompatImageButton;
            appCompatImageButton.setImageDrawable(this.l);
            this.n.setContentDescription(this.m);
            e h2 = generateDefaultLayoutParams();
            h2.a = 8388611 | (this.t & R.styleable.AppCompatTheme_tooltipForegroundColor);
            h2.b = 2;
            this.n.setLayoutParams(h2);
            this.n.setOnClickListener(new c());
        }
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof e);
    }

    public final void d() {
        if (this.z == null) {
            this.z = new x3();
        }
    }

    public final void e() {
        f();
        ActionMenuView actionMenuView = this.g;
        if (actionMenuView.v == null) {
            d2 d2Var = (d2) actionMenuView.getMenu();
            if (this.Q == null) {
                this.Q = new d();
            }
            this.g.setExpandedActionViewsExclusive(true);
            d2Var.b(this.Q, this.p);
        }
    }

    public final void f() {
        if (this.g == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext(), null);
            this.g = actionMenuView;
            actionMenuView.setPopupTheme(this.q);
            this.g.setOnMenuItemClickListener(this.N);
            ActionMenuView actionMenuView2 = this.g;
            j2.a aVar = this.R;
            d2.a aVar2 = this.S;
            actionMenuView2.A = aVar;
            actionMenuView2.B = aVar2;
            e h2 = generateDefaultLayoutParams();
            h2.a = 8388613 | (this.t & R.styleable.AppCompatTheme_tooltipForegroundColor);
            this.g.setLayoutParams(h2);
            b(this.g, false);
        }
    }

    public final void g() {
        if (this.j == null) {
            this.j = new AppCompatImageButton(getContext(), null, com.telkom.tracencare.R.attr.toolbarNavigationButtonStyle);
            e h2 = generateDefaultLayoutParams();
            h2.a = 8388611 | (this.t & R.styleable.AppCompatTheme_tooltipForegroundColor);
            this.j.setLayoutParams(h2);
        }
    }

    public CharSequence getCollapseContentDescription() {
        ImageButton imageButton = this.n;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        ImageButton imageButton = this.n;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        x3 x3Var = this.z;
        if (x3Var != null) {
            return x3Var.g ? x3Var.a : x3Var.b;
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i2 = this.B;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        x3 x3Var = this.z;
        if (x3Var != null) {
            return x3Var.a;
        }
        return 0;
    }

    public int getContentInsetRight() {
        x3 x3Var = this.z;
        if (x3Var != null) {
            return x3Var.b;
        }
        return 0;
    }

    public int getContentInsetStart() {
        x3 x3Var = this.z;
        if (x3Var != null) {
            return x3Var.g ? x3Var.b : x3Var.a;
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i2 = this.A;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetStart();
    }

    public int getCurrentContentInsetEnd() {
        d2 d2Var;
        ActionMenuView actionMenuView = this.g;
        if ((actionMenuView == null || (d2Var = actionMenuView.v) == null || !d2Var.hasVisibleItems()) ? false : true) {
            return Math.max(getContentInsetEnd(), Math.max(this.B, 0));
        }
        return getContentInsetEnd();
    }

    public int getCurrentContentInsetLeft() {
        AtomicInteger atomicInteger = co.a;
        if (co.d.d(this) == 1) {
            return getCurrentContentInsetEnd();
        }
        return getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        AtomicInteger atomicInteger = co.a;
        if (co.d.d(this) == 1) {
            return getCurrentContentInsetStart();
        }
        return getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        if (getNavigationIcon() != null) {
            return Math.max(getContentInsetStart(), Math.max(this.A, 0));
        }
        return getContentInsetStart();
    }

    public Drawable getLogo() {
        ImageView imageView = this.k;
        if (imageView != null) {
            return imageView.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        ImageView imageView = this.k;
        if (imageView != null) {
            return imageView.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        e();
        return this.g.getMenu();
    }

    public CharSequence getNavigationContentDescription() {
        ImageButton imageButton = this.j;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        ImageButton imageButton = this.j;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    public s2 getOuterActionMenuPresenter() {
        return this.P;
    }

    public Drawable getOverflowIcon() {
        e();
        return this.g.getOverflowIcon();
    }

    public Context getPopupContext() {
        return this.p;
    }

    public int getPopupTheme() {
        return this.q;
    }

    public CharSequence getSubtitle() {
        return this.E;
    }

    public final TextView getSubtitleTextView() {
        return this.i;
    }

    public CharSequence getTitle() {
        return this.D;
    }

    public int getTitleMarginBottom() {
        return this.y;
    }

    public int getTitleMarginEnd() {
        return this.w;
    }

    public int getTitleMarginStart() {
        return this.v;
    }

    public int getTitleMarginTop() {
        return this.x;
    }

    public final TextView getTitleTextView() {
        return this.h;
    }

    public l3 getWrapper() {
        if (this.O == null) {
            this.O = new h4(this, true);
        }
        return this.O;
    }

    /* renamed from: h */
    public e generateDefaultLayoutParams() {
        return new e(-2, -2);
    }

    /* renamed from: i */
    public e generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof e) {
            return new e((e) layoutParams);
        }
        if (layoutParams instanceof k0.a) {
            return new e((k0.a) layoutParams);
        }
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            return new e((ViewGroup.MarginLayoutParams) layoutParams);
        }
        return new e(layoutParams);
    }

    public final int j(int i2) {
        AtomicInteger atomicInteger = co.a;
        int d2 = co.d.d(this);
        int absoluteGravity = Gravity.getAbsoluteGravity(i2, d2) & 7;
        if (absoluteGravity == 1 || absoluteGravity == 3 || absoluteGravity == 5) {
            return absoluteGravity;
        }
        return d2 == 1 ? 5 : 3;
    }

    public final int k(View view, int i2) {
        e eVar = (e) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i3 = i2 > 0 ? (measuredHeight - i2) / 2 : 0;
        int i4 = eVar.a & R.styleable.AppCompatTheme_tooltipForegroundColor;
        if (!(i4 == 16 || i4 == 48 || i4 == 80)) {
            i4 = this.C & R.styleable.AppCompatTheme_tooltipForegroundColor;
        }
        if (i4 == 48) {
            return getPaddingTop() - i3;
        }
        if (i4 == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - ((ViewGroup.MarginLayoutParams) eVar).bottomMargin) - i3;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int i5 = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i6 = ((ViewGroup.MarginLayoutParams) eVar).topMargin;
        if (i5 < i6) {
            i5 = i6;
        } else {
            int i7 = (((height - paddingBottom) - measuredHeight) - i5) - paddingTop;
            int i8 = ((ViewGroup.MarginLayoutParams) eVar).bottomMargin;
            if (i7 < i8) {
                i5 = Math.max(0, i5 - (i8 - i7));
            }
        }
        return paddingTop + i5;
    }

    public final int l(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.getMarginStart() + marginLayoutParams.getMarginEnd();
    }

    public final int m(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    public void n(int i2) {
        getMenuInflater().inflate(i2, getMenu());
    }

    public final boolean o(View view) {
        return view.getParent() == this || this.K.contains(view);
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.U);
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.I = false;
        }
        if (!this.I) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.I = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.I = false;
        }
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:102:0x02a1 A[LOOP:0: B:101:0x029f->B:102:0x02a1, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:105:0x02c3 A[LOOP:1: B:104:0x02c1->B:105:0x02c3, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:108:0x02e8 A[LOOP:2: B:107:0x02e6->B:108:0x02e8, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:111:0x0329  */
    /* JADX WARNING: Removed duplicated region for block: B:116:0x033a A[LOOP:3: B:115:0x0338->B:116:0x033a, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x0061  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x0078  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x00b5  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x00cc  */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x00e9  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x0102  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x0107  */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x011f  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x012e  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x0131  */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x0135  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x0138  */
    /* JADX WARNING: Removed duplicated region for block: B:62:0x0169  */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x01a7  */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x01b8  */
    /* JADX WARNING: Removed duplicated region for block: B:87:0x0227  */
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int i6;
        int i7;
        boolean v2;
        boolean v3;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        int size;
        int i13;
        int i14;
        int size2;
        int i15;
        int size3;
        int i16;
        int i17;
        int size4;
        int i18;
        int i19;
        int i20;
        int i21;
        int i22;
        int i23;
        int i24;
        int i25;
        AtomicInteger atomicInteger = co.a;
        boolean z3 = co.d.d(this) == 1;
        int width = getWidth();
        int height = getHeight();
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int i26 = width - paddingRight;
        int[] iArr = this.L;
        iArr[1] = 0;
        iArr[0] = 0;
        int d2 = co.c.d(this);
        int min = d2 >= 0 ? Math.min(d2, i5 - i3) : 0;
        if (!v(this.j)) {
            i7 = paddingLeft;
        } else if (z3) {
            i6 = r(this.j, i26, iArr, min);
            i7 = paddingLeft;
            if (v(this.n)) {
                if (z3) {
                    i6 = r(this.n, i6, iArr, min);
                } else {
                    i7 = q(this.n, i7, iArr, min);
                }
            }
            if (v(this.g)) {
                if (z3) {
                    i7 = q(this.g, i7, iArr, min);
                } else {
                    i6 = r(this.g, i6, iArr, min);
                }
            }
            int currentContentInsetLeft = getCurrentContentInsetLeft();
            int currentContentInsetRight = getCurrentContentInsetRight();
            iArr[0] = Math.max(0, currentContentInsetLeft - i7);
            iArr[1] = Math.max(0, currentContentInsetRight - (i26 - i6));
            int max = Math.max(i7, currentContentInsetLeft);
            int min2 = Math.min(i6, i26 - currentContentInsetRight);
            if (v(this.o)) {
                if (z3) {
                    min2 = r(this.o, min2, iArr, min);
                } else {
                    max = q(this.o, max, iArr, min);
                }
            }
            if (v(this.k)) {
                if (z3) {
                    min2 = r(this.k, min2, iArr, min);
                } else {
                    max = q(this.k, max, iArr, min);
                }
            }
            v2 = v(this.h);
            v3 = v(this.i);
            if (!v2) {
                e eVar = (e) this.h.getLayoutParams();
                i8 = paddingRight;
                i9 = this.h.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar).topMargin + ((ViewGroup.MarginLayoutParams) eVar).bottomMargin + 0;
            } else {
                i8 = paddingRight;
                i9 = 0;
            }
            if (!v3) {
                e eVar2 = (e) this.i.getLayoutParams();
                i10 = width;
                i9 += this.i.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar2).topMargin + ((ViewGroup.MarginLayoutParams) eVar2).bottomMargin;
            } else {
                i10 = width;
            }
            if (!v2 || v3) {
                TextView textView = !v2 ? this.h : this.i;
                TextView textView2 = !v3 ? this.i : this.h;
                e eVar3 = (e) textView.getLayoutParams();
                e eVar4 = (e) textView2.getLayoutParams();
                boolean z4 = (!v2 && this.h.getMeasuredWidth() > 0) || (v3 && this.i.getMeasuredWidth() > 0);
                i19 = this.C & R.styleable.AppCompatTheme_tooltipForegroundColor;
                i12 = paddingLeft;
                if (i19 != 48) {
                    i20 = max;
                    i11 = min;
                    i21 = getPaddingTop() + ((ViewGroup.MarginLayoutParams) eVar3).topMargin + this.x;
                } else if (i19 != 80) {
                    int i27 = (((height - paddingTop) - paddingBottom) - i9) / 2;
                    int i28 = ((ViewGroup.MarginLayoutParams) eVar3).topMargin;
                    i11 = min;
                    int i29 = this.x;
                    i20 = max;
                    if (i27 < i28 + i29) {
                        i27 = i28 + i29;
                    } else {
                        int i30 = (((height - paddingBottom) - i9) - i27) - paddingTop;
                        int i31 = ((ViewGroup.MarginLayoutParams) eVar3).bottomMargin;
                        int i32 = this.y;
                        if (i30 < i31 + i32) {
                            i27 = Math.max(0, i27 - ((((ViewGroup.MarginLayoutParams) eVar4).bottomMargin + i32) - i30));
                        }
                    }
                    i21 = paddingTop + i27;
                } else {
                    i20 = max;
                    i11 = min;
                    i21 = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) eVar4).bottomMargin) - this.y) - i9;
                }
                if (!z3) {
                    int i33 = (z4 ? this.v : 0) - iArr[1];
                    min2 -= Math.max(0, i33);
                    iArr[1] = Math.max(0, -i33);
                    if (v2) {
                        int measuredWidth = min2 - this.h.getMeasuredWidth();
                        int measuredHeight = this.h.getMeasuredHeight() + i21;
                        this.h.layout(measuredWidth, i21, min2, measuredHeight);
                        i24 = measuredWidth - this.w;
                        i21 = measuredHeight + ((ViewGroup.MarginLayoutParams) ((e) this.h.getLayoutParams())).bottomMargin;
                    } else {
                        i24 = min2;
                    }
                    if (v3) {
                        int i34 = i21 + ((ViewGroup.MarginLayoutParams) ((e) this.i.getLayoutParams())).topMargin;
                        this.i.layout(min2 - this.i.getMeasuredWidth(), i34, min2, this.i.getMeasuredHeight() + i34);
                        i25 = min2 - this.w;
                    } else {
                        i25 = min2;
                    }
                    if (z4) {
                        min2 = Math.min(i24, i25);
                    }
                    max = i20;
                } else {
                    int i35 = (z4 ? this.v : 0) - iArr[0];
                    int max2 = Math.max(0, i35) + i20;
                    iArr[0] = Math.max(0, -i35);
                    if (v2) {
                        int measuredWidth2 = this.h.getMeasuredWidth() + max2;
                        int measuredHeight2 = this.h.getMeasuredHeight() + i21;
                        this.h.layout(max2, i21, measuredWidth2, measuredHeight2);
                        i22 = measuredWidth2 + this.w;
                        i21 = measuredHeight2 + ((ViewGroup.MarginLayoutParams) ((e) this.h.getLayoutParams())).bottomMargin;
                    } else {
                        i22 = max2;
                    }
                    if (v3) {
                        int i36 = i21 + ((ViewGroup.MarginLayoutParams) ((e) this.i.getLayoutParams())).topMargin;
                        int measuredWidth3 = this.i.getMeasuredWidth() + max2;
                        this.i.layout(max2, i36, measuredWidth3, this.i.getMeasuredHeight() + i36);
                        i23 = measuredWidth3 + this.w;
                    } else {
                        i23 = max2;
                    }
                    max = z4 ? Math.max(i22, i23) : max2;
                }
            } else {
                i12 = paddingLeft;
                i11 = min;
            }
            a(this.J, 3);
            size = this.J.size();
            i13 = max;
            for (i14 = 0; i14 < size; i14++) {
                i13 = q(this.J.get(i14), i13, iArr, i11);
            }
            a(this.J, 5);
            size2 = this.J.size();
            for (i15 = 0; i15 < size2; i15++) {
                min2 = r(this.J.get(i15), min2, iArr, i11);
            }
            a(this.J, 1);
            ArrayList<View> arrayList = this.J;
            int i37 = iArr[0];
            int i38 = iArr[1];
            size3 = arrayList.size();
            int i39 = i37;
            i16 = 0;
            int i40 = 0;
            while (i16 < size3) {
                View view = arrayList.get(i16);
                e eVar5 = (e) view.getLayoutParams();
                int i41 = ((ViewGroup.MarginLayoutParams) eVar5).leftMargin - i39;
                int i42 = ((ViewGroup.MarginLayoutParams) eVar5).rightMargin - i38;
                int max3 = Math.max(0, i41);
                int max4 = Math.max(0, i42);
                int max5 = Math.max(0, -i41);
                int max6 = Math.max(0, -i42);
                i40 += view.getMeasuredWidth() + max3 + max4;
                i16++;
                i38 = max6;
                i39 = max5;
            }
            i17 = ((((i10 - i12) - i8) / 2) + i12) - (i40 / 2);
            int i43 = i40 + i17;
            if (i17 >= i13) {
                i13 = i43 > min2 ? i17 - (i43 - min2) : i17;
            }
            size4 = this.J.size();
            int i44 = i13;
            for (i18 = 0; i18 < size4; i18++) {
                i44 = q(this.J.get(i18), i44, iArr, i11);
            }
            this.J.clear();
        } else {
            i7 = q(this.j, paddingLeft, iArr, min);
        }
        i6 = i26;
        if (v(this.n)) {
        }
        if (v(this.g)) {
        }
        int currentContentInsetLeft2 = getCurrentContentInsetLeft();
        int currentContentInsetRight2 = getCurrentContentInsetRight();
        iArr[0] = Math.max(0, currentContentInsetLeft2 - i7);
        iArr[1] = Math.max(0, currentContentInsetRight2 - (i26 - i6));
        int max7 = Math.max(i7, currentContentInsetLeft2);
        int min22 = Math.min(i6, i26 - currentContentInsetRight2);
        if (v(this.o)) {
        }
        if (v(this.k)) {
        }
        v2 = v(this.h);
        v3 = v(this.i);
        if (!v2) {
        }
        if (!v3) {
        }
        if (!v2) {
        }
        if (!v2) {
        }
        if (!v3) {
        }
        e eVar32 = (e) textView.getLayoutParams();
        e eVar42 = (e) textView2.getLayoutParams();
        if (!v2) {
        }
        i19 = this.C & R.styleable.AppCompatTheme_tooltipForegroundColor;
        i12 = paddingLeft;
        if (i19 != 48) {
        }
        if (!z3) {
        }
        a(this.J, 3);
        size = this.J.size();
        i13 = max7;
        while (i14 < size) {
        }
        a(this.J, 5);
        size2 = this.J.size();
        while (i15 < size2) {
        }
        a(this.J, 1);
        ArrayList<View> arrayList2 = this.J;
        int i372 = iArr[0];
        int i382 = iArr[1];
        size3 = arrayList2.size();
        int i392 = i372;
        i16 = 0;
        int i402 = 0;
        while (i16 < size3) {
        }
        i17 = ((((i10 - i12) - i8) / 2) + i12) - (i402 / 2);
        int i432 = i402 + i17;
        if (i17 >= i13) {
        }
        size4 = this.J.size();
        int i442 = i13;
        while (i18 < size4) {
        }
        this.J.clear();
    }

    public void onMeasure(int i2, int i3) {
        char c2;
        char c3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int[] iArr = this.L;
        boolean z2 = true;
        int i11 = 0;
        if (l4.b(this)) {
            c3 = 1;
            c2 = 0;
        } else {
            c3 = 0;
            c2 = 1;
        }
        if (v(this.j)) {
            t(this.j, i2, 0, i3, 0, this.u);
            i6 = l(this.j) + this.j.getMeasuredWidth();
            i5 = Math.max(0, m(this.j) + this.j.getMeasuredHeight());
            i4 = View.combineMeasuredStates(0, this.j.getMeasuredState());
        } else {
            i6 = 0;
            i5 = 0;
            i4 = 0;
        }
        if (v(this.n)) {
            t(this.n, i2, 0, i3, 0, this.u);
            i6 = l(this.n) + this.n.getMeasuredWidth();
            i5 = Math.max(i5, m(this.n) + this.n.getMeasuredHeight());
            i4 = View.combineMeasuredStates(i4, this.n.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int max = Math.max(currentContentInsetStart, i6) + 0;
        iArr[c3] = Math.max(0, currentContentInsetStart - i6);
        if (v(this.g)) {
            t(this.g, i2, max, i3, 0, this.u);
            i7 = l(this.g) + this.g.getMeasuredWidth();
            i5 = Math.max(i5, m(this.g) + this.g.getMeasuredHeight());
            i4 = View.combineMeasuredStates(i4, this.g.getMeasuredState());
        } else {
            i7 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int max2 = Math.max(currentContentInsetEnd, i7) + max;
        iArr[c2] = Math.max(0, currentContentInsetEnd - i7);
        if (v(this.o)) {
            max2 += s(this.o, i2, max2, i3, 0, iArr);
            i5 = Math.max(i5, m(this.o) + this.o.getMeasuredHeight());
            i4 = View.combineMeasuredStates(i4, this.o.getMeasuredState());
        }
        if (v(this.k)) {
            max2 += s(this.k, i2, max2, i3, 0, iArr);
            i5 = Math.max(i5, m(this.k) + this.k.getMeasuredHeight());
            i4 = View.combineMeasuredStates(i4, this.k.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i12 = 0; i12 < childCount; i12++) {
            View childAt = getChildAt(i12);
            if (((e) childAt.getLayoutParams()).b == 0 && v(childAt)) {
                max2 += s(childAt, i2, max2, i3, 0, iArr);
                i5 = Math.max(i5, m(childAt) + childAt.getMeasuredHeight());
                i4 = View.combineMeasuredStates(i4, childAt.getMeasuredState());
            }
        }
        int i13 = this.x + this.y;
        int i14 = this.v + this.w;
        if (v(this.h)) {
            s(this.h, i2, max2 + i14, i3, i13, iArr);
            int l2 = l(this.h) + this.h.getMeasuredWidth();
            i8 = m(this.h) + this.h.getMeasuredHeight();
            i10 = View.combineMeasuredStates(i4, this.h.getMeasuredState());
            i9 = l2;
        } else {
            i10 = i4;
            i9 = 0;
            i8 = 0;
        }
        if (v(this.i)) {
            i9 = Math.max(i9, s(this.i, i2, max2 + i14, i3, i8 + i13, iArr));
            i8 = m(this.i) + this.i.getMeasuredHeight() + i8;
            i10 = View.combineMeasuredStates(i10, this.i.getMeasuredState());
        }
        int max3 = Math.max(i5, i8);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop() + max3;
        int resolveSizeAndState = View.resolveSizeAndState(Math.max(paddingRight + max2 + i9, getSuggestedMinimumWidth()), i2, -16777216 & i10);
        int resolveSizeAndState2 = View.resolveSizeAndState(Math.max(paddingBottom, getSuggestedMinimumHeight()), i3, i10 << 16);
        if (this.T) {
            int childCount2 = getChildCount();
            int i15 = 0;
            while (true) {
                if (i15 >= childCount2) {
                    break;
                }
                View childAt2 = getChildAt(i15);
                if (v(childAt2) && childAt2.getMeasuredWidth() > 0 && childAt2.getMeasuredHeight() > 0) {
                    break;
                }
                i15++;
            }
        }
        z2 = false;
        if (!z2) {
            i11 = resolveSizeAndState2;
        }
        setMeasuredDimension(resolveSizeAndState, i11);
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem findItem;
        if (!(parcelable instanceof g)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        g gVar = (g) parcelable;
        super.onRestoreInstanceState(gVar.g);
        ActionMenuView actionMenuView = this.g;
        d2 d2Var = actionMenuView != null ? actionMenuView.v : null;
        int i2 = gVar.i;
        if (!(i2 == 0 || this.Q == null || d2Var == null || (findItem = d2Var.findItem(i2)) == null)) {
            findItem.expandActionView();
        }
        if (gVar.j) {
            removeCallbacks(this.U);
            post(this.U);
        }
    }

    public void onRtlPropertiesChanged(int i2) {
        super.onRtlPropertiesChanged(i2);
        d();
        x3 x3Var = this.z;
        boolean z2 = true;
        if (i2 != 1) {
            z2 = false;
        }
        if (z2 != x3Var.g) {
            x3Var.g = z2;
            if (!x3Var.h) {
                x3Var.a = x3Var.e;
                x3Var.b = x3Var.f;
            } else if (z2) {
                int i3 = x3Var.d;
                if (i3 == Integer.MIN_VALUE) {
                    i3 = x3Var.e;
                }
                x3Var.a = i3;
                int i4 = x3Var.c;
                if (i4 == Integer.MIN_VALUE) {
                    i4 = x3Var.f;
                }
                x3Var.b = i4;
            } else {
                int i5 = x3Var.c;
                if (i5 == Integer.MIN_VALUE) {
                    i5 = x3Var.e;
                }
                x3Var.a = i5;
                int i6 = x3Var.d;
                if (i6 == Integer.MIN_VALUE) {
                    i6 = x3Var.f;
                }
                x3Var.b = i6;
            }
        }
    }

    public Parcelable onSaveInstanceState() {
        f2 f2Var;
        g gVar = new g(super.onSaveInstanceState());
        d dVar = this.Q;
        if (!(dVar == null || (f2Var = dVar.h) == null)) {
            gVar.i = f2Var.a;
        }
        gVar.j = p();
        return gVar;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.H = false;
        }
        if (!this.H) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.H = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.H = false;
        }
        return true;
    }

    public boolean p() {
        ActionMenuView actionMenuView = this.g;
        if (actionMenuView != null) {
            s2 s2Var = actionMenuView.z;
            if (s2Var != null && s2Var.p()) {
                return true;
            }
        }
        return false;
    }

    public final int q(View view, int i2, int[] iArr, int i3) {
        e eVar = (e) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) eVar).leftMargin - iArr[0];
        int max = Math.max(0, i4) + i2;
        iArr[0] = Math.max(0, -i4);
        int k2 = k(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max, k2, max + measuredWidth, view.getMeasuredHeight() + k2);
        return measuredWidth + ((ViewGroup.MarginLayoutParams) eVar).rightMargin + max;
    }

    public final int r(View view, int i2, int[] iArr, int i3) {
        e eVar = (e) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) eVar).rightMargin - iArr[1];
        int max = i2 - Math.max(0, i4);
        iArr[1] = Math.max(0, -i4);
        int k2 = k(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max - measuredWidth, k2, max, view.getMeasuredHeight() + k2);
        return max - (measuredWidth + ((ViewGroup.MarginLayoutParams) eVar).leftMargin);
    }

    public final int s(View view, int i2, int i3, int i4, int i5, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i6 = marginLayoutParams.leftMargin - iArr[0];
        int i7 = marginLayoutParams.rightMargin - iArr[1];
        int max = Math.max(0, i7) + Math.max(0, i6);
        iArr[0] = Math.max(0, -i6);
        iArr[1] = Math.max(0, -i7);
        view.measure(ViewGroup.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft() + max + i3, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i4, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, marginLayoutParams.height));
        return view.getMeasuredWidth() + max;
    }

    public void setCollapseContentDescription(int i2) {
        setCollapseContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setCollapseIcon(int i2) {
        setCollapseIcon(i1.b(getContext(), i2));
    }

    public void setCollapsible(boolean z2) {
        this.T = z2;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.B) {
            this.B = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.A) {
            this.A = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i2) {
        setLogo(i1.b(getContext(), i2));
    }

    public void setLogoDescription(int i2) {
        setLogoDescription(getContext().getText(i2));
    }

    public void setNavigationContentDescription(int i2) {
        setNavigationContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setNavigationIcon(int i2) {
        setNavigationIcon(i1.b(getContext(), i2));
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        g();
        this.j.setOnClickListener(onClickListener);
    }

    public void setOnMenuItemClickListener(f fVar) {
        this.M = fVar;
    }

    public void setOverflowIcon(Drawable drawable) {
        e();
        this.g.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i2) {
        if (this.q != i2) {
            this.q = i2;
            if (i2 == 0) {
                this.p = getContext();
            } else {
                this.p = new ContextThemeWrapper(getContext(), i2);
            }
        }
    }

    public void setSubtitle(int i2) {
        setSubtitle(getContext().getText(i2));
    }

    public void setSubtitleTextColor(int i2) {
        setSubtitleTextColor(ColorStateList.valueOf(i2));
    }

    public void setTitle(int i2) {
        setTitle(getContext().getText(i2));
    }

    public void setTitleMarginBottom(int i2) {
        this.y = i2;
        requestLayout();
    }

    public void setTitleMarginEnd(int i2) {
        this.w = i2;
        requestLayout();
    }

    public void setTitleMarginStart(int i2) {
        this.v = i2;
        requestLayout();
    }

    public void setTitleMarginTop(int i2) {
        this.x = i2;
        requestLayout();
    }

    public void setTitleTextColor(int i2) {
        setTitleTextColor(ColorStateList.valueOf(i2));
    }

    public final void t(View view, int i2, int i3, int i4, int i5, int i6) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i4, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i6 >= 0) {
            if (mode != 0) {
                i6 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i6);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i6, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    public void u(int i2, int i3) {
        d();
        this.z.a(i2, i3);
    }

    public final boolean v(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    public boolean w() {
        ActionMenuView actionMenuView = this.g;
        if (actionMenuView != null) {
            s2 s2Var = actionMenuView.z;
            if (s2Var != null && s2Var.q()) {
                return true;
            }
        }
        return false;
    }

    public static class e extends k0.a {
        public int b = 0;

        public e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public e(int i, int i2) {
            super(i, i2);
            this.a = 8388627;
        }

        public e(e eVar) {
            super((k0.a) eVar);
            this.b = eVar.b;
        }

        public e(k0.a aVar) {
            super(aVar);
        }

        public e(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            ((ViewGroup.MarginLayoutParams) this).leftMargin = marginLayoutParams.leftMargin;
            ((ViewGroup.MarginLayoutParams) this).topMargin = marginLayoutParams.topMargin;
            ((ViewGroup.MarginLayoutParams) this).rightMargin = marginLayoutParams.rightMargin;
            ((ViewGroup.MarginLayoutParams) this).bottomMargin = marginLayoutParams.bottomMargin;
        }

        public e(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    public Toolbar(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.C = 8388627;
        this.J = new ArrayList<>();
        this.K = new ArrayList<>();
        this.L = new int[2];
        this.N = new a();
        this.U = new b();
        Context context2 = getContext();
        int[] iArr = j0.y;
        f4 r2 = f4.r(context2, attributeSet, iArr, i2, 0);
        co.t(this, context, iArr, attributeSet, r2.b, i2, 0);
        this.r = r2.m(28, 0);
        this.s = r2.m(19, 0);
        this.C = r2.k(0, this.C);
        this.t = r2.k(2, 48);
        int e2 = r2.e(22, 0);
        e2 = r2.p(27) ? r2.e(27, e2) : e2;
        this.y = e2;
        this.x = e2;
        this.w = e2;
        this.v = e2;
        int e3 = r2.e(25, -1);
        if (e3 >= 0) {
            this.v = e3;
        }
        int e4 = r2.e(24, -1);
        if (e4 >= 0) {
            this.w = e4;
        }
        int e5 = r2.e(26, -1);
        if (e5 >= 0) {
            this.x = e5;
        }
        int e6 = r2.e(23, -1);
        if (e6 >= 0) {
            this.y = e6;
        }
        this.u = r2.f(13, -1);
        int e7 = r2.e(9, Integer.MIN_VALUE);
        int e8 = r2.e(5, Integer.MIN_VALUE);
        int f2 = r2.f(7, 0);
        int f3 = r2.f(8, 0);
        d();
        x3 x3Var = this.z;
        x3Var.h = false;
        if (f2 != Integer.MIN_VALUE) {
            x3Var.e = f2;
            x3Var.a = f2;
        }
        if (f3 != Integer.MIN_VALUE) {
            x3Var.f = f3;
            x3Var.b = f3;
        }
        if (!(e7 == Integer.MIN_VALUE && e8 == Integer.MIN_VALUE)) {
            x3Var.a(e7, e8);
        }
        this.A = r2.e(10, Integer.MIN_VALUE);
        this.B = r2.e(6, Integer.MIN_VALUE);
        this.l = r2.g(4);
        this.m = r2.o(3);
        CharSequence o2 = r2.o(21);
        if (!TextUtils.isEmpty(o2)) {
            setTitle(o2);
        }
        CharSequence o3 = r2.o(18);
        if (!TextUtils.isEmpty(o3)) {
            setSubtitle(o3);
        }
        this.p = getContext();
        setPopupTheme(r2.m(17, 0));
        Drawable g2 = r2.g(16);
        if (g2 != null) {
            setNavigationIcon(g2);
        }
        CharSequence o4 = r2.o(15);
        if (!TextUtils.isEmpty(o4)) {
            setNavigationContentDescription(o4);
        }
        Drawable g3 = r2.g(11);
        if (g3 != null) {
            setLogo(g3);
        }
        CharSequence o5 = r2.o(12);
        if (!TextUtils.isEmpty(o5)) {
            setLogoDescription(o5);
        }
        if (r2.p(29)) {
            setTitleTextColor(r2.c(29));
        }
        if (r2.p(20)) {
            setSubtitleTextColor(r2.c(20));
        }
        if (r2.p(14)) {
            getMenuInflater().inflate(r2.m(14, 0), getMenu());
        }
        r2.b.recycle();
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new e(getContext(), attributeSet);
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            c();
        }
        ImageButton imageButton = this.n;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            c();
            this.n.setImageDrawable(drawable);
            return;
        }
        ImageButton imageButton = this.n;
        if (imageButton != null) {
            imageButton.setImageDrawable(this.l);
        }
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            if (this.k == null) {
                this.k = new AppCompatImageView(getContext(), null);
            }
            if (!o(this.k)) {
                b(this.k, true);
            }
        } else {
            ImageView imageView = this.k;
            if (imageView != null && o(imageView)) {
                removeView(this.k);
                this.K.remove(this.k);
            }
        }
        ImageView imageView2 = this.k;
        if (imageView2 != null) {
            imageView2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence) && this.k == null) {
            this.k = new AppCompatImageView(getContext(), null);
        }
        ImageView imageView = this.k;
        if (imageView != null) {
            imageView.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            g();
        }
        ImageButton imageButton = this.j;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            g();
            if (!o(this.j)) {
                b(this.j, true);
            }
        } else {
            ImageButton imageButton = this.j;
            if (imageButton != null && o(imageButton)) {
                removeView(this.j);
                this.K.remove(this.j);
            }
        }
        ImageButton imageButton2 = this.j;
        if (imageButton2 != null) {
            imageButton2.setImageDrawable(drawable);
        }
    }

    public void setSubtitle(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.i == null) {
                Context context = getContext();
                AppCompatTextView appCompatTextView = new AppCompatTextView(context);
                this.i = appCompatTextView;
                appCompatTextView.setSingleLine();
                this.i.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.s;
                if (i2 != 0) {
                    this.i.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.G;
                if (colorStateList != null) {
                    this.i.setTextColor(colorStateList);
                }
            }
            if (!o(this.i)) {
                b(this.i, true);
            }
        } else {
            TextView textView = this.i;
            if (textView != null && o(textView)) {
                removeView(this.i);
                this.K.remove(this.i);
            }
        }
        TextView textView2 = this.i;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.E = charSequence;
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.G = colorStateList;
        TextView textView = this.i;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.h == null) {
                Context context = getContext();
                AppCompatTextView appCompatTextView = new AppCompatTextView(context);
                this.h = appCompatTextView;
                appCompatTextView.setSingleLine();
                this.h.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.r;
                if (i2 != 0) {
                    this.h.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.F;
                if (colorStateList != null) {
                    this.h.setTextColor(colorStateList);
                }
            }
            if (!o(this.h)) {
                b(this.h, true);
            }
        } else {
            TextView textView = this.h;
            if (textView != null && o(textView)) {
                removeView(this.h);
                this.K.remove(this.h);
            }
        }
        TextView textView2 = this.h;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.D = charSequence;
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.F = colorStateList;
        TextView textView = this.h;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public static class g extends dp {
        public static final Parcelable.Creator<g> CREATOR = new a();
        public int i;
        public boolean j;

        public class a implements Parcelable.ClassLoaderCreator<g> {
            /* Return type fixed from 'java.lang.Object' to match base method */
            @Override // android.os.Parcelable.ClassLoaderCreator
            public g createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new g(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            public Object[] newArray(int i) {
                return new g[i];
            }

            @Override // android.os.Parcelable.Creator
            public Object createFromParcel(Parcel parcel) {
                return new g(parcel, null);
            }
        }

        public g(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.i = parcel.readInt();
            this.j = parcel.readInt() != 0;
        }

        @Override // defpackage.dp
        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeParcelable(this.g, i2);
            parcel.writeInt(this.i);
            parcel.writeInt(this.j ? 1 : 0);
        }

        public g(Parcelable parcelable) {
            super(parcelable);
        }
    }
}
