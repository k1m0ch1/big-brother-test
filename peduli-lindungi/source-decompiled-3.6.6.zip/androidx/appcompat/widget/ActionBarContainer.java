package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.telkom.tracencare.R;
import defpackage.co;
import java.util.concurrent.atomic.AtomicInteger;

public class ActionBarContainer extends FrameLayout {
    public boolean g;
    public View h;
    public View i;
    public View j;
    public Drawable k;
    public Drawable l;
    public Drawable m;
    public boolean n;
    public boolean o;
    public int p;

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        r2 r2Var = new r2(this);
        AtomicInteger atomicInteger = co.a;
        co.c.q(this, r2Var);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j0.a);
        boolean z = false;
        this.k = obtainStyledAttributes.getDrawable(0);
        this.l = obtainStyledAttributes.getDrawable(2);
        this.p = obtainStyledAttributes.getDimensionPixelSize(13, -1);
        if (getId() == R.id.split_action_bar) {
            this.n = true;
            this.m = obtainStyledAttributes.getDrawable(1);
        }
        obtainStyledAttributes.recycle();
        if (!this.n ? this.k == null && this.l == null : this.m == null) {
            z = true;
        }
        setWillNotDraw(z);
    }

    public final int a(View view) {
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
        return view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    }

    public final boolean b(View view) {
        return view == null || view.getVisibility() == 8 || view.getMeasuredHeight() == 0;
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.k;
        if (drawable != null && drawable.isStateful()) {
            this.k.setState(getDrawableState());
        }
        Drawable drawable2 = this.l;
        if (drawable2 != null && drawable2.isStateful()) {
            this.l.setState(getDrawableState());
        }
        Drawable drawable3 = this.m;
        if (drawable3 != null && drawable3.isStateful()) {
            this.m.setState(getDrawableState());
        }
    }

    public View getTabContainer() {
        return this.h;
    }

    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.k;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.l;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        Drawable drawable3 = this.m;
        if (drawable3 != null) {
            drawable3.jumpToCurrentState();
        }
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        this.i = findViewById(R.id.action_bar);
        this.j = findViewById(R.id.action_context_bar);
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.g || super.onInterceptTouchEvent(motionEvent);
    }

    public void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        Drawable drawable;
        super.onLayout(z, i2, i3, i4, i5);
        View view = this.h;
        boolean z2 = true;
        boolean z3 = false;
        boolean z4 = (view == null || view.getVisibility() == 8) ? false : true;
        if (!(view == null || view.getVisibility() == 8)) {
            int measuredHeight = getMeasuredHeight();
            int i6 = ((FrameLayout.LayoutParams) view.getLayoutParams()).bottomMargin;
            view.layout(i2, (measuredHeight - view.getMeasuredHeight()) - i6, i4, measuredHeight - i6);
        }
        if (this.n) {
            Drawable drawable2 = this.m;
            if (drawable2 != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            } else {
                z2 = false;
            }
        } else {
            if (this.k != null) {
                if (this.i.getVisibility() == 0) {
                    this.k.setBounds(this.i.getLeft(), this.i.getTop(), this.i.getRight(), this.i.getBottom());
                } else {
                    View view2 = this.j;
                    if (view2 == null || view2.getVisibility() != 0) {
                        this.k.setBounds(0, 0, 0, 0);
                    } else {
                        this.k.setBounds(this.j.getLeft(), this.j.getTop(), this.j.getRight(), this.j.getBottom());
                    }
                }
                z3 = true;
            }
            this.o = z4;
            if (!z4 || (drawable = this.l) == null) {
                z2 = z3;
            } else {
                drawable.setBounds(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
            }
        }
        if (z2) {
            invalidate();
        }
    }

    public void onMeasure(int i2, int i3) {
        int i4;
        int i5;
        if (this.i == null && View.MeasureSpec.getMode(i3) == Integer.MIN_VALUE && (i5 = this.p) >= 0) {
            i3 = View.MeasureSpec.makeMeasureSpec(Math.min(i5, View.MeasureSpec.getSize(i3)), Integer.MIN_VALUE);
        }
        super.onMeasure(i2, i3);
        if (this.i != null) {
            int mode = View.MeasureSpec.getMode(i3);
            View view = this.h;
            if (view != null && view.getVisibility() != 8 && mode != 1073741824) {
                if (!b(this.i)) {
                    i4 = a(this.i);
                } else {
                    i4 = !b(this.j) ? a(this.j) : 0;
                }
                setMeasuredDimension(getMeasuredWidth(), Math.min(a(this.h) + i4, mode == Integer.MIN_VALUE ? View.MeasureSpec.getSize(i3) : Integer.MAX_VALUE));
            }
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable) {
        Drawable drawable2 = this.k;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.k);
        }
        this.k = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            View view = this.i;
            if (view != null) {
                this.k.setBounds(view.getLeft(), this.i.getTop(), this.i.getRight(), this.i.getBottom());
            }
        }
        boolean z = true;
        if (!this.n ? !(this.k == null && this.l == null) : this.m != null) {
            z = false;
        }
        setWillNotDraw(z);
        invalidate();
        invalidateOutline();
    }

    public void setSplitBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.m;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.m);
        }
        this.m = drawable;
        boolean z = false;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.n && (drawable2 = this.m) != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (!this.n ? this.k == null && this.l == null : this.m == null) {
            z = true;
        }
        setWillNotDraw(z);
        invalidate();
        invalidateOutline();
    }

    public void setStackedBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.l;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.l);
        }
        this.l = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.o && (drawable2 = this.l) != null) {
                drawable2.setBounds(this.h.getLeft(), this.h.getTop(), this.h.getRight(), this.h.getBottom());
            }
        }
        boolean z = true;
        if (!this.n ? !(this.k == null && this.l == null) : this.m != null) {
            z = false;
        }
        setWillNotDraw(z);
        invalidate();
        invalidateOutline();
    }

    public void setTabContainer(y3 y3Var) {
        View view = this.h;
        if (view != null) {
            removeView(view);
        }
        this.h = y3Var;
        if (y3Var != null) {
            addView(y3Var);
            ViewGroup.LayoutParams layoutParams = y3Var.getLayoutParams();
            layoutParams.width = -1;
            layoutParams.height = -2;
            y3Var.setAllowCollapse(false);
        }
    }

    public void setTransitioning(boolean z) {
        this.g = z;
        setDescendantFocusability(z ? 393216 : 262144);
    }

    public void setVisibility(int i2) {
        super.setVisibility(i2);
        boolean z = i2 == 0;
        Drawable drawable = this.k;
        if (drawable != null) {
            drawable.setVisible(z, false);
        }
        Drawable drawable2 = this.l;
        if (drawable2 != null) {
            drawable2.setVisible(z, false);
        }
        Drawable drawable3 = this.m;
        if (drawable3 != null) {
            drawable3.setVisible(z, false);
        }
    }

    public ActionMode startActionModeForChild(View view, ActionMode.Callback callback) {
        return null;
    }

    public ActionMode startActionModeForChild(View view, ActionMode.Callback callback, int i2) {
        if (i2 != 0) {
            return super.startActionModeForChild(view, callback, i2);
        }
        return null;
    }

    public boolean verifyDrawable(Drawable drawable) {
        return (drawable == this.k && !this.n) || (drawable == this.l && this.o) || ((drawable == this.m && this.n) || super.verifyDrawable(drawable));
    }
}
