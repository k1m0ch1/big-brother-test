package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.CheckBox;
import com.telkom.tracencare.R;

public class AppCompatCheckBox extends CheckBox {
    public final w2 g;
    public final u2 h;
    public final i3 i;

    public AppCompatCheckBox(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.checkboxStyle);
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        u2 u2Var = this.h;
        if (u2Var != null) {
            u2Var.a();
        }
        i3 i3Var = this.i;
        if (i3Var != null) {
            i3Var.b();
        }
    }

    public int getCompoundPaddingLeft() {
        int compoundPaddingLeft = super.getCompoundPaddingLeft();
        w2 w2Var = this.g;
        return compoundPaddingLeft;
    }

    public ColorStateList getSupportBackgroundTintList() {
        u2 u2Var = this.h;
        if (u2Var != null) {
            return u2Var.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        u2 u2Var = this.h;
        if (u2Var != null) {
            return u2Var.c();
        }
        return null;
    }

    public ColorStateList getSupportButtonTintList() {
        w2 w2Var = this.g;
        if (w2Var != null) {
            return w2Var.b;
        }
        return null;
    }

    public PorterDuff.Mode getSupportButtonTintMode() {
        w2 w2Var = this.g;
        if (w2Var != null) {
            return w2Var.c;
        }
        return null;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        u2 u2Var = this.h;
        if (u2Var != null) {
            u2Var.e();
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        u2 u2Var = this.h;
        if (u2Var != null) {
            u2Var.f(i2);
        }
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(Drawable drawable) {
        super.setButtonDrawable(drawable);
        w2 w2Var = this.g;
        if (w2Var == null) {
            return;
        }
        if (w2Var.f) {
            w2Var.f = false;
            return;
        }
        w2Var.f = true;
        w2Var.a();
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        u2 u2Var = this.h;
        if (u2Var != null) {
            u2Var.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        u2 u2Var = this.h;
        if (u2Var != null) {
            u2Var.i(mode);
        }
    }

    public void setSupportButtonTintList(ColorStateList colorStateList) {
        w2 w2Var = this.g;
        if (w2Var != null) {
            w2Var.b = colorStateList;
            w2Var.d = true;
            w2Var.a();
        }
    }

    public void setSupportButtonTintMode(PorterDuff.Mode mode) {
        w2 w2Var = this.g;
        if (w2Var != null) {
            w2Var.c = mode;
            w2Var.e = true;
            w2Var.a();
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppCompatCheckBox(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        c4.a(context);
        a4.a(this, getContext());
        w2 w2Var = new w2(this);
        this.g = w2Var;
        w2Var.b(attributeSet, i2);
        u2 u2Var = new u2(this);
        this.h = u2Var;
        u2Var.d(attributeSet, i2);
        i3 i3Var = new i3(this);
        this.i = i3Var;
        i3Var.e(attributeSet, i2);
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(int i2) {
        setButtonDrawable(i1.b(getContext(), i2));
    }
}
