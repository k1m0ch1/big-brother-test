package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageView;

public class AppCompatImageView extends ImageView {
    public final u2 g;
    public final y2 h;

    public AppCompatImageView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        u2 u2Var = this.g;
        if (u2Var != null) {
            u2Var.a();
        }
        y2 y2Var = this.h;
        if (y2Var != null) {
            y2Var.a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        u2 u2Var = this.g;
        if (u2Var != null) {
            return u2Var.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        u2 u2Var = this.g;
        if (u2Var != null) {
            return u2Var.c();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        d4 d4Var;
        y2 y2Var = this.h;
        if (y2Var == null || (d4Var = y2Var.b) == null) {
            return null;
        }
        return d4Var.a;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        d4 d4Var;
        y2 y2Var = this.h;
        if (y2Var == null || (d4Var = y2Var.b) == null) {
            return null;
        }
        return d4Var.b;
    }

    public boolean hasOverlappingRendering() {
        if (!(!(this.h.a.getBackground() instanceof RippleDrawable)) || !super.hasOverlappingRendering()) {
            return false;
        }
        return true;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        u2 u2Var = this.g;
        if (u2Var != null) {
            u2Var.e();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        u2 u2Var = this.g;
        if (u2Var != null) {
            u2Var.f(i);
        }
    }

    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        y2 y2Var = this.h;
        if (y2Var != null) {
            y2Var.a();
        }
    }

    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        y2 y2Var = this.h;
        if (y2Var != null) {
            y2Var.a();
        }
    }

    public void setImageResource(int i) {
        y2 y2Var = this.h;
        if (y2Var != null) {
            y2Var.c(i);
        }
    }

    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        y2 y2Var = this.h;
        if (y2Var != null) {
            y2Var.a();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        u2 u2Var = this.g;
        if (u2Var != null) {
            u2Var.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        u2 u2Var = this.g;
        if (u2Var != null) {
            u2Var.i(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        y2 y2Var = this.h;
        if (y2Var != null) {
            y2Var.d(colorStateList);
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        y2 y2Var = this.h;
        if (y2Var != null) {
            y2Var.e(mode);
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppCompatImageView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        c4.a(context);
        a4.a(this, getContext());
        u2 u2Var = new u2(this);
        this.g = u2Var;
        u2Var.d(attributeSet, i);
        y2 y2Var = new y2(this);
        this.h = y2Var;
        y2Var.b(attributeSet, i);
    }
}
