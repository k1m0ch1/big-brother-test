package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import com.telkom.tracencare.R;

public class AppCompatButton extends Button implements to, zo {
    public final u2 g;
    public final i3 h;

    public AppCompatButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.buttonStyle);
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        u2 u2Var = this.g;
        if (u2Var != null) {
            u2Var.a();
        }
        i3 i3Var = this.h;
        if (i3Var != null) {
            i3Var.b();
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (to.a) {
            return super.getAutoSizeMaxTextSize();
        }
        i3 i3Var = this.h;
        if (i3Var != null) {
            return Math.round(i3Var.i.e);
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (to.a) {
            return super.getAutoSizeMinTextSize();
        }
        i3 i3Var = this.h;
        if (i3Var != null) {
            return Math.round(i3Var.i.d);
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (to.a) {
            return super.getAutoSizeStepGranularity();
        }
        i3 i3Var = this.h;
        if (i3Var != null) {
            return Math.round(i3Var.i.c);
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        if (to.a) {
            return super.getAutoSizeTextAvailableSizes();
        }
        i3 i3Var = this.h;
        return i3Var != null ? i3Var.i.f : new int[0];
    }

    @SuppressLint({"WrongConstant"})
    public int getAutoSizeTextType() {
        if (!to.a) {
            i3 i3Var = this.h;
            if (i3Var != null) {
                return i3Var.i.a;
            }
            return 0;
        } else if (super.getAutoSizeTextType() == 1) {
            return 1;
        } else {
            return 0;
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        u2 u2Var = this.g;
        if (u2Var != null) {
            return u2Var.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        u2 u2Var = this.g;
        if (u2Var != null) {
            return u2Var.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        d4 d4Var = this.h.h;
        if (d4Var != null) {
            return d4Var.a;
        }
        return null;
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        d4 d4Var = this.h.h;
        if (d4Var != null) {
            return d4Var.b;
        }
        return null;
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(Button.class.getName());
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(Button.class.getName());
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        i3 i3Var = this.h;
        if (i3Var != null && !to.a) {
            i3Var.i.a();
        }
    }

    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        super.onTextChanged(charSequence, i, i2, i3);
        i3 i3Var = this.h;
        if (i3Var != null && !to.a && i3Var.d()) {
            this.h.i.a();
        }
    }

    public void setAutoSizeTextTypeUniformWithConfiguration(int i, int i2, int i3, int i4) {
        if (to.a) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i, i2, i3, i4);
            return;
        }
        i3 i3Var = this.h;
        if (i3Var != null) {
            i3Var.g(i, i2, i3, i4);
        }
    }

    public void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i) {
        if (to.a) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i);
            return;
        }
        i3 i3Var = this.h;
        if (i3Var != null) {
            i3Var.h(iArr, i);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i) {
        if (to.a) {
            super.setAutoSizeTextTypeWithDefaults(i);
            return;
        }
        i3 i3Var = this.h;
        if (i3Var != null) {
            i3Var.i(i);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        u2 u2Var = this.g;
        if (u2Var != null) {
            u2Var.e();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        u2 u2Var = this.g;
        if (u2Var != null) {
            u2Var.f(i);
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(ek.t0(this, callback));
    }

    public void setSupportAllCaps(boolean z) {
        i3 i3Var = this.h;
        if (i3Var != null) {
            i3Var.a.setAllCaps(z);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        u2 u2Var = this.g;
        if (u2Var != null) {
            u2Var.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        u2 u2Var = this.g;
        if (u2Var != null) {
            u2Var.i(mode);
        }
    }

    @Override // defpackage.zo
    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.h.j(colorStateList);
        this.h.b();
    }

    @Override // defpackage.zo
    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.h.k(mode);
        this.h.b();
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        i3 i3Var = this.h;
        if (i3Var != null) {
            i3Var.f(context, i);
        }
    }

    public void setTextSize(int i, float f) {
        boolean z = to.a;
        if (z) {
            super.setTextSize(i, f);
            return;
        }
        i3 i3Var = this.h;
        if (i3Var != null && !z && !i3Var.d()) {
            i3Var.i.f(i, f);
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppCompatButton(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        c4.a(context);
        a4.a(this, getContext());
        u2 u2Var = new u2(this);
        this.g = u2Var;
        u2Var.d(attributeSet, i);
        i3 i3Var = new i3(this);
        this.h = i3Var;
        i3Var.e(attributeSet, i);
        i3Var.b();
    }
}
