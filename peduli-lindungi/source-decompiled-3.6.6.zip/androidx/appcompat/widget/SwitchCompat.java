package androidx.appcompat.widget;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.Property;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import com.github.mikephil.charting.utils.Utils;
import com.telkom.tracencare.R;
import defpackage.co;
import java.util.concurrent.atomic.AtomicInteger;

public class SwitchCompat extends CompoundButton {
    public static final Property<SwitchCompat, Float> T = new a(Float.class, "thumbPos");
    public static final int[] U = {16842912};
    public float A;
    public VelocityTracker B = VelocityTracker.obtain();
    public int C;
    public float D;
    public int E;
    public int F;
    public int G;
    public int H;
    public int I;
    public int J;
    public int K;
    public final TextPaint L;
    public ColorStateList M;
    public Layout N;
    public Layout O;
    public TransformationMethod P;
    public ObjectAnimator Q;
    public final i3 R;
    public final Rect S = new Rect();
    public Drawable g;
    public ColorStateList h = null;
    public PorterDuff.Mode i = null;
    public boolean j = false;
    public boolean k = false;
    public Drawable l;
    public ColorStateList m = null;
    public PorterDuff.Mode n = null;
    public boolean o = false;
    public boolean p = false;
    public int q;
    public int r;
    public int s;
    public boolean t;
    public CharSequence u;
    public CharSequence v;
    public boolean w;
    public int x;
    public int y;
    public float z;

    public class a extends Property<SwitchCompat, Float> {
        public a(Class cls, String str) {
            super(cls, str);
        }

        /* Return type fixed from 'java.lang.Object' to match base method */
        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object] */
        @Override // android.util.Property
        public Float get(SwitchCompat switchCompat) {
            return Float.valueOf(switchCompat.D);
        }

        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object, java.lang.Object] */
        @Override // android.util.Property
        public void set(SwitchCompat switchCompat, Float f) {
            switchCompat.setThumbPosition(f.floatValue());
        }
    }

    public SwitchCompat(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.switchStyle);
        Typeface typeface;
        Typeface typeface2;
        int resourceId;
        a4.a(this, getContext());
        boolean z2 = true;
        TextPaint textPaint = new TextPaint(1);
        this.L = textPaint;
        textPaint.density = getResources().getDisplayMetrics().density;
        int[] iArr = j0.w;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, R.attr.switchStyle, 0);
        f4 f4Var = new f4(context, obtainStyledAttributes);
        co.t(this, context, iArr, attributeSet, obtainStyledAttributes, R.attr.switchStyle, 0);
        Drawable g2 = f4Var.g(2);
        this.g = g2;
        if (g2 != null) {
            g2.setCallback(this);
        }
        Drawable g3 = f4Var.g(11);
        this.l = g3;
        if (g3 != null) {
            g3.setCallback(this);
        }
        this.u = f4Var.o(0);
        this.v = f4Var.o(1);
        this.w = f4Var.a(3, true);
        this.q = f4Var.f(8, 0);
        this.r = f4Var.f(5, 0);
        this.s = f4Var.f(6, 0);
        this.t = f4Var.a(4, false);
        ColorStateList c = f4Var.c(9);
        if (c != null) {
            this.h = c;
            this.j = true;
        }
        PorterDuff.Mode d = m3.d(f4Var.j(10, -1), null);
        if (this.i != d) {
            this.i = d;
            this.k = true;
        }
        if (this.j || this.k) {
            a();
        }
        ColorStateList c2 = f4Var.c(12);
        if (c2 != null) {
            this.m = c2;
            this.o = true;
        }
        PorterDuff.Mode d2 = m3.d(f4Var.j(13, -1), null);
        if (this.n != d2) {
            this.n = d2;
            this.p = true;
        }
        if (this.o || this.p) {
            b();
        }
        int m2 = f4Var.m(7, 0);
        if (m2 != 0) {
            TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(m2, j0.x);
            ColorStateList colorStateList = (!obtainStyledAttributes2.hasValue(3) || (resourceId = obtainStyledAttributes2.getResourceId(3, 0)) == 0 || (colorStateList = i1.a(context, resourceId)) == null) ? obtainStyledAttributes2.getColorStateList(3) : colorStateList;
            if (colorStateList != null) {
                this.M = colorStateList;
            } else {
                this.M = getTextColors();
            }
            int dimensionPixelSize = obtainStyledAttributes2.getDimensionPixelSize(0, 0);
            if (dimensionPixelSize != 0) {
                float f = (float) dimensionPixelSize;
                if (f != textPaint.getTextSize()) {
                    textPaint.setTextSize(f);
                    requestLayout();
                }
            }
            int i2 = obtainStyledAttributes2.getInt(1, -1);
            int i3 = obtainStyledAttributes2.getInt(2, -1);
            if (i2 == 1) {
                typeface = Typeface.SANS_SERIF;
            } else if (i2 == 2) {
                typeface = Typeface.SERIF;
            } else if (i2 != 3) {
                typeface = null;
            } else {
                typeface = Typeface.MONOSPACE;
            }
            float f2 = Utils.FLOAT_EPSILON;
            if (i3 > 0) {
                if (typeface == null) {
                    typeface2 = Typeface.defaultFromStyle(i3);
                } else {
                    typeface2 = Typeface.create(typeface, i3);
                }
                setSwitchTypeface(typeface2);
                int i4 = (~(typeface2 != null ? typeface2.getStyle() : 0)) & i3;
                textPaint.setFakeBoldText((i4 & 1) == 0 ? false : z2);
                textPaint.setTextSkewX((i4 & 2) != 0 ? -0.25f : f2);
            } else {
                textPaint.setFakeBoldText(false);
                textPaint.setTextSkewX(Utils.FLOAT_EPSILON);
                setSwitchTypeface(typeface);
            }
            if (obtainStyledAttributes2.getBoolean(14, false)) {
                this.P = new o1(getContext());
            } else {
                this.P = null;
            }
            obtainStyledAttributes2.recycle();
        }
        i3 i3Var = new i3(this);
        this.R = i3Var;
        i3Var.e(attributeSet, R.attr.switchStyle);
        f4Var.b.recycle();
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.y = viewConfiguration.getScaledTouchSlop();
        this.C = viewConfiguration.getScaledMinimumFlingVelocity();
        refreshDrawableState();
        setChecked(isChecked());
    }

    private boolean getTargetCheckedState() {
        return this.D > 0.5f;
    }

    private int getThumbOffset() {
        float f;
        if (l4.b(this)) {
            f = 1.0f - this.D;
        } else {
            f = this.D;
        }
        return (int) ((f * ((float) getThumbScrollRange())) + 0.5f);
    }

    private int getThumbScrollRange() {
        Rect rect;
        Drawable drawable = this.l;
        if (drawable == null) {
            return 0;
        }
        Rect rect2 = this.S;
        drawable.getPadding(rect2);
        Drawable drawable2 = this.g;
        if (drawable2 != null) {
            rect = m3.c(drawable2);
        } else {
            rect = m3.c;
        }
        return ((((this.E - this.G) - rect2.left) - rect2.right) - rect.left) - rect.right;
    }

    public final void a() {
        Drawable drawable = this.g;
        if (drawable == null) {
            return;
        }
        if (this.j || this.k) {
            Drawable mutate = ek.s0(drawable).mutate();
            this.g = mutate;
            if (this.j) {
                mutate.setTintList(this.h);
            }
            if (this.k) {
                this.g.setTintMode(this.i);
            }
            if (this.g.isStateful()) {
                this.g.setState(getDrawableState());
            }
        }
    }

    public final void b() {
        Drawable drawable = this.l;
        if (drawable == null) {
            return;
        }
        if (this.o || this.p) {
            Drawable mutate = ek.s0(drawable).mutate();
            this.l = mutate;
            if (this.o) {
                mutate.setTintList(this.m);
            }
            if (this.p) {
                this.l.setTintMode(this.n);
            }
            if (this.l.isStateful()) {
                this.l.setState(getDrawableState());
            }
        }
    }

    public final Layout c(CharSequence charSequence) {
        TransformationMethod transformationMethod = this.P;
        if (transformationMethod != null) {
            charSequence = transformationMethod.getTransformation(charSequence, this);
        }
        TextPaint textPaint = this.L;
        return new StaticLayout(charSequence, textPaint, charSequence != null ? (int) Math.ceil((double) Layout.getDesiredWidth(charSequence, textPaint)) : 0, Layout.Alignment.ALIGN_NORMAL, 1.0f, Utils.FLOAT_EPSILON, true);
    }

    public void draw(Canvas canvas) {
        Rect rect;
        int i2;
        int i3;
        Rect rect2 = this.S;
        int i4 = this.H;
        int i5 = this.I;
        int i6 = this.J;
        int i7 = this.K;
        int thumbOffset = getThumbOffset() + i4;
        Drawable drawable = this.g;
        if (drawable != null) {
            rect = m3.c(drawable);
        } else {
            rect = m3.c;
        }
        Drawable drawable2 = this.l;
        if (drawable2 != null) {
            drawable2.getPadding(rect2);
            int i8 = rect2.left;
            thumbOffset += i8;
            if (rect != null) {
                int i9 = rect.left;
                if (i9 > i8) {
                    i4 += i9 - i8;
                }
                int i10 = rect.top;
                int i11 = rect2.top;
                i2 = i10 > i11 ? (i10 - i11) + i5 : i5;
                int i12 = rect.right;
                int i13 = rect2.right;
                if (i12 > i13) {
                    i6 -= i12 - i13;
                }
                int i14 = rect.bottom;
                int i15 = rect2.bottom;
                if (i14 > i15) {
                    i3 = i7 - (i14 - i15);
                    this.l.setBounds(i4, i2, i6, i3);
                }
            } else {
                i2 = i5;
            }
            i3 = i7;
            this.l.setBounds(i4, i2, i6, i3);
        }
        Drawable drawable3 = this.g;
        if (drawable3 != null) {
            drawable3.getPadding(rect2);
            int i16 = thumbOffset - rect2.left;
            int i17 = thumbOffset + this.G + rect2.right;
            this.g.setBounds(i16, i5, i17, i7);
            Drawable background = getBackground();
            if (background != null) {
                background.setHotspotBounds(i16, i5, i17, i7);
            }
        }
        super.draw(canvas);
    }

    public void drawableHotspotChanged(float f, float f2) {
        super.drawableHotspotChanged(f, f2);
        Drawable drawable = this.g;
        if (drawable != null) {
            drawable.setHotspot(f, f2);
        }
        Drawable drawable2 = this.l;
        if (drawable2 != null) {
            drawable2.setHotspot(f, f2);
        }
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.g;
        boolean z2 = false;
        if (drawable != null && drawable.isStateful()) {
            z2 = false | drawable.setState(drawableState);
        }
        Drawable drawable2 = this.l;
        if (drawable2 != null && drawable2.isStateful()) {
            z2 |= drawable2.setState(drawableState);
        }
        if (z2) {
            invalidate();
        }
    }

    public int getCompoundPaddingLeft() {
        if (!l4.b(this)) {
            return super.getCompoundPaddingLeft();
        }
        int compoundPaddingLeft = super.getCompoundPaddingLeft() + this.E;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingLeft + this.s : compoundPaddingLeft;
    }

    public int getCompoundPaddingRight() {
        if (l4.b(this)) {
            return super.getCompoundPaddingRight();
        }
        int compoundPaddingRight = super.getCompoundPaddingRight() + this.E;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingRight + this.s : compoundPaddingRight;
    }

    public boolean getShowText() {
        return this.w;
    }

    public boolean getSplitTrack() {
        return this.t;
    }

    public int getSwitchMinWidth() {
        return this.r;
    }

    public int getSwitchPadding() {
        return this.s;
    }

    public CharSequence getTextOff() {
        return this.v;
    }

    public CharSequence getTextOn() {
        return this.u;
    }

    public Drawable getThumbDrawable() {
        return this.g;
    }

    public int getThumbTextPadding() {
        return this.q;
    }

    public ColorStateList getThumbTintList() {
        return this.h;
    }

    public PorterDuff.Mode getThumbTintMode() {
        return this.i;
    }

    public Drawable getTrackDrawable() {
        return this.l;
    }

    public ColorStateList getTrackTintList() {
        return this.m;
    }

    public PorterDuff.Mode getTrackTintMode() {
        return this.n;
    }

    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.g;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.l;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        ObjectAnimator objectAnimator = this.Q;
        if (objectAnimator != null && objectAnimator.isStarted()) {
            this.Q.end();
            this.Q = null;
        }
    }

    public int[] onCreateDrawableState(int i2) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i2 + 1);
        if (isChecked()) {
            CompoundButton.mergeDrawableStates(onCreateDrawableState, U);
        }
        return onCreateDrawableState;
    }

    public void onDraw(Canvas canvas) {
        int i2;
        super.onDraw(canvas);
        Rect rect = this.S;
        Drawable drawable = this.l;
        if (drawable != null) {
            drawable.getPadding(rect);
        } else {
            rect.setEmpty();
        }
        int i3 = this.I;
        int i4 = this.K;
        int i5 = i3 + rect.top;
        int i6 = i4 - rect.bottom;
        Drawable drawable2 = this.g;
        if (drawable != null) {
            if (!this.t || drawable2 == null) {
                drawable.draw(canvas);
            } else {
                Rect c = m3.c(drawable2);
                drawable2.copyBounds(rect);
                rect.left += c.left;
                rect.right -= c.right;
                int save = canvas.save();
                canvas.clipRect(rect, Region.Op.DIFFERENCE);
                drawable.draw(canvas);
                canvas.restoreToCount(save);
            }
        }
        int save2 = canvas.save();
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
        Layout layout = getTargetCheckedState() ? this.N : this.O;
        if (layout != null) {
            int[] drawableState = getDrawableState();
            ColorStateList colorStateList = this.M;
            if (colorStateList != null) {
                this.L.setColor(colorStateList.getColorForState(drawableState, 0));
            }
            this.L.drawableState = drawableState;
            if (drawable2 != null) {
                Rect bounds = drawable2.getBounds();
                i2 = bounds.left + bounds.right;
            } else {
                i2 = getWidth();
            }
            canvas.translate((float) ((i2 / 2) - (layout.getWidth() / 2)), (float) (((i5 + i6) / 2) - (layout.getHeight() / 2)));
            layout.draw(canvas);
        }
        canvas.restoreToCount(save2);
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("android.widget.Switch");
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("android.widget.Switch");
        CharSequence charSequence = isChecked() ? this.u : this.v;
        if (!TextUtils.isEmpty(charSequence)) {
            CharSequence text = accessibilityNodeInfo.getText();
            if (TextUtils.isEmpty(text)) {
                accessibilityNodeInfo.setText(charSequence);
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append(text);
            sb.append(' ');
            sb.append(charSequence);
            accessibilityNodeInfo.setText(sb);
        }
    }

    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        super.onLayout(z2, i2, i3, i4, i5);
        int i11 = 0;
        if (this.g != null) {
            Rect rect = this.S;
            Drawable drawable = this.l;
            if (drawable != null) {
                drawable.getPadding(rect);
            } else {
                rect.setEmpty();
            }
            Rect c = m3.c(this.g);
            i6 = Math.max(0, c.left - rect.left);
            i11 = Math.max(0, c.right - rect.right);
        } else {
            i6 = 0;
        }
        if (l4.b(this)) {
            i8 = getPaddingLeft() + i6;
            i7 = ((this.E + i8) - i6) - i11;
        } else {
            i7 = (getWidth() - getPaddingRight()) - i11;
            i8 = (i7 - this.E) + i6 + i11;
        }
        int gravity = getGravity() & com.google.maps.android.R.styleable.AppCompatTheme_tooltipForegroundColor;
        if (gravity == 16) {
            int paddingTop = getPaddingTop();
            int i12 = this.F;
            int height = (((getHeight() + paddingTop) - getPaddingBottom()) / 2) - (i12 / 2);
            i9 = i12 + height;
            i10 = height;
        } else if (gravity != 80) {
            i10 = getPaddingTop();
            i9 = this.F + i10;
        } else {
            i9 = getHeight() - getPaddingBottom();
            i10 = i9 - this.F;
        }
        this.H = i8;
        this.I = i10;
        this.K = i9;
        this.J = i7;
    }

    public void onMeasure(int i2, int i3) {
        int i4;
        int i5;
        int i6;
        if (this.w) {
            if (this.N == null) {
                this.N = c(this.u);
            }
            if (this.O == null) {
                this.O = c(this.v);
            }
        }
        Rect rect = this.S;
        Drawable drawable = this.g;
        int i7 = 0;
        if (drawable != null) {
            drawable.getPadding(rect);
            i5 = (this.g.getIntrinsicWidth() - rect.left) - rect.right;
            i4 = this.g.getIntrinsicHeight();
        } else {
            i5 = 0;
            i4 = 0;
        }
        if (this.w) {
            i6 = (this.q * 2) + Math.max(this.N.getWidth(), this.O.getWidth());
        } else {
            i6 = 0;
        }
        this.G = Math.max(i6, i5);
        Drawable drawable2 = this.l;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            i7 = this.l.getIntrinsicHeight();
        } else {
            rect.setEmpty();
        }
        int i8 = rect.left;
        int i9 = rect.right;
        Drawable drawable3 = this.g;
        if (drawable3 != null) {
            Rect c = m3.c(drawable3);
            i8 = Math.max(i8, c.left);
            i9 = Math.max(i9, c.right);
        }
        int max = Math.max(this.r, (this.G * 2) + i8 + i9);
        int max2 = Math.max(i7, i4);
        this.E = max;
        this.F = max2;
        super.onMeasure(i2, i3);
        if (getMeasuredHeight() < max2) {
            setMeasuredDimension(getMeasuredWidthAndState(), max2);
        }
    }

    public void onPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onPopulateAccessibilityEvent(accessibilityEvent);
        CharSequence charSequence = isChecked() ? this.u : this.v;
        if (charSequence != null) {
            accessibilityEvent.getText().add(charSequence);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0014, code lost:
        if (r0 != 3) goto L_0x0153;
     */
    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z2;
        this.B.addMovement(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        boolean z3 = false;
        if (actionMasked != 0) {
            float f = Utils.FLOAT_EPSILON;
            if (actionMasked != 1) {
                if (actionMasked == 2) {
                    int i2 = this.x;
                    if (i2 == 1) {
                        float x2 = motionEvent.getX();
                        float y2 = motionEvent.getY();
                        if (Math.abs(x2 - this.z) > ((float) this.y) || Math.abs(y2 - this.A) > ((float) this.y)) {
                            this.x = 2;
                            getParent().requestDisallowInterceptTouchEvent(true);
                            this.z = x2;
                            this.A = y2;
                            return true;
                        }
                    } else if (i2 == 2) {
                        float x3 = motionEvent.getX();
                        int thumbScrollRange = getThumbScrollRange();
                        float f2 = x3 - this.z;
                        float f3 = thumbScrollRange != 0 ? f2 / ((float) thumbScrollRange) : f2 > Utils.FLOAT_EPSILON ? 1.0f : -1.0f;
                        if (l4.b(this)) {
                            f3 = -f3;
                        }
                        float f4 = this.D;
                        float f5 = f3 + f4;
                        if (f5 >= Utils.FLOAT_EPSILON) {
                            f = f5 > 1.0f ? 1.0f : f5;
                        }
                        if (f != f4) {
                            this.z = x3;
                            setThumbPosition(f);
                        }
                        return true;
                    }
                }
            }
            if (this.x == 2) {
                this.x = 0;
                boolean z4 = motionEvent.getAction() == 1 && isEnabled();
                boolean isChecked = isChecked();
                if (z4) {
                    this.B.computeCurrentVelocity(vf0.DEFAULT_IMAGE_TIMEOUT_MS);
                    float xVelocity = this.B.getXVelocity();
                    z2 = Math.abs(xVelocity) > ((float) this.C) ? !l4.b(this) ? xVelocity > Utils.FLOAT_EPSILON : xVelocity < Utils.FLOAT_EPSILON : getTargetCheckedState();
                } else {
                    z2 = isChecked;
                }
                if (z2 != isChecked) {
                    playSoundEffect(0);
                }
                setChecked(z2);
                MotionEvent obtain = MotionEvent.obtain(motionEvent);
                obtain.setAction(3);
                super.onTouchEvent(obtain);
                obtain.recycle();
                super.onTouchEvent(motionEvent);
                return true;
            }
            this.x = 0;
            this.B.clear();
        } else {
            float x4 = motionEvent.getX();
            float y3 = motionEvent.getY();
            if (isEnabled()) {
                if (this.g != null) {
                    int thumbOffset = getThumbOffset();
                    this.g.getPadding(this.S);
                    int i3 = this.I;
                    int i4 = this.y;
                    int i5 = i3 - i4;
                    int i6 = (this.H + thumbOffset) - i4;
                    Rect rect = this.S;
                    int i7 = this.G + i6 + rect.left + rect.right + i4;
                    int i8 = this.K + i4;
                    if (x4 > ((float) i6) && x4 < ((float) i7) && y3 > ((float) i5) && y3 < ((float) i8)) {
                        z3 = true;
                    }
                }
                if (z3) {
                    this.x = 1;
                    this.z = x4;
                    this.A = y3;
                }
            }
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setChecked(boolean z2) {
        super.setChecked(z2);
        boolean isChecked = isChecked();
        float f = 1.0f;
        if (getWindowToken() != null) {
            AtomicInteger atomicInteger = co.a;
            if (co.f.c(this)) {
                if (!isChecked) {
                    f = Utils.FLOAT_EPSILON;
                }
                ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this, T, f);
                this.Q = ofFloat;
                ofFloat.setDuration(250L);
                this.Q.setAutoCancel(true);
                this.Q.start();
                return;
            }
        }
        ObjectAnimator objectAnimator = this.Q;
        if (objectAnimator != null) {
            objectAnimator.cancel();
        }
        if (!isChecked) {
            f = Utils.FLOAT_EPSILON;
        }
        setThumbPosition(f);
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(ek.t0(this, callback));
    }

    public void setShowText(boolean z2) {
        if (this.w != z2) {
            this.w = z2;
            requestLayout();
        }
    }

    public void setSplitTrack(boolean z2) {
        this.t = z2;
        invalidate();
    }

    public void setSwitchMinWidth(int i2) {
        this.r = i2;
        requestLayout();
    }

    public void setSwitchPadding(int i2) {
        this.s = i2;
        requestLayout();
    }

    public void setSwitchTypeface(Typeface typeface) {
        if ((this.L.getTypeface() != null && !this.L.getTypeface().equals(typeface)) || (this.L.getTypeface() == null && typeface != null)) {
            this.L.setTypeface(typeface);
            requestLayout();
            invalidate();
        }
    }

    public void setTextOff(CharSequence charSequence) {
        this.v = charSequence;
        requestLayout();
    }

    public void setTextOn(CharSequence charSequence) {
        this.u = charSequence;
        requestLayout();
    }

    public void setThumbDrawable(Drawable drawable) {
        Drawable drawable2 = this.g;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.g = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    public void setThumbPosition(float f) {
        this.D = f;
        invalidate();
    }

    public void setThumbResource(int i2) {
        setThumbDrawable(i1.b(getContext(), i2));
    }

    public void setThumbTextPadding(int i2) {
        this.q = i2;
        requestLayout();
    }

    public void setThumbTintList(ColorStateList colorStateList) {
        this.h = colorStateList;
        this.j = true;
        a();
    }

    public void setThumbTintMode(PorterDuff.Mode mode) {
        this.i = mode;
        this.k = true;
        a();
    }

    public void setTrackDrawable(Drawable drawable) {
        Drawable drawable2 = this.l;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.l = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    public void setTrackResource(int i2) {
        setTrackDrawable(i1.b(getContext(), i2));
    }

    public void setTrackTintList(ColorStateList colorStateList) {
        this.m = colorStateList;
        this.o = true;
        b();
    }

    public void setTrackTintMode(PorterDuff.Mode mode) {
        this.n = mode;
        this.p = true;
        b();
    }

    public void toggle() {
        setChecked(!isChecked());
    }

    public boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.g || drawable == this.l;
    }
}
