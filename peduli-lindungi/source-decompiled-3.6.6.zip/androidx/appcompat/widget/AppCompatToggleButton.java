package androidx.appcompat.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ToggleButton;

public class AppCompatToggleButton extends ToggleButton {
    public final i3 g;

    public AppCompatToggleButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 16842827);
        a4.a(this, getContext());
        i3 i3Var = new i3(this);
        this.g = i3Var;
        i3Var.e(attributeSet, 16842827);
    }
}
