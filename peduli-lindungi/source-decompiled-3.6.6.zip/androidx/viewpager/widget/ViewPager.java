package androidx.viewpager.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.Scroller;
import androidx.recyclerview.widget.RecyclerView;
import com.github.mikephil.charting.utils.Utils;
import com.google.maps.android.R;
import defpackage.co;
import defpackage.wk;
import j$.util.Comparator;
import j$.util.function.Function;
import j$.util.function.ToDoubleFunction;
import j$.util.function.ToIntFunction;
import j$.util.function.ToLongFunction;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.KotlinVersion;

public class ViewPager extends ViewGroup {
    public static final int[] j0 = {16842931};
    public static final Comparator<e> k0 = new a();
    public static final Interpolator l0 = new b();
    public static final m m0 = new m();
    public boolean A;
    public boolean B;
    public int C = 1;
    public boolean D;
    public boolean E;
    public int F;
    public int G;
    public int H;
    public float I;
    public float J;
    public float K;
    public float L;
    public int M = -1;
    public VelocityTracker N;
    public int O;
    public int P;
    public int Q;
    public int R;
    public EdgeEffect S;
    public EdgeEffect T;
    public boolean U = true;
    public boolean V;
    public int W;
    public List<i> a0;
    public i b0;
    public List<h> c0;
    public j d0;
    public int e0;
    public int f0;
    public int g;
    public ArrayList<View> g0;
    public final ArrayList<e> h = new ArrayList<>();
    public final Runnable h0 = new c();
    public final e i = new e();
    public int i0 = 0;
    public final Rect j = new Rect();
    public r10 k;
    public int l;
    public int m = -1;
    public Parcelable n = null;
    public ClassLoader o = null;
    public Scroller p;
    public boolean q;
    public k r;
    public int s;
    public Drawable t;
    public int u;
    public int v;
    public float w = -3.4028235E38f;
    public float x = Float.MAX_VALUE;
    public int y;
    public boolean z;

    public static class a implements Comparator<e>, j$.util.Comparator {
        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object, java.lang.Object] */
        @Override // j$.util.Comparator, java.util.Comparator
        public int compare(e eVar, e eVar2) {
            return eVar.b - eVar2.b;
        }

        /* Return type fixed from 'java.util.Comparator' to match base method */
        @Override // j$.util.Comparator, java.util.Comparator
        public /* synthetic */ Comparator<e> reversed() {
            return Comparator.CC.$default$reversed(this);
        }

        @Override // j$.util.Comparator
        public /* synthetic */ java.util.Comparator thenComparing(Function function) {
            return Comparator.CC.$default$thenComparing(this, function);
        }

        @Override // j$.util.Comparator
        public /* synthetic */ java.util.Comparator thenComparing(Function function, java.util.Comparator comparator) {
            return Comparator.CC.$default$thenComparing(this, function, comparator);
        }

        /* Return type fixed from 'java.util.Comparator' to match base method */
        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.util.Comparator] */
        @Override // j$.util.Comparator, java.util.Comparator
        public /* synthetic */ java.util.Comparator<e> thenComparing(java.util.Comparator<? super e> comparator) {
            return Comparator.CC.$default$thenComparing(this, comparator);
        }

        @Override // j$.util.Comparator
        public /* synthetic */ java.util.Comparator thenComparingDouble(ToDoubleFunction toDoubleFunction) {
            return Comparator.CC.$default$thenComparingDouble(this, toDoubleFunction);
        }

        @Override // j$.util.Comparator
        public /* synthetic */ java.util.Comparator thenComparingInt(ToIntFunction toIntFunction) {
            return Comparator.CC.$default$thenComparingInt(this, toIntFunction);
        }

        @Override // j$.util.Comparator
        public /* synthetic */ java.util.Comparator thenComparingLong(ToLongFunction toLongFunction) {
            return Comparator.CC.$default$thenComparingLong(this, toLongFunction);
        }
    }

    public static class b implements Interpolator {
        public float getInterpolation(float f) {
            float f2 = f - 1.0f;
            return (f2 * f2 * f2 * f2 * f2) + 1.0f;
        }
    }

    public class c implements Runnable {
        public c() {
        }

        public void run() {
            ViewPager.this.setScrollState(0);
            ViewPager viewPager = ViewPager.this;
            viewPager.r(viewPager.l);
        }
    }

    @Target({ElementType.TYPE})
    @Inherited
    @Retention(RetentionPolicy.RUNTIME)
    public @interface d {
    }

    public static class e {
        public Object a;
        public int b;
        public boolean c;
        public float d;
        public float e;
    }

    public class g extends mn {
        public g() {
        }

        @Override // defpackage.mn
        public void c(View view, AccessibilityEvent accessibilityEvent) {
            r10 r10;
            this.a.onInitializeAccessibilityEvent(view, accessibilityEvent);
            accessibilityEvent.setClassName(ViewPager.class.getName());
            r10 r102 = ViewPager.this.k;
            boolean z = true;
            if (r102 == null || r102.c() <= 1) {
                z = false;
            }
            accessibilityEvent.setScrollable(z);
            if (accessibilityEvent.getEventType() == 4096 && (r10 = ViewPager.this.k) != null) {
                accessibilityEvent.setItemCount(r10.c());
                accessibilityEvent.setFromIndex(ViewPager.this.l);
                accessibilityEvent.setToIndex(ViewPager.this.l);
            }
        }

        @Override // defpackage.mn
        public void d(View view, lo loVar) {
            this.a.onInitializeAccessibilityNodeInfo(view, loVar.a);
            loVar.a.setClassName(ViewPager.class.getName());
            r10 r10 = ViewPager.this.k;
            loVar.a.setScrollable(r10 != null && r10.c() > 1);
            if (ViewPager.this.canScrollHorizontally(1)) {
                loVar.a.addAction(4096);
            }
            if (ViewPager.this.canScrollHorizontally(-1)) {
                loVar.a.addAction(RecyclerView.b0.FLAG_BOUNCED_FROM_HIDDEN_LIST);
            }
        }

        @Override // defpackage.mn
        public boolean g(View view, int i, Bundle bundle) {
            if (super.g(view, i, bundle)) {
                return true;
            }
            if (i != 4096) {
                if (i != 8192 || !ViewPager.this.canScrollHorizontally(-1)) {
                    return false;
                }
                ViewPager viewPager = ViewPager.this;
                viewPager.setCurrentItem(viewPager.l - 1);
                return true;
            } else if (!ViewPager.this.canScrollHorizontally(1)) {
                return false;
            } else {
                ViewPager viewPager2 = ViewPager.this;
                viewPager2.setCurrentItem(viewPager2.l + 1);
                return true;
            }
        }
    }

    public interface h {
        void a(ViewPager viewPager, r10 r10, r10 r102);
    }

    public interface i {
        void a(int i, float f, int i2);

        void b(int i);

        void c(int i);
    }

    public interface j {
    }

    public class k extends DataSetObserver {
        public k() {
        }

        public void onChanged() {
            ViewPager.this.f();
        }

        public void onInvalidated() {
            ViewPager.this.f();
        }
    }

    public static class l extends dp {
        public static final Parcelable.Creator<l> CREATOR = new a();
        public int i;
        public Parcelable j;
        public ClassLoader k;

        public static class a implements Parcelable.ClassLoaderCreator<l> {
            /* Return type fixed from 'java.lang.Object' to match base method */
            @Override // android.os.Parcelable.ClassLoaderCreator
            public l createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new l(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            public Object[] newArray(int i) {
                return new l[i];
            }

            @Override // android.os.Parcelable.Creator
            public Object createFromParcel(Parcel parcel) {
                return new l(parcel, null);
            }
        }

        public l(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder J0 = ze0.J0("FragmentPager.SavedState{");
            J0.append(Integer.toHexString(System.identityHashCode(this)));
            J0.append(" position=");
            return ze0.w0(J0, this.i, "}");
        }

        @Override // defpackage.dp
        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeParcelable(this.g, i2);
            parcel.writeInt(this.i);
            parcel.writeParcelable(this.j, i2);
        }

        public l(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            classLoader = classLoader == null ? l.class.getClassLoader() : classLoader;
            this.i = parcel.readInt();
            this.j = parcel.readParcelable(classLoader);
            this.k = classLoader;
        }
    }

    public static class m implements java.util.Comparator<View>, j$.util.Comparator {
        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object, java.lang.Object] */
        @Override // j$.util.Comparator, java.util.Comparator
        public int compare(View view, View view2) {
            f fVar = (f) view.getLayoutParams();
            f fVar2 = (f) view2.getLayoutParams();
            boolean z = fVar.a;
            if (z != fVar2.a) {
                return z ? 1 : -1;
            }
            return fVar.e - fVar2.e;
        }

        /* Return type fixed from 'java.util.Comparator' to match base method */
        @Override // j$.util.Comparator, java.util.Comparator
        public /* synthetic */ java.util.Comparator<View> reversed() {
            return Comparator.CC.$default$reversed(this);
        }

        @Override // j$.util.Comparator
        public /* synthetic */ java.util.Comparator thenComparing(Function function) {
            return Comparator.CC.$default$thenComparing(this, function);
        }

        @Override // j$.util.Comparator
        public /* synthetic */ java.util.Comparator thenComparing(Function function, java.util.Comparator comparator) {
            return Comparator.CC.$default$thenComparing(this, function, comparator);
        }

        /* Return type fixed from 'java.util.Comparator' to match base method */
        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.util.Comparator] */
        @Override // j$.util.Comparator, java.util.Comparator
        public /* synthetic */ java.util.Comparator<View> thenComparing(java.util.Comparator<? super View> comparator) {
            return Comparator.CC.$default$thenComparing(this, comparator);
        }

        @Override // j$.util.Comparator
        public /* synthetic */ java.util.Comparator thenComparingDouble(ToDoubleFunction toDoubleFunction) {
            return Comparator.CC.$default$thenComparingDouble(this, toDoubleFunction);
        }

        @Override // j$.util.Comparator
        public /* synthetic */ java.util.Comparator thenComparingInt(ToIntFunction toIntFunction) {
            return Comparator.CC.$default$thenComparingInt(this, toIntFunction);
        }

        @Override // j$.util.Comparator
        public /* synthetic */ java.util.Comparator thenComparingLong(ToLongFunction toLongFunction) {
            return Comparator.CC.$default$thenComparingLong(this, toLongFunction);
        }
    }

    public ViewPager(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setWillNotDraw(false);
        setDescendantFocusability(262144);
        setFocusable(true);
        Context context2 = getContext();
        this.p = new Scroller(context2, l0);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context2);
        float f2 = context2.getResources().getDisplayMetrics().density;
        this.H = viewConfiguration.getScaledPagingTouchSlop();
        this.O = (int) (400.0f * f2);
        this.P = viewConfiguration.getScaledMaximumFlingVelocity();
        this.S = new EdgeEffect(context2);
        this.T = new EdgeEffect(context2);
        this.Q = (int) (25.0f * f2);
        this.R = (int) (2.0f * f2);
        this.F = (int) (f2 * 16.0f);
        co.u(this, new g());
        if (co.c.c(this) == 0) {
            co.c.s(this, 1);
        }
        co.h.u(this, new s10(this));
    }

    private int getClientWidth() {
        return (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
    }

    private void setScrollingCacheEnabled(boolean z2) {
        if (this.A != z2) {
            this.A = z2;
        }
    }

    public e a(int i2, int i3) {
        e eVar = new e();
        eVar.b = i2;
        eVar.a = this.k.e(this, i2);
        Objects.requireNonNull(this.k);
        eVar.d = 1.0f;
        if (i3 < 0 || i3 >= this.h.size()) {
            this.h.add(eVar);
        } else {
            this.h.add(i3, eVar);
        }
        return eVar;
    }

    @Override // android.view.View, android.view.ViewGroup
    public void addFocusables(ArrayList<View> arrayList, int i2, int i3) {
        e i4;
        int size = arrayList.size();
        int descendantFocusability = getDescendantFocusability();
        if (descendantFocusability != 393216) {
            for (int i5 = 0; i5 < getChildCount(); i5++) {
                View childAt = getChildAt(i5);
                if (childAt.getVisibility() == 0 && (i4 = i(childAt)) != null && i4.b == this.l) {
                    childAt.addFocusables(arrayList, i2, i3);
                }
            }
        }
        if ((descendantFocusability == 262144 && size != arrayList.size()) || !isFocusable()) {
            return;
        }
        if ((i3 & 1) != 1 || !isInTouchMode() || isFocusableInTouchMode()) {
            arrayList.add(this);
        }
    }

    @Override // android.view.View, android.view.ViewGroup
    public void addTouchables(ArrayList<View> arrayList) {
        e i2;
        for (int i3 = 0; i3 < getChildCount(); i3++) {
            View childAt = getChildAt(i3);
            if (childAt.getVisibility() == 0 && (i2 = i(childAt)) != null && i2.b == this.l) {
                childAt.addTouchables(arrayList);
            }
        }
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        if (!checkLayoutParams(layoutParams)) {
            layoutParams = generateLayoutParams(layoutParams);
        }
        f fVar = (f) layoutParams;
        boolean z2 = fVar.a | (view.getClass().getAnnotation(d.class) != null);
        fVar.a = z2;
        if (!this.z) {
            super.addView(view, i2, layoutParams);
        } else if (!z2) {
            fVar.d = true;
            addViewInLayout(view, i2, layoutParams);
        } else {
            throw new IllegalStateException("Cannot add pager decor view during layout");
        }
    }

    public void b(i iVar) {
        if (this.a0 == null) {
            this.a0 = new ArrayList();
        }
        this.a0.add(iVar);
    }

    /* JADX WARNING: Removed duplicated region for block: B:41:0x00ca  */
    public boolean c(int i2) {
        View findNextFocus;
        boolean requestFocus;
        boolean z2;
        View findFocus = findFocus();
        boolean z3 = false;
        if (findFocus != this) {
            if (findFocus != null) {
                ViewParent parent = findFocus.getParent();
                while (true) {
                    if (!(parent instanceof ViewGroup)) {
                        z2 = false;
                        break;
                    } else if (parent == this) {
                        z2 = true;
                        break;
                    } else {
                        parent = parent.getParent();
                    }
                }
                if (!z2) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(findFocus.getClass().getSimpleName());
                    for (ViewParent parent2 = findFocus.getParent(); parent2 instanceof ViewGroup; parent2 = parent2.getParent()) {
                        sb.append(" => ");
                        sb.append(parent2.getClass().getSimpleName());
                    }
                    StringBuilder J0 = ze0.J0("arrowScroll tried to find focus based on non-child current focused view ");
                    J0.append(sb.toString());
                    Log.e("ViewPager", J0.toString());
                }
            }
            findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, i2);
            if (findNextFocus == null && findNextFocus != findFocus) {
                if (i2 == 17) {
                    int i3 = h(this.j, findNextFocus).left;
                    int i4 = h(this.j, findFocus).left;
                    if (findFocus == null || i3 < i4) {
                        requestFocus = findNextFocus.requestFocus();
                    } else {
                        requestFocus = n();
                    }
                } else if (i2 == 66) {
                    int i5 = h(this.j, findNextFocus).left;
                    int i6 = h(this.j, findFocus).left;
                    if (findFocus == null || i5 > i6) {
                        requestFocus = findNextFocus.requestFocus();
                    } else {
                        requestFocus = o();
                    }
                }
                z3 = requestFocus;
            } else if (i2 != 17 || i2 == 1) {
                z3 = n();
            } else if (i2 == 66 || i2 == 2) {
                z3 = o();
            }
            if (z3) {
                playSoundEffect(SoundEffectConstants.getContantForFocusDirection(i2));
            }
            return z3;
        }
        findFocus = null;
        findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, i2);
        if (findNextFocus == null) {
        }
        if (i2 != 17) {
        }
        z3 = n();
        if (z3) {
        }
        return z3;
    }

    public boolean canScrollHorizontally(int i2) {
        if (this.k == null) {
            return false;
        }
        int clientWidth = getClientWidth();
        int scrollX = getScrollX();
        if (i2 < 0) {
            if (scrollX > ((int) (((float) clientWidth) * this.w))) {
                return true;
            }
            return false;
        } else if (i2 <= 0 || scrollX >= ((int) (((float) clientWidth) * this.x))) {
            return false;
        } else {
            return true;
        }
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof f) && super.checkLayoutParams(layoutParams);
    }

    public void computeScroll() {
        this.q = true;
        if (this.p.isFinished() || !this.p.computeScrollOffset()) {
            e(true);
            return;
        }
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        int currX = this.p.getCurrX();
        int currY = this.p.getCurrY();
        if (!(scrollX == currX && scrollY == currY)) {
            scrollTo(currX, currY);
            if (!p(currX)) {
                this.p.abortAnimation();
                scrollTo(0, currY);
            }
        }
        AtomicInteger atomicInteger = co.a;
        co.c.k(this);
    }

    public boolean d(View view, boolean z2, int i2, int i3, int i4) {
        int i5;
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int scrollX = view.getScrollX();
            int scrollY = view.getScrollY();
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount);
                int i6 = i3 + scrollX;
                if (i6 >= childAt.getLeft() && i6 < childAt.getRight() && (i5 = i4 + scrollY) >= childAt.getTop() && i5 < childAt.getBottom() && d(childAt, true, i2, i6 - childAt.getLeft(), i5 - childAt.getTop())) {
                    return true;
                }
            }
        }
        if (!z2 || !view.canScrollHorizontally(-i2)) {
            return false;
        }
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:27:? A[RETURN, SYNTHETIC] */
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        boolean z2;
        if (!super.dispatchKeyEvent(keyEvent)) {
            if (keyEvent.getAction() == 0) {
                int keyCode = keyEvent.getKeyCode();
                if (keyCode == 21) {
                    z2 = keyEvent.hasModifiers(2) ? n() : c(17);
                } else if (keyCode == 22) {
                    z2 = keyEvent.hasModifiers(2) ? o() : c(66);
                } else if (keyCode == 61) {
                    if (keyEvent.hasNoModifiers()) {
                        z2 = c(2);
                    } else if (keyEvent.hasModifiers(1)) {
                        z2 = c(1);
                    }
                }
                if (!z2) {
                    return true;
                }
                return false;
            }
            z2 = false;
            if (!z2) {
            }
        }
        return true;
    }

    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        e i2;
        if (accessibilityEvent.getEventType() == 4096) {
            return super.dispatchPopulateAccessibilityEvent(accessibilityEvent);
        }
        int childCount = getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            if (childAt.getVisibility() == 0 && (i2 = i(childAt)) != null && i2.b == this.l && childAt.dispatchPopulateAccessibilityEvent(accessibilityEvent)) {
                return true;
            }
        }
        return false;
    }

    public void draw(Canvas canvas) {
        r10 r10;
        super.draw(canvas);
        int overScrollMode = getOverScrollMode();
        boolean z2 = false;
        if (overScrollMode == 0 || (overScrollMode == 1 && (r10 = this.k) != null && r10.c() > 1)) {
            if (!this.S.isFinished()) {
                int save = canvas.save();
                int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
                int width = getWidth();
                canvas.rotate(270.0f);
                canvas.translate((float) (getPaddingTop() + (-height)), this.w * ((float) width));
                this.S.setSize(height, width);
                z2 = false | this.S.draw(canvas);
                canvas.restoreToCount(save);
            }
            if (!this.T.isFinished()) {
                int save2 = canvas.save();
                int width2 = getWidth();
                int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
                canvas.rotate(90.0f);
                canvas.translate((float) (-getPaddingTop()), (-(this.x + 1.0f)) * ((float) width2));
                this.T.setSize(height2, width2);
                z2 |= this.T.draw(canvas);
                canvas.restoreToCount(save2);
            }
        } else {
            this.S.finish();
            this.T.finish();
        }
        if (z2) {
            AtomicInteger atomicInteger = co.a;
            co.c.k(this);
        }
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.t;
        if (drawable != null && drawable.isStateful()) {
            drawable.setState(getDrawableState());
        }
    }

    public final void e(boolean z2) {
        boolean z3 = this.i0 == 2;
        if (z3) {
            setScrollingCacheEnabled(false);
            if (!this.p.isFinished()) {
                this.p.abortAnimation();
                int scrollX = getScrollX();
                int scrollY = getScrollY();
                int currX = this.p.getCurrX();
                int currY = this.p.getCurrY();
                if (!(scrollX == currX && scrollY == currY)) {
                    scrollTo(currX, currY);
                    if (currX != scrollX) {
                        p(currX);
                    }
                }
            }
        }
        this.B = false;
        for (int i2 = 0; i2 < this.h.size(); i2++) {
            e eVar = this.h.get(i2);
            if (eVar.c) {
                eVar.c = false;
                z3 = true;
            }
        }
        if (!z3) {
            return;
        }
        if (z2) {
            Runnable runnable = this.h0;
            AtomicInteger atomicInteger = co.a;
            co.c.m(this, runnable);
            return;
        }
        this.h0.run();
    }

    public void f() {
        int c2 = this.k.c();
        this.g = c2;
        boolean z2 = this.h.size() < (this.C * 2) + 1 && this.h.size() < c2;
        int i2 = this.l;
        for (int i3 = 0; i3 < this.h.size(); i3++) {
            r10 r10 = this.k;
            Object obj = this.h.get(i3).a;
            Objects.requireNonNull(r10);
        }
        Collections.sort(this.h, k0);
        if (z2) {
            int childCount = getChildCount();
            for (int i4 = 0; i4 < childCount; i4++) {
                f fVar = (f) getChildAt(i4).getLayoutParams();
                if (!fVar.a) {
                    fVar.c = Utils.FLOAT_EPSILON;
                }
            }
            x(i2, false, true, 0);
            requestLayout();
        }
    }

    public final void g(int i2) {
        i iVar = this.b0;
        if (iVar != null) {
            iVar.c(i2);
        }
        List<i> list = this.a0;
        if (list != null) {
            int size = list.size();
            for (int i3 = 0; i3 < size; i3++) {
                i iVar2 = this.a0.get(i3);
                if (iVar2 != null) {
                    iVar2.c(i2);
                }
            }
        }
    }

    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new f();
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return generateDefaultLayoutParams();
    }

    public r10 getAdapter() {
        return this.k;
    }

    public int getChildDrawingOrder(int i2, int i3) {
        if (this.f0 == 2) {
            i3 = (i2 - 1) - i3;
        }
        return ((f) this.g0.get(i3).getLayoutParams()).f;
    }

    public int getCurrentItem() {
        return this.l;
    }

    public int getOffscreenPageLimit() {
        return this.C;
    }

    public int getPageMargin() {
        return this.s;
    }

    public final Rect h(Rect rect, View view) {
        if (rect == null) {
            rect = new Rect();
        }
        if (view == null) {
            rect.set(0, 0, 0, 0);
            return rect;
        }
        rect.left = view.getLeft();
        rect.right = view.getRight();
        rect.top = view.getTop();
        rect.bottom = view.getBottom();
        ViewParent parent = view.getParent();
        while ((parent instanceof ViewGroup) && parent != this) {
            ViewGroup viewGroup = (ViewGroup) parent;
            rect.left = viewGroup.getLeft() + rect.left;
            rect.right = viewGroup.getRight() + rect.right;
            rect.top = viewGroup.getTop() + rect.top;
            rect.bottom = viewGroup.getBottom() + rect.bottom;
            parent = viewGroup.getParent();
        }
        return rect;
    }

    public e i(View view) {
        for (int i2 = 0; i2 < this.h.size(); i2++) {
            e eVar = this.h.get(i2);
            if (this.k.f(view, eVar.a)) {
                return eVar;
            }
        }
        return null;
    }

    public final e j() {
        int i2;
        int clientWidth = getClientWidth();
        float f2 = Utils.FLOAT_EPSILON;
        float scrollX = clientWidth > 0 ? ((float) getScrollX()) / ((float) clientWidth) : Utils.FLOAT_EPSILON;
        float f3 = clientWidth > 0 ? ((float) this.s) / ((float) clientWidth) : Utils.FLOAT_EPSILON;
        e eVar = null;
        float f4 = Utils.FLOAT_EPSILON;
        int i3 = -1;
        int i4 = 0;
        boolean z2 = true;
        while (i4 < this.h.size()) {
            e eVar2 = this.h.get(i4);
            if (!z2 && eVar2.b != (i2 = i3 + 1)) {
                eVar2 = this.i;
                eVar2.e = f2 + f4 + f3;
                eVar2.b = i2;
                Objects.requireNonNull(this.k);
                eVar2.d = 1.0f;
                i4--;
            }
            f2 = eVar2.e;
            float f5 = eVar2.d + f2 + f3;
            if (!z2 && scrollX < f2) {
                return eVar;
            }
            if (scrollX < f5 || i4 == this.h.size() - 1) {
                return eVar2;
            }
            i3 = eVar2.b;
            f4 = eVar2.d;
            i4++;
            eVar = eVar2;
            z2 = false;
        }
        return eVar;
    }

    public e k(int i2) {
        for (int i3 = 0; i3 < this.h.size(); i3++) {
            e eVar = this.h.get(i3);
            if (eVar.b == i2) {
                return eVar;
            }
        }
        return null;
    }

    /* JADX WARNING: Removed duplicated region for block: B:19:0x0064  */
    public void l(int i2, float f2, int i3) {
        int i4;
        int left;
        int i5;
        if (this.W > 0) {
            int scrollX = getScrollX();
            int paddingLeft = getPaddingLeft();
            int paddingRight = getPaddingRight();
            int width = getWidth();
            int childCount = getChildCount();
            for (int i6 = 0; i6 < childCount; i6++) {
                View childAt = getChildAt(i6);
                f fVar = (f) childAt.getLayoutParams();
                if (fVar.a) {
                    int i7 = fVar.b & 7;
                    if (i7 != 1) {
                        if (i7 == 3) {
                            i4 = childAt.getWidth() + paddingLeft;
                        } else if (i7 != 5) {
                            i4 = paddingLeft;
                        } else {
                            i5 = (width - paddingRight) - childAt.getMeasuredWidth();
                            paddingRight += childAt.getMeasuredWidth();
                        }
                        left = (paddingLeft + scrollX) - childAt.getLeft();
                        if (left != 0) {
                            childAt.offsetLeftAndRight(left);
                        }
                        paddingLeft = i4;
                    } else {
                        i5 = Math.max((width - childAt.getMeasuredWidth()) / 2, paddingLeft);
                    }
                    i4 = paddingLeft;
                    paddingLeft = i5;
                    left = (paddingLeft + scrollX) - childAt.getLeft();
                    if (left != 0) {
                    }
                    paddingLeft = i4;
                }
            }
        }
        i iVar = this.b0;
        if (iVar != null) {
            iVar.a(i2, f2, i3);
        }
        List<i> list = this.a0;
        if (list != null) {
            int size = list.size();
            for (int i8 = 0; i8 < size; i8++) {
                i iVar2 = this.a0.get(i8);
                if (iVar2 != null) {
                    iVar2.a(i2, f2, i3);
                }
            }
        }
        if (this.d0 != null) {
            int scrollX2 = getScrollX();
            int childCount2 = getChildCount();
            for (int i9 = 0; i9 < childCount2; i9++) {
                View childAt2 = getChildAt(i9);
                if (!((f) childAt2.getLayoutParams()).a) {
                    float left2 = ((float) (childAt2.getLeft() - scrollX2)) / ((float) getClientWidth());
                    Objects.requireNonNull((br3) this.d0);
                    childAt2.setTranslationX(left2 * -2.0f * ((float) childAt2.getWidth()));
                }
            }
        }
        this.V = true;
    }

    public final void m(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.M) {
            int i2 = actionIndex == 0 ? 1 : 0;
            this.I = motionEvent.getX(i2);
            this.M = motionEvent.getPointerId(i2);
            VelocityTracker velocityTracker = this.N;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    public boolean n() {
        int i2 = this.l;
        if (i2 <= 0) {
            return false;
        }
        w(i2 - 1, true);
        return true;
    }

    public boolean o() {
        r10 r10 = this.k;
        if (r10 == null || this.l >= r10.c() - 1) {
            return false;
        }
        w(this.l + 1, true);
        return true;
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.U = true;
    }

    public void onDetachedFromWindow() {
        removeCallbacks(this.h0);
        Scroller scroller = this.p;
        if (scroller != null && !scroller.isFinished()) {
            this.p.abortAnimation();
        }
        super.onDetachedFromWindow();
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x005a  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x0065  */
    public void onDraw(Canvas canvas) {
        int i2;
        float f2;
        float f3;
        super.onDraw(canvas);
        if (this.s > 0 && this.t != null && this.h.size() > 0 && this.k != null) {
            int scrollX = getScrollX();
            int width = getWidth();
            float f4 = (float) width;
            float f5 = ((float) this.s) / f4;
            int i3 = 0;
            e eVar = this.h.get(0);
            float f6 = eVar.e;
            int size = this.h.size();
            int i4 = eVar.b;
            int i5 = this.h.get(size - 1).b;
            while (i4 < i5) {
                while (true) {
                    i2 = eVar.b;
                    if (i4 > i2 && i3 < size) {
                        i3++;
                        eVar = this.h.get(i3);
                    } else if (i4 != i2) {
                        float f7 = eVar.e;
                        float f8 = eVar.d;
                        f2 = (f7 + f8) * f4;
                        f6 = f7 + f8 + f5;
                    } else {
                        Objects.requireNonNull(this.k);
                        f2 = (f6 + 1.0f) * f4;
                        f6 = 1.0f + f5 + f6;
                    }
                }
                if (i4 != i2) {
                }
                if (((float) this.s) + f2 > ((float) scrollX)) {
                    f3 = f5;
                    this.t.setBounds(Math.round(f2), this.u, Math.round(((float) this.s) + f2), this.v);
                    this.t.draw(canvas);
                } else {
                    f3 = f5;
                }
                if (f2 <= ((float) (scrollX + width))) {
                    i4++;
                    f5 = f3;
                } else {
                    return;
                }
            }
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction() & KotlinVersion.MAX_COMPONENT_VALUE;
        if (action == 3 || action == 1) {
            u();
            return false;
        }
        if (action != 0) {
            if (this.D) {
                return true;
            }
            if (this.E) {
                return false;
            }
        }
        if (action == 0) {
            float x2 = motionEvent.getX();
            this.K = x2;
            this.I = x2;
            float y2 = motionEvent.getY();
            this.L = y2;
            this.J = y2;
            this.M = motionEvent.getPointerId(0);
            this.E = false;
            this.q = true;
            this.p.computeScrollOffset();
            if (this.i0 != 2 || Math.abs(this.p.getFinalX() - this.p.getCurrX()) <= this.R) {
                e(false);
                this.D = false;
            } else {
                this.p.abortAnimation();
                this.B = false;
                r(this.l);
                this.D = true;
                t(true);
                setScrollState(1);
            }
        } else if (action == 2) {
            int i2 = this.M;
            if (i2 != -1) {
                int findPointerIndex = motionEvent.findPointerIndex(i2);
                float x3 = motionEvent.getX(findPointerIndex);
                float f2 = x3 - this.I;
                float abs = Math.abs(f2);
                float y3 = motionEvent.getY(findPointerIndex);
                float abs2 = Math.abs(y3 - this.L);
                int i3 = (f2 > Utils.FLOAT_EPSILON ? 1 : (f2 == Utils.FLOAT_EPSILON ? 0 : -1));
                if (i3 != 0) {
                    float f3 = this.I;
                    if (!((f3 < ((float) this.G) && i3 > 0) || (f3 > ((float) (getWidth() - this.G)) && f2 < Utils.FLOAT_EPSILON)) && d(this, false, (int) f2, (int) x3, (int) y3)) {
                        this.I = x3;
                        this.J = y3;
                        this.E = true;
                        return false;
                    }
                }
                int i4 = this.H;
                if (abs > ((float) i4) && abs * 0.5f > abs2) {
                    this.D = true;
                    t(true);
                    setScrollState(1);
                    float f4 = this.K;
                    float f5 = (float) this.H;
                    this.I = i3 > 0 ? f4 + f5 : f4 - f5;
                    this.J = y3;
                    setScrollingCacheEnabled(true);
                } else if (abs2 > ((float) i4)) {
                    this.E = true;
                }
                if (this.D && q(x3)) {
                    AtomicInteger atomicInteger = co.a;
                    co.c.k(this);
                }
            }
        } else if (action == 6) {
            m(motionEvent);
        }
        if (this.N == null) {
            this.N = VelocityTracker.obtain();
        }
        this.N.addMovement(motionEvent);
        return this.D;
    }

    /* JADX WARNING: Removed duplicated region for block: B:20:0x0071  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x008e  */
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        boolean z3;
        e i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int childCount = getChildCount();
        int i11 = i4 - i2;
        int i12 = i5 - i3;
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();
        int scrollX = getScrollX();
        int i13 = 0;
        for (int i14 = 0; i14 < childCount; i14++) {
            View childAt = getChildAt(i14);
            if (childAt.getVisibility() != 8) {
                f fVar = (f) childAt.getLayoutParams();
                if (fVar.a) {
                    int i15 = fVar.b;
                    int i16 = i15 & 7;
                    int i17 = i15 & R.styleable.AppCompatTheme_tooltipForegroundColor;
                    if (i16 != 1) {
                        if (i16 == 3) {
                            i7 = childAt.getMeasuredWidth() + paddingLeft;
                        } else if (i16 != 5) {
                            i7 = paddingLeft;
                        } else {
                            i10 = (i11 - paddingRight) - childAt.getMeasuredWidth();
                            paddingRight += childAt.getMeasuredWidth();
                        }
                        if (i17 == 16) {
                            if (i17 == 48) {
                                i8 = childAt.getMeasuredHeight() + paddingTop;
                            } else if (i17 != 80) {
                                i8 = paddingTop;
                            } else {
                                i9 = (i12 - paddingBottom) - childAt.getMeasuredHeight();
                                paddingBottom += childAt.getMeasuredHeight();
                            }
                            int i18 = paddingLeft + scrollX;
                            childAt.layout(i18, paddingTop, childAt.getMeasuredWidth() + i18, childAt.getMeasuredHeight() + paddingTop);
                            i13++;
                            paddingTop = i8;
                            paddingLeft = i7;
                        } else {
                            i9 = Math.max((i12 - childAt.getMeasuredHeight()) / 2, paddingTop);
                        }
                        i8 = paddingTop;
                        paddingTop = i9;
                        int i182 = paddingLeft + scrollX;
                        childAt.layout(i182, paddingTop, childAt.getMeasuredWidth() + i182, childAt.getMeasuredHeight() + paddingTop);
                        i13++;
                        paddingTop = i8;
                        paddingLeft = i7;
                    } else {
                        i10 = Math.max((i11 - childAt.getMeasuredWidth()) / 2, paddingLeft);
                    }
                    i7 = paddingLeft;
                    paddingLeft = i10;
                    if (i17 == 16) {
                    }
                    i8 = paddingTop;
                    paddingTop = i9;
                    int i1822 = paddingLeft + scrollX;
                    childAt.layout(i1822, paddingTop, childAt.getMeasuredWidth() + i1822, childAt.getMeasuredHeight() + paddingTop);
                    i13++;
                    paddingTop = i8;
                    paddingLeft = i7;
                }
            }
        }
        int i19 = (i11 - paddingLeft) - paddingRight;
        for (int i20 = 0; i20 < childCount; i20++) {
            View childAt2 = getChildAt(i20);
            if (childAt2.getVisibility() != 8) {
                f fVar2 = (f) childAt2.getLayoutParams();
                if (!fVar2.a && (i6 = i(childAt2)) != null) {
                    float f2 = (float) i19;
                    int i21 = ((int) (i6.e * f2)) + paddingLeft;
                    if (fVar2.d) {
                        fVar2.d = false;
                        childAt2.measure(View.MeasureSpec.makeMeasureSpec((int) (f2 * fVar2.c), 1073741824), View.MeasureSpec.makeMeasureSpec((i12 - paddingTop) - paddingBottom, 1073741824));
                    }
                    childAt2.layout(i21, paddingTop, childAt2.getMeasuredWidth() + i21, childAt2.getMeasuredHeight() + paddingTop);
                }
            }
        }
        this.u = paddingTop;
        this.v = i12 - paddingBottom;
        this.W = i13;
        if (this.U) {
            z3 = false;
            v(this.l, false, 0, false);
        } else {
            z3 = false;
        }
        this.U = z3;
    }

    /* JADX WARNING: Removed duplicated region for block: B:28:0x0082  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x0089  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x008e  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x0093  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x00a2  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x00a8  */
    public void onMeasure(int i2, int i3) {
        f fVar;
        f fVar2;
        int i4;
        int i5;
        int i6;
        setMeasuredDimension(ViewGroup.getDefaultSize(0, i2), ViewGroup.getDefaultSize(0, i3));
        int measuredWidth = getMeasuredWidth();
        this.G = Math.min(measuredWidth / 10, this.F);
        int paddingLeft = (measuredWidth - getPaddingLeft()) - getPaddingRight();
        int measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
        int childCount = getChildCount();
        int i7 = 0;
        while (true) {
            boolean z2 = true;
            int i8 = 1073741824;
            if (i7 >= childCount) {
                break;
            }
            View childAt = getChildAt(i7);
            if (!(childAt.getVisibility() == 8 || (fVar2 = (f) childAt.getLayoutParams()) == null || !fVar2.a)) {
                int i9 = fVar2.b;
                int i10 = i9 & 7;
                int i11 = i9 & R.styleable.AppCompatTheme_tooltipForegroundColor;
                boolean z3 = i11 == 48 || i11 == 80;
                if (!(i10 == 3 || i10 == 5)) {
                    z2 = false;
                }
                int i12 = Integer.MIN_VALUE;
                if (z3) {
                    i12 = 1073741824;
                } else if (z2) {
                    i4 = 1073741824;
                    i5 = ((ViewGroup.LayoutParams) fVar2).width;
                    if (i5 == -2) {
                        if (i5 == -1) {
                            i5 = paddingLeft;
                        }
                        i12 = 1073741824;
                    } else {
                        i5 = paddingLeft;
                    }
                    i6 = ((ViewGroup.LayoutParams) fVar2).height;
                    if (i6 != -2) {
                        i6 = measuredHeight;
                        i8 = i4;
                    } else if (i6 == -1) {
                        i6 = measuredHeight;
                    }
                    childAt.measure(View.MeasureSpec.makeMeasureSpec(i5, i12), View.MeasureSpec.makeMeasureSpec(i6, i8));
                    if (!z3) {
                        measuredHeight -= childAt.getMeasuredHeight();
                    } else if (z2) {
                        paddingLeft -= childAt.getMeasuredWidth();
                    }
                }
                i4 = Integer.MIN_VALUE;
                i5 = ((ViewGroup.LayoutParams) fVar2).width;
                if (i5 == -2) {
                }
                i6 = ((ViewGroup.LayoutParams) fVar2).height;
                if (i6 != -2) {
                }
                childAt.measure(View.MeasureSpec.makeMeasureSpec(i5, i12), View.MeasureSpec.makeMeasureSpec(i6, i8));
                if (!z3) {
                }
            }
            i7++;
        }
        View.MeasureSpec.makeMeasureSpec(paddingLeft, 1073741824);
        this.y = View.MeasureSpec.makeMeasureSpec(measuredHeight, 1073741824);
        this.z = true;
        r(this.l);
        this.z = false;
        int childCount2 = getChildCount();
        for (int i13 = 0; i13 < childCount2; i13++) {
            View childAt2 = getChildAt(i13);
            if (childAt2.getVisibility() != 8 && ((fVar = (f) childAt2.getLayoutParams()) == null || !fVar.a)) {
                childAt2.measure(View.MeasureSpec.makeMeasureSpec((int) (((float) paddingLeft) * fVar.c), 1073741824), this.y);
            }
        }
    }

    public boolean onRequestFocusInDescendants(int i2, Rect rect) {
        int i3;
        int i4;
        e i5;
        int childCount = getChildCount();
        int i6 = -1;
        if ((i2 & 2) != 0) {
            i6 = childCount;
            i4 = 0;
            i3 = 1;
        } else {
            i4 = childCount - 1;
            i3 = -1;
        }
        while (i4 != i6) {
            View childAt = getChildAt(i4);
            if (childAt.getVisibility() == 0 && (i5 = i(childAt)) != null && i5.b == this.l && childAt.requestFocus(i2, rect)) {
                return true;
            }
            i4 += i3;
        }
        return false;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof l)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        l lVar = (l) parcelable;
        super.onRestoreInstanceState(lVar.g);
        r10 r10 = this.k;
        if (r10 != null) {
            r10.g(lVar.j, lVar.k);
            x(lVar.i, false, true, 0);
            return;
        }
        this.m = lVar.i;
        this.n = lVar.j;
        this.o = lVar.k;
    }

    public Parcelable onSaveInstanceState() {
        l lVar = new l(super.onSaveInstanceState());
        lVar.i = this.l;
        r10 r10 = this.k;
        if (r10 != null) {
            lVar.j = r10.h();
        }
        return lVar;
    }

    public void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        if (i2 != i4) {
            int i6 = this.s;
            s(i2, i4, i6, i6);
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        r10 r10;
        boolean z2 = false;
        if ((motionEvent.getAction() == 0 && motionEvent.getEdgeFlags() != 0) || (r10 = this.k) == null || r10.c() == 0) {
            return false;
        }
        if (this.N == null) {
            this.N = VelocityTracker.obtain();
        }
        this.N.addMovement(motionEvent);
        int action = motionEvent.getAction() & KotlinVersion.MAX_COMPONENT_VALUE;
        if (action == 0) {
            this.p.abortAnimation();
            this.B = false;
            r(this.l);
            float x2 = motionEvent.getX();
            this.K = x2;
            this.I = x2;
            float y2 = motionEvent.getY();
            this.L = y2;
            this.J = y2;
            this.M = motionEvent.getPointerId(0);
        } else if (action != 1) {
            if (action == 2) {
                if (!this.D) {
                    int findPointerIndex = motionEvent.findPointerIndex(this.M);
                    if (findPointerIndex == -1) {
                        z2 = u();
                    } else {
                        float x3 = motionEvent.getX(findPointerIndex);
                        float abs = Math.abs(x3 - this.I);
                        float y3 = motionEvent.getY(findPointerIndex);
                        float abs2 = Math.abs(y3 - this.J);
                        if (abs > ((float) this.H) && abs > abs2) {
                            this.D = true;
                            t(true);
                            float f2 = this.K;
                            this.I = x3 - f2 > Utils.FLOAT_EPSILON ? f2 + ((float) this.H) : f2 - ((float) this.H);
                            this.J = y3;
                            setScrollState(1);
                            setScrollingCacheEnabled(true);
                            ViewParent parent = getParent();
                            if (parent != null) {
                                parent.requestDisallowInterceptTouchEvent(true);
                            }
                        }
                    }
                }
                if (this.D) {
                    z2 = false | q(motionEvent.getX(motionEvent.findPointerIndex(this.M)));
                }
            } else if (action != 3) {
                if (action == 5) {
                    int actionIndex = motionEvent.getActionIndex();
                    this.I = motionEvent.getX(actionIndex);
                    this.M = motionEvent.getPointerId(actionIndex);
                } else if (action == 6) {
                    m(motionEvent);
                    this.I = motionEvent.getX(motionEvent.findPointerIndex(this.M));
                }
            } else if (this.D) {
                v(this.l, true, 0, false);
                z2 = u();
            }
        } else if (this.D) {
            VelocityTracker velocityTracker = this.N;
            velocityTracker.computeCurrentVelocity(vf0.DEFAULT_IMAGE_TIMEOUT_MS, (float) this.P);
            int xVelocity = (int) velocityTracker.getXVelocity(this.M);
            this.B = true;
            int clientWidth = getClientWidth();
            int scrollX = getScrollX();
            e j2 = j();
            float f3 = (float) clientWidth;
            float f4 = ((float) this.s) / f3;
            int i2 = j2.b;
            float f5 = ((((float) scrollX) / f3) - j2.e) / (j2.d + f4);
            if (Math.abs((int) (motionEvent.getX(motionEvent.findPointerIndex(this.M)) - this.K)) <= this.Q || Math.abs(xVelocity) <= this.O) {
                i2 += (int) (f5 + (i2 >= this.l ? 0.4f : 0.6f));
            } else if (xVelocity <= 0) {
                i2++;
            }
            if (this.h.size() > 0) {
                ArrayList<e> arrayList = this.h;
                i2 = Math.max(this.h.get(0).b, Math.min(i2, arrayList.get(arrayList.size() - 1).b));
            }
            x(i2, true, true, xVelocity);
            z2 = u();
        }
        if (z2) {
            AtomicInteger atomicInteger = co.a;
            co.c.k(this);
        }
        return true;
    }

    public final boolean p(int i2) {
        if (this.h.size() != 0) {
            e j2 = j();
            int clientWidth = getClientWidth();
            int i3 = this.s;
            int i4 = clientWidth + i3;
            float f2 = (float) clientWidth;
            int i5 = j2.b;
            float f3 = ((((float) i2) / f2) - j2.e) / (j2.d + (((float) i3) / f2));
            this.V = false;
            l(i5, f3, (int) (((float) i4) * f3));
            if (this.V) {
                return true;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        } else if (this.U) {
            return false;
        } else {
            this.V = false;
            l(0, Utils.FLOAT_EPSILON, 0);
            if (this.V) {
                return false;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        }
    }

    public final boolean q(float f2) {
        boolean z2;
        boolean z3;
        float f3 = this.I - f2;
        this.I = f2;
        float scrollX = ((float) getScrollX()) + f3;
        float clientWidth = (float) getClientWidth();
        float f4 = this.w * clientWidth;
        float f5 = this.x * clientWidth;
        boolean z4 = false;
        e eVar = this.h.get(0);
        ArrayList<e> arrayList = this.h;
        e eVar2 = arrayList.get(arrayList.size() - 1);
        if (eVar.b != 0) {
            f4 = eVar.e * clientWidth;
            z2 = false;
        } else {
            z2 = true;
        }
        if (eVar2.b != this.k.c() - 1) {
            f5 = eVar2.e * clientWidth;
            z3 = false;
        } else {
            z3 = true;
        }
        if (scrollX < f4) {
            if (z2) {
                this.S.onPull(Math.abs(f4 - scrollX) / clientWidth);
                z4 = true;
            }
            scrollX = f4;
        } else if (scrollX > f5) {
            if (z3) {
                this.T.onPull(Math.abs(scrollX - f5) / clientWidth);
                z4 = true;
            }
            scrollX = f5;
        }
        int i2 = (int) scrollX;
        this.I = (scrollX - ((float) i2)) + this.I;
        scrollTo(i2, getScrollY());
        p(i2);
        return z4;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:22:0x005c, code lost:
        if (r5 == r6) goto L_0x0063;
     */
    public void r(int i2) {
        e eVar;
        String str;
        e eVar2;
        e eVar3;
        e i3;
        float f2;
        int i4;
        int i5;
        e eVar4;
        e eVar5;
        float f3;
        int i6 = this.l;
        if (i6 != i2) {
            eVar = k(i6);
            this.l = i2;
        } else {
            eVar = null;
        }
        if (this.k == null) {
            y();
        } else if (this.B) {
            y();
        } else if (getWindowToken() != null) {
            this.k.j(this);
            int i7 = this.C;
            int max = Math.max(0, this.l - i7);
            int c2 = this.k.c();
            int min = Math.min(c2 - 1, this.l + i7);
            if (c2 == this.g) {
                int i8 = 0;
                while (true) {
                    if (i8 >= this.h.size()) {
                        break;
                    }
                    eVar2 = this.h.get(i8);
                    int i9 = eVar2.b;
                    int i10 = this.l;
                    if (i9 < i10) {
                        i8++;
                    }
                }
                eVar2 = null;
                if (eVar2 == null && c2 > 0) {
                    eVar2 = a(this.l, i8);
                }
                if (eVar2 != null) {
                    int i11 = i8 - 1;
                    e eVar6 = i11 >= 0 ? this.h.get(i11) : null;
                    int clientWidth = getClientWidth();
                    if (clientWidth <= 0) {
                        f2 = Utils.FLOAT_EPSILON;
                    } else {
                        f2 = (2.0f - eVar2.d) + (((float) getPaddingLeft()) / ((float) clientWidth));
                    }
                    float f4 = Utils.FLOAT_EPSILON;
                    for (int i12 = this.l - 1; i12 >= 0; i12--) {
                        if (f4 < f2 || i12 >= max) {
                            if (eVar6 == null || i12 != eVar6.b) {
                                f4 += a(i12, i11 + 1).d;
                                i8++;
                                if (i11 >= 0) {
                                    eVar6 = this.h.get(i11);
                                }
                            } else {
                                f4 += eVar6.d;
                                i11--;
                                if (i11 >= 0) {
                                    eVar6 = this.h.get(i11);
                                }
                            }
                        } else if (eVar6 == null) {
                            break;
                        } else {
                            if (i12 == eVar6.b && !eVar6.c) {
                                this.h.remove(i11);
                                this.k.a(this, i12, eVar6.a);
                                i11--;
                                i8--;
                                if (i11 >= 0) {
                                    eVar6 = this.h.get(i11);
                                }
                            }
                        }
                        eVar6 = null;
                    }
                    float f5 = eVar2.d;
                    int i13 = i8 + 1;
                    if (f5 < 2.0f) {
                        e eVar7 = i13 < this.h.size() ? this.h.get(i13) : null;
                        if (clientWidth <= 0) {
                            f3 = Utils.FLOAT_EPSILON;
                        } else {
                            f3 = (((float) getPaddingRight()) / ((float) clientWidth)) + 2.0f;
                        }
                        int i14 = i13;
                        for (int i15 = this.l + 1; i15 < c2; i15++) {
                            if (f5 < f3 || i15 <= min) {
                                if (eVar7 == null || i15 != eVar7.b) {
                                    e a2 = a(i15, i14);
                                    i14++;
                                    f5 += a2.d;
                                    if (i14 < this.h.size()) {
                                        eVar7 = this.h.get(i14);
                                    }
                                } else {
                                    f5 += eVar7.d;
                                    i14++;
                                    if (i14 < this.h.size()) {
                                        eVar7 = this.h.get(i14);
                                    }
                                }
                            } else if (eVar7 == null) {
                                break;
                            } else {
                                if (i15 == eVar7.b && !eVar7.c) {
                                    this.h.remove(i14);
                                    this.k.a(this, i15, eVar7.a);
                                    if (i14 < this.h.size()) {
                                        eVar7 = this.h.get(i14);
                                    }
                                }
                            }
                            eVar7 = null;
                        }
                    }
                    int c3 = this.k.c();
                    int clientWidth2 = getClientWidth();
                    float f6 = clientWidth2 > 0 ? ((float) this.s) / ((float) clientWidth2) : Utils.FLOAT_EPSILON;
                    if (eVar != null) {
                        int i16 = eVar.b;
                        int i17 = eVar2.b;
                        if (i16 < i17) {
                            float f7 = eVar.e + eVar.d + f6;
                            int i18 = 0;
                            while (true) {
                                i16++;
                                if (i16 > eVar2.b || i18 >= this.h.size()) {
                                    break;
                                }
                                e eVar8 = this.h.get(i18);
                                while (true) {
                                    eVar5 = eVar8;
                                    if (i16 > eVar5.b && i18 < this.h.size() - 1) {
                                        i18++;
                                        eVar8 = this.h.get(i18);
                                    }
                                }
                                while (i16 < eVar5.b) {
                                    Objects.requireNonNull(this.k);
                                    f7 += 1.0f + f6;
                                    i16++;
                                }
                                eVar5.e = f7;
                                f7 += eVar5.d + f6;
                            }
                        } else if (i16 > i17) {
                            int size = this.h.size() - 1;
                            float f8 = eVar.e;
                            while (true) {
                                i16--;
                                if (i16 < eVar2.b || size < 0) {
                                    break;
                                }
                                e eVar9 = this.h.get(size);
                                while (true) {
                                    eVar4 = eVar9;
                                    if (i16 < eVar4.b && size > 0) {
                                        size--;
                                        eVar9 = this.h.get(size);
                                    }
                                }
                                while (i16 > eVar4.b) {
                                    Objects.requireNonNull(this.k);
                                    f8 -= 1.0f + f6;
                                    i16--;
                                }
                                f8 -= eVar4.d + f6;
                                eVar4.e = f8;
                            }
                        }
                    }
                    int size2 = this.h.size();
                    float f9 = eVar2.e;
                    int i19 = eVar2.b;
                    int i20 = i19 - 1;
                    this.w = i19 == 0 ? f9 : -3.4028235E38f;
                    int i21 = c3 - 1;
                    this.x = i19 == i21 ? (eVar2.d + f9) - 1.0f : Float.MAX_VALUE;
                    int i22 = i8 - 1;
                    while (i22 >= 0) {
                        e eVar10 = this.h.get(i22);
                        while (true) {
                            i5 = eVar10.b;
                            if (i20 <= i5) {
                                break;
                            }
                            i20--;
                            Objects.requireNonNull(this.k);
                            f9 -= 1.0f + f6;
                        }
                        f9 -= eVar10.d + f6;
                        eVar10.e = f9;
                        if (i5 == 0) {
                            this.w = f9;
                        }
                        i22--;
                        i20--;
                    }
                    float f10 = eVar2.e + eVar2.d + f6;
                    int i23 = eVar2.b;
                    while (true) {
                        i23++;
                        if (i13 >= size2) {
                            break;
                        }
                        e eVar11 = this.h.get(i13);
                        while (true) {
                            i4 = eVar11.b;
                            if (i23 >= i4) {
                                break;
                            }
                            i23++;
                            Objects.requireNonNull(this.k);
                            f10 += 1.0f + f6;
                        }
                        if (i4 == i21) {
                            this.x = (eVar11.d + f10) - 1.0f;
                        }
                        eVar11.e = f10;
                        f10 += eVar11.d + f6;
                        i13++;
                    }
                    this.k.i(this, this.l, eVar2.a);
                }
                this.k.b(this);
                int childCount = getChildCount();
                for (int i24 = 0; i24 < childCount; i24++) {
                    View childAt = getChildAt(i24);
                    f fVar = (f) childAt.getLayoutParams();
                    fVar.f = i24;
                    if (!fVar.a && fVar.c == Utils.FLOAT_EPSILON && (i3 = i(childAt)) != null) {
                        fVar.c = i3.d;
                        fVar.e = i3.b;
                    }
                }
                y();
                if (hasFocus()) {
                    View findFocus = findFocus();
                    if (findFocus != null) {
                        while (true) {
                            ViewParent parent = findFocus.getParent();
                            if (parent == this) {
                                eVar3 = i(findFocus);
                                break;
                            }
                            if (parent == null || !(parent instanceof View)) {
                                break;
                            }
                            findFocus = (View) parent;
                        }
                    }
                    eVar3 = null;
                    if (eVar3 == null || eVar3.b != this.l) {
                        for (int i25 = 0; i25 < getChildCount(); i25++) {
                            View childAt2 = getChildAt(i25);
                            e i26 = i(childAt2);
                            if (i26 != null && i26.b == this.l && childAt2.requestFocus(2)) {
                                return;
                            }
                        }
                        return;
                    }
                    return;
                }
                return;
            }
            try {
                str = getResources().getResourceName(getId());
            } catch (Resources.NotFoundException unused) {
                str = Integer.toHexString(getId());
            }
            StringBuilder J0 = ze0.J0("The application's PagerAdapter changed the adapter's contents without calling PagerAdapter#notifyDataSetChanged! Expected adapter item count: ");
            J0.append(this.g);
            J0.append(", found: ");
            J0.append(c2);
            J0.append(" Pager id: ");
            J0.append(str);
            J0.append(" Pager class: ");
            J0.append(getClass());
            J0.append(" Problematic adapter: ");
            J0.append(this.k.getClass());
            throw new IllegalStateException(J0.toString());
        }
    }

    public void removeView(View view) {
        if (this.z) {
            removeViewInLayout(view);
        } else {
            super.removeView(view);
        }
    }

    public final void s(int i2, int i3, int i4, int i5) {
        if (i3 <= 0 || this.h.isEmpty()) {
            e k2 = k(this.l);
            int min = (int) ((k2 != null ? Math.min(k2.e, this.x) : Utils.FLOAT_EPSILON) * ((float) ((i2 - getPaddingLeft()) - getPaddingRight())));
            if (min != getScrollX()) {
                e(false);
                scrollTo(min, getScrollY());
            }
        } else if (!this.p.isFinished()) {
            this.p.setFinalX(getCurrentItem() * getClientWidth());
        } else {
            scrollTo((int) ((((float) getScrollX()) / ((float) (((i3 - getPaddingLeft()) - getPaddingRight()) + i5))) * ((float) (((i2 - getPaddingLeft()) - getPaddingRight()) + i4))), getScrollY());
        }
    }

    public void setAdapter(r10 r10) {
        r10 r102 = this.k;
        if (r102 != null) {
            synchronized (r102) {
            }
            this.k.j(this);
            for (int i2 = 0; i2 < this.h.size(); i2++) {
                e eVar = this.h.get(i2);
                this.k.a(this, eVar.b, eVar.a);
            }
            this.k.b(this);
            this.h.clear();
            int i3 = 0;
            while (i3 < getChildCount()) {
                if (!((f) getChildAt(i3).getLayoutParams()).a) {
                    removeViewAt(i3);
                    i3--;
                }
                i3++;
            }
            this.l = 0;
            scrollTo(0, 0);
        }
        r10 r103 = this.k;
        this.k = r10;
        this.g = 0;
        if (r10 != null) {
            if (this.r == null) {
                this.r = new k();
            }
            synchronized (this.k) {
            }
            this.B = false;
            boolean z2 = this.U;
            this.U = true;
            this.g = this.k.c();
            if (this.m >= 0) {
                this.k.g(this.n, this.o);
                x(this.m, false, true, 0);
                this.m = -1;
                this.n = null;
                this.o = null;
            } else if (!z2) {
                r(this.l);
            } else {
                requestLayout();
            }
        }
        List<h> list = this.c0;
        if (!(list == null || list.isEmpty())) {
            int size = this.c0.size();
            for (int i4 = 0; i4 < size; i4++) {
                this.c0.get(i4).a(this, r103, r10);
            }
        }
    }

    public void setCurrentItem(int i2) {
        this.B = false;
        x(i2, !this.U, false, 0);
    }

    public void setOffscreenPageLimit(int i2) {
        if (i2 < 1) {
            Log.w("ViewPager", "Requested offscreen page limit " + i2 + " too small; defaulting to " + 1);
            i2 = 1;
        }
        if (i2 != this.C) {
            this.C = i2;
            r(this.l);
        }
    }

    @Deprecated
    public void setOnPageChangeListener(i iVar) {
        this.b0 = iVar;
    }

    public void setPageMargin(int i2) {
        int i3 = this.s;
        this.s = i2;
        int width = getWidth();
        s(width, width, i2, i3);
        requestLayout();
    }

    public void setPageMarginDrawable(Drawable drawable) {
        this.t = drawable;
        if (drawable != null) {
            refreshDrawableState();
        }
        setWillNotDraw(drawable == null);
        invalidate();
    }

    public void setScrollState(int i2) {
        if (this.i0 != i2) {
            this.i0 = i2;
            if (this.d0 != null) {
                boolean z2 = i2 != 0;
                int childCount = getChildCount();
                for (int i3 = 0; i3 < childCount; i3++) {
                    getChildAt(i3).setLayerType(z2 ? this.e0 : 0, null);
                }
            }
            i iVar = this.b0;
            if (iVar != null) {
                iVar.b(i2);
            }
            List<i> list = this.a0;
            if (list != null) {
                int size = list.size();
                for (int i4 = 0; i4 < size; i4++) {
                    i iVar2 = this.a0.get(i4);
                    if (iVar2 != null) {
                        iVar2.b(i2);
                    }
                }
            }
        }
    }

    public final void t(boolean z2) {
        ViewParent parent = getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(z2);
        }
    }

    public final boolean u() {
        this.M = -1;
        this.D = false;
        this.E = false;
        VelocityTracker velocityTracker = this.N;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.N = null;
        }
        this.S.onRelease();
        this.T.onRelease();
        if (this.S.isFinished() || this.T.isFinished()) {
            return true;
        }
        return false;
    }

    public final void v(int i2, boolean z2, int i3, boolean z3) {
        int i4;
        int i5;
        e k2 = k(i2);
        int max = k2 != null ? (int) (Math.max(this.w, Math.min(k2.e, this.x)) * ((float) getClientWidth())) : 0;
        if (z2) {
            if (getChildCount() == 0) {
                setScrollingCacheEnabled(false);
            } else {
                Scroller scroller = this.p;
                if (scroller != null && !scroller.isFinished()) {
                    i4 = this.q ? this.p.getCurrX() : this.p.getStartX();
                    this.p.abortAnimation();
                    setScrollingCacheEnabled(false);
                } else {
                    i4 = getScrollX();
                }
                int scrollY = getScrollY();
                int i6 = max - i4;
                int i7 = 0 - scrollY;
                if (i6 == 0 && i7 == 0) {
                    e(false);
                    r(this.l);
                    setScrollState(0);
                } else {
                    setScrollingCacheEnabled(true);
                    setScrollState(2);
                    int clientWidth = getClientWidth();
                    int i8 = clientWidth / 2;
                    float f2 = (float) clientWidth;
                    float f3 = (float) i8;
                    float sin = (((float) Math.sin((double) ((Math.min(1.0f, (((float) Math.abs(i6)) * 1.0f) / f2) - 0.5f) * 0.47123894f))) * f3) + f3;
                    int abs = Math.abs(i3);
                    if (abs > 0) {
                        i5 = Math.round(Math.abs(sin / ((float) abs)) * 1000.0f) * 4;
                    } else {
                        Objects.requireNonNull(this.k);
                        i5 = (int) (((((float) Math.abs(i6)) / ((f2 * 1.0f) + ((float) this.s))) + 1.0f) * 100.0f);
                    }
                    int min = Math.min(i5, 600);
                    this.q = false;
                    this.p.startScroll(i4, scrollY, i6, i7, min);
                    AtomicInteger atomicInteger = co.a;
                    co.c.k(this);
                }
            }
            if (z3) {
                g(i2);
                return;
            }
            return;
        }
        if (z3) {
            g(i2);
        }
        e(false);
        scrollTo(max, 0);
        p(max);
    }

    public boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.t;
    }

    public void w(int i2, boolean z2) {
        this.B = false;
        x(i2, z2, false, 0);
    }

    public void x(int i2, boolean z2, boolean z3, int i3) {
        r10 r10 = this.k;
        boolean z4 = false;
        if (r10 == null || r10.c() <= 0) {
            setScrollingCacheEnabled(false);
        } else if (z3 || this.l != i2 || this.h.size() == 0) {
            if (i2 < 0) {
                i2 = 0;
            } else if (i2 >= this.k.c()) {
                i2 = this.k.c() - 1;
            }
            int i4 = this.C;
            int i5 = this.l;
            if (i2 > i5 + i4 || i2 < i5 - i4) {
                for (int i6 = 0; i6 < this.h.size(); i6++) {
                    this.h.get(i6).c = true;
                }
            }
            if (this.l != i2) {
                z4 = true;
            }
            if (this.U) {
                this.l = i2;
                if (z4) {
                    g(i2);
                }
                requestLayout();
                return;
            }
            r(i2);
            v(i2, z2, i3, z4);
        } else {
            setScrollingCacheEnabled(false);
        }
    }

    public final void y() {
        if (this.f0 != 0) {
            ArrayList<View> arrayList = this.g0;
            if (arrayList == null) {
                this.g0 = new ArrayList<>();
            } else {
                arrayList.clear();
            }
            int childCount = getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                this.g0.add(getChildAt(i2));
            }
            Collections.sort(this.g0, m0);
        }
    }

    public static class f extends ViewGroup.LayoutParams {
        public boolean a;
        public int b;
        public float c = Utils.FLOAT_EPSILON;
        public boolean d;
        public int e;
        public int f;

        public f() {
            super(-1, -1);
        }

        public f(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ViewPager.j0);
            this.b = obtainStyledAttributes.getInteger(0, 48);
            obtainStyledAttributes.recycle();
        }
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new f(getContext(), attributeSet);
    }

    public void setPageMarginDrawable(int i2) {
        Context context = getContext();
        Object obj = wk.a;
        setPageMarginDrawable(wk.c.b(context, i2));
    }
}
