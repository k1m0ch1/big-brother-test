package androidx.databinding;

import android.util.Log;
import android.view.View;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

public class MergedDataBinderMapper extends lp {
    public Set<Class<? extends lp>> a = new HashSet();
    public List<lp> b = new CopyOnWriteArrayList();
    public List<String> c = new CopyOnWriteArrayList();

    @Override // defpackage.lp
    public ViewDataBinding b(mp mpVar, View view, int i) {
        for (lp lpVar : this.b) {
            ViewDataBinding b2 = lpVar.b(mpVar, view, i);
            if (b2 != null) {
                return b2;
            }
        }
        if (e()) {
            return b(mpVar, view, i);
        }
        return null;
    }

    @Override // defpackage.lp
    public ViewDataBinding c(mp mpVar, View[] viewArr, int i) {
        for (lp lpVar : this.b) {
            ViewDataBinding c2 = lpVar.c(mpVar, viewArr, i);
            if (c2 != null) {
                return c2;
            }
        }
        if (e()) {
            return c(mpVar, viewArr, i);
        }
        return null;
    }

    /* JADX DEBUG: Multi-variable search result rejected for r1v0, resolved type: java.util.Set<java.lang.Class<? extends lp>> */
    /* JADX WARN: Multi-variable type inference failed */
    public void d(lp lpVar) {
        if (this.a.add(lpVar.getClass())) {
            this.b.add(lpVar);
            for (lp lpVar2 : lpVar.a()) {
                d(lpVar2);
            }
        }
    }

    public final boolean e() {
        boolean z = false;
        for (String str : this.c) {
            try {
                Class<?> cls = Class.forName(str);
                if (lp.class.isAssignableFrom(cls)) {
                    d((lp) cls.newInstance());
                    this.c.remove(str);
                    z = true;
                }
            } catch (ClassNotFoundException unused) {
            } catch (IllegalAccessException e) {
                Log.e("MergedDataBinderMapper", "unable to add feature mapper for " + str, e);
            } catch (InstantiationException e2) {
                Log.e("MergedDataBinderMapper", "unable to add feature mapper for " + str, e2);
            }
        }
        return z;
    }
}
