package androidx.databinding;

import android.annotation.TargetApi;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.SparseIntArray;
import android.view.Choreographer;
import android.view.View;
import android.view.ViewGroup;
import androidx.lifecycle.LiveData;
import com.telkom.tracencare.R;
import defpackage.sr;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;

public abstract class ViewDataBinding extends jp {
    public static int p;
    public static final boolean q;
    public static final e r = new b();
    public static final ReferenceQueue<ViewDataBinding> s = new ReferenceQueue<>();
    public static final View.OnAttachStateChangeListener t = new c();
    public final Runnable b;
    public boolean c;
    public boolean d;
    public i[] e;
    public final View f;
    public boolean g;
    public Choreographer h;
    public final Choreographer.FrameCallback i;
    public Handler j;
    public final mp k;
    public ViewDataBinding l;
    public yr m;
    public OnStartListener n;
    public boolean o;

    public static class OnStartListener implements xr {
        public final WeakReference<ViewDataBinding> g;

        public OnStartListener(ViewDataBinding viewDataBinding, a aVar) {
            this.g = new WeakReference<>(viewDataBinding);
        }

        @gs(sr.a.ON_START)
        public void onStart() {
            ViewDataBinding viewDataBinding = this.g.get();
            if (viewDataBinding != null) {
                viewDataBinding.d();
            }
        }
    }

    public static class a implements e {
    }

    public static class b implements e {
        @Override // androidx.databinding.ViewDataBinding.e
        public i a(ViewDataBinding viewDataBinding, int i) {
            return new g(viewDataBinding, i).a;
        }
    }

    public static class c implements View.OnAttachStateChangeListener {
        @TargetApi(19)
        public void onViewAttachedToWindow(View view) {
            (view != null ? (ViewDataBinding) view.getTag(R.id.dataBinding) : null).b.run();
            view.removeOnAttachStateChangeListener(this);
        }

        public void onViewDetachedFromWindow(View view) {
        }
    }

    public class d implements Runnable {
        public d() {
        }

        public void run() {
            synchronized (this) {
                ViewDataBinding.this.c = false;
            }
            while (true) {
                Reference<? extends ViewDataBinding> poll = ViewDataBinding.s.poll();
                if (poll == null) {
                    break;
                } else if (poll instanceof i) {
                    ((i) poll).a();
                }
            }
            if (!ViewDataBinding.this.f.isAttachedToWindow()) {
                View view = ViewDataBinding.this.f;
                View.OnAttachStateChangeListener onAttachStateChangeListener = ViewDataBinding.t;
                view.removeOnAttachStateChangeListener(onAttachStateChangeListener);
                ViewDataBinding.this.f.addOnAttachStateChangeListener(onAttachStateChangeListener);
                return;
            }
            ViewDataBinding.this.d();
        }
    }

    public interface e {
        i a(ViewDataBinding viewDataBinding, int i);
    }

    public static class f {
        public final String[][] a;
        public final int[][] b;
        public final int[][] c;

        public f(int i) {
            this.a = new String[i][];
            this.b = new int[i][];
            this.c = new int[i][];
        }

        public void a(int i, String[] strArr, int[] iArr, int[] iArr2) {
            this.a[i] = strArr;
            this.b[i] = iArr;
            this.c[i] = iArr2;
        }
    }

    public static class g implements fs, h<LiveData<?>> {
        public final i<LiveData<?>> a;
        public yr b;

        public g(ViewDataBinding viewDataBinding, int i) {
            this.a = new i<>(viewDataBinding, i, this);
        }

        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object] */
        @Override // androidx.databinding.ViewDataBinding.h
        public void a(LiveData<?> liveData) {
            liveData.h(this);
        }

        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object] */
        @Override // androidx.databinding.ViewDataBinding.h
        public void b(LiveData<?> liveData) {
            LiveData<?> liveData2 = liveData;
            yr yrVar = this.b;
            if (yrVar != null) {
                liveData2.e(yrVar, this);
            }
        }

        @Override // androidx.databinding.ViewDataBinding.h
        public void c(yr yrVar) {
            T t = this.a.c;
            if (t != null) {
                if (this.b != null) {
                    t.h(this);
                }
                if (yrVar != null) {
                    t.e(yrVar, this);
                }
            }
            this.b = yrVar;
        }

        @Override // defpackage.fs
        public void onChanged(Object obj) {
            i<LiveData<?>> iVar = this.a;
            ViewDataBinding viewDataBinding = (ViewDataBinding) iVar.get();
            if (viewDataBinding == null) {
                iVar.a();
            }
            if (viewDataBinding != null) {
                i<LiveData<?>> iVar2 = this.a;
                int i = iVar2.b;
                T t = iVar2.c;
                if (!viewDataBinding.o && viewDataBinding.l(i, t, 0)) {
                    viewDataBinding.o();
                }
            }
        }
    }

    public interface h<T> {
        void a(T t);

        void b(T t);

        void c(yr yrVar);
    }

    public static class i<T> extends WeakReference<ViewDataBinding> {
        public final h<T> a;
        public final int b;
        public T c;

        public i(ViewDataBinding viewDataBinding, int i, h<T> hVar) {
            super(viewDataBinding, ViewDataBinding.s);
            this.b = i;
            this.a = hVar;
        }

        public boolean a() {
            boolean z;
            T t = this.c;
            if (t != null) {
                this.a.a(t);
                z = true;
            } else {
                z = false;
            }
            this.c = null;
            return z;
        }
    }

    static {
        int i2 = Build.VERSION.SDK_INT;
        p = i2;
        q = i2 >= 16;
    }

    public ViewDataBinding(Object obj, View view, int i2) {
        mp mpVar;
        if (obj == null) {
            mpVar = null;
        } else if (obj instanceof mp) {
            mpVar = (mp) obj;
        } else {
            throw new IllegalArgumentException("The provided bindingComponent parameter must be an instance of DataBindingComponent. See  https://issuetracker.google.com/issues/116541301 for details of why this parameter is not defined as DataBindingComponent");
        }
        this.b = new d();
        this.c = false;
        this.d = false;
        this.k = mpVar;
        this.e = new i[i2];
        this.f = view;
        if (Looper.myLooper() == null) {
            throw new IllegalStateException("DataBinding must be created in view's UI Thread");
        } else if (q) {
            this.h = Choreographer.getInstance();
            this.i = new pp(this);
        } else {
            this.i = null;
            this.j = new Handler(Looper.myLooper());
        }
    }

    public static int e(View view, int i2) {
        if (Build.VERSION.SDK_INT >= 23) {
            return view.getContext().getColor(i2);
        }
        return view.getResources().getColor(i2);
    }

    public static boolean i(String str, int i2) {
        int length = str.length();
        if (length == i2) {
            return false;
        }
        while (i2 < length) {
            if (!Character.isDigit(str.charAt(i2))) {
                return false;
            }
            i2++;
        }
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:95:0x019d  */
    /* JADX WARNING: Removed duplicated region for block: B:96:0x01ad  */
    public static void j(mp mpVar, View view, Object[] objArr, f fVar, SparseIntArray sparseIntArray, boolean z) {
        int i2;
        boolean z2;
        int i3;
        String str;
        int i4;
        int i5;
        boolean z3;
        int i6;
        int id;
        int i7;
        int i8;
        f fVar2 = fVar;
        if ((view != null ? (ViewDataBinding) view.getTag(R.id.dataBinding) : null) == null) {
            Object tag = view.getTag();
            String str2 = tag instanceof String ? (String) tag : null;
            String str3 = "layout";
            int i9 = -1;
            int i10 = 1;
            if (z && str2 != null && str2.startsWith(str3)) {
                int lastIndexOf = str2.lastIndexOf(95);
                if (lastIndexOf > 0) {
                    int i11 = lastIndexOf + 1;
                    if (i(str2, i11)) {
                        i8 = m(str2, i11);
                        if (objArr[i8] == null) {
                            objArr[i8] = view;
                        }
                        if (fVar2 == null) {
                            i8 = -1;
                        }
                        z2 = true;
                        i2 = i8;
                    }
                }
                i8 = -1;
                z2 = false;
                i2 = i8;
            } else if (str2 == null || !str2.startsWith("binding_")) {
                z2 = false;
                i2 = -1;
            } else {
                int m2 = m(str2, 8);
                if (objArr[m2] == null) {
                    objArr[m2] = view;
                }
                if (fVar2 == null) {
                    m2 = -1;
                }
                i2 = m2;
                z2 = true;
            }
            if (!z2 && (id = view.getId()) > 0 && sparseIntArray != null && (i7 = sparseIntArray.get(id, -1)) >= 0 && objArr[i7] == null) {
                objArr[i7] = view;
            }
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                int childCount = viewGroup.getChildCount();
                int i12 = 0;
                int i13 = 0;
                while (i12 < childCount) {
                    View childAt = viewGroup.getChildAt(i12);
                    if (i2 >= 0 && (childAt.getTag() instanceof String)) {
                        String str4 = (String) childAt.getTag();
                        if (str4.endsWith("_0") && str4.startsWith(str3) && str4.indexOf(47) > 0) {
                            CharSequence subSequence = str4.subSequence(str4.indexOf(47) + i10, str4.length() - 2);
                            String[] strArr = fVar2.a[i2];
                            int length = strArr.length;
                            int i14 = i13;
                            while (true) {
                                if (i14 >= length) {
                                    i14 = -1;
                                    break;
                                } else if (TextUtils.equals(subSequence, strArr[i14])) {
                                    break;
                                } else {
                                    i14++;
                                }
                            }
                            if (i14 >= 0) {
                                int i15 = i14 + 1;
                                int i16 = fVar2.b[i2][i14];
                                int i17 = fVar2.c[i2][i14];
                                String str5 = (String) viewGroup.getChildAt(i12).getTag();
                                String substring = str5.substring(0, str5.length() + i9);
                                int length2 = substring.length();
                                int childCount2 = viewGroup.getChildCount();
                                i3 = childCount;
                                int i18 = i12 + 1;
                                int i19 = i12;
                                while (true) {
                                    if (i18 >= childCount2) {
                                        str = str3;
                                        break;
                                    }
                                    View childAt2 = viewGroup.getChildAt(i18);
                                    String str6 = childAt2.getTag() instanceof String ? (String) childAt2.getTag() : null;
                                    if (str6 != null && str6.startsWith(substring)) {
                                        str = str3;
                                        if (str6.length() == str5.length() && str6.charAt(str6.length() - 1) == '0') {
                                            break;
                                        } else if (i(str6, length2)) {
                                            i19 = i18;
                                        }
                                    } else {
                                        str = str3;
                                    }
                                    i18++;
                                    str3 = str;
                                }
                                if (i19 == i12) {
                                    objArr[i16] = np.a(mpVar, childAt, i17);
                                } else {
                                    int i20 = (i19 - i12) + 1;
                                    View[] viewArr = new View[i20];
                                    for (int i21 = 0; i21 < i20; i21++) {
                                        viewArr[i21] = viewGroup.getChildAt(i12 + i21);
                                    }
                                    objArr[i16] = np.a.c(mpVar, viewArr, i17);
                                    i12 += i20 - 1;
                                }
                                i4 = i15;
                                i5 = i12;
                                z3 = true;
                                if (z3) {
                                    i6 = i3;
                                    j(mpVar, childAt, objArr, fVar, sparseIntArray, false);
                                } else {
                                    i6 = i3;
                                }
                                int i22 = i5 + 1;
                                fVar2 = fVar;
                                i12 = i22;
                                i13 = i4;
                                childCount = i6;
                                str3 = str;
                                i9 = -1;
                                i10 = 1;
                            }
                        }
                    }
                    i3 = childCount;
                    str = str3;
                    i5 = i12;
                    i4 = i13;
                    z3 = false;
                    if (z3) {
                    }
                    int i222 = i5 + 1;
                    fVar2 = fVar;
                    i12 = i222;
                    i13 = i4;
                    childCount = i6;
                    str3 = str;
                    i9 = -1;
                    i10 = 1;
                }
            }
        }
    }

    public static Object[] k(mp mpVar, View view, int i2, f fVar, SparseIntArray sparseIntArray) {
        Object[] objArr = new Object[i2];
        j(mpVar, view, objArr, fVar, sparseIntArray, true);
        return objArr;
    }

    public static int m(String str, int i2) {
        int length = str.length();
        int i3 = 0;
        while (i2 < length) {
            i3 = (i3 * 10) + (str.charAt(i2) - '0');
            i2++;
        }
        return i3;
    }

    public static boolean p(Boolean bool) {
        if (bool == null) {
            return false;
        }
        return bool.booleanValue();
    }

    public abstract void b();

    public final void c() {
        if (this.g) {
            o();
        } else if (g()) {
            this.g = true;
            this.d = false;
            b();
            this.g = false;
        }
    }

    public void d() {
        ViewDataBinding viewDataBinding = this.l;
        if (viewDataBinding == null) {
            c();
        } else {
            viewDataBinding.d();
        }
    }

    public View f() {
        return this.f;
    }

    public abstract boolean g();

    public abstract void h();

    public abstract boolean l(int i2, Object obj, int i3);

    /* JADX DEBUG: Multi-variable search result rejected for r3v0, resolved type: java.lang.Object */
    /* JADX WARN: Multi-variable type inference failed */
    public void n(int i2, Object obj, e eVar) {
        i iVar = this.e[i2];
        if (iVar == null) {
            iVar = eVar.a(this, i2);
            this.e[i2] = iVar;
            yr yrVar = this.m;
            if (yrVar != null) {
                iVar.a.c(yrVar);
            }
        }
        iVar.a();
        iVar.c = obj;
        iVar.a.b(obj);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:20:0x002f, code lost:
        if (androidx.databinding.ViewDataBinding.q == false) goto L_0x0039;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0031, code lost:
        r3.h.postFrameCallback(r3.i);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0039, code lost:
        r3.j.post(r3.b);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:?, code lost:
        return;
     */
    public void o() {
        ViewDataBinding viewDataBinding = this.l;
        if (viewDataBinding != null) {
            viewDataBinding.o();
            return;
        }
        yr yrVar = this.m;
        if (yrVar != null) {
            if (!(((as) yrVar.getLifecycle()).c.compareTo(sr.b.STARTED) >= 0)) {
                return;
            }
        }
        synchronized (this) {
            if (!this.c) {
                this.c = true;
            }
        }
    }

    public void q(yr yrVar) {
        yr yrVar2 = this.m;
        if (yrVar2 != yrVar) {
            if (yrVar2 != null) {
                yrVar2.getLifecycle().b(this.n);
            }
            this.m = yrVar;
            if (yrVar != null) {
                if (this.n == null) {
                    this.n = new OnStartListener(this, null);
                }
                yrVar.getLifecycle().a(this.n);
            }
            i[] iVarArr = this.e;
            for (i iVar : iVarArr) {
                if (iVar != null) {
                    iVar.a.c(yrVar);
                }
            }
        }
    }

    public abstract boolean r(int i2, Object obj);

    public boolean s(int i2, LiveData<?> liveData) {
        boolean z = true;
        this.o = true;
        try {
            e eVar = r;
            if (liveData == null) {
                i iVar = this.e[i2];
                if (iVar != null) {
                    z = iVar.a();
                    return z;
                }
            } else {
                i[] iVarArr = this.e;
                i iVar2 = iVarArr[i2];
                if (iVar2 == null) {
                    n(i2, liveData, eVar);
                } else if (iVar2.c != liveData) {
                    i iVar3 = iVarArr[i2];
                    if (iVar3 != null) {
                        iVar3.a();
                    }
                    n(i2, liveData, eVar);
                }
                return z;
            }
            z = false;
            return z;
        } finally {
            this.o = false;
        }
    }
}
