package androidx.databinding;

public class DataBinderMapperImpl extends MergedDataBinderMapper {
    public DataBinderMapperImpl() {
        d(new com.telkom.tracencare.DataBinderMapperImpl());
    }
}
