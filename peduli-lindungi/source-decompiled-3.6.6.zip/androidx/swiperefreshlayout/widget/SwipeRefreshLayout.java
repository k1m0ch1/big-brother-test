package androidx.swiperefreshlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Transformation;
import android.widget.ListView;
import com.github.mikephil.charting.utils.Utils;
import defpackage.co;
import defpackage.e00;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.KotlinVersion;

public class SwipeRefreshLayout extends ViewGroup implements qn {
    public static final String P = SwipeRefreshLayout.class.getSimpleName();
    public static final int[] Q = {16842766};
    public int A;
    public int B;
    public int C;
    public int D;
    public e00 E;
    public Animation F;
    public Animation G;
    public Animation H;
    public Animation I;
    public boolean J;
    public int K;
    public g L;
    public Animation.AnimationListener M = new a();
    public final Animation N = new e();
    public final Animation O = new f();
    public View g;
    public h h;
    public boolean i = false;
    public int j;
    public float k = -1.0f;
    public float l;
    public final un m;
    public final rn n;
    public final int[] o = new int[2];
    public final int[] p = new int[2];
    public boolean q;
    public int r;
    public int s;
    public float t;
    public float u;
    public boolean v;
    public int w = -1;
    public final DecelerateInterpolator x;
    public b00 y;
    public int z = -1;

    public class a implements Animation.AnimationListener {
        public a() {
        }

        public void onAnimationEnd(Animation animation) {
            h hVar;
            SwipeRefreshLayout swipeRefreshLayout = SwipeRefreshLayout.this;
            if (swipeRefreshLayout.i) {
                swipeRefreshLayout.E.setAlpha(KotlinVersion.MAX_COMPONENT_VALUE);
                SwipeRefreshLayout.this.E.start();
                SwipeRefreshLayout swipeRefreshLayout2 = SwipeRefreshLayout.this;
                if (swipeRefreshLayout2.J && (hVar = swipeRefreshLayout2.h) != null) {
                    hVar.a();
                }
                SwipeRefreshLayout swipeRefreshLayout3 = SwipeRefreshLayout.this;
                swipeRefreshLayout3.s = swipeRefreshLayout3.y.getTop();
                return;
            }
            swipeRefreshLayout.h();
        }

        public void onAnimationRepeat(Animation animation) {
        }

        public void onAnimationStart(Animation animation) {
        }
    }

    public class b extends Animation {
        public b() {
        }

        public void applyTransformation(float f, Transformation transformation) {
            SwipeRefreshLayout.this.setAnimationProgress(1.0f - f);
        }
    }

    public class c extends Animation {
        public final /* synthetic */ int g;
        public final /* synthetic */ int h;

        public c(int i2, int i3) {
            this.g = i2;
            this.h = i3;
        }

        public void applyTransformation(float f, Transformation transformation) {
            e00 e00 = SwipeRefreshLayout.this.E;
            int i2 = this.g;
            e00.setAlpha((int) ((((float) (this.h - i2)) * f) + ((float) i2)));
        }
    }

    public class d implements Animation.AnimationListener {
        public d() {
        }

        public void onAnimationEnd(Animation animation) {
            Objects.requireNonNull(SwipeRefreshLayout.this);
            SwipeRefreshLayout.this.l(null);
        }

        public void onAnimationRepeat(Animation animation) {
        }

        public void onAnimationStart(Animation animation) {
        }
    }

    public class e extends Animation {
        public e() {
        }

        public void applyTransformation(float f, Transformation transformation) {
            Objects.requireNonNull(SwipeRefreshLayout.this);
            SwipeRefreshLayout swipeRefreshLayout = SwipeRefreshLayout.this;
            int abs = swipeRefreshLayout.C - Math.abs(swipeRefreshLayout.B);
            SwipeRefreshLayout swipeRefreshLayout2 = SwipeRefreshLayout.this;
            int i = swipeRefreshLayout2.A;
            SwipeRefreshLayout.this.setTargetOffsetTopAndBottom((i + ((int) (((float) (abs - i)) * f))) - swipeRefreshLayout2.y.getTop());
            e00 e00 = SwipeRefreshLayout.this.E;
            float f2 = 1.0f - f;
            e00.a aVar = e00.g;
            if (f2 != aVar.p) {
                aVar.p = f2;
            }
            e00.invalidateSelf();
        }
    }

    public class f extends Animation {
        public f() {
        }

        public void applyTransformation(float f, Transformation transformation) {
            SwipeRefreshLayout.this.f(f);
        }
    }

    public interface g {
        boolean a(SwipeRefreshLayout swipeRefreshLayout, View view);
    }

    public interface h {
        void a();
    }

    public SwipeRefreshLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.j = ViewConfiguration.get(context).getScaledTouchSlop();
        this.r = getResources().getInteger(17694721);
        setWillNotDraw(false);
        this.x = new DecelerateInterpolator(2.0f);
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        this.K = (int) (displayMetrics.density * 40.0f);
        this.y = new b00(getContext(), -328966);
        e00 e00 = new e00(getContext());
        this.E = e00;
        e00.c(1);
        this.y.setImageDrawable(this.E);
        this.y.setVisibility(8);
        addView(this.y);
        setChildrenDrawingOrderEnabled(true);
        int i2 = (int) (displayMetrics.density * 64.0f);
        this.C = i2;
        this.k = (float) i2;
        this.m = new un();
        this.n = new rn(this);
        setNestedScrollingEnabled(true);
        int i3 = -this.K;
        this.s = i3;
        this.B = i3;
        f(1.0f);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, Q);
        setEnabled(obtainStyledAttributes.getBoolean(0, true));
        obtainStyledAttributes.recycle();
    }

    private void setColorViewAlpha(int i2) {
        this.y.getBackground().setAlpha(i2);
        e00 e00 = this.E;
        e00.g.t = i2;
        e00.invalidateSelf();
    }

    public boolean a() {
        g gVar = this.L;
        if (gVar != null) {
            return gVar.a(this, this.g);
        }
        View view = this.g;
        if (view instanceof ListView) {
            return ((ListView) view).canScrollList(-1);
        }
        return view.canScrollVertically(-1);
    }

    public final void b() {
        if (this.g == null) {
            for (int i2 = 0; i2 < getChildCount(); i2++) {
                View childAt = getChildAt(i2);
                if (!childAt.equals(this.y)) {
                    this.g = childAt;
                    return;
                }
            }
        }
    }

    public final void c(float f2) {
        if (f2 > this.k) {
            i(true, true);
            return;
        }
        this.i = false;
        e00 e00 = this.E;
        e00.a aVar = e00.g;
        aVar.e = Utils.FLOAT_EPSILON;
        aVar.f = Utils.FLOAT_EPSILON;
        e00.invalidateSelf();
        d dVar = new d();
        this.A = this.s;
        this.O.reset();
        this.O.setDuration(200);
        this.O.setInterpolator(this.x);
        b00 b00 = this.y;
        b00.g = dVar;
        b00.clearAnimation();
        this.y.startAnimation(this.O);
        e00 e002 = this.E;
        e00.a aVar2 = e002.g;
        if (aVar2.n) {
            aVar2.n = false;
        }
        e002.invalidateSelf();
    }

    public final boolean d(Animation animation) {
        return animation != null && animation.hasStarted() && !animation.hasEnded();
    }

    public boolean dispatchNestedFling(float f2, float f3, boolean z2) {
        return this.n.a(f2, f3, z2);
    }

    public boolean dispatchNestedPreFling(float f2, float f3) {
        return this.n.b(f2, f3);
    }

    public boolean dispatchNestedPreScroll(int i2, int i3, int[] iArr, int[] iArr2) {
        return this.n.c(i2, i3, iArr, iArr2, 0);
    }

    public boolean dispatchNestedScroll(int i2, int i3, int i4, int i5, int[] iArr) {
        return this.n.e(i2, i3, i4, i5, iArr);
    }

    public final void e(float f2) {
        e00 e00 = this.E;
        e00.a aVar = e00.g;
        if (!aVar.n) {
            aVar.n = true;
        }
        e00.invalidateSelf();
        float min = Math.min(1.0f, Math.abs(f2 / this.k));
        float max = (((float) Math.max(((double) min) - 0.4d, (double) Utils.DOUBLE_EPSILON)) * 5.0f) / 3.0f;
        float abs = Math.abs(f2) - this.k;
        int i2 = this.D;
        if (i2 <= 0) {
            i2 = this.C;
        }
        float f3 = (float) i2;
        double max2 = (double) (Math.max((float) Utils.FLOAT_EPSILON, Math.min(abs, f3 * 2.0f) / f3) / 4.0f);
        float pow = ((float) (max2 - Math.pow(max2, 2.0d))) * 2.0f;
        int i3 = this.B + ((int) ((f3 * min) + (f3 * pow * 2.0f)));
        if (this.y.getVisibility() != 0) {
            this.y.setVisibility(0);
        }
        this.y.setScaleX(1.0f);
        this.y.setScaleY(1.0f);
        if (f2 < this.k) {
            if (this.E.g.t > 76 && !d(this.H)) {
                this.H = j(this.E.g.t, 76);
            }
        } else if (this.E.g.t < 255 && !d(this.I)) {
            this.I = j(this.E.g.t, KotlinVersion.MAX_COMPONENT_VALUE);
        }
        e00 e002 = this.E;
        float min2 = Math.min(0.8f, max * 0.8f);
        e00.a aVar2 = e002.g;
        aVar2.e = Utils.FLOAT_EPSILON;
        aVar2.f = min2;
        e002.invalidateSelf();
        e00 e003 = this.E;
        float min3 = Math.min(1.0f, max);
        e00.a aVar3 = e003.g;
        if (min3 != aVar3.p) {
            aVar3.p = min3;
        }
        e003.invalidateSelf();
        e00 e004 = this.E;
        e004.g.g = ((pow * 2.0f) + ((max * 0.4f) - 16.0f)) * 0.5f;
        e004.invalidateSelf();
        setTargetOffsetTopAndBottom(i3 - this.s);
    }

    public void f(float f2) {
        int i2 = this.A;
        setTargetOffsetTopAndBottom((i2 + ((int) (((float) (this.B - i2)) * f2))) - this.y.getTop());
    }

    public final void g(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.w) {
            this.w = motionEvent.getPointerId(actionIndex == 0 ? 1 : 0);
        }
    }

    public int getChildDrawingOrder(int i2, int i3) {
        int i4 = this.z;
        if (i4 < 0) {
            return i3;
        }
        if (i3 == i2 - 1) {
            return i4;
        }
        return i3 >= i4 ? i3 + 1 : i3;
    }

    public int getNestedScrollAxes() {
        return this.m.a();
    }

    public int getProgressCircleDiameter() {
        return this.K;
    }

    public int getProgressViewEndOffset() {
        return this.C;
    }

    public int getProgressViewStartOffset() {
        return this.B;
    }

    public void h() {
        this.y.clearAnimation();
        this.E.stop();
        this.y.setVisibility(8);
        setColorViewAlpha(KotlinVersion.MAX_COMPONENT_VALUE);
        setTargetOffsetTopAndBottom(this.B - this.s);
        this.s = this.y.getTop();
    }

    public boolean hasNestedScrollingParent() {
        return this.n.h(0);
    }

    public final void i(boolean z2, boolean z3) {
        if (this.i != z2) {
            this.J = z3;
            b();
            this.i = z2;
            if (z2) {
                int i2 = this.s;
                Animation.AnimationListener animationListener = this.M;
                this.A = i2;
                this.N.reset();
                this.N.setDuration(200);
                this.N.setInterpolator(this.x);
                if (animationListener != null) {
                    this.y.g = animationListener;
                }
                this.y.clearAnimation();
                this.y.startAnimation(this.N);
                return;
            }
            l(this.M);
        }
    }

    public boolean isNestedScrollingEnabled() {
        return this.n.d;
    }

    public final Animation j(int i2, int i3) {
        c cVar = new c(i2, i3);
        cVar.setDuration(300);
        b00 b00 = this.y;
        b00.g = null;
        b00.clearAnimation();
        this.y.startAnimation(cVar);
        return cVar;
    }

    public final void k(float f2) {
        float f3 = this.u;
        int i2 = this.j;
        if (f2 - f3 > ((float) i2) && !this.v) {
            this.t = f3 + ((float) i2);
            this.v = true;
            this.E.setAlpha(76);
        }
    }

    public void l(Animation.AnimationListener animationListener) {
        b bVar = new b();
        this.G = bVar;
        bVar.setDuration(150);
        b00 b00 = this.y;
        b00.g = animationListener;
        b00.clearAnimation();
        this.y.startAnimation(this.G);
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        h();
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        b();
        int actionMasked = motionEvent.getActionMasked();
        if (!isEnabled() || a() || this.i || this.q) {
            return false;
        }
        if (actionMasked != 0) {
            if (actionMasked != 1) {
                if (actionMasked == 2) {
                    int i2 = this.w;
                    if (i2 == -1) {
                        Log.e(P, "Got ACTION_MOVE event but don't have an active pointer id.");
                        return false;
                    }
                    int findPointerIndex = motionEvent.findPointerIndex(i2);
                    if (findPointerIndex < 0) {
                        return false;
                    }
                    k(motionEvent.getY(findPointerIndex));
                } else if (actionMasked != 3) {
                    if (actionMasked == 6) {
                        g(motionEvent);
                    }
                }
            }
            this.v = false;
            this.w = -1;
        } else {
            setTargetOffsetTopAndBottom(this.B - this.y.getTop());
            int pointerId = motionEvent.getPointerId(0);
            this.w = pointerId;
            this.v = false;
            int findPointerIndex2 = motionEvent.findPointerIndex(pointerId);
            if (findPointerIndex2 < 0) {
                return false;
            }
            this.u = motionEvent.getY(findPointerIndex2);
        }
        return this.v;
    }

    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int measuredWidth = getMeasuredWidth();
        int measuredHeight = getMeasuredHeight();
        if (getChildCount() != 0) {
            if (this.g == null) {
                b();
            }
            View view = this.g;
            if (view != null) {
                int paddingLeft = getPaddingLeft();
                int paddingTop = getPaddingTop();
                view.layout(paddingLeft, paddingTop, ((measuredWidth - getPaddingLeft()) - getPaddingRight()) + paddingLeft, ((measuredHeight - getPaddingTop()) - getPaddingBottom()) + paddingTop);
                int measuredWidth2 = this.y.getMeasuredWidth();
                int measuredHeight2 = this.y.getMeasuredHeight();
                int i6 = measuredWidth / 2;
                int i7 = measuredWidth2 / 2;
                int i8 = this.s;
                this.y.layout(i6 - i7, i8, i6 + i7, measuredHeight2 + i8);
            }
        }
    }

    public void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        if (this.g == null) {
            b();
        }
        View view = this.g;
        if (view != null) {
            view.measure(View.MeasureSpec.makeMeasureSpec((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), 1073741824), View.MeasureSpec.makeMeasureSpec((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), 1073741824));
            this.y.measure(View.MeasureSpec.makeMeasureSpec(this.K, 1073741824), View.MeasureSpec.makeMeasureSpec(this.K, 1073741824));
            this.z = -1;
            for (int i4 = 0; i4 < getChildCount(); i4++) {
                if (getChildAt(i4) == this.y) {
                    this.z = i4;
                    return;
                }
            }
        }
    }

    public boolean onNestedFling(View view, float f2, float f3, boolean z2) {
        return dispatchNestedFling(f2, f3, z2);
    }

    public boolean onNestedPreFling(View view, float f2, float f3) {
        return dispatchNestedPreFling(f2, f3);
    }

    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
        if (i3 > 0) {
            float f2 = this.l;
            if (f2 > Utils.FLOAT_EPSILON) {
                float f3 = (float) i3;
                if (f3 > f2) {
                    iArr[1] = i3 - ((int) f2);
                    this.l = Utils.FLOAT_EPSILON;
                } else {
                    this.l = f2 - f3;
                    iArr[1] = i3;
                }
                e(this.l);
            }
        }
        int[] iArr2 = this.o;
        if (dispatchNestedPreScroll(i2 - iArr[0], i3 - iArr[1], iArr2, null)) {
            iArr[0] = iArr[0] + iArr2[0];
            iArr[1] = iArr[1] + iArr2[1];
        }
    }

    public void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        dispatchNestedScroll(i2, i3, i4, i5, this.p);
        int i6 = i5 + this.p[1];
        if (i6 < 0 && !a()) {
            float abs = this.l + ((float) Math.abs(i6));
            this.l = abs;
            e(abs);
        }
    }

    public void onNestedScrollAccepted(View view, View view2, int i2) {
        this.m.a = i2;
        startNestedScroll(i2 & 2);
        this.l = Utils.FLOAT_EPSILON;
        this.q = true;
    }

    public boolean onStartNestedScroll(View view, View view2, int i2) {
        return isEnabled() && !this.i && (i2 & 2) != 0;
    }

    public void onStopNestedScroll(View view) {
        this.m.b(0);
        this.q = false;
        float f2 = this.l;
        if (f2 > Utils.FLOAT_EPSILON) {
            c(f2);
            this.l = Utils.FLOAT_EPSILON;
        }
        stopNestedScroll();
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (!isEnabled() || a() || this.i || this.q) {
            return false;
        }
        if (actionMasked == 0) {
            this.w = motionEvent.getPointerId(0);
            this.v = false;
        } else if (actionMasked == 1) {
            int findPointerIndex = motionEvent.findPointerIndex(this.w);
            if (findPointerIndex < 0) {
                Log.e(P, "Got ACTION_UP event but don't have an active pointer id.");
                return false;
            }
            if (this.v) {
                this.v = false;
                c((motionEvent.getY(findPointerIndex) - this.t) * 0.5f);
            }
            this.w = -1;
            return false;
        } else if (actionMasked == 2) {
            int findPointerIndex2 = motionEvent.findPointerIndex(this.w);
            if (findPointerIndex2 < 0) {
                Log.e(P, "Got ACTION_MOVE event but have an invalid active pointer id.");
                return false;
            }
            float y2 = motionEvent.getY(findPointerIndex2);
            k(y2);
            if (this.v) {
                float f2 = (y2 - this.t) * 0.5f;
                if (f2 <= Utils.FLOAT_EPSILON) {
                    return false;
                }
                e(f2);
            }
        } else if (actionMasked == 3) {
            return false;
        } else {
            if (actionMasked == 5) {
                int actionIndex = motionEvent.getActionIndex();
                if (actionIndex < 0) {
                    Log.e(P, "Got ACTION_POINTER_DOWN event but have an invalid action index.");
                    return false;
                }
                this.w = motionEvent.getPointerId(actionIndex);
            } else if (actionMasked == 6) {
                g(motionEvent);
            }
        }
        return true;
    }

    public void requestDisallowInterceptTouchEvent(boolean z2) {
        View view = this.g;
        if (view != null) {
            AtomicInteger atomicInteger = co.a;
            if (!co.h.p(view)) {
                return;
            }
        }
        super.requestDisallowInterceptTouchEvent(z2);
    }

    public void setAnimationProgress(float f2) {
        this.y.setScaleX(f2);
        this.y.setScaleY(f2);
    }

    @Deprecated
    public void setColorScheme(int... iArr) {
        setColorSchemeResources(iArr);
    }

    public void setColorSchemeColors(int... iArr) {
        b();
        e00 e00 = this.E;
        e00.a aVar = e00.g;
        aVar.i = iArr;
        aVar.a(0);
        e00.g.a(0);
        e00.invalidateSelf();
    }

    public void setColorSchemeResources(int... iArr) {
        Context context = getContext();
        int[] iArr2 = new int[iArr.length];
        for (int i2 = 0; i2 < iArr.length; i2++) {
            iArr2[i2] = wk.b(context, iArr[i2]);
        }
        setColorSchemeColors(iArr2);
    }

    public void setDistanceToTriggerSync(int i2) {
        this.k = (float) i2;
    }

    public void setEnabled(boolean z2) {
        super.setEnabled(z2);
        if (!z2) {
            h();
        }
    }

    public void setNestedScrollingEnabled(boolean z2) {
        rn rnVar = this.n;
        if (rnVar.d) {
            View view = rnVar.c;
            AtomicInteger atomicInteger = co.a;
            co.h.z(view);
        }
        rnVar.d = z2;
    }

    public void setOnChildScrollUpCallback(g gVar) {
        this.L = gVar;
    }

    public void setOnRefreshListener(h hVar) {
        this.h = hVar;
    }

    @Deprecated
    public void setProgressBackgroundColor(int i2) {
        setProgressBackgroundColorSchemeResource(i2);
    }

    public void setProgressBackgroundColorSchemeColor(int i2) {
        this.y.setBackgroundColor(i2);
    }

    public void setProgressBackgroundColorSchemeResource(int i2) {
        setProgressBackgroundColorSchemeColor(wk.b(getContext(), i2));
    }

    public void setRefreshing(boolean z2) {
        if (!z2 || this.i == z2) {
            i(z2, false);
            return;
        }
        this.i = z2;
        setTargetOffsetTopAndBottom((this.C + this.B) - this.s);
        this.J = false;
        Animation.AnimationListener animationListener = this.M;
        this.y.setVisibility(0);
        this.E.setAlpha(KotlinVersion.MAX_COMPONENT_VALUE);
        f00 f00 = new f00(this);
        this.F = f00;
        f00.setDuration((long) this.r);
        if (animationListener != null) {
            this.y.g = animationListener;
        }
        this.y.clearAnimation();
        this.y.startAnimation(this.F);
    }

    public void setSize(int i2) {
        if (i2 == 0 || i2 == 1) {
            DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
            if (i2 == 0) {
                this.K = (int) (displayMetrics.density * 56.0f);
            } else {
                this.K = (int) (displayMetrics.density * 40.0f);
            }
            this.y.setImageDrawable(null);
            this.E.c(i2);
            this.y.setImageDrawable(this.E);
        }
    }

    public void setSlingshotDistance(int i2) {
        this.D = i2;
    }

    public void setTargetOffsetTopAndBottom(int i2) {
        this.y.bringToFront();
        co.o(this.y, i2);
        this.s = this.y.getTop();
    }

    public boolean startNestedScroll(int i2) {
        return this.n.i(i2, 0);
    }

    public void stopNestedScroll() {
        this.n.j(0);
    }
}
