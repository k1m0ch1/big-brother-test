package androidx.navigation.fragment;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import androidx.fragment.app.Fragment;
import defpackage.ku;
import defpackage.sr;
import java.util.HashSet;

@ku.b("dialog")
public final class DialogFragmentNavigator extends ku<a> {
    public final Context a;
    public final iq b;
    public int c = 0;
    public final HashSet<String> d = new HashSet<>();
    public wr e = new wr(this) {
        /* class androidx.navigation.fragment.DialogFragmentNavigator.AnonymousClass1 */

        @Override // defpackage.wr
        public void c(yr yrVar, sr.a aVar) {
            if (aVar == sr.a.ON_STOP) {
                up upVar = (up) yrVar;
                if (!upVar.U1().isShowing()) {
                    NavHostFragment.R1(upVar).k();
                }
            }
        }
    };

    public static class a extends cu implements rt {
        public String o;

        public a(ku<? extends a> kuVar) {
            super(kuVar);
        }

        @Override // defpackage.cu
        public void o(Context context, AttributeSet attributeSet) {
            super.o(context, attributeSet);
            TypedArray obtainAttributes = context.getResources().obtainAttributes(attributeSet, qu.a);
            String string = obtainAttributes.getString(0);
            if (string != null) {
                this.o = string;
            }
            obtainAttributes.recycle();
        }
    }

    public DialogFragmentNavigator(Context context, iq iqVar) {
        this.a = context;
        this.b = iqVar;
    }

    /* Return type fixed from 'cu' to match base method */
    @Override // defpackage.ku
    public a a() {
        return new a(this);
    }

    /* JADX DEBUG: Method arguments types fixed to match base method, original types: [cu, android.os.Bundle, iu, ku$a] */
    @Override // defpackage.ku
    public cu b(a aVar, Bundle bundle, iu iuVar, ku.a aVar2) {
        a aVar3 = aVar;
        if (this.b.S()) {
            Log.i("DialogFragmentNavigator", "Ignoring navigate() call: FragmentManager has already saved its state");
            return null;
        }
        String str = aVar3.o;
        if (str != null) {
            if (str.charAt(0) == '.') {
                str = this.a.getPackageName() + str;
            }
            Fragment instantiate = this.b.M().instantiate(this.a.getClassLoader(), str);
            if (!up.class.isAssignableFrom(instantiate.getClass())) {
                StringBuilder J0 = ze0.J0("Dialog destination ");
                String str2 = aVar3.o;
                if (str2 != null) {
                    throw new IllegalArgumentException(ze0.C0(J0, str2, " is not an instance of DialogFragment"));
                }
                throw new IllegalStateException("DialogFragment class was not set");
            }
            up upVar = (up) instantiate;
            upVar.setArguments(bundle);
            upVar.getLifecycle().a(this.e);
            iq iqVar = this.b;
            StringBuilder J02 = ze0.J0("androidx-nav-fragment:navigator:dialog:");
            int i = this.c;
            this.c = i + 1;
            J02.append(i);
            upVar.X1(iqVar, J02.toString());
            return aVar3;
        }
        throw new IllegalStateException("DialogFragment class was not set");
    }

    @Override // defpackage.ku
    public void c(Bundle bundle) {
        this.c = bundle.getInt("androidx-nav-dialogfragment:navigator:count", 0);
        for (int i = 0; i < this.c; i++) {
            iq iqVar = this.b;
            up upVar = (up) iqVar.I("androidx-nav-fragment:navigator:dialog:" + i);
            if (upVar != null) {
                upVar.getLifecycle().a(this.e);
            } else {
                HashSet<String> hashSet = this.d;
                hashSet.add("androidx-nav-fragment:navigator:dialog:" + i);
            }
        }
    }

    @Override // defpackage.ku
    public Bundle d() {
        if (this.c == 0) {
            return null;
        }
        Bundle bundle = new Bundle();
        bundle.putInt("androidx-nav-dialogfragment:navigator:count", this.c);
        return bundle;
    }

    @Override // defpackage.ku
    public boolean e() {
        if (this.c == 0) {
            return false;
        }
        if (this.b.S()) {
            Log.i("DialogFragmentNavigator", "Ignoring popBackStack() call: FragmentManager has already saved its state");
            return false;
        }
        iq iqVar = this.b;
        StringBuilder J0 = ze0.J0("androidx-nav-fragment:navigator:dialog:");
        int i = this.c - 1;
        this.c = i;
        J0.append(i);
        Fragment I = iqVar.I(J0.toString());
        if (I != null) {
            I.getLifecycle().b(this.e);
            ((up) I).R1();
        }
        return true;
    }
}
