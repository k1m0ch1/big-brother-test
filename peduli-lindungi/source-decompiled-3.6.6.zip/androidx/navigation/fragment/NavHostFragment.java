package androidx.navigation.fragment;

import android.app.Dialog;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.activity.OnBackPressedDispatcher;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import com.telkom.tracencare.R;
import defpackage.os;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;

public class NavHostFragment extends Fragment {
    public gu g;
    public Boolean h = null;
    public View i;
    public int j;
    public boolean k;

    public static NavController R1(Fragment fragment) {
        for (Fragment fragment2 = fragment; fragment2 != null; fragment2 = fragment2.getParentFragment()) {
            if (fragment2 instanceof NavHostFragment) {
                gu guVar = ((NavHostFragment) fragment2).g;
                if (guVar != null) {
                    return guVar;
                }
                throw new IllegalStateException("NavController is not available before onCreate()");
            }
            Fragment fragment3 = fragment2.getParentFragmentManager().q;
            if (fragment3 instanceof NavHostFragment) {
                gu guVar2 = ((NavHostFragment) fragment3).g;
                if (guVar2 != null) {
                    return guVar2;
                }
                throw new IllegalStateException("NavController is not available before onCreate()");
            }
        }
        View view = fragment.getView();
        if (view != null) {
            return ek.v(view);
        }
        Dialog dialog = fragment instanceof up ? ((up) fragment).q : null;
        if (!(dialog == null || dialog.getWindow() == null)) {
            return ek.v(dialog.getWindow().getDecorView());
        }
        throw new IllegalStateException(ze0.o0("Fragment ", fragment, " does not have a NavController set"));
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        super.onAttach(context);
        if (this.k) {
            sp spVar = new sp(getParentFragmentManager());
            spVar.s(this);
            spVar.c();
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttachFragment(Fragment fragment) {
        super.onAttachFragment(fragment);
        lu luVar = this.g.k;
        Objects.requireNonNull(luVar);
        DialogFragmentNavigator dialogFragmentNavigator = (DialogFragmentNavigator) luVar.c(lu.b(DialogFragmentNavigator.class));
        if (dialogFragmentNavigator.d.remove(fragment.getTag())) {
            fragment.getLifecycle().a(dialogFragmentNavigator.e);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        Bundle bundle2;
        ns nsVar;
        gu guVar = new gu(requireContext());
        this.g = guVar;
        guVar.i = this;
        getLifecycle().a(guVar.m);
        gu guVar2 = this.g;
        OnBackPressedDispatcher onBackPressedDispatcher = requireActivity().getOnBackPressedDispatcher();
        if (guVar2.i != null) {
            guVar2.n.remove();
            onBackPressedDispatcher.a(guVar2.i, guVar2.n);
            gu guVar3 = this.g;
            Boolean bool = this.h;
            int i2 = 0;
            guVar3.o = bool != null && bool.booleanValue();
            guVar3.p();
            Bundle bundle3 = null;
            this.h = null;
            gu guVar4 = this.g;
            ps viewModelStore = getViewModelStore();
            if (guVar4.h.isEmpty()) {
                os.b bVar = zt.b;
                String canonicalName = zt.class.getCanonicalName();
                if (canonicalName != null) {
                    String r0 = ze0.r0("androidx.lifecycle.ViewModelProvider.DefaultKey:", canonicalName);
                    ns nsVar2 = viewModelStore.a.get(r0);
                    if (!zt.class.isInstance(nsVar2)) {
                        if (bVar instanceof os.c) {
                            nsVar = ((os.c) bVar).b(r0, zt.class);
                        } else {
                            nsVar = new zt();
                        }
                        nsVar2 = nsVar;
                        ns put = viewModelStore.a.put(r0, nsVar2);
                        if (put != null) {
                            put.onCleared();
                        }
                    } else if (bVar instanceof os.e) {
                        ((os.e) bVar).a(nsVar2);
                    }
                    guVar4.j = (zt) nsVar2;
                    gu guVar5 = this.g;
                    guVar5.k.a(new DialogFragmentNavigator(requireContext(), getChildFragmentManager()));
                    lu luVar = guVar5.k;
                    Context requireContext = requireContext();
                    iq childFragmentManager = getChildFragmentManager();
                    int id = getId();
                    if (id == 0 || id == -1) {
                        id = R.id.nav_host_fragment_container;
                    }
                    luVar.a(new ou(requireContext, childFragmentManager, id));
                    if (bundle != null) {
                        bundle2 = bundle.getBundle("android-support-nav:fragment:navControllerState");
                        if (bundle.getBoolean("android-support-nav:fragment:defaultHost", false)) {
                            this.k = true;
                            sp spVar = new sp(getParentFragmentManager());
                            spVar.s(this);
                            spVar.c();
                        }
                        this.j = bundle.getInt("android-support-nav:fragment:graphId");
                    } else {
                        bundle2 = null;
                    }
                    if (bundle2 != null) {
                        gu guVar6 = this.g;
                        Objects.requireNonNull(guVar6);
                        bundle2.setClassLoader(guVar6.a.getClassLoader());
                        guVar6.e = bundle2.getBundle("android-support-nav:controller:navigatorState");
                        guVar6.f = bundle2.getParcelableArray("android-support-nav:controller:backStack");
                        guVar6.g = bundle2.getBoolean("android-support-nav:controller:deepLinkHandled");
                    }
                    int i3 = this.j;
                    if (i3 != 0) {
                        this.g.n(i3, null);
                    } else {
                        Bundle arguments = getArguments();
                        if (arguments != null) {
                            i2 = arguments.getInt("android-support-nav:fragment:graphId");
                        }
                        if (arguments != null) {
                            bundle3 = arguments.getBundle("android-support-nav:fragment:startDestinationArgs");
                        }
                        if (i2 != 0) {
                            this.g.n(i2, bundle3);
                        }
                    }
                    super.onCreate(bundle);
                    return;
                }
                throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
            }
            throw new IllegalStateException("ViewModelStore should be set before setGraph call");
        }
        throw new IllegalStateException("You must call setLifecycleOwner() before calling setOnBackPressedDispatcher()");
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        cq cqVar = new cq(layoutInflater.getContext());
        int id = getId();
        if (id == 0 || id == -1) {
            id = R.id.nav_host_fragment_container;
        }
        cqVar.setId(id);
        return cqVar;
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        View view = this.i;
        if (view != null && ek.v(view) == this.g) {
            this.i.setTag(R.id.nav_controller_view_tag, null);
        }
        this.i = null;
    }

    @Override // androidx.fragment.app.Fragment
    public void onInflate(Context context, AttributeSet attributeSet, Bundle bundle) {
        super.onInflate(context, attributeSet, bundle);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, mu.b);
        int resourceId = obtainStyledAttributes.getResourceId(0, 0);
        if (resourceId != 0) {
            this.j = resourceId;
        }
        obtainStyledAttributes.recycle();
        TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, qu.c);
        if (obtainStyledAttributes2.getBoolean(0, false)) {
            this.k = true;
        }
        obtainStyledAttributes2.recycle();
    }

    @Override // androidx.fragment.app.Fragment
    public void onPrimaryNavigationFragmentChanged(boolean z) {
        gu guVar = this.g;
        if (guVar != null) {
            guVar.o = z;
            guVar.p();
            return;
        }
        this.h = Boolean.valueOf(z);
    }

    @Override // androidx.fragment.app.Fragment
    public void onSaveInstanceState(Bundle bundle) {
        Bundle bundle2;
        super.onSaveInstanceState(bundle);
        gu guVar = this.g;
        Objects.requireNonNull(guVar);
        ArrayList<String> arrayList = new ArrayList<>();
        Bundle bundle3 = new Bundle();
        for (Map.Entry<String, ku<? extends cu>> entry : guVar.k.a.entrySet()) {
            String key = entry.getKey();
            Bundle d = entry.getValue().d();
            if (d != null) {
                arrayList.add(key);
                bundle3.putBundle(key, d);
            }
        }
        if (!arrayList.isEmpty()) {
            bundle2 = new Bundle();
            bundle3.putStringArrayList("android-support-nav:controller:navigatorState:names", arrayList);
            bundle2.putBundle("android-support-nav:controller:navigatorState", bundle3);
        } else {
            bundle2 = null;
        }
        if (!guVar.h.isEmpty()) {
            if (bundle2 == null) {
                bundle2 = new Bundle();
            }
            Parcelable[] parcelableArr = new Parcelable[guVar.h.size()];
            int i2 = 0;
            for (xt xtVar : guVar.h) {
                parcelableArr[i2] = new yt(xtVar);
                i2++;
            }
            bundle2.putParcelableArray("android-support-nav:controller:backStack", parcelableArr);
        }
        if (guVar.g) {
            if (bundle2 == null) {
                bundle2 = new Bundle();
            }
            bundle2.putBoolean("android-support-nav:controller:deepLinkHandled", guVar.g);
        }
        if (bundle2 != null) {
            bundle.putBundle("android-support-nav:fragment:navControllerState", bundle2);
        }
        if (this.k) {
            bundle.putBoolean("android-support-nav:fragment:defaultHost", true);
        }
        int i3 = this.j;
        if (i3 != 0) {
            bundle.putInt("android-support-nav:fragment:graphId", i3);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        if (view instanceof ViewGroup) {
            view.setTag(R.id.nav_controller_view_tag, this.g);
            if (view.getParent() != null) {
                View view2 = (View) view.getParent();
                this.i = view2;
                if (view2.getId() == getId()) {
                    this.i.setTag(R.id.nav_controller_view_tag, this.g);
                    return;
                }
                return;
            }
            return;
        }
        throw new IllegalStateException("created host view " + view + " is not a ViewGroup");
    }
}
