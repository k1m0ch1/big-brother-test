package androidx.navigation;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import defpackage.cu;
import defpackage.eu;
import defpackage.ku;
import defpackage.sr;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;

public class NavController {
    public final Context a;
    public Activity b;
    public hu c;
    public eu d;
    public Bundle e;
    public Parcelable[] f;
    public boolean g;
    public final Deque<xt> h = new ArrayDeque();
    public yr i;
    public zt j;
    public lu k = new lu();
    public final CopyOnWriteArrayList<b> l = new CopyOnWriteArrayList<>();
    public final xr m = new wr() {
        /* class androidx.navigation.NavController.AnonymousClass1 */

        @Override // defpackage.wr
        public void c(yr yrVar, sr.a aVar) {
            sr.b bVar;
            NavController navController = NavController.this;
            if (navController.d != null) {
                for (xt xtVar : navController.h) {
                    Objects.requireNonNull(xtVar);
                    int ordinal = aVar.ordinal();
                    if (ordinal != 0) {
                        if (ordinal != 1) {
                            if (ordinal == 2) {
                                bVar = sr.b.RESUMED;
                            } else if (ordinal != 3) {
                                if (ordinal != 4) {
                                    if (ordinal == 5) {
                                        bVar = sr.b.DESTROYED;
                                    } else {
                                        throw new IllegalArgumentException("Unexpected event value " + aVar);
                                    }
                                }
                            }
                            xtVar.l = bVar;
                            xtVar.b();
                        }
                        bVar = sr.b.STARTED;
                        xtVar.l = bVar;
                        xtVar.b();
                    }
                    bVar = sr.b.CREATED;
                    xtVar.l = bVar;
                    xtVar.b();
                }
            }
        }
    };
    public final g0 n = new a(false);
    public boolean o = true;

    public class a extends g0 {
        public a(boolean z) {
            super(z);
        }

        @Override // defpackage.g0
        public void handleOnBackPressed() {
            NavController.this.k();
        }
    }

    public interface b {
        void a(NavController navController, cu cuVar, Bundle bundle);
    }

    public NavController(Context context) {
        this.a = context;
        while (true) {
            if (!(context instanceof ContextWrapper)) {
                break;
            } else if (context instanceof Activity) {
                this.b = (Activity) context;
                break;
            } else {
                context = ((ContextWrapper) context).getBaseContext();
            }
        }
        lu luVar = this.k;
        luVar.a(new fu(luVar));
        this.k.a(new qt(this.a));
    }

    /* JADX WARNING: Removed duplicated region for block: B:3:0x000d  */
    public final boolean a() {
        sr.b bVar = sr.b.STARTED;
        sr.b bVar2 = sr.b.RESUMED;
        while (!this.h.isEmpty() && (this.h.peekLast().g instanceof eu) && m(this.h.peekLast().g.i, true)) {
            while (!this.h.isEmpty()) {
                while (!this.h.isEmpty()) {
                }
            }
        }
        if (this.h.isEmpty()) {
            return false;
        }
        cu cuVar = this.h.peekLast().g;
        cu cuVar2 = null;
        if (cuVar instanceof rt) {
            Iterator<xt> descendingIterator = this.h.descendingIterator();
            while (true) {
                if (!descendingIterator.hasNext()) {
                    break;
                }
                cu cuVar3 = descendingIterator.next().g;
                if (!((cuVar3 instanceof eu) || (cuVar3 instanceof rt))) {
                    cuVar2 = cuVar3;
                    break;
                }
            }
        }
        HashMap hashMap = new HashMap();
        Iterator<xt> descendingIterator2 = this.h.descendingIterator();
        while (descendingIterator2.hasNext()) {
            xt next = descendingIterator2.next();
            sr.b bVar3 = next.m;
            cu cuVar4 = next.g;
            if (cuVar != null && cuVar4.i == cuVar.i) {
                if (bVar3 != bVar2) {
                    hashMap.put(next, bVar2);
                }
                cuVar = cuVar.h;
            } else if (cuVar2 == null || cuVar4.i != cuVar2.i) {
                next.m = sr.b.CREATED;
                next.b();
            } else {
                if (bVar3 == bVar2) {
                    next.m = bVar;
                    next.b();
                } else if (bVar3 != bVar) {
                    hashMap.put(next, bVar);
                }
                cuVar2 = cuVar2.h;
            }
        }
        for (xt xtVar : this.h) {
            sr.b bVar4 = (sr.b) hashMap.get(xtVar);
            if (bVar4 != null) {
                xtVar.m = bVar4;
                xtVar.b();
            } else {
                xtVar.b();
            }
        }
        xt peekLast = this.h.peekLast();
        Iterator<b> it = this.l.iterator();
        while (it.hasNext()) {
            it.next().a(this, peekLast.g, peekLast.h);
        }
        return true;
    }

    public cu b(int i2) {
        cu cuVar;
        eu euVar;
        eu euVar2 = this.d;
        if (euVar2 == null) {
            return null;
        }
        if (euVar2.i == i2) {
            return euVar2;
        }
        if (this.h.isEmpty()) {
            cuVar = this.d;
        } else {
            cuVar = this.h.getLast().g;
        }
        if (cuVar instanceof eu) {
            euVar = (eu) cuVar;
        } else {
            euVar = cuVar.h;
        }
        return euVar.s(i2, true);
    }

    public xt c(int i2) {
        xt xtVar;
        Iterator<xt> descendingIterator = this.h.descendingIterator();
        while (true) {
            if (!descendingIterator.hasNext()) {
                xtVar = null;
                break;
            }
            xtVar = descendingIterator.next();
            if (xtVar.g.i == i2) {
                break;
            }
        }
        if (xtVar != null) {
            return xtVar;
        }
        StringBuilder K0 = ze0.K0("No destination with ID ", i2, " is on the NavController's back stack. The current destination is ");
        K0.append(d());
        throw new IllegalArgumentException(K0.toString());
    }

    public cu d() {
        xt xtVar;
        if (this.h.isEmpty()) {
            xtVar = null;
        } else {
            xtVar = this.h.getLast();
        }
        if (xtVar != null) {
            return xtVar.g;
        }
        return null;
    }

    public final int e() {
        int i2 = 0;
        for (xt xtVar : this.h) {
            if (!(xtVar.g instanceof eu)) {
                i2++;
            }
        }
        return i2;
    }

    public xt f() {
        Iterator<xt> descendingIterator = this.h.descendingIterator();
        if (descendingIterator.hasNext()) {
            descendingIterator.next();
        }
        while (descendingIterator.hasNext()) {
            xt next = descendingIterator.next();
            if (!(next.g instanceof eu)) {
                return next;
            }
        }
        return null;
    }

    /* JADX WARNING: Removed duplicated region for block: B:13:0x0034  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x004f  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x00a1  */
    public void g(int i2, Bundle bundle) {
        cu cuVar;
        Bundle bundle2;
        int i3;
        iu iuVar;
        int i4;
        if (this.h.isEmpty()) {
            cuVar = this.d;
        } else {
            cuVar = this.h.getLast().g;
        }
        if (cuVar != null) {
            st f2 = cuVar.f(i2);
            if (f2 != null) {
                iuVar = f2.b;
                i3 = f2.a;
                Bundle bundle3 = f2.c;
                if (bundle3 != null) {
                    bundle2 = new Bundle();
                    bundle2.putAll(bundle3);
                    if (bundle != null) {
                        if (bundle2 == null) {
                            bundle2 = new Bundle();
                        }
                        bundle2.putAll(bundle);
                    }
                    if (i3 != 0 && iuVar != null && (i4 = iuVar.b) != -1) {
                        l(i4, iuVar.c);
                        return;
                    } else if (i3 == 0) {
                        cu b2 = b(i3);
                        if (b2 == null) {
                            String g2 = cu.g(this.a, i3);
                            if (f2 != null) {
                                StringBuilder O0 = ze0.O0("Navigation destination ", g2, " referenced from action ");
                                O0.append(cu.g(this.a, i2));
                                O0.append(" cannot be found from the current destination ");
                                O0.append(cuVar);
                                throw new IllegalArgumentException(O0.toString());
                            }
                            throw new IllegalArgumentException("Navigation action/destination " + g2 + " cannot be found from the current destination " + cuVar);
                        }
                        h(b2, bundle2, iuVar, null);
                        return;
                    } else {
                        throw new IllegalArgumentException("Destination id == 0 can only be used in conjunction with a valid navOptions.popUpTo");
                    }
                }
            } else {
                i3 = i2;
                iuVar = null;
            }
            bundle2 = null;
            if (bundle != null) {
            }
            if (i3 != 0) {
            }
            if (i3 == 0) {
            }
        } else {
            throw new IllegalStateException("no current navigation node");
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:10:0x0027 A[LOOP:0: B:10:0x0027->B:15:0x004d, LOOP_START] */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x00d7  */
    public final void h(cu cuVar, Bundle bundle, iu iuVar, ku.a aVar) {
        cu cuVar2;
        cu cuVar3;
        int i2;
        boolean z = false;
        boolean m2 = (iuVar == null || (i2 = iuVar.b) == -1) ? false : m(i2, iuVar.c);
        ku c2 = this.k.c(cuVar.g);
        Bundle a2 = cuVar.a(bundle);
        cu b2 = c2.b(cuVar, a2, iuVar, aVar);
        if (b2 != null) {
            if (!(b2 instanceof rt)) {
                while (!this.h.isEmpty() && (this.h.peekLast().g instanceof rt) && m(this.h.peekLast().g.i, true)) {
                }
            }
            ArrayDeque arrayDeque = new ArrayDeque();
            if (cuVar instanceof eu) {
                eu euVar = b2;
                while (true) {
                    eu euVar2 = euVar.h;
                    if (euVar2 != null) {
                        arrayDeque.addFirst(new xt(this.a, euVar2, a2, this.i, this.j));
                        if (!this.h.isEmpty() && this.h.getLast().g == euVar2) {
                            m(euVar2.i, true);
                        }
                    }
                    if (euVar2 == null || euVar2 == cuVar) {
                        break;
                    }
                    euVar = euVar2;
                }
            }
            if (arrayDeque.isEmpty()) {
                cuVar2 = b2;
            } else {
                cuVar2 = ((xt) arrayDeque.getFirst()).g;
            }
            while (cuVar2 != null && b(cuVar2.i) == null) {
                cuVar2 = cuVar2.h;
                if (cuVar2 != null) {
                    arrayDeque.addFirst(new xt(this.a, cuVar2, a2, this.i, this.j));
                }
            }
            if (arrayDeque.isEmpty()) {
                cuVar3 = b2;
            } else {
                cuVar3 = ((xt) arrayDeque.getLast()).g;
            }
            while (!this.h.isEmpty() && (this.h.getLast().g instanceof eu) && ((eu) this.h.getLast().g).s(cuVar3.i, false) == null && m(this.h.getLast().g.i, true)) {
                while (!this.h.isEmpty()) {
                    while (!this.h.isEmpty()) {
                    }
                }
            }
            this.h.addAll(arrayDeque);
            if (this.h.isEmpty() || this.h.getFirst().g != this.d) {
                this.h.addFirst(new xt(this.a, this.d, a2, this.i, this.j));
            }
            this.h.add(new xt(this.a, b2, b2.a(a2), this.i, this.j));
        } else if (iuVar != null && iuVar.a) {
            xt peekLast = this.h.peekLast();
            if (peekLast != null) {
                peekLast.h = a2;
            }
            z = true;
        }
        p();
        if (m2 || b2 != null || z) {
            a();
        }
    }

    public void i(du duVar) {
        g(duVar.a(), duVar.getArguments());
    }

    public boolean j() {
        Intent intent;
        if (e() != 1) {
            return k();
        }
        cu d2 = d();
        int i2 = d2.i;
        eu euVar = d2.h;
        while (true) {
            if (euVar == null) {
                return false;
            }
            if (euVar.p != i2) {
                Bundle bundle = new Bundle();
                Activity activity = this.b;
                if (!(activity == null || activity.getIntent() == null || this.b.getIntent().getData() == null)) {
                    bundle.putParcelable("android-support-nav:controller:deepLinkIntent", this.b.getIntent());
                    cu.a m2 = this.d.m(new bu(this.b.getIntent()));
                    if (m2 != null) {
                        bundle.putAll(m2.g.a(m2.h));
                    }
                }
                Context context = this.a;
                if (context instanceof Activity) {
                    intent = new Intent(context, context.getClass());
                } else {
                    intent = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
                    if (intent == null) {
                        intent = new Intent();
                    }
                }
                intent.addFlags(268468224);
                eu euVar2 = this.d;
                if (euVar2 != null) {
                    int i3 = euVar.i;
                    ArrayDeque arrayDeque = new ArrayDeque();
                    arrayDeque.add(euVar2);
                    cu cuVar = null;
                    while (!arrayDeque.isEmpty() && cuVar == null) {
                        cu cuVar2 = (cu) arrayDeque.poll();
                        if (cuVar2.i == i3) {
                            cuVar = cuVar2;
                        } else if (cuVar2 instanceof eu) {
                            eu.a aVar = new eu.a();
                            while (aVar.hasNext()) {
                                arrayDeque.add((cu) aVar.next());
                            }
                        }
                    }
                    if (cuVar != null) {
                        intent.putExtra("android-support-nav:controller:deepLinkIds", cuVar.b());
                        intent.putExtra("android-support-nav:controller:deepLinkExtras", bundle);
                        if (intent.getIntArrayExtra("android-support-nav:controller:deepLinkIds") != null) {
                            sk skVar = new sk(context);
                            skVar.a(new Intent(intent));
                            for (int i4 = 0; i4 < skVar.g.size(); i4++) {
                                skVar.g.get(i4).putExtra("android-support-nav:controller:deepLinkIntent", intent);
                            }
                            skVar.f();
                            Activity activity2 = this.b;
                            if (activity2 != null) {
                                activity2.finish();
                            }
                            return true;
                        }
                        throw new IllegalStateException("You must call setDestination() before constructing the deep link");
                    }
                    String g2 = cu.g(context, i3);
                    throw new IllegalArgumentException("Navigation destination " + g2 + " cannot be found in the navigation graph " + euVar2);
                }
                throw new IllegalStateException("You must call setGraph() before calling getGraph()");
            }
            i2 = euVar.i;
            euVar = euVar.h;
        }
    }

    public boolean k() {
        if (this.h.isEmpty()) {
            return false;
        }
        return l(d().i, true);
    }

    public boolean l(int i2, boolean z) {
        return m(i2, z) && a();
    }

    public boolean m(int i2, boolean z) {
        boolean z2;
        ps remove;
        if (this.h.isEmpty()) {
            return false;
        }
        ArrayList arrayList = new ArrayList();
        Iterator<xt> descendingIterator = this.h.descendingIterator();
        while (true) {
            if (!descendingIterator.hasNext()) {
                z2 = false;
                break;
            }
            cu cuVar = descendingIterator.next().g;
            ku c2 = this.k.c(cuVar.g);
            if (z || cuVar.i != i2) {
                arrayList.add(c2);
            }
            if (cuVar.i == i2) {
                z2 = true;
                break;
            }
        }
        if (!z2) {
            String g2 = cu.g(this.a, i2);
            Log.i("NavController", "Ignoring popBackStack to destination " + g2 + " as it was not found on the current back stack");
            return false;
        }
        Iterator it = arrayList.iterator();
        boolean z3 = false;
        while (it.hasNext() && ((ku) it.next()).e()) {
            xt removeLast = this.h.removeLast();
            if (removeLast.i.c.compareTo(sr.b.CREATED) >= 0) {
                removeLast.m = sr.b.DESTROYED;
                removeLast.b();
            }
            zt ztVar = this.j;
            if (!(ztVar == null || (remove = ztVar.a.remove(removeLast.k)) == null)) {
                remove.a();
            }
            z3 = true;
        }
        p();
        return z3;
    }

    public void n(int i2, Bundle bundle) {
        if (this.c == null) {
            this.c = new hu(this.a, this.k);
        }
        o(this.c.c(i2), bundle);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:119:0x0269, code lost:
        if (r1 == false) goto L_0x026c;
     */
    public void o(eu euVar, Bundle bundle) {
        Activity activity;
        boolean z;
        String str;
        eu euVar2;
        cu cuVar;
        eu euVar3;
        cu.a m2;
        ArrayList<String> stringArrayList;
        eu euVar4 = this.d;
        boolean z2 = true;
        if (euVar4 != null) {
            m(euVar4.i, true);
        }
        this.d = euVar;
        Bundle bundle2 = this.e;
        if (!(bundle2 == null || (stringArrayList = bundle2.getStringArrayList("android-support-nav:controller:navigatorState:names")) == null)) {
            Iterator<String> it = stringArrayList.iterator();
            while (it.hasNext()) {
                String next = it.next();
                ku c2 = this.k.c(next);
                Bundle bundle3 = this.e.getBundle(next);
                if (bundle3 != null) {
                    c2.c(bundle3);
                }
            }
        }
        Parcelable[] parcelableArr = this.f;
        if (parcelableArr != null) {
            for (Parcelable parcelable : parcelableArr) {
                yt ytVar = (yt) parcelable;
                cu b2 = b(ytVar.h);
                if (b2 != null) {
                    Bundle bundle4 = ytVar.i;
                    if (bundle4 != null) {
                        bundle4.setClassLoader(this.a.getClassLoader());
                    }
                    this.h.add(new xt(this.a, b2, bundle4, this.i, this.j, ytVar.g, ytVar.j));
                } else {
                    StringBuilder O0 = ze0.O0("Restoring the Navigation back stack failed: destination ", cu.g(this.a, ytVar.h), " cannot be found from the current destination ");
                    O0.append(d());
                    throw new IllegalStateException(O0.toString());
                }
            }
            p();
            this.f = null;
        }
        if (this.d == null || !this.h.isEmpty()) {
            a();
            return;
        }
        if (!this.g && (activity = this.b) != null) {
            Intent intent = activity.getIntent();
            if (intent != null) {
                Bundle extras = intent.getExtras();
                int[] intArray = extras != null ? extras.getIntArray("android-support-nav:controller:deepLinkIds") : null;
                Bundle bundle5 = new Bundle();
                Bundle bundle6 = extras != null ? extras.getBundle("android-support-nav:controller:deepLinkExtras") : null;
                if (bundle6 != null) {
                    bundle5.putAll(bundle6);
                }
                if (!(!(intArray == null || intArray.length == 0) || intent.getData() == null || (m2 = this.d.m(new bu(intent))) == null)) {
                    cu cuVar2 = m2.g;
                    int[] b3 = cuVar2.b();
                    bundle5.putAll(cuVar2.a(m2.h));
                    intArray = b3;
                }
                if (!(intArray == null || intArray.length == 0)) {
                    eu euVar5 = this.d;
                    int i2 = 0;
                    while (true) {
                        if (i2 >= intArray.length) {
                            str = null;
                            break;
                        }
                        int i3 = intArray[i2];
                        if (i2 == 0) {
                            cuVar = this.d;
                            if (cuVar.i != i3) {
                                cuVar = null;
                            }
                        } else {
                            cuVar = euVar5.r(i3);
                        }
                        if (cuVar == null) {
                            str = cu.g(this.a, i3);
                            break;
                        }
                        if (i2 != intArray.length - 1) {
                            while (true) {
                                euVar3 = (eu) cuVar;
                                if (!(euVar3.r(euVar3.p) instanceof eu)) {
                                    break;
                                }
                                cuVar = euVar3.r(euVar3.p);
                            }
                            euVar5 = euVar3;
                        }
                        i2++;
                    }
                    if (str != null) {
                        Log.i("NavController", "Could not find destination " + str + " in the navigation graph, ignoring the deep link from " + intent);
                    } else {
                        bundle5.putParcelable("android-support-nav:controller:deepLinkIntent", intent);
                        int flags = intent.getFlags();
                        int i4 = 268435456 & flags;
                        if (i4 != 0 && (flags & 32768) == 0) {
                            intent.addFlags(32768);
                            sk skVar = new sk(this.a);
                            skVar.a(intent);
                            skVar.f();
                            Activity activity2 = this.b;
                            if (activity2 != null) {
                                activity2.finish();
                                this.b.overridePendingTransition(0, 0);
                            }
                        } else if (i4 != 0) {
                            if (!this.h.isEmpty()) {
                                m(this.d.i, true);
                            }
                            int i5 = 0;
                            while (i5 < intArray.length) {
                                int i6 = i5 + 1;
                                int i7 = intArray[i5];
                                cu b4 = b(i7);
                                if (b4 != null) {
                                    h(b4, bundle5, new iu(false, -1, false, 0, 0, -1, -1), null);
                                    i5 = i6;
                                } else {
                                    StringBuilder O02 = ze0.O0("Deep Linking failed: destination ", cu.g(this.a, i7), " cannot be found from the current destination ");
                                    O02.append(d());
                                    throw new IllegalStateException(O02.toString());
                                }
                            }
                        } else {
                            eu euVar6 = this.d;
                            int i8 = 0;
                            while (i8 < intArray.length) {
                                int i9 = intArray[i8];
                                cu r = i8 == 0 ? this.d : euVar6.r(i9);
                                if (r != null) {
                                    if (i8 != intArray.length - 1) {
                                        while (true) {
                                            euVar2 = (eu) r;
                                            if (!(euVar2.r(euVar2.p) instanceof eu)) {
                                                break;
                                            }
                                            r = euVar2.r(euVar2.p);
                                        }
                                        euVar6 = euVar2;
                                    } else {
                                        h(r, r.a(bundle5), new iu(false, this.d.i, true, 0, 0, -1, -1), null);
                                    }
                                    i8++;
                                } else {
                                    throw new IllegalStateException("Deep Linking failed: destination " + cu.g(this.a, i9) + " cannot be found in graph " + euVar6);
                                }
                            }
                            this.g = true;
                        }
                        z = true;
                    }
                }
            }
            z = false;
        }
        z2 = false;
        if (!z2) {
            h(this.d, bundle, null, null);
        }
    }

    public final void p() {
        g0 g0Var = this.n;
        boolean z = true;
        if (!this.o || e() <= 1) {
            z = false;
        }
        g0Var.setEnabled(z);
    }
}
