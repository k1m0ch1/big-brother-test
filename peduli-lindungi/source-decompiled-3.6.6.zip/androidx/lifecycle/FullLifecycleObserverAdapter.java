package androidx.lifecycle;

import defpackage.sr;

public class FullLifecycleObserverAdapter implements wr {
    public final qr g;
    public final wr h;

    public FullLifecycleObserverAdapter(qr qrVar, wr wrVar) {
        this.g = qrVar;
        this.h = wrVar;
    }

    @Override // defpackage.wr
    public void c(yr yrVar, sr.a aVar) {
        switch (aVar.ordinal()) {
            case 0:
                this.g.b(yrVar);
                break;
            case 1:
                this.g.onStart(yrVar);
                break;
            case 2:
                this.g.a(yrVar);
                break;
            case 3:
                this.g.d(yrVar);
                break;
            case 4:
                this.g.onStop(yrVar);
                break;
            case 5:
                this.g.onDestroy(yrVar);
                break;
            case 6:
                throw new IllegalArgumentException("ON_ANY must not been send by anybody");
        }
        wr wrVar = this.h;
        if (wrVar != null) {
            wrVar.c(yrVar, aVar);
        }
    }
}
