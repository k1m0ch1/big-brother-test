package androidx.lifecycle;

import defpackage.sr;

public class Lifecycling$1 implements wr {
    @Override // defpackage.wr
    public void c(yr yrVar, sr.a aVar) {
        throw null;
    }
}
