package androidx.lifecycle;

import defpackage.nr;
import defpackage.sr;

public class ReflectiveGenericLifecycleObserver implements wr {
    public final Object g;
    public final nr.a h;

    public ReflectiveGenericLifecycleObserver(Object obj) {
        this.g = obj;
        this.h = nr.c.b(obj.getClass());
    }

    @Override // defpackage.wr
    public void c(yr yrVar, sr.a aVar) {
        nr.a aVar2 = this.h;
        Object obj = this.g;
        nr.a.a(aVar2.a.get(aVar), yrVar, aVar, obj);
        nr.a.a(aVar2.a.get(sr.a.ON_ANY), yrVar, aVar, obj);
    }
}
