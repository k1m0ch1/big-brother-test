package androidx.lifecycle;

import defpackage.sr;
import java.util.Map;

public abstract class LiveData<T> {
    public static final Object j = new Object();
    public final Object a;
    public r4<fs<? super T>, LiveData<T>.c> b;
    public int c;
    public volatile Object d;
    public volatile Object e;
    public int f;
    public boolean g;
    public boolean h;
    public final Runnable i;

    public class LifecycleBoundObserver extends LiveData<T>.c implements wr {
        public final yr k;

        public LifecycleBoundObserver(yr yrVar, fs<? super T> fsVar) {
            super(fsVar);
            this.k = yrVar;
        }

        @Override // defpackage.wr
        public void c(yr yrVar, sr.a aVar) {
            if (((as) this.k.getLifecycle()).c == sr.b.DESTROYED) {
                LiveData.this.h(this.g);
            } else {
                e(h());
            }
        }

        @Override // androidx.lifecycle.LiveData.c
        public void f() {
            as asVar = (as) this.k.getLifecycle();
            asVar.d("removeObserver");
            asVar.b.m(this);
        }

        @Override // androidx.lifecycle.LiveData.c
        public boolean g(yr yrVar) {
            return this.k == yrVar;
        }

        @Override // androidx.lifecycle.LiveData.c
        public boolean h() {
            return ((as) this.k.getLifecycle()).c.compareTo(sr.b.STARTED) >= 0;
        }
    }

    public class a implements Runnable {
        public a() {
        }

        /* JADX DEBUG: Multi-variable search result rejected for r0v2, resolved type: androidx.lifecycle.LiveData */
        /* JADX WARN: Multi-variable type inference failed */
        public void run() {
            Object obj;
            synchronized (LiveData.this.a) {
                obj = LiveData.this.e;
                LiveData.this.e = LiveData.j;
            }
            LiveData.this.i(obj);
        }
    }

    public class b extends LiveData<T>.c {
        public b(LiveData liveData, fs<? super T> fsVar) {
            super(fsVar);
        }

        @Override // androidx.lifecycle.LiveData.c
        public boolean h() {
            return true;
        }
    }

    public abstract class c {
        public final fs<? super T> g;
        public boolean h;
        public int i = -1;

        public c(fs<? super T> fsVar) {
            this.g = fsVar;
        }

        public void e(boolean z) {
            if (z != this.h) {
                this.h = z;
                LiveData liveData = LiveData.this;
                int i2 = liveData.c;
                int i3 = 1;
                boolean z2 = i2 == 0;
                if (!z) {
                    i3 = -1;
                }
                liveData.c = i2 + i3;
                if (z2 && z) {
                    liveData.f();
                }
                LiveData liveData2 = LiveData.this;
                if (liveData2.c == 0 && !this.h) {
                    liveData2.g();
                }
                if (this.h) {
                    LiveData.this.c(this);
                }
            }
        }

        public void f() {
        }

        public boolean g(yr yrVar) {
            return false;
        }

        public abstract boolean h();
    }

    public LiveData(T t) {
        this.a = new Object();
        this.b = new r4<>();
        this.c = 0;
        this.e = j;
        this.i = new a();
        this.d = t;
        this.f = 0;
    }

    public static void a(String str) {
        if (!n4.d().b()) {
            throw new IllegalStateException(ze0.s0("Cannot invoke ", str, " on a background thread"));
        }
    }

    public final void b(LiveData<T>.c cVar) {
        if (cVar.h) {
            if (!cVar.h()) {
                cVar.e(false);
                return;
            }
            int i2 = cVar.i;
            int i3 = this.f;
            if (i2 < i3) {
                cVar.i = i3;
                cVar.g.onChanged((Object) this.d);
            }
        }
    }

    public void c(LiveData<T>.c cVar) {
        if (this.g) {
            this.h = true;
            return;
        }
        this.g = true;
        do {
            this.h = false;
            if (cVar == null) {
                r4<K, V>.d b2 = this.b.b();
                while (b2.hasNext()) {
                    b((c) ((Map.Entry) b2.next()).getValue());
                    if (this.h) {
                        break;
                    }
                }
            } else {
                b(cVar);
                cVar = null;
            }
        } while (this.h);
        this.g = false;
    }

    public T d() {
        T t = (T) this.d;
        if (t != j) {
            return t;
        }
        return null;
    }

    public void e(yr yrVar, fs<? super T> fsVar) {
        a("observe");
        if (((as) yrVar.getLifecycle()).c != sr.b.DESTROYED) {
            LifecycleBoundObserver lifecycleBoundObserver = new LifecycleBoundObserver(yrVar, fsVar);
            LiveData<T>.c g2 = this.b.g(fsVar, lifecycleBoundObserver);
            if (g2 != null && !g2.g(yrVar)) {
                throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
            } else if (g2 == null) {
                yrVar.getLifecycle().a(lifecycleBoundObserver);
            }
        }
    }

    public void f() {
    }

    public void g() {
    }

    public void h(fs<? super T> fsVar) {
        a("removeObserver");
        LiveData<T>.c m = this.b.m(fsVar);
        if (m != null) {
            m.f();
            m.e(false);
        }
    }

    public void i(T t) {
        a("setValue");
        this.f++;
        this.d = t;
        c(null);
    }

    public LiveData() {
        this.a = new Object();
        this.b = new r4<>();
        this.c = 0;
        Object obj = j;
        this.e = obj;
        this.i = new a();
        this.d = obj;
        this.f = -1;
    }
}
