package androidx.lifecycle;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import defpackage.sr;

public class LifecycleService extends Service implements yr {
    public final ms g = new ms(this);

    @Override // defpackage.yr
    public sr getLifecycle() {
        return this.g.a;
    }

    public IBinder onBind(Intent intent) {
        this.g.a(sr.a.ON_START);
        return null;
    }

    public void onCreate() {
        this.g.a(sr.a.ON_CREATE);
        super.onCreate();
    }

    public void onDestroy() {
        ms msVar = this.g;
        msVar.a(sr.a.ON_STOP);
        msVar.a(sr.a.ON_DESTROY);
        super.onDestroy();
    }

    public void onStart(Intent intent, int i) {
        this.g.a(sr.a.ON_START);
        super.onStart(intent, i);
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        return super.onStartCommand(intent, i, i2);
    }
}
