package androidx.lifecycle;

import defpackage.sr;

public class SingleGeneratedAdapterObserver implements wr {
    public final rr g;

    public SingleGeneratedAdapterObserver(rr rrVar) {
        this.g = rrVar;
    }

    @Override // defpackage.wr
    public void c(yr yrVar, sr.a aVar) {
        this.g.a(yrVar, aVar, false, null);
        this.g.a(yrVar, aVar, true, null);
    }
}
