package androidx.lifecycle;

import defpackage.sr;
import kotlin.Metadata;

@Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0001\u001a\u00020\u00002\u0006\u0010\u0003\u001a\u00020\u0002H\n¢\u0006\u0004\b\u0005\u0010\u0006"}, d2 = {"Lyr;", "source", "Lsr$a;", "<anonymous parameter 1>", "", "c", "(Lyr;Lsr$a;)V"}, k = 3, mv = {1, 4, 0})
/* compiled from: LifecycleController.kt */
public final class LifecycleController$observer$1 implements wr {
    @Override // defpackage.wr
    public final void c(yr yrVar, sr.a aVar) {
        a56.f(yrVar, "source");
        a56.f(aVar, "<anonymous parameter 1>");
        sr lifecycle = yrVar.getLifecycle();
        a56.b(lifecycle, "source.lifecycle");
        if (((as) lifecycle).c == sr.b.DESTROYED) {
            mz6.v(null, null, 1, null);
            throw null;
        }
        sr lifecycle2 = yrVar.getLifecycle();
        a56.b(lifecycle2, "source.lifecycle");
        as asVar = (as) lifecycle2;
        throw null;
    }
}
