package androidx.lifecycle;

import android.os.Bundle;
import defpackage.nz;
import defpackage.sr;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Objects;

public final class SavedStateHandleController implements wr {
    public final String g;
    public boolean h = false;
    public final ks i;

    public static final class a implements nz.a {
        @Override // defpackage.nz.a
        public void a(pz pzVar) {
            if (pzVar instanceof qs) {
                ps viewModelStore = ((qs) pzVar).getViewModelStore();
                nz savedStateRegistry = pzVar.getSavedStateRegistry();
                Objects.requireNonNull(viewModelStore);
                Iterator it = new HashSet(viewModelStore.a.keySet()).iterator();
                while (it.hasNext()) {
                    SavedStateHandleController.e(viewModelStore.a.get((String) it.next()), savedStateRegistry, pzVar.getLifecycle());
                }
                if (!new HashSet(viewModelStore.a.keySet()).isEmpty()) {
                    savedStateRegistry.b(a.class);
                    return;
                }
                return;
            }
            throw new IllegalStateException("Internal error: OnRecreation should be registered only on componentsthat implement ViewModelStoreOwner");
        }
    }

    public SavedStateHandleController(String str, ks ksVar) {
        this.g = str;
        this.i = ksVar;
    }

    public static void e(ns nsVar, nz nzVar, sr srVar) {
        SavedStateHandleController savedStateHandleController = (SavedStateHandleController) nsVar.getTag("androidx.lifecycle.savedstate.vm.tag");
        if (savedStateHandleController != null && !savedStateHandleController.h) {
            savedStateHandleController.f(nzVar, srVar);
            h(nzVar, srVar);
        }
    }

    public static SavedStateHandleController g(nz nzVar, sr srVar, String str, Bundle bundle) {
        ks ksVar;
        Bundle a2 = nzVar.a(str);
        Class[] clsArr = ks.d;
        if (a2 == null && bundle == null) {
            ksVar = new ks();
        } else {
            HashMap hashMap = new HashMap();
            if (bundle != null) {
                for (String str2 : bundle.keySet()) {
                    hashMap.put(str2, bundle.get(str2));
                }
            }
            if (a2 == null) {
                ksVar = new ks(hashMap);
            } else {
                ArrayList parcelableArrayList = a2.getParcelableArrayList("keys");
                ArrayList parcelableArrayList2 = a2.getParcelableArrayList("values");
                if (parcelableArrayList == null || parcelableArrayList2 == null || parcelableArrayList.size() != parcelableArrayList2.size()) {
                    throw new IllegalStateException("Invalid bundle passed as restored state");
                }
                for (int i2 = 0; i2 < parcelableArrayList.size(); i2++) {
                    hashMap.put((String) parcelableArrayList.get(i2), parcelableArrayList2.get(i2));
                }
                ksVar = new ks(hashMap);
            }
        }
        SavedStateHandleController savedStateHandleController = new SavedStateHandleController(str, ksVar);
        savedStateHandleController.f(nzVar, srVar);
        h(nzVar, srVar);
        return savedStateHandleController;
    }

    public static void h(final nz nzVar, final sr srVar) {
        sr.b bVar = ((as) srVar).c;
        if (bVar != sr.b.INITIALIZED) {
            if (!(bVar.compareTo(sr.b.STARTED) >= 0)) {
                srVar.a(new wr() {
                    /* class androidx.lifecycle.SavedStateHandleController.AnonymousClass1 */

                    @Override // defpackage.wr
                    public void c(yr yrVar, sr.a aVar) {
                        if (aVar == sr.a.ON_START) {
                            as asVar = (as) srVar;
                            asVar.d("removeObserver");
                            asVar.b.m(this);
                            nzVar.b(a.class);
                        }
                    }
                });
                return;
            }
        }
        nzVar.b(a.class);
    }

    @Override // defpackage.wr
    public void c(yr yrVar, sr.a aVar) {
        if (aVar == sr.a.ON_DESTROY) {
            this.h = false;
            as asVar = (as) yrVar.getLifecycle();
            asVar.d("removeObserver");
            asVar.b.m(this);
        }
    }

    public void f(nz nzVar, sr srVar) {
        if (!this.h) {
            this.h = true;
            srVar.a(this);
            if (nzVar.a.g(this.g, this.i.c) != null) {
                throw new IllegalArgumentException("SavedStateProvider with the given key is already registered");
            }
            return;
        }
        throw new IllegalStateException("Already attached to lifecycleOwner");
    }
}
