package androidx.lifecycle;

import defpackage.sr;

public class CompositeGeneratedAdaptersObserver implements wr {
    public final rr[] g;

    public CompositeGeneratedAdaptersObserver(rr[] rrVarArr) {
        this.g = rrVarArr;
    }

    @Override // defpackage.wr
    public void c(yr yrVar, sr.a aVar) {
        ds dsVar = new ds();
        for (rr rrVar : this.g) {
            rrVar.a(yrVar, aVar, false, dsVar);
        }
        for (rr rrVar2 : this.g) {
            rrVar2.a(yrVar, aVar, true, dsVar);
        }
    }
}
