package androidx.lifecycle;

import defpackage.sr;
import kotlin.Metadata;

@Metadata(bv = {1, 0, 3}, d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\b\b\u0000\u0018\u00002\u00020\u00012\u00020\u0002B\u0017\u0012\u0006\u0010\u0015\u001a\u00020\u0010\u0012\u0006\u0010\u000f\u001a\u00020\n¢\u0006\u0004\b\u0016\u0010\u0017J\u001f\u0010\b\u001a\u00020\u00072\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u0005H\u0016¢\u0006\u0004\b\b\u0010\tR\u001c\u0010\u000f\u001a\u00020\n8\u0016@\u0016X\u0004¢\u0006\f\n\u0004\b\u000b\u0010\f\u001a\u0004\b\r\u0010\u000eR\u001c\u0010\u0015\u001a\u00020\u00108\u0010@\u0010X\u0004¢\u0006\f\n\u0004\b\u0011\u0010\u0012\u001a\u0004\b\u0013\u0010\u0014¨\u0006\u0018"}, d2 = {"Landroidx/lifecycle/LifecycleCoroutineScopeImpl;", "Ltr;", "Lwr;", "Lyr;", "source", "Lsr$a;", "event", "", "c", "(Lyr;Lsr$a;)V", "Lx26;", "h", "Lx26;", "Z", "()Lx26;", "coroutineContext", "Lsr;", "g", "Lsr;", "getLifecycle$lifecycle_runtime_ktx_release", "()Lsr;", "lifecycle", "<init>", "(Lsr;Lx26;)V", "lifecycle-runtime-ktx_release"}, k = 1, mv = {1, 4, 0})
/* compiled from: Lifecycle.kt */
public final class LifecycleCoroutineScopeImpl extends tr implements wr {
    public final sr g;
    public final x26 h;

    public LifecycleCoroutineScopeImpl(sr srVar, x26 x26) {
        a56.f(srVar, "lifecycle");
        a56.f(x26, "coroutineContext");
        this.g = srVar;
        this.h = x26;
        if (((as) srVar).c == sr.b.DESTROYED) {
            mz6.u(x26, null, 1, null);
        }
    }

    @Override // defpackage.l37
    public x26 Z() {
        return this.h;
    }

    @Override // defpackage.wr
    public void c(yr yrVar, sr.a aVar) {
        a56.f(yrVar, "source");
        a56.f(aVar, "event");
        if (((as) this.g).c.compareTo((Enum) sr.b.DESTROYED) <= 0) {
            as asVar = (as) this.g;
            asVar.d("removeObserver");
            asVar.b.m(this);
            mz6.u(this.h, null, 1, null);
        }
    }
}
