package androidx.room;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.util.Log;
import java.util.HashMap;

public class MultiInstanceInvalidationService extends Service {
    public int g = 0;
    public final HashMap<Integer, String> h = new HashMap<>();
    public final RemoteCallbackList<bz> i = new a();
    public final cz j = new b();

    public class a extends RemoteCallbackList<bz> {
        public a() {
        }

        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [android.os.IInterface, java.lang.Object] */
        @Override // android.os.RemoteCallbackList
        public void onCallbackDied(bz bzVar, Object obj) {
            MultiInstanceInvalidationService.this.h.remove(Integer.valueOf(((Integer) obj).intValue()));
        }
    }

    public class b extends cz {
        public b() {
        }

        public void f1(int i, String[] strArr) {
            synchronized (MultiInstanceInvalidationService.this.i) {
                String str = MultiInstanceInvalidationService.this.h.get(Integer.valueOf(i));
                if (str == null) {
                    Log.w("ROOM", "Remote invalidation client ID not registered");
                    return;
                }
                int beginBroadcast = MultiInstanceInvalidationService.this.i.beginBroadcast();
                for (int i2 = 0; i2 < beginBroadcast; i2++) {
                    try {
                        int intValue = ((Integer) MultiInstanceInvalidationService.this.i.getBroadcastCookie(i2)).intValue();
                        String str2 = MultiInstanceInvalidationService.this.h.get(Integer.valueOf(intValue));
                        if (i != intValue && str.equals(str2)) {
                            try {
                                MultiInstanceInvalidationService.this.i.getBroadcastItem(i2).R(strArr);
                            } catch (RemoteException e) {
                                Log.w("ROOM", "Error invoking a remote callback", e);
                            }
                        }
                    } catch (Throwable th) {
                        MultiInstanceInvalidationService.this.i.finishBroadcast();
                        throw th;
                    }
                }
                MultiInstanceInvalidationService.this.i.finishBroadcast();
            }
        }

        public int g1(bz bzVar, String str) {
            if (str == null) {
                return 0;
            }
            synchronized (MultiInstanceInvalidationService.this.i) {
                MultiInstanceInvalidationService multiInstanceInvalidationService = MultiInstanceInvalidationService.this;
                int i = multiInstanceInvalidationService.g + 1;
                multiInstanceInvalidationService.g = i;
                if (multiInstanceInvalidationService.i.register(bzVar, Integer.valueOf(i))) {
                    MultiInstanceInvalidationService.this.h.put(Integer.valueOf(i), str);
                    return i;
                }
                MultiInstanceInvalidationService multiInstanceInvalidationService2 = MultiInstanceInvalidationService.this;
                multiInstanceInvalidationService2.g--;
                return 0;
            }
        }

        public void h1(bz bzVar, int i) {
            synchronized (MultiInstanceInvalidationService.this.i) {
                MultiInstanceInvalidationService.this.i.unregister(bzVar);
                MultiInstanceInvalidationService.this.h.remove(Integer.valueOf(i));
            }
        }
    }

    public IBinder onBind(Intent intent) {
        return this.j;
    }
}
