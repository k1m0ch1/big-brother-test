package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import com.github.mikephil.charting.utils.Utils;
import com.telkom.tracencare.R;

public class CardView extends FrameLayout {
    public static final int[] n = {16842801};
    public static final jg o = new hg();
    public boolean g;
    public boolean h;
    public int i;
    public int j;
    public final Rect k;
    public final Rect l = new Rect();
    public final ig m;

    public class a implements ig {
        public Drawable a;

        public a() {
        }

        public boolean a() {
            return CardView.this.getPreventCornerOverlap();
        }

        public void b(int i, int i2, int i3, int i4) {
            CardView.this.l.set(i, i2, i3, i4);
            CardView cardView = CardView.this;
            Rect rect = cardView.k;
            CardView.super.setPadding(i + rect.left, i2 + rect.top, i3 + rect.right, i4 + rect.bottom);
        }
    }

    public CardView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.cardViewStyle);
        ColorStateList colorStateList;
        int i2;
        Rect rect = new Rect();
        this.k = rect;
        a aVar = new a();
        this.m = aVar;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, gg.a, R.attr.cardViewStyle, R.style.CardView);
        if (obtainStyledAttributes.hasValue(2)) {
            colorStateList = obtainStyledAttributes.getColorStateList(2);
        } else {
            TypedArray obtainStyledAttributes2 = getContext().obtainStyledAttributes(n);
            int color = obtainStyledAttributes2.getColor(0, 0);
            obtainStyledAttributes2.recycle();
            float[] fArr = new float[3];
            Color.colorToHSV(color, fArr);
            if (fArr[2] > 0.5f) {
                i2 = getResources().getColor(R.color.cardview_light_background);
            } else {
                i2 = getResources().getColor(R.color.cardview_dark_background);
            }
            colorStateList = ColorStateList.valueOf(i2);
        }
        float dimension = obtainStyledAttributes.getDimension(3, Utils.FLOAT_EPSILON);
        float dimension2 = obtainStyledAttributes.getDimension(4, Utils.FLOAT_EPSILON);
        float dimension3 = obtainStyledAttributes.getDimension(5, Utils.FLOAT_EPSILON);
        this.g = obtainStyledAttributes.getBoolean(7, false);
        this.h = obtainStyledAttributes.getBoolean(6, true);
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(8, 0);
        rect.left = obtainStyledAttributes.getDimensionPixelSize(10, dimensionPixelSize);
        rect.top = obtainStyledAttributes.getDimensionPixelSize(12, dimensionPixelSize);
        rect.right = obtainStyledAttributes.getDimensionPixelSize(11, dimensionPixelSize);
        rect.bottom = obtainStyledAttributes.getDimensionPixelSize(9, dimensionPixelSize);
        dimension3 = dimension2 > dimension3 ? dimension2 : dimension3;
        this.i = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        this.j = obtainStyledAttributes.getDimensionPixelSize(1, 0);
        obtainStyledAttributes.recycle();
        kg kgVar = new kg(colorStateList, dimension);
        aVar.a = kgVar;
        CardView.this.setBackgroundDrawable(kgVar);
        CardView cardView = CardView.this;
        cardView.setClipToOutline(true);
        cardView.setElevation(dimension2);
        ((hg) o).b(aVar, dimension3);
    }

    public ColorStateList getCardBackgroundColor() {
        return ((kg) ((a) this.m).a).h;
    }

    public float getCardElevation() {
        return CardView.this.getElevation();
    }

    public int getContentPaddingBottom() {
        return this.k.bottom;
    }

    public int getContentPaddingLeft() {
        return this.k.left;
    }

    public int getContentPaddingRight() {
        return this.k.right;
    }

    public int getContentPaddingTop() {
        return this.k.top;
    }

    public float getMaxCardElevation() {
        return ((kg) ((a) this.m).a).e;
    }

    public boolean getPreventCornerOverlap() {
        return this.h;
    }

    public float getRadius() {
        return ((kg) ((a) this.m).a).a;
    }

    public boolean getUseCompatPadding() {
        return this.g;
    }

    public void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
    }

    public void setCardBackgroundColor(int i2) {
        ig igVar = this.m;
        ColorStateList valueOf = ColorStateList.valueOf(i2);
        kg kgVar = (kg) ((a) igVar).a;
        kgVar.b(valueOf);
        kgVar.invalidateSelf();
    }

    public void setCardElevation(float f) {
        CardView.this.setElevation(f);
    }

    public void setMaxCardElevation(float f) {
        ((hg) o).b(this.m, f);
    }

    public void setMinimumHeight(int i2) {
        this.j = i2;
        super.setMinimumHeight(i2);
    }

    public void setMinimumWidth(int i2) {
        this.i = i2;
        super.setMinimumWidth(i2);
    }

    public void setPadding(int i2, int i3, int i4, int i5) {
    }

    public void setPaddingRelative(int i2, int i3, int i4, int i5) {
    }

    public void setPreventCornerOverlap(boolean z) {
        if (z != this.h) {
            this.h = z;
            jg jgVar = o;
            ig igVar = this.m;
            hg hgVar = (hg) jgVar;
            hgVar.b(igVar, hgVar.a(igVar).e);
        }
    }

    public void setRadius(float f) {
        kg kgVar = (kg) ((a) this.m).a;
        if (f != kgVar.a) {
            kgVar.a = f;
            kgVar.c(null);
            kgVar.invalidateSelf();
        }
    }

    public void setUseCompatPadding(boolean z) {
        if (this.g != z) {
            this.g = z;
            jg jgVar = o;
            ig igVar = this.m;
            hg hgVar = (hg) jgVar;
            hgVar.b(igVar, hgVar.a(igVar).e);
        }
    }

    public void setCardBackgroundColor(ColorStateList colorStateList) {
        kg kgVar = (kg) ((a) this.m).a;
        kgVar.b(colorStateList);
        kgVar.invalidateSelf();
    }
}
