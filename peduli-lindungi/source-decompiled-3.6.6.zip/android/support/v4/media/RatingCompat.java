package android.support.v4.media;

import android.os.Parcel;
import android.os.Parcelable;
import com.github.mikephil.charting.utils.Utils;

public final class RatingCompat implements Parcelable {
    public static final Parcelable.Creator<RatingCompat> CREATOR = new a();
    public final int g;
    public final float h;

    public static class a implements Parcelable.Creator<RatingCompat> {
        /* Return type fixed from 'java.lang.Object' to match base method */
        @Override // android.os.Parcelable.Creator
        public RatingCompat createFromParcel(Parcel parcel) {
            return new RatingCompat(parcel.readInt(), parcel.readFloat());
        }

        /* Return type fixed from 'java.lang.Object[]' to match base method */
        @Override // android.os.Parcelable.Creator
        public RatingCompat[] newArray(int i) {
            return new RatingCompat[i];
        }
    }

    public RatingCompat(int i, float f) {
        this.g = i;
        this.h = f;
    }

    public int describeContents() {
        return this.g;
    }

    public String toString() {
        String str;
        StringBuilder J0 = ze0.J0("Rating:style=");
        J0.append(this.g);
        J0.append(" rating=");
        float f = this.h;
        if (f < Utils.FLOAT_EPSILON) {
            str = "unrated";
        } else {
            str = String.valueOf(f);
        }
        J0.append(str);
        return J0.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.g);
        parcel.writeFloat(this.h);
    }
}
