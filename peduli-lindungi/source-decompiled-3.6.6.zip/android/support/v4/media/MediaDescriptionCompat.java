package android.support.v4.media;

import android.graphics.Bitmap;
import android.media.MediaDescription;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.session.MediaSessionCompat;

public final class MediaDescriptionCompat implements Parcelable {
    public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new a();
    public final String g;
    public final CharSequence h;
    public final CharSequence i;
    public final CharSequence j;
    public final Bitmap k;
    public final Uri l;
    public final Bundle m;
    public final Uri n;
    public Object o;

    public static class a implements Parcelable.Creator<MediaDescriptionCompat> {
        /* Return type fixed from 'java.lang.Object' to match base method */
        @Override // android.os.Parcelable.Creator
        public MediaDescriptionCompat createFromParcel(Parcel parcel) {
            return MediaDescriptionCompat.a(MediaDescription.CREATOR.createFromParcel(parcel));
        }

        /* Return type fixed from 'java.lang.Object[]' to match base method */
        @Override // android.os.Parcelable.Creator
        public MediaDescriptionCompat[] newArray(int i) {
            return new MediaDescriptionCompat[i];
        }
    }

    public MediaDescriptionCompat(String str, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, Bitmap bitmap, Uri uri, Bundle bundle, Uri uri2) {
        this.g = str;
        this.h = charSequence;
        this.i = charSequence2;
        this.j = charSequence3;
        this.k = bitmap;
        this.l = uri;
        this.m = bundle;
        this.n = uri2;
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x0050  */
    public static MediaDescriptionCompat a(Object obj) {
        Uri uri;
        Bundle bundle;
        Uri uri2 = null;
        if (obj == null) {
            return null;
        }
        int i2 = Build.VERSION.SDK_INT;
        MediaDescription mediaDescription = (MediaDescription) obj;
        String mediaId = mediaDescription.getMediaId();
        CharSequence title = mediaDescription.getTitle();
        CharSequence subtitle = mediaDescription.getSubtitle();
        CharSequence description = mediaDescription.getDescription();
        Bitmap iconBitmap = mediaDescription.getIconBitmap();
        Uri iconUri = mediaDescription.getIconUri();
        Bundle extras = mediaDescription.getExtras();
        if (extras != null) {
            MediaSessionCompat.a(extras);
            uri = (Uri) extras.getParcelable("android.support.v4.media.description.MEDIA_URI");
        } else {
            uri = null;
        }
        if (uri != null) {
            if (!extras.containsKey("android.support.v4.media.description.NULL_BUNDLE_FLAG") || extras.size() != 2) {
                extras.remove("android.support.v4.media.description.MEDIA_URI");
                extras.remove("android.support.v4.media.description.NULL_BUNDLE_FLAG");
            } else {
                bundle = null;
                if (uri == null) {
                    if (i2 >= 23) {
                        uri2 = mediaDescription.getMediaUri();
                    }
                    uri = uri2;
                }
                MediaDescriptionCompat mediaDescriptionCompat = new MediaDescriptionCompat(mediaId, title, subtitle, description, iconBitmap, iconUri, bundle, uri);
                mediaDescriptionCompat.o = obj;
                return mediaDescriptionCompat;
            }
        }
        bundle = extras;
        if (uri == null) {
        }
        MediaDescriptionCompat mediaDescriptionCompat2 = new MediaDescriptionCompat(mediaId, title, subtitle, description, iconBitmap, iconUri, bundle, uri);
        mediaDescriptionCompat2.o = obj;
        return mediaDescriptionCompat2;
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        return ((Object) this.h) + ", " + ((Object) this.i) + ", " + ((Object) this.j);
    }

    public void writeToParcel(Parcel parcel, int i2) {
        int i3 = Build.VERSION.SDK_INT;
        Object obj = this.o;
        if (obj == null) {
            MediaDescription.Builder builder = new MediaDescription.Builder();
            builder.setMediaId(this.g);
            builder.setTitle(this.h);
            builder.setSubtitle(this.i);
            builder.setDescription(this.j);
            builder.setIconBitmap(this.k);
            builder.setIconUri(this.l);
            Bundle bundle = this.m;
            if (i3 < 23 && this.n != null) {
                if (bundle == null) {
                    bundle = new Bundle();
                    bundle.putBoolean("android.support.v4.media.description.NULL_BUNDLE_FLAG", true);
                }
                bundle.putParcelable("android.support.v4.media.description.MEDIA_URI", this.n);
            }
            builder.setExtras(bundle);
            if (i3 >= 23) {
                builder.setMediaUri(this.n);
            }
            obj = builder.build();
            this.o = obj;
        }
        ((MediaDescription) obj).writeToParcel(parcel, i2);
    }
}
