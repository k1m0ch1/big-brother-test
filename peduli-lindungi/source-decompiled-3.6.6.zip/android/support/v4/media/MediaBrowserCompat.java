package android.support.v4.media;

import android.content.ComponentName;
import android.content.Context;
import android.media.browse.MediaBrowser;
import android.os.BadParcelableException;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.session.MediaSessionCompat;
import android.text.TextUtils;
import android.util.Log;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public final class MediaBrowserCompat {
    public static final boolean b = Log.isLoggable("MediaBrowserCompat", 3);
    public final c a;

    public static class CustomActionResultReceiver extends e0 {
        @Override // defpackage.e0
        public void a(int i, Bundle bundle) {
        }
    }

    public static class ItemReceiver extends e0 {
        @Override // defpackage.e0
        public void a(int i, Bundle bundle) {
            MediaSessionCompat.a(bundle);
            if (i != 0 || bundle == null || !bundle.containsKey("media_item")) {
                throw null;
            }
            Parcelable parcelable = bundle.getParcelable("media_item");
            if (parcelable == null || (parcelable instanceof MediaItem)) {
                MediaItem mediaItem = (MediaItem) parcelable;
                throw null;
            }
            throw null;
        }
    }

    public static class SearchResultReceiver extends e0 {
        @Override // defpackage.e0
        public void a(int i, Bundle bundle) {
            MediaSessionCompat.a(bundle);
            if (i != 0 || bundle == null || !bundle.containsKey("search_results")) {
                throw null;
            }
            Parcelable[] parcelableArray = bundle.getParcelableArray("search_results");
            if (parcelableArray != null) {
                ArrayList arrayList = new ArrayList();
                for (Parcelable parcelable : parcelableArray) {
                    arrayList.add((MediaItem) parcelable);
                }
            }
            throw null;
        }
    }

    public static class a extends Handler {
        public final WeakReference<g> a;
        public WeakReference<Messenger> b;

        public a(g gVar) {
            this.a = new WeakReference<>(gVar);
        }

        public void a(Messenger messenger) {
            this.b = new WeakReference<>(messenger);
        }

        public void handleMessage(Message message) {
            WeakReference<Messenger> weakReference = this.b;
            if (weakReference != null && weakReference.get() != null && this.a.get() != null) {
                Bundle data = message.getData();
                MediaSessionCompat.a(data);
                g gVar = this.a.get();
                Messenger messenger = this.b.get();
                try {
                    int i = message.what;
                    if (i == 1) {
                        Bundle bundle = data.getBundle("data_root_hints");
                        MediaSessionCompat.a(bundle);
                        gVar.b(messenger, data.getString("data_media_item_id"), (MediaSessionCompat.Token) data.getParcelable("data_media_session_token"), bundle);
                    } else if (i == 2) {
                        gVar.a(messenger);
                    } else if (i != 3) {
                        Log.w("MediaBrowserCompat", "Unhandled message: " + message + "\n  Client version: " + 1 + "\n  Service version: " + message.arg1);
                    } else {
                        Bundle bundle2 = data.getBundle("data_options");
                        MediaSessionCompat.a(bundle2);
                        Bundle bundle3 = data.getBundle("data_notify_children_changed_options");
                        MediaSessionCompat.a(bundle3);
                        gVar.c(messenger, data.getString("data_media_item_id"), data.getParcelableArrayList("data_media_item_list"), bundle2, bundle3);
                    }
                } catch (BadParcelableException unused) {
                    Log.e("MediaBrowserCompat", "Could not unparcel the data.");
                    if (message.what == 1) {
                        gVar.a(messenger);
                    }
                }
            }
        }
    }

    public static class b {
        public final Object a = new r(new C0001b());
        public a b;

        public interface a {
        }

        /* renamed from: android.support.v4.media.MediaBrowserCompat$b$b  reason: collision with other inner class name */
        public class C0001b implements q {
            public C0001b() {
            }
        }

        public void a() {
            throw null;
        }
    }

    public interface c {
    }

    public static class d implements c, g, b.a {
        public final Context a;
        public final Object b;
        public final Bundle c;
        public final a d = new a(this);
        public final mg<String, i> e = new mg<>();
        public h f;
        public Messenger g;
        public MediaSessionCompat.Token h;

        public d(Context context, ComponentName componentName, b bVar, Bundle bundle) {
            Bundle bundle2;
            this.a = context;
            if (bundle == null) {
                bundle2 = new Bundle();
            }
            this.c = bundle2;
            bundle2.putInt("extra_client_version", 1);
            bVar.b = this;
            this.b = new MediaBrowser(context, componentName, (MediaBrowser.ConnectionCallback) bVar.a, bundle2);
        }

        @Override // android.support.v4.media.MediaBrowserCompat.g
        public void a(Messenger messenger) {
        }

        @Override // android.support.v4.media.MediaBrowserCompat.g
        public void b(Messenger messenger, String str, MediaSessionCompat.Token token, Bundle bundle) {
        }

        @Override // android.support.v4.media.MediaBrowserCompat.g
        public void c(Messenger messenger, String str, List list, Bundle bundle, Bundle bundle2) {
            if (this.g == messenger) {
                i orDefault = this.e.getOrDefault(str, null);
                if (orDefault != null) {
                    orDefault.a(bundle);
                } else if (MediaBrowserCompat.b) {
                    Log.d("MediaBrowserCompat", "onLoadChildren for id that isn't subscribed id=" + str);
                }
            }
        }
    }

    public static class e extends d {
        public e(Context context, ComponentName componentName, b bVar, Bundle bundle) {
            super(context, componentName, bVar, bundle);
        }
    }

    public static class f extends e {
        public f(Context context, ComponentName componentName, b bVar, Bundle bundle) {
            super(context, componentName, bVar, bundle);
        }
    }

    public interface g {
        void a(Messenger messenger);

        void b(Messenger messenger, String str, MediaSessionCompat.Token token, Bundle bundle);

        void c(Messenger messenger, String str, List list, Bundle bundle, Bundle bundle2);
    }

    public static class h {
        public Messenger a;
        public Bundle b;

        public h(IBinder iBinder, Bundle bundle) {
            this.a = new Messenger(iBinder);
            this.b = bundle;
        }

        public final void a(int i, Bundle bundle, Messenger messenger) {
            Message obtain = Message.obtain();
            obtain.what = i;
            obtain.arg1 = 1;
            obtain.setData(bundle);
            obtain.replyTo = messenger;
            this.a.send(obtain);
        }
    }

    public static class i {
        public final List<j> a = new ArrayList();
        public final List<Bundle> b = new ArrayList();

        public j a(Bundle bundle) {
            for (int i = 0; i < this.b.size(); i++) {
                if (ek.a(this.b.get(i), bundle)) {
                    return this.a.get(i);
                }
            }
            return null;
        }
    }

    public static abstract class j {
        public final IBinder a = new Binder();

        public class a implements s {
            public a() {
            }

            @Override // defpackage.s
            public void c(String str) {
                Objects.requireNonNull(j.this);
            }

            @Override // defpackage.s
            public void d(String str, List<?> list) {
                Objects.requireNonNull(j.this);
                j jVar = j.this;
                MediaItem.a(list);
                Objects.requireNonNull(jVar);
            }
        }

        public class b extends a implements u {
            public b() {
                super();
            }

            @Override // defpackage.u
            public void a(String str, List<?> list, Bundle bundle) {
                j jVar = j.this;
                MediaItem.a(list);
                Objects.requireNonNull(jVar);
            }

            @Override // defpackage.u
            public void b(String str, Bundle bundle) {
                Objects.requireNonNull(j.this);
            }
        }

        public j() {
            if (Build.VERSION.SDK_INT >= 26) {
                new v(new b());
            } else {
                new t(new a());
            }
        }
    }

    public MediaBrowserCompat(Context context, ComponentName componentName, b bVar, Bundle bundle) {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 26) {
            this.a = new f(context, componentName, bVar, null);
        } else if (i2 >= 23) {
            this.a = new e(context, componentName, bVar, null);
        } else {
            this.a = new d(context, componentName, bVar, null);
        }
    }

    public static class MediaItem implements Parcelable {
        public static final Parcelable.Creator<MediaItem> CREATOR = new a();
        public final int g;
        public final MediaDescriptionCompat h;

        public static class a implements Parcelable.Creator<MediaItem> {
            /* Return type fixed from 'java.lang.Object' to match base method */
            @Override // android.os.Parcelable.Creator
            public MediaItem createFromParcel(Parcel parcel) {
                return new MediaItem(parcel);
            }

            /* Return type fixed from 'java.lang.Object[]' to match base method */
            @Override // android.os.Parcelable.Creator
            public MediaItem[] newArray(int i) {
                return new MediaItem[i];
            }
        }

        public MediaItem(MediaDescriptionCompat mediaDescriptionCompat, int i) {
            if (mediaDescriptionCompat == null) {
                throw new IllegalArgumentException("description cannot be null");
            } else if (!TextUtils.isEmpty(mediaDescriptionCompat.g)) {
                this.g = i;
                this.h = mediaDescriptionCompat;
            } else {
                throw new IllegalArgumentException("description must have a non-empty media id");
            }
        }

        public static List<MediaItem> a(List<?> list) {
            MediaItem mediaItem;
            if (list == null) {
                return null;
            }
            ArrayList arrayList = new ArrayList(list.size());
            for (Object obj : list) {
                if (obj != null) {
                    MediaBrowser.MediaItem mediaItem2 = (MediaBrowser.MediaItem) obj;
                    mediaItem = new MediaItem(MediaDescriptionCompat.a(mediaItem2.getDescription()), mediaItem2.getFlags());
                } else {
                    mediaItem = null;
                }
                arrayList.add(mediaItem);
            }
            return arrayList;
        }

        public int describeContents() {
            return 0;
        }

        public String toString() {
            return "MediaItem{" + "mFlags=" + this.g + ", mDescription=" + this.h + '}';
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.g);
            this.h.writeToParcel(parcel, i);
        }

        public MediaItem(Parcel parcel) {
            this.g = parcel.readInt();
            this.h = MediaDescriptionCompat.CREATOR.createFromParcel(parcel);
        }
    }
}
