package android.support.v4.media.session;

import android.content.Context;
import android.media.session.MediaController;
import android.media.session.MediaSession;
import android.os.Bundle;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.util.Log;
import defpackage.x;
import defpackage.y;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

public class MediaControllerCompat$MediaControllerImplApi21 {
    public final Object a;
    public final Object b = new Object();
    public final List<y> c = new ArrayList();
    public HashMap<y, a> d = new HashMap<>();
    public final MediaSessionCompat.Token e;

    public static class ExtraBinderRequestResultReceiver extends ResultReceiver {
        public WeakReference<MediaControllerCompat$MediaControllerImplApi21> g;

        public ExtraBinderRequestResultReceiver(MediaControllerCompat$MediaControllerImplApi21 mediaControllerCompat$MediaControllerImplApi21) {
            super(null);
            this.g = new WeakReference<>(mediaControllerCompat$MediaControllerImplApi21);
        }

        public void onReceiveResult(int i, Bundle bundle) {
            MediaControllerCompat$MediaControllerImplApi21 mediaControllerCompat$MediaControllerImplApi21 = this.g.get();
            if (mediaControllerCompat$MediaControllerImplApi21 != null && bundle != null) {
                synchronized (mediaControllerCompat$MediaControllerImplApi21.b) {
                    mediaControllerCompat$MediaControllerImplApi21.e.h = x.a.f1(bundle.getBinder("android.support.v4.media.session.EXTRA_BINDER"));
                    MediaSessionCompat.Token token = mediaControllerCompat$MediaControllerImplApi21.e;
                    bundle.getBundle("android.support.v4.media.session.SESSION_TOKEN2_BUNDLE");
                    Objects.requireNonNull(token);
                    mediaControllerCompat$MediaControllerImplApi21.a();
                }
            }
        }
    }

    public static class a extends y.b {
        public a(y yVar) {
            super(yVar);
        }

        @Override // defpackage.y.b, defpackage.w
        public void V(Bundle bundle) {
            throw new AssertionError();
        }

        @Override // defpackage.y.b, defpackage.w
        public void a0(List<MediaSessionCompat.QueueItem> list) {
            throw new AssertionError();
        }

        @Override // defpackage.y.b, defpackage.w
        public void e1(ParcelableVolumeInfo parcelableVolumeInfo) {
            throw new AssertionError();
        }

        @Override // defpackage.y.b, defpackage.w
        public void q(CharSequence charSequence) {
            throw new AssertionError();
        }

        @Override // defpackage.y.b, defpackage.w
        public void x() {
            throw new AssertionError();
        }

        @Override // defpackage.y.b, defpackage.w
        public void z(MediaMetadataCompat mediaMetadataCompat) {
            throw new AssertionError();
        }
    }

    public MediaControllerCompat$MediaControllerImplApi21(Context context, MediaSessionCompat.Token token) {
        this.e = token;
        MediaController mediaController = new MediaController(context, (MediaSession.Token) token.g);
        this.a = mediaController;
        if (token.h == null) {
            mediaController.sendCommand("android.support.v4.media.session.command.GET_EXTRA_BINDER", null, new ExtraBinderRequestResultReceiver(this));
        }
    }

    public void a() {
        if (this.e.h != null) {
            for (y yVar : this.c) {
                a aVar = new a(yVar);
                this.d.put(yVar, aVar);
                yVar.a = aVar;
                try {
                    this.e.h.t(aVar);
                } catch (RemoteException e2) {
                    Log.e("MediaControllerCompat", "Dead object in registerCallback.", e2);
                }
            }
            this.c.clear();
        }
    }
}
