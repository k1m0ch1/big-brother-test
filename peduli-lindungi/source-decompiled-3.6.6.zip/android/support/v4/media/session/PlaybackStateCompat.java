package android.support.v4.media.session;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.List;

public final class PlaybackStateCompat implements Parcelable {
    public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new a();
    public final int g;
    public final long h;
    public final long i;
    public final float j;
    public final long k;
    public final int l;
    public final CharSequence m;
    public final long n;
    public List<CustomAction> o;
    public final long p;
    public final Bundle q;

    public static class a implements Parcelable.Creator<PlaybackStateCompat> {
        /* Return type fixed from 'java.lang.Object' to match base method */
        @Override // android.os.Parcelable.Creator
        public PlaybackStateCompat createFromParcel(Parcel parcel) {
            return new PlaybackStateCompat(parcel);
        }

        /* Return type fixed from 'java.lang.Object[]' to match base method */
        @Override // android.os.Parcelable.Creator
        public PlaybackStateCompat[] newArray(int i) {
            return new PlaybackStateCompat[i];
        }
    }

    public PlaybackStateCompat(int i2, long j2, long j3, float f, long j4, int i3, CharSequence charSequence, long j5, List<CustomAction> list, long j6, Bundle bundle) {
        this.g = i2;
        this.h = j2;
        this.i = j3;
        this.j = f;
        this.k = j4;
        this.l = i3;
        this.m = charSequence;
        this.n = j5;
        this.o = new ArrayList(list);
        this.p = j6;
        this.q = bundle;
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        return "PlaybackState {" + "state=" + this.g + ", position=" + this.h + ", buffered position=" + this.i + ", speed=" + this.j + ", updated=" + this.n + ", actions=" + this.k + ", error code=" + this.l + ", error message=" + this.m + ", custom actions=" + this.o + ", active item id=" + this.p + "}";
    }

    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeInt(this.g);
        parcel.writeLong(this.h);
        parcel.writeFloat(this.j);
        parcel.writeLong(this.n);
        parcel.writeLong(this.i);
        parcel.writeLong(this.k);
        TextUtils.writeToParcel(this.m, parcel, i2);
        parcel.writeTypedList(this.o);
        parcel.writeLong(this.p);
        parcel.writeBundle(this.q);
        parcel.writeInt(this.l);
    }

    public static final class CustomAction implements Parcelable {
        public static final Parcelable.Creator<CustomAction> CREATOR = new a();
        public final String g;
        public final CharSequence h;
        public final int i;
        public final Bundle j;
        public Object k;

        public static class a implements Parcelable.Creator<CustomAction> {
            /* Return type fixed from 'java.lang.Object' to match base method */
            @Override // android.os.Parcelable.Creator
            public CustomAction createFromParcel(Parcel parcel) {
                return new CustomAction(parcel);
            }

            /* Return type fixed from 'java.lang.Object[]' to match base method */
            @Override // android.os.Parcelable.Creator
            public CustomAction[] newArray(int i) {
                return new CustomAction[i];
            }
        }

        public CustomAction(String str, CharSequence charSequence, int i2, Bundle bundle) {
            this.g = str;
            this.h = charSequence;
            this.i = i2;
            this.j = bundle;
        }

        public int describeContents() {
            return 0;
        }

        public String toString() {
            StringBuilder J0 = ze0.J0("Action:mName='");
            J0.append((Object) this.h);
            J0.append(", mIcon=");
            J0.append(this.i);
            J0.append(", mExtras=");
            J0.append(this.j);
            return J0.toString();
        }

        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeString(this.g);
            TextUtils.writeToParcel(this.h, parcel, i2);
            parcel.writeInt(this.i);
            parcel.writeBundle(this.j);
        }

        public CustomAction(Parcel parcel) {
            this.g = parcel.readString();
            this.h = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.i = parcel.readInt();
            this.j = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
        }
    }

    public PlaybackStateCompat(Parcel parcel) {
        this.g = parcel.readInt();
        this.h = parcel.readLong();
        this.j = parcel.readFloat();
        this.n = parcel.readLong();
        this.i = parcel.readLong();
        this.k = parcel.readLong();
        this.m = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.o = parcel.createTypedArrayList(CustomAction.CREATOR);
        this.p = parcel.readLong();
        this.q = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
        this.l = parcel.readInt();
    }
}
