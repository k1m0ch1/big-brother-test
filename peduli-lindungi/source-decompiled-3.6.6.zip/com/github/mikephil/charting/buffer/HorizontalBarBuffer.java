package com.github.mikephil.charting.buffer;

import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.utils.Utils;

public class HorizontalBarBuffer extends BarBuffer {
    public HorizontalBarBuffer(int i, int i2, boolean z) {
        super(i, i2, z);
    }

    @Override // com.github.mikephil.charting.buffer.BarBuffer
    public void feed(IBarDataSet iBarDataSet) {
        float f;
        float f2;
        float f3;
        float f4;
        float entryCount = ((float) iBarDataSet.getEntryCount()) * this.phaseX;
        float f5 = this.mBarWidth / 2.0f;
        for (int i = 0; ((float) i) < entryCount; i++) {
            BarEntry barEntry = (BarEntry) iBarDataSet.getEntryForIndex(i);
            if (barEntry != null) {
                float x = barEntry.getX();
                float y = barEntry.getY();
                float[] yVals = barEntry.getYVals();
                if (!this.mContainsStacks || yVals == null) {
                    float f6 = x - f5;
                    float f7 = x + f5;
                    if (this.mInverted) {
                        f = y >= Utils.FLOAT_EPSILON ? y : Utils.FLOAT_EPSILON;
                        if (y > Utils.FLOAT_EPSILON) {
                            y = Utils.FLOAT_EPSILON;
                        }
                    } else {
                        float f8 = y >= Utils.FLOAT_EPSILON ? y : Utils.FLOAT_EPSILON;
                        if (y > Utils.FLOAT_EPSILON) {
                            y = Utils.FLOAT_EPSILON;
                        }
                        y = f8;
                        f = y;
                    }
                    if (y > Utils.FLOAT_EPSILON) {
                        y *= this.phaseY;
                    } else {
                        f *= this.phaseY;
                    }
                    addBar(f, f7, y, f6);
                } else {
                    float f9 = -barEntry.getNegativeSum();
                    int i2 = 0;
                    float f10 = Utils.FLOAT_EPSILON;
                    while (i2 < yVals.length) {
                        float f11 = yVals[i2];
                        if (f11 >= Utils.FLOAT_EPSILON) {
                            f2 = f11 + f10;
                            f3 = f9;
                            f9 = f10;
                            f10 = f2;
                        } else {
                            f2 = Math.abs(f11) + f9;
                            f3 = Math.abs(f11) + f9;
                        }
                        float f12 = x - f5;
                        float f13 = x + f5;
                        if (this.mInverted) {
                            f4 = f9 >= f2 ? f9 : f2;
                            if (f9 > f2) {
                                f9 = f2;
                            }
                        } else {
                            float f14 = f9 >= f2 ? f9 : f2;
                            if (f9 > f2) {
                                f9 = f2;
                            }
                            f9 = f14;
                            f4 = f9;
                        }
                        float f15 = this.phaseY;
                        addBar(f4 * f15, f13, f9 * f15, f12);
                        i2++;
                        f9 = f3;
                    }
                }
            }
        }
        reset();
    }
}
