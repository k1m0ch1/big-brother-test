package com.github.mikephil.charting.charts;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.ChartData;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.interfaces.datasets.IDataSet;
import com.github.mikephil.charting.listener.ChartTouchListener;
import com.github.mikephil.charting.listener.PieRadarChartTouchListener;
import com.github.mikephil.charting.utils.MPPointF;
import com.github.mikephil.charting.utils.Utils;

public abstract class PieRadarChartBase<T extends ChartData<? extends IDataSet<? extends Entry>>> extends Chart<T> {
    public float mMinOffset = Utils.FLOAT_EPSILON;
    private float mRawRotationAngle = 270.0f;
    public boolean mRotateEnabled = true;
    private float mRotationAngle = 270.0f;

    /* renamed from: com.github.mikephil.charting.charts.PieRadarChartBase$2  reason: invalid class name */
    public static /* synthetic */ class AnonymousClass2 {
        public static final /* synthetic */ int[] $SwitchMap$com$github$mikephil$charting$components$Legend$LegendHorizontalAlignment;
        public static final /* synthetic */ int[] $SwitchMap$com$github$mikephil$charting$components$Legend$LegendOrientation;
        public static final /* synthetic */ int[] $SwitchMap$com$github$mikephil$charting$components$Legend$LegendVerticalAlignment;

        /* JADX WARNING: Can't wrap try/catch for region: R(17:0|(2:1|2)|3|(2:5|6)|7|9|10|11|12|13|14|15|17|18|19|20|22) */
        /* JADX WARNING: Can't wrap try/catch for region: R(18:0|(2:1|2)|3|5|6|7|9|10|11|12|13|14|15|17|18|19|20|22) */
        /* JADX WARNING: Can't wrap try/catch for region: R(19:0|1|2|3|5|6|7|9|10|11|12|13|14|15|17|18|19|20|22) */
        /* JADX WARNING: Code restructure failed: missing block: B:23:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:11:0x0020 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:13:0x0026 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:19:0x0037 */
        static {
            Legend.LegendOrientation.values();
            int[] iArr = new int[2];
            $SwitchMap$com$github$mikephil$charting$components$Legend$LegendOrientation = iArr;
            try {
                Legend.LegendOrientation legendOrientation = Legend.LegendOrientation.VERTICAL;
                iArr[1] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                int[] iArr2 = $SwitchMap$com$github$mikephil$charting$components$Legend$LegendOrientation;
                Legend.LegendOrientation legendOrientation2 = Legend.LegendOrientation.HORIZONTAL;
                iArr2[0] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            Legend.LegendHorizontalAlignment.values();
            int[] iArr3 = new int[3];
            $SwitchMap$com$github$mikephil$charting$components$Legend$LegendHorizontalAlignment = iArr3;
            Legend.LegendHorizontalAlignment legendHorizontalAlignment = Legend.LegendHorizontalAlignment.LEFT;
            iArr3[0] = 1;
            int[] iArr4 = $SwitchMap$com$github$mikephil$charting$components$Legend$LegendHorizontalAlignment;
            Legend.LegendHorizontalAlignment legendHorizontalAlignment2 = Legend.LegendHorizontalAlignment.RIGHT;
            iArr4[2] = 2;
            int[] iArr5 = $SwitchMap$com$github$mikephil$charting$components$Legend$LegendHorizontalAlignment;
            Legend.LegendHorizontalAlignment legendHorizontalAlignment3 = Legend.LegendHorizontalAlignment.CENTER;
            iArr5[1] = 3;
            Legend.LegendVerticalAlignment.values();
            int[] iArr6 = new int[3];
            $SwitchMap$com$github$mikephil$charting$components$Legend$LegendVerticalAlignment = iArr6;
            Legend.LegendVerticalAlignment legendVerticalAlignment = Legend.LegendVerticalAlignment.TOP;
            iArr6[0] = 1;
            int[] iArr7 = $SwitchMap$com$github$mikephil$charting$components$Legend$LegendVerticalAlignment;
            Legend.LegendVerticalAlignment legendVerticalAlignment2 = Legend.LegendVerticalAlignment.BOTTOM;
            iArr7[2] = 2;
        }
    }

    public PieRadarChartBase(Context context) {
        super(context);
    }

    @Override // com.github.mikephil.charting.charts.Chart
    public void calcMinMax() {
    }

    @Override // com.github.mikephil.charting.charts.Chart
    public void calculateOffsets() {
        float f;
        float f2;
        float f3;
        float f4;
        float f5;
        float f6;
        float f7;
        float f8;
        Legend legend = this.mLegend;
        float f9 = Utils.FLOAT_EPSILON;
        if (legend == null || !legend.isEnabled() || this.mLegend.isDrawInsideEnabled()) {
            f3 = Utils.FLOAT_EPSILON;
            f2 = Utils.FLOAT_EPSILON;
            f = Utils.FLOAT_EPSILON;
        } else {
            float min = Math.min(this.mLegend.mNeededWidth, this.mLegend.getMaxSizePercent() * this.mViewPortHandler.getChartWidth());
            int ordinal = this.mLegend.getOrientation().ordinal();
            if (ordinal != 0) {
                if (ordinal == 1) {
                    if (this.mLegend.getHorizontalAlignment() != Legend.LegendHorizontalAlignment.LEFT && this.mLegend.getHorizontalAlignment() != Legend.LegendHorizontalAlignment.RIGHT) {
                        f5 = Utils.FLOAT_EPSILON;
                    } else if (this.mLegend.getVerticalAlignment() == Legend.LegendVerticalAlignment.CENTER) {
                        f5 = Utils.convertDpToPixel(13.0f) + min;
                    } else {
                        f5 = Utils.convertDpToPixel(8.0f) + min;
                        Legend legend2 = this.mLegend;
                        float f10 = legend2.mNeededHeight + legend2.mTextHeightMax;
                        MPPointF center = getCenter();
                        float width = this.mLegend.getHorizontalAlignment() == Legend.LegendHorizontalAlignment.RIGHT ? (((float) getWidth()) - f5) + 15.0f : f5 - 15.0f;
                        float f11 = f10 + 15.0f;
                        float distanceToCenter = distanceToCenter(width, f11);
                        MPPointF position = getPosition(center, getRadius(), getAngleForPoint(width, f11));
                        float distanceToCenter2 = distanceToCenter(position.x, position.y);
                        float convertDpToPixel = Utils.convertDpToPixel(5.0f);
                        if (f11 < center.y || ((float) getHeight()) - f5 <= ((float) getWidth())) {
                            f5 = distanceToCenter < distanceToCenter2 ? (distanceToCenter2 - distanceToCenter) + convertDpToPixel : Utils.FLOAT_EPSILON;
                        }
                        MPPointF.recycleInstance(center);
                        MPPointF.recycleInstance(position);
                    }
                    int ordinal2 = this.mLegend.getHorizontalAlignment().ordinal();
                    if (ordinal2 == 0) {
                        f9 = f5;
                    } else if (ordinal2 == 1) {
                        int ordinal3 = this.mLegend.getVerticalAlignment().ordinal();
                        if (ordinal3 == 0) {
                            f7 = Math.min(this.mLegend.mNeededHeight, this.mLegend.getMaxSizePercent() * this.mViewPortHandler.getChartHeight());
                            f8 = Utils.FLOAT_EPSILON;
                            f5 = Utils.FLOAT_EPSILON;
                            f4 = f8;
                            f6 = f7;
                            f9 += getRequiredBaseOffset();
                            f2 = f5 + getRequiredBaseOffset();
                            f3 = f6 + getRequiredBaseOffset();
                            f = f4 + getRequiredBaseOffset();
                        } else if (ordinal3 == 2) {
                            f8 = Math.min(this.mLegend.mNeededHeight, this.mLegend.getMaxSizePercent() * this.mViewPortHandler.getChartHeight());
                            f5 = Utils.FLOAT_EPSILON;
                            f7 = Utils.FLOAT_EPSILON;
                            f4 = f8;
                            f6 = f7;
                            f9 += getRequiredBaseOffset();
                            f2 = f5 + getRequiredBaseOffset();
                            f3 = f6 + getRequiredBaseOffset();
                            f = f4 + getRequiredBaseOffset();
                        }
                    } else if (ordinal2 == 2) {
                        f8 = Utils.FLOAT_EPSILON;
                        f7 = Utils.FLOAT_EPSILON;
                        f4 = f8;
                        f6 = f7;
                        f9 += getRequiredBaseOffset();
                        f2 = f5 + getRequiredBaseOffset();
                        f3 = f6 + getRequiredBaseOffset();
                        f = f4 + getRequiredBaseOffset();
                    }
                    f8 = Utils.FLOAT_EPSILON;
                    f5 = Utils.FLOAT_EPSILON;
                    f7 = Utils.FLOAT_EPSILON;
                    f4 = f8;
                    f6 = f7;
                    f9 += getRequiredBaseOffset();
                    f2 = f5 + getRequiredBaseOffset();
                    f3 = f6 + getRequiredBaseOffset();
                    f = f4 + getRequiredBaseOffset();
                }
            } else if (this.mLegend.getVerticalAlignment() == Legend.LegendVerticalAlignment.TOP || this.mLegend.getVerticalAlignment() == Legend.LegendVerticalAlignment.BOTTOM) {
                f6 = Math.min(this.mLegend.mNeededHeight + getRequiredLegendOffset(), this.mLegend.getMaxSizePercent() * this.mViewPortHandler.getChartHeight());
                int ordinal4 = this.mLegend.getVerticalAlignment().ordinal();
                if (ordinal4 != 0) {
                    if (ordinal4 == 2) {
                        f4 = f6;
                        f6 = Utils.FLOAT_EPSILON;
                        f5 = Utils.FLOAT_EPSILON;
                        f9 += getRequiredBaseOffset();
                        f2 = f5 + getRequiredBaseOffset();
                        f3 = f6 + getRequiredBaseOffset();
                        f = f4 + getRequiredBaseOffset();
                    }
                }
                f5 = Utils.FLOAT_EPSILON;
                f4 = Utils.FLOAT_EPSILON;
                f9 += getRequiredBaseOffset();
                f2 = f5 + getRequiredBaseOffset();
                f3 = f6 + getRequiredBaseOffset();
                f = f4 + getRequiredBaseOffset();
            }
            f6 = Utils.FLOAT_EPSILON;
            f5 = Utils.FLOAT_EPSILON;
            f4 = Utils.FLOAT_EPSILON;
            f9 += getRequiredBaseOffset();
            f2 = f5 + getRequiredBaseOffset();
            f3 = f6 + getRequiredBaseOffset();
            f = f4 + getRequiredBaseOffset();
        }
        float convertDpToPixel2 = Utils.convertDpToPixel(this.mMinOffset);
        if (this instanceof RadarChart) {
            XAxis xAxis = getXAxis();
            if (xAxis.isEnabled() && xAxis.isDrawLabelsEnabled()) {
                convertDpToPixel2 = Math.max(convertDpToPixel2, (float) xAxis.mLabelRotatedWidth);
            }
        }
        float extraTopOffset = getExtraTopOffset() + f3;
        float extraRightOffset = getExtraRightOffset() + f2;
        float extraBottomOffset = getExtraBottomOffset() + f;
        float max = Math.max(convertDpToPixel2, getExtraLeftOffset() + f9);
        float max2 = Math.max(convertDpToPixel2, extraTopOffset);
        float max3 = Math.max(convertDpToPixel2, extraRightOffset);
        float max4 = Math.max(convertDpToPixel2, Math.max(getRequiredBaseOffset(), extraBottomOffset));
        this.mViewPortHandler.restrainViewPort(max, max2, max3, max4);
        if (this.mLogEnabled) {
            Log.i(Chart.LOG_TAG, "offsetLeft: " + max + ", offsetTop: " + max2 + ", offsetRight: " + max3 + ", offsetBottom: " + max4);
        }
    }

    public void computeScroll() {
        ChartTouchListener chartTouchListener = this.mChartTouchListener;
        if (chartTouchListener instanceof PieRadarChartTouchListener) {
            ((PieRadarChartTouchListener) chartTouchListener).computeScroll();
        }
    }

    public float distanceToCenter(float f, float f2) {
        MPPointF centerOffsets = getCenterOffsets();
        float f3 = centerOffsets.x;
        float f4 = f > f3 ? f - f3 : f3 - f;
        float f5 = centerOffsets.y;
        float sqrt = (float) Math.sqrt(Math.pow((double) (f2 > f5 ? f2 - f5 : f5 - f2), 2.0d) + Math.pow((double) f4, 2.0d));
        MPPointF.recycleInstance(centerOffsets);
        return sqrt;
    }

    public float getAngleForPoint(float f, float f2) {
        MPPointF centerOffsets = getCenterOffsets();
        double d = (double) (f - centerOffsets.x);
        double d2 = (double) (f2 - centerOffsets.y);
        float degrees = (float) Math.toDegrees(Math.acos(d2 / Math.sqrt((d2 * d2) + (d * d))));
        if (f > centerOffsets.x) {
            degrees = 360.0f - degrees;
        }
        float f3 = degrees + 90.0f;
        if (f3 > 360.0f) {
            f3 -= 360.0f;
        }
        MPPointF.recycleInstance(centerOffsets);
        return f3;
    }

    public float getDiameter() {
        RectF contentRect = this.mViewPortHandler.getContentRect();
        contentRect.left = getExtraLeftOffset() + contentRect.left;
        contentRect.top = getExtraTopOffset() + contentRect.top;
        contentRect.right -= getExtraRightOffset();
        contentRect.bottom -= getExtraBottomOffset();
        return Math.min(contentRect.width(), contentRect.height());
    }

    public abstract int getIndexForAngle(float f);

    @Override // com.github.mikephil.charting.interfaces.dataprovider.ChartInterface
    public int getMaxVisibleCount() {
        return this.mData.getEntryCount();
    }

    public float getMinOffset() {
        return this.mMinOffset;
    }

    public MPPointF getPosition(MPPointF mPPointF, float f, float f2) {
        MPPointF instance = MPPointF.getInstance(Utils.FLOAT_EPSILON, Utils.FLOAT_EPSILON);
        getPosition(mPPointF, f, f2, instance);
        return instance;
    }

    public abstract float getRadius();

    public float getRawRotationAngle() {
        return this.mRawRotationAngle;
    }

    public abstract float getRequiredBaseOffset();

    public abstract float getRequiredLegendOffset();

    public float getRotationAngle() {
        return this.mRotationAngle;
    }

    @Override // com.github.mikephil.charting.interfaces.dataprovider.ChartInterface
    public float getYChartMax() {
        return Utils.FLOAT_EPSILON;
    }

    @Override // com.github.mikephil.charting.interfaces.dataprovider.ChartInterface
    public float getYChartMin() {
        return Utils.FLOAT_EPSILON;
    }

    @Override // com.github.mikephil.charting.charts.Chart
    public void init() {
        super.init();
        this.mChartTouchListener = new PieRadarChartTouchListener(this);
    }

    public boolean isRotationEnabled() {
        return this.mRotateEnabled;
    }

    @Override // com.github.mikephil.charting.charts.Chart
    public void notifyDataSetChanged() {
        if (this.mData != null) {
            calcMinMax();
            if (this.mLegend != null) {
                this.mLegendRenderer.computeLegend(this.mData);
            }
            calculateOffsets();
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        ChartTouchListener chartTouchListener;
        if (!this.mTouchEnabled || (chartTouchListener = this.mChartTouchListener) == null) {
            return super.onTouchEvent(motionEvent);
        }
        return chartTouchListener.onTouch(this, motionEvent);
    }

    public void setMinOffset(float f) {
        this.mMinOffset = f;
    }

    public void setRotationAngle(float f) {
        this.mRawRotationAngle = f;
        this.mRotationAngle = Utils.getNormalizedAngle(f);
    }

    public void setRotationEnabled(boolean z) {
        this.mRotateEnabled = z;
    }

    @SuppressLint({"NewApi"})
    public void spin(int i, float f, float f2, Easing.EasingFunction easingFunction) {
        setRotationAngle(f);
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this, "rotationAngle", f, f2);
        ofFloat.setDuration((long) i);
        ofFloat.setInterpolator(easingFunction);
        ofFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            /* class com.github.mikephil.charting.charts.PieRadarChartBase.AnonymousClass1 */

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                PieRadarChartBase.this.postInvalidate();
            }
        });
        ofFloat.start();
    }

    public void getPosition(MPPointF mPPointF, float f, float f2, MPPointF mPPointF2) {
        double d = (double) f;
        double d2 = (double) f2;
        mPPointF2.x = (float) ((Math.cos(Math.toRadians(d2)) * d) + ((double) mPPointF.x));
        mPPointF2.y = (float) ((Math.sin(Math.toRadians(d2)) * d) + ((double) mPPointF.y));
    }

    public PieRadarChartBase(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public PieRadarChartBase(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }
}
