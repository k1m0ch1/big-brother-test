package com.github.mikephil.charting.data;

import com.github.mikephil.charting.charts.ScatterChart;
import com.github.mikephil.charting.interfaces.datasets.IScatterDataSet;
import com.github.mikephil.charting.renderer.scatter.ChevronDownShapeRenderer;
import com.github.mikephil.charting.renderer.scatter.ChevronUpShapeRenderer;
import com.github.mikephil.charting.renderer.scatter.CircleShapeRenderer;
import com.github.mikephil.charting.renderer.scatter.CrossShapeRenderer;
import com.github.mikephil.charting.renderer.scatter.IShapeRenderer;
import com.github.mikephil.charting.renderer.scatter.SquareShapeRenderer;
import com.github.mikephil.charting.renderer.scatter.TriangleShapeRenderer;
import com.github.mikephil.charting.renderer.scatter.XShapeRenderer;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.github.mikephil.charting.utils.Utils;
import java.util.ArrayList;
import java.util.List;

public class ScatterDataSet extends LineScatterCandleRadarDataSet<Entry> implements IScatterDataSet {
    private int mScatterShapeHoleColor = ColorTemplate.COLOR_NONE;
    private float mScatterShapeHoleRadius = Utils.FLOAT_EPSILON;
    public IShapeRenderer mShapeRenderer = new SquareShapeRenderer();
    private float mShapeSize = 15.0f;

    /* renamed from: com.github.mikephil.charting.data.ScatterDataSet$1  reason: invalid class name */
    public static /* synthetic */ class AnonymousClass1 {
        public static final /* synthetic */ int[] $SwitchMap$com$github$mikephil$charting$charts$ScatterChart$ScatterShape;

        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:23:0x0031 */
        static {
            ScatterChart.ScatterShape.values();
            int[] iArr = new int[7];
            $SwitchMap$com$github$mikephil$charting$charts$ScatterChart$ScatterShape = iArr;
            try {
                ScatterChart.ScatterShape scatterShape = ScatterChart.ScatterShape.SQUARE;
                iArr[0] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                int[] iArr2 = $SwitchMap$com$github$mikephil$charting$charts$ScatterChart$ScatterShape;
                ScatterChart.ScatterShape scatterShape2 = ScatterChart.ScatterShape.CIRCLE;
                iArr2[1] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                int[] iArr3 = $SwitchMap$com$github$mikephil$charting$charts$ScatterChart$ScatterShape;
                ScatterChart.ScatterShape scatterShape3 = ScatterChart.ScatterShape.TRIANGLE;
                iArr3[2] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                int[] iArr4 = $SwitchMap$com$github$mikephil$charting$charts$ScatterChart$ScatterShape;
                ScatterChart.ScatterShape scatterShape4 = ScatterChart.ScatterShape.CROSS;
                iArr4[3] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                int[] iArr5 = $SwitchMap$com$github$mikephil$charting$charts$ScatterChart$ScatterShape;
                ScatterChart.ScatterShape scatterShape5 = ScatterChart.ScatterShape.X;
                iArr5[4] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            int[] iArr6 = $SwitchMap$com$github$mikephil$charting$charts$ScatterChart$ScatterShape;
            ScatterChart.ScatterShape scatterShape6 = ScatterChart.ScatterShape.CHEVRON_UP;
            iArr6[5] = 6;
            try {
                int[] iArr7 = $SwitchMap$com$github$mikephil$charting$charts$ScatterChart$ScatterShape;
                ScatterChart.ScatterShape scatterShape7 = ScatterChart.ScatterShape.CHEVRON_DOWN;
                iArr7[6] = 7;
            } catch (NoSuchFieldError unused6) {
            }
        }
    }

    public ScatterDataSet(List<Entry> list, String str) {
        super(list, str);
    }

    public static IShapeRenderer getRendererForShape(ScatterChart.ScatterShape scatterShape) {
        switch (scatterShape.ordinal()) {
            case 0:
                return new SquareShapeRenderer();
            case 1:
                return new CircleShapeRenderer();
            case 2:
                return new TriangleShapeRenderer();
            case 3:
                return new CrossShapeRenderer();
            case 4:
                return new XShapeRenderer();
            case 5:
                return new ChevronUpShapeRenderer();
            case 6:
                return new ChevronDownShapeRenderer();
            default:
                return null;
        }
    }

    @Override // com.github.mikephil.charting.data.DataSet
    public DataSet<Entry> copy() {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < this.mValues.size(); i++) {
            arrayList.add(this.mValues.get(i).copy());
        }
        ScatterDataSet scatterDataSet = new ScatterDataSet(arrayList, getLabel());
        copy(scatterDataSet);
        return scatterDataSet;
    }

    @Override // com.github.mikephil.charting.interfaces.datasets.IScatterDataSet
    public int getScatterShapeHoleColor() {
        return this.mScatterShapeHoleColor;
    }

    @Override // com.github.mikephil.charting.interfaces.datasets.IScatterDataSet
    public float getScatterShapeHoleRadius() {
        return this.mScatterShapeHoleRadius;
    }

    @Override // com.github.mikephil.charting.interfaces.datasets.IScatterDataSet
    public float getScatterShapeSize() {
        return this.mShapeSize;
    }

    @Override // com.github.mikephil.charting.interfaces.datasets.IScatterDataSet
    public IShapeRenderer getShapeRenderer() {
        return this.mShapeRenderer;
    }

    public void setScatterShape(ScatterChart.ScatterShape scatterShape) {
        this.mShapeRenderer = getRendererForShape(scatterShape);
    }

    public void setScatterShapeHoleColor(int i) {
        this.mScatterShapeHoleColor = i;
    }

    public void setScatterShapeHoleRadius(float f) {
        this.mScatterShapeHoleRadius = f;
    }

    public void setScatterShapeSize(float f) {
        this.mShapeSize = f;
    }

    public void setShapeRenderer(IShapeRenderer iShapeRenderer) {
        this.mShapeRenderer = iShapeRenderer;
    }

    public void copy(ScatterDataSet scatterDataSet) {
        super.copy((LineScatterCandleRadarDataSet) scatterDataSet);
        scatterDataSet.mShapeSize = this.mShapeSize;
        scatterDataSet.mShapeRenderer = this.mShapeRenderer;
        scatterDataSet.mScatterShapeHoleRadius = this.mScatterShapeHoleRadius;
        scatterDataSet.mScatterShapeHoleColor = this.mScatterShapeHoleColor;
    }
}
