package com.github.mikephil.charting.renderer;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import com.github.mikephil.charting.animation.ChartAnimator;
import com.github.mikephil.charting.buffer.BarBuffer;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.highlight.Range;
import com.github.mikephil.charting.interfaces.dataprovider.BarDataProvider;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.model.GradientColor;
import com.github.mikephil.charting.utils.MPPointF;
import com.github.mikephil.charting.utils.Transformer;
import com.github.mikephil.charting.utils.Utils;
import com.github.mikephil.charting.utils.ViewPortHandler;
import com.google.maps.android.R;
import java.util.List;

public class BarChartRenderer extends BarLineScatterCandleBubbleRenderer {
    public Paint mBarBorderPaint;
    public BarBuffer[] mBarBuffers;
    public RectF mBarRect = new RectF();
    private RectF mBarShadowRectBuffer = new RectF();
    public BarDataProvider mChart;
    public Paint mShadowPaint;

    public BarChartRenderer(BarDataProvider barDataProvider, ChartAnimator chartAnimator, ViewPortHandler viewPortHandler) {
        super(chartAnimator, viewPortHandler);
        this.mChart = barDataProvider;
        Paint paint = new Paint(1);
        this.mHighlightPaint = paint;
        paint.setStyle(Paint.Style.FILL);
        this.mHighlightPaint.setColor(Color.rgb(0, 0, 0));
        this.mHighlightPaint.setAlpha(R.styleable.AppCompatTheme_windowFixedWidthMajor);
        Paint paint2 = new Paint(1);
        this.mShadowPaint = paint2;
        paint2.setStyle(Paint.Style.FILL);
        Paint paint3 = new Paint(1);
        this.mBarBorderPaint = paint3;
        paint3.setStyle(Paint.Style.STROKE);
    }

    @Override // com.github.mikephil.charting.renderer.DataRenderer
    public void drawData(Canvas canvas) {
        BarData barData = this.mChart.getBarData();
        for (int i = 0; i < barData.getDataSetCount(); i++) {
            IBarDataSet iBarDataSet = (IBarDataSet) barData.getDataSetByIndex(i);
            if (iBarDataSet.isVisible()) {
                drawDataSet(canvas, iBarDataSet, i);
            }
        }
    }

    public void drawDataSet(Canvas canvas, IBarDataSet iBarDataSet, int i) {
        Transformer transformer = this.mChart.getTransformer(iBarDataSet.getAxisDependency());
        this.mBarBorderPaint.setColor(iBarDataSet.getBarBorderColor());
        this.mBarBorderPaint.setStrokeWidth(Utils.convertDpToPixel(iBarDataSet.getBarBorderWidth()));
        boolean z = true;
        boolean z2 = iBarDataSet.getBarBorderWidth() > Utils.FLOAT_EPSILON;
        float phaseX = this.mAnimator.getPhaseX();
        float phaseY = this.mAnimator.getPhaseY();
        if (this.mChart.isDrawBarShadowEnabled()) {
            this.mShadowPaint.setColor(iBarDataSet.getBarShadowColor());
            float barWidth = this.mChart.getBarData().getBarWidth() / 2.0f;
            int min = Math.min((int) Math.ceil((double) (((float) iBarDataSet.getEntryCount()) * phaseX)), iBarDataSet.getEntryCount());
            for (int i2 = 0; i2 < min; i2++) {
                float x = ((BarEntry) iBarDataSet.getEntryForIndex(i2)).getX();
                RectF rectF = this.mBarShadowRectBuffer;
                rectF.left = x - barWidth;
                rectF.right = x + barWidth;
                transformer.rectValueToPixel(rectF);
                if (this.mViewPortHandler.isInBoundsLeft(this.mBarShadowRectBuffer.right)) {
                    if (!this.mViewPortHandler.isInBoundsRight(this.mBarShadowRectBuffer.left)) {
                        break;
                    }
                    this.mBarShadowRectBuffer.top = this.mViewPortHandler.contentTop();
                    this.mBarShadowRectBuffer.bottom = this.mViewPortHandler.contentBottom();
                    canvas.drawRect(this.mBarShadowRectBuffer, this.mShadowPaint);
                }
            }
        }
        BarBuffer barBuffer = this.mBarBuffers[i];
        barBuffer.setPhases(phaseX, phaseY);
        barBuffer.setDataSet(i);
        barBuffer.setInverted(this.mChart.isInverted(iBarDataSet.getAxisDependency()));
        barBuffer.setBarWidth(this.mChart.getBarData().getBarWidth());
        barBuffer.feed(iBarDataSet);
        transformer.pointValuesToPixel(barBuffer.buffer);
        if (iBarDataSet.getColors().size() != 1) {
            z = false;
        }
        if (z) {
            this.mRenderPaint.setColor(iBarDataSet.getColor());
        }
        for (int i3 = 0; i3 < barBuffer.size(); i3 += 4) {
            int i4 = i3 + 2;
            if (this.mViewPortHandler.isInBoundsLeft(barBuffer.buffer[i4])) {
                if (this.mViewPortHandler.isInBoundsRight(barBuffer.buffer[i3])) {
                    if (!z) {
                        this.mRenderPaint.setColor(iBarDataSet.getColor(i3 / 4));
                    }
                    if (iBarDataSet.getGradientColor() != null) {
                        GradientColor gradientColor = iBarDataSet.getGradientColor();
                        Paint paint = this.mRenderPaint;
                        float[] fArr = barBuffer.buffer;
                        paint.setShader(new LinearGradient(fArr[i3], fArr[i3 + 3], fArr[i3], fArr[i3 + 1], gradientColor.getStartColor(), gradientColor.getEndColor(), Shader.TileMode.MIRROR));
                    }
                    if (iBarDataSet.getGradientColors() != null) {
                        Paint paint2 = this.mRenderPaint;
                        float[] fArr2 = barBuffer.buffer;
                        float f = fArr2[i3];
                        float f2 = fArr2[i3 + 3];
                        float f3 = fArr2[i3];
                        float f4 = fArr2[i3 + 1];
                        int i5 = i3 / 4;
                        paint2.setShader(new LinearGradient(f, f2, f3, f4, iBarDataSet.getGradientColor(i5).getStartColor(), iBarDataSet.getGradientColor(i5).getEndColor(), Shader.TileMode.MIRROR));
                    }
                    float[] fArr3 = barBuffer.buffer;
                    int i6 = i3 + 1;
                    int i7 = i3 + 3;
                    canvas.drawRect(fArr3[i3], fArr3[i6], fArr3[i4], fArr3[i7], this.mRenderPaint);
                    if (z2) {
                        float[] fArr4 = barBuffer.buffer;
                        canvas.drawRect(fArr4[i3], fArr4[i6], fArr4[i4], fArr4[i7], this.mBarBorderPaint);
                    }
                } else {
                    return;
                }
            }
        }
    }

    @Override // com.github.mikephil.charting.renderer.DataRenderer
    public void drawExtras(Canvas canvas) {
    }

    @Override // com.github.mikephil.charting.renderer.DataRenderer
    public void drawHighlighted(Canvas canvas, Highlight[] highlightArr) {
        float f;
        float f2;
        BarData barData = this.mChart.getBarData();
        for (Highlight highlight : highlightArr) {
            IBarDataSet iBarDataSet = (IBarDataSet) barData.getDataSetByIndex(highlight.getDataSetIndex());
            if (iBarDataSet != null && iBarDataSet.isHighlightEnabled()) {
                BarEntry barEntry = (BarEntry) iBarDataSet.getEntryForXValue(highlight.getX(), highlight.getY());
                if (isInBoundsX(barEntry, iBarDataSet)) {
                    Transformer transformer = this.mChart.getTransformer(iBarDataSet.getAxisDependency());
                    this.mHighlightPaint.setColor(iBarDataSet.getHighLightColor());
                    this.mHighlightPaint.setAlpha(iBarDataSet.getHighLightAlpha());
                    if (!(highlight.getStackIndex() >= 0 && barEntry.isStacked())) {
                        f2 = barEntry.getY();
                        f = Utils.FLOAT_EPSILON;
                    } else if (this.mChart.isHighlightFullBarEnabled()) {
                        float positiveSum = barEntry.getPositiveSum();
                        f = -barEntry.getNegativeSum();
                        f2 = positiveSum;
                    } else {
                        Range range = barEntry.getRanges()[highlight.getStackIndex()];
                        f2 = range.from;
                        f = range.to;
                    }
                    prepareBarHighlight(barEntry.getX(), f2, f, barData.getBarWidth() / 2.0f, transformer);
                    setHighlightDrawPos(highlight, this.mBarRect);
                    canvas.drawRect(this.mBarRect, this.mHighlightPaint);
                }
            }
        }
    }

    @Override // com.github.mikephil.charting.renderer.DataRenderer
    public void drawValue(Canvas canvas, String str, float f, float f2, int i) {
        this.mValuePaint.setColor(i);
        canvas.drawText(str, f, f2, this.mValuePaint);
    }

    @Override // com.github.mikephil.charting.renderer.DataRenderer
    public void drawValues(Canvas canvas) {
        float f;
        List list;
        boolean z;
        MPPointF mPPointF;
        int i;
        float f2;
        boolean z2;
        Transformer transformer;
        float[] fArr;
        float f3;
        int i2;
        int i3;
        BarEntry barEntry;
        float[] fArr2;
        float f4;
        float f5;
        float f6;
        BarEntry barEntry2;
        List list2;
        int i4;
        ValueFormatter valueFormatter;
        MPPointF mPPointF2;
        float f7;
        BarEntry barEntry3;
        if (isDrawingValuesAllowed(this.mChart)) {
            List dataSets = this.mChart.getBarData().getDataSets();
            float convertDpToPixel = Utils.convertDpToPixel(4.5f);
            boolean isDrawValueAboveBarEnabled = this.mChart.isDrawValueAboveBarEnabled();
            int i5 = 0;
            while (i5 < this.mChart.getBarData().getDataSetCount()) {
                IBarDataSet iBarDataSet = (IBarDataSet) dataSets.get(i5);
                if (!shouldDrawValues(iBarDataSet)) {
                    list = dataSets;
                    f = convertDpToPixel;
                    z = isDrawValueAboveBarEnabled;
                } else {
                    applyValueTextStyle(iBarDataSet);
                    boolean isInverted = this.mChart.isInverted(iBarDataSet.getAxisDependency());
                    float calcTextHeight = (float) Utils.calcTextHeight(this.mValuePaint, "8");
                    float f8 = isDrawValueAboveBarEnabled ? -convertDpToPixel : calcTextHeight + convertDpToPixel;
                    float f9 = isDrawValueAboveBarEnabled ? calcTextHeight + convertDpToPixel : -convertDpToPixel;
                    if (isInverted) {
                        f8 = (-f8) - calcTextHeight;
                        f9 = (-f9) - calcTextHeight;
                    }
                    BarBuffer barBuffer = this.mBarBuffers[i5];
                    float phaseY = this.mAnimator.getPhaseY();
                    ValueFormatter valueFormatter2 = iBarDataSet.getValueFormatter();
                    MPPointF instance = MPPointF.getInstance(iBarDataSet.getIconsOffset());
                    instance.x = Utils.convertDpToPixel(instance.x);
                    instance.y = Utils.convertDpToPixel(instance.y);
                    if (iBarDataSet.isStacked()) {
                        list = dataSets;
                        mPPointF = instance;
                        Transformer transformer2 = this.mChart.getTransformer(iBarDataSet.getAxisDependency());
                        int i6 = 0;
                        int i7 = 0;
                        while (true) {
                            if (((float) i6) >= this.mAnimator.getPhaseX() * ((float) iBarDataSet.getEntryCount())) {
                                break;
                            }
                            BarEntry barEntry4 = (BarEntry) iBarDataSet.getEntryForIndex(i6);
                            float[] yVals = barEntry4.getYVals();
                            float[] fArr3 = barBuffer.buffer;
                            float f10 = (fArr3[i7] + fArr3[i7 + 2]) / 2.0f;
                            int valueTextColor = iBarDataSet.getValueTextColor(i6);
                            if (yVals != null) {
                                BarEntry barEntry5 = barEntry4;
                                i = i6;
                                f2 = convertDpToPixel;
                                z2 = isDrawValueAboveBarEnabled;
                                fArr = yVals;
                                transformer = transformer2;
                                float f11 = f10;
                                int length = fArr.length * 2;
                                float[] fArr4 = new float[length];
                                float f12 = -barEntry5.getNegativeSum();
                                int i8 = 0;
                                int i9 = 0;
                                float f13 = Utils.FLOAT_EPSILON;
                                while (i8 < length) {
                                    float f14 = fArr[i9];
                                    int i10 = (f14 > Utils.FLOAT_EPSILON ? 1 : (f14 == Utils.FLOAT_EPSILON ? 0 : -1));
                                    if (i10 == 0 && (f13 == Utils.FLOAT_EPSILON || f12 == Utils.FLOAT_EPSILON)) {
                                        f12 = f14;
                                        f5 = f12;
                                    } else if (i10 >= 0) {
                                        f13 += f14;
                                        f5 = f12;
                                        f12 = f13;
                                    } else {
                                        f5 = f12 - f14;
                                    }
                                    fArr4[i8 + 1] = f12 * phaseY;
                                    i8 += 2;
                                    i9++;
                                    f12 = f5;
                                }
                                transformer.pointValuesToPixel(fArr4);
                                int i11 = 0;
                                while (i11 < length) {
                                    float f15 = fArr[i11 / 2];
                                    float f16 = fArr4[i11 + 1] + (((f15 > Utils.FLOAT_EPSILON ? 1 : (f15 == Utils.FLOAT_EPSILON ? 0 : -1)) == 0 && (f12 > Utils.FLOAT_EPSILON ? 1 : (f12 == Utils.FLOAT_EPSILON ? 0 : -1)) == 0 && (f13 > Utils.FLOAT_EPSILON ? 1 : (f13 == Utils.FLOAT_EPSILON ? 0 : -1)) > 0) || (f15 > Utils.FLOAT_EPSILON ? 1 : (f15 == Utils.FLOAT_EPSILON ? 0 : -1)) < 0 ? f9 : f8);
                                    if (!this.mViewPortHandler.isInBoundsRight(f11)) {
                                        break;
                                    }
                                    if (!this.mViewPortHandler.isInBoundsY(f16) || !this.mViewPortHandler.isInBoundsLeft(f11)) {
                                        i2 = length;
                                        f3 = f11;
                                        i3 = i11;
                                        barEntry = barEntry5;
                                        fArr2 = fArr4;
                                    } else {
                                        if (iBarDataSet.isDrawValuesEnabled()) {
                                            String barStackedLabel = valueFormatter2.getBarStackedLabel(f15, barEntry5);
                                            f4 = f16;
                                            i3 = i11;
                                            barEntry = barEntry5;
                                            fArr2 = fArr4;
                                            i2 = length;
                                            f3 = f11;
                                            drawValue(canvas, barStackedLabel, f11, f4, valueTextColor);
                                        } else {
                                            f4 = f16;
                                            i2 = length;
                                            f3 = f11;
                                            i3 = i11;
                                            barEntry = barEntry5;
                                            fArr2 = fArr4;
                                        }
                                        if (barEntry.getIcon() != null && iBarDataSet.isDrawIconsEnabled()) {
                                            Drawable icon = barEntry.getIcon();
                                            Utils.drawImage(canvas, icon, (int) (f3 + mPPointF.x), (int) (f4 + mPPointF.y), icon.getIntrinsicWidth(), icon.getIntrinsicHeight());
                                        }
                                    }
                                    i11 = i3 + 2;
                                    fArr4 = fArr2;
                                    barEntry5 = barEntry;
                                    length = i2;
                                    f11 = f3;
                                }
                            } else if (!this.mViewPortHandler.isInBoundsRight(f10)) {
                                break;
                            } else {
                                int i12 = i7 + 1;
                                if (!this.mViewPortHandler.isInBoundsY(barBuffer.buffer[i12]) || !this.mViewPortHandler.isInBoundsLeft(f10)) {
                                    transformer2 = transformer2;
                                    isDrawValueAboveBarEnabled = isDrawValueAboveBarEnabled;
                                    convertDpToPixel = convertDpToPixel;
                                    i6 = i6;
                                } else {
                                    if (iBarDataSet.isDrawValuesEnabled()) {
                                        f6 = f10;
                                        f2 = convertDpToPixel;
                                        fArr = yVals;
                                        barEntry2 = barEntry4;
                                        i = i6;
                                        z2 = isDrawValueAboveBarEnabled;
                                        transformer = transformer2;
                                        drawValue(canvas, valueFormatter2.getBarLabel(barEntry4), f6, barBuffer.buffer[i12] + (barEntry4.getY() >= Utils.FLOAT_EPSILON ? f8 : f9), valueTextColor);
                                    } else {
                                        f6 = f10;
                                        i = i6;
                                        f2 = convertDpToPixel;
                                        z2 = isDrawValueAboveBarEnabled;
                                        fArr = yVals;
                                        barEntry2 = barEntry4;
                                        transformer = transformer2;
                                    }
                                    if (barEntry2.getIcon() != null && iBarDataSet.isDrawIconsEnabled()) {
                                        Drawable icon2 = barEntry2.getIcon();
                                        Utils.drawImage(canvas, icon2, (int) (mPPointF.x + f6), (int) (barBuffer.buffer[i12] + (barEntry2.getY() >= Utils.FLOAT_EPSILON ? f8 : f9) + mPPointF.y), icon2.getIntrinsicWidth(), icon2.getIntrinsicHeight());
                                    }
                                }
                            }
                            if (fArr == null) {
                                i7 += 4;
                            } else {
                                i7 = (fArr.length * 4) + i7;
                            }
                            i6 = i + 1;
                            transformer2 = transformer;
                            isDrawValueAboveBarEnabled = z2;
                            convertDpToPixel = f2;
                        }
                    } else {
                        int i13 = 0;
                        while (true) {
                            if (((float) i13) >= this.mAnimator.getPhaseX() * ((float) barBuffer.buffer.length)) {
                                break;
                            }
                            float[] fArr5 = barBuffer.buffer;
                            float f17 = (fArr5[i13] + fArr5[i13 + 2]) / 2.0f;
                            if (!this.mViewPortHandler.isInBoundsRight(f17)) {
                                break;
                            }
                            int i14 = i13 + 1;
                            if (!this.mViewPortHandler.isInBoundsY(barBuffer.buffer[i14]) || !this.mViewPortHandler.isInBoundsLeft(f17)) {
                                i4 = i13;
                                valueFormatter = valueFormatter2;
                                list2 = dataSets;
                                mPPointF2 = instance;
                            } else {
                                int i15 = i13 / 4;
                                BarEntry barEntry6 = (BarEntry) iBarDataSet.getEntryForIndex(i15);
                                float y = barEntry6.getY();
                                if (iBarDataSet.isDrawValuesEnabled()) {
                                    String barLabel = valueFormatter2.getBarLabel(barEntry6);
                                    int i16 = (y > Utils.FLOAT_EPSILON ? 1 : (y == Utils.FLOAT_EPSILON ? 0 : -1));
                                    float[] fArr6 = barBuffer.buffer;
                                    float f18 = i16 >= 0 ? fArr6[i14] + f8 : fArr6[i13 + 3] + f9;
                                    barEntry3 = barEntry6;
                                    f7 = f17;
                                    i4 = i13;
                                    list2 = dataSets;
                                    mPPointF2 = instance;
                                    valueFormatter = valueFormatter2;
                                    drawValue(canvas, barLabel, f7, f18, iBarDataSet.getValueTextColor(i15));
                                } else {
                                    barEntry3 = barEntry6;
                                    f7 = f17;
                                    i4 = i13;
                                    valueFormatter = valueFormatter2;
                                    list2 = dataSets;
                                    mPPointF2 = instance;
                                }
                                if (barEntry3.getIcon() != null && iBarDataSet.isDrawIconsEnabled()) {
                                    Drawable icon3 = barEntry3.getIcon();
                                    Utils.drawImage(canvas, icon3, (int) (f7 + mPPointF2.x), (int) ((y >= Utils.FLOAT_EPSILON ? barBuffer.buffer[i14] + f8 : barBuffer.buffer[i4 + 3] + f9) + mPPointF2.y), icon3.getIntrinsicWidth(), icon3.getIntrinsicHeight());
                                }
                            }
                            i13 = i4 + 4;
                            instance = mPPointF2;
                            valueFormatter2 = valueFormatter;
                            dataSets = list2;
                        }
                        list = dataSets;
                        mPPointF = instance;
                    }
                    f = convertDpToPixel;
                    z = isDrawValueAboveBarEnabled;
                    MPPointF.recycleInstance(mPPointF);
                }
                i5++;
                isDrawValueAboveBarEnabled = z;
                dataSets = list;
                convertDpToPixel = f;
            }
        }
    }

    @Override // com.github.mikephil.charting.renderer.DataRenderer
    public void initBuffers() {
        BarData barData = this.mChart.getBarData();
        this.mBarBuffers = new BarBuffer[barData.getDataSetCount()];
        for (int i = 0; i < this.mBarBuffers.length; i++) {
            IBarDataSet iBarDataSet = (IBarDataSet) barData.getDataSetByIndex(i);
            this.mBarBuffers[i] = new BarBuffer(iBarDataSet.getEntryCount() * 4 * (iBarDataSet.isStacked() ? iBarDataSet.getStackSize() : 1), barData.getDataSetCount(), iBarDataSet.isStacked());
        }
    }

    public void prepareBarHighlight(float f, float f2, float f3, float f4, Transformer transformer) {
        this.mBarRect.set(f - f4, f2, f + f4, f3);
        transformer.rectToPixelPhase(this.mBarRect, this.mAnimator.getPhaseY());
    }

    public void setHighlightDrawPos(Highlight highlight, RectF rectF) {
        highlight.setDraw(rectF.centerX(), rectF.top);
    }
}
