package com.github.mikephil.charting.renderer;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import com.github.mikephil.charting.animation.ChartAnimator;
import com.github.mikephil.charting.buffer.BarBuffer;
import com.github.mikephil.charting.buffer.HorizontalBarBuffer;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.interfaces.dataprovider.BarDataProvider;
import com.github.mikephil.charting.interfaces.dataprovider.ChartInterface;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.utils.MPPointF;
import com.github.mikephil.charting.utils.Transformer;
import com.github.mikephil.charting.utils.Utils;
import com.github.mikephil.charting.utils.ViewPortHandler;
import java.util.List;

public class HorizontalBarChartRenderer extends BarChartRenderer {
    private RectF mBarShadowRectBuffer = new RectF();

    public HorizontalBarChartRenderer(BarDataProvider barDataProvider, ChartAnimator chartAnimator, ViewPortHandler viewPortHandler) {
        super(barDataProvider, chartAnimator, viewPortHandler);
        this.mValuePaint.setTextAlign(Paint.Align.LEFT);
    }

    @Override // com.github.mikephil.charting.renderer.BarChartRenderer
    public void drawDataSet(Canvas canvas, IBarDataSet iBarDataSet, int i) {
        Transformer transformer = this.mChart.getTransformer(iBarDataSet.getAxisDependency());
        this.mBarBorderPaint.setColor(iBarDataSet.getBarBorderColor());
        this.mBarBorderPaint.setStrokeWidth(Utils.convertDpToPixel(iBarDataSet.getBarBorderWidth()));
        boolean z = true;
        boolean z2 = iBarDataSet.getBarBorderWidth() > Utils.FLOAT_EPSILON;
        float phaseX = this.mAnimator.getPhaseX();
        float phaseY = this.mAnimator.getPhaseY();
        if (this.mChart.isDrawBarShadowEnabled()) {
            this.mShadowPaint.setColor(iBarDataSet.getBarShadowColor());
            float barWidth = this.mChart.getBarData().getBarWidth() / 2.0f;
            int min = Math.min((int) Math.ceil((double) (((float) iBarDataSet.getEntryCount()) * phaseX)), iBarDataSet.getEntryCount());
            for (int i2 = 0; i2 < min; i2++) {
                float x = ((BarEntry) iBarDataSet.getEntryForIndex(i2)).getX();
                RectF rectF = this.mBarShadowRectBuffer;
                rectF.top = x - barWidth;
                rectF.bottom = x + barWidth;
                transformer.rectValueToPixel(rectF);
                if (this.mViewPortHandler.isInBoundsTop(this.mBarShadowRectBuffer.bottom)) {
                    if (!this.mViewPortHandler.isInBoundsBottom(this.mBarShadowRectBuffer.top)) {
                        break;
                    }
                    this.mBarShadowRectBuffer.left = this.mViewPortHandler.contentLeft();
                    this.mBarShadowRectBuffer.right = this.mViewPortHandler.contentRight();
                    canvas.drawRect(this.mBarShadowRectBuffer, this.mShadowPaint);
                }
            }
        }
        BarBuffer barBuffer = this.mBarBuffers[i];
        barBuffer.setPhases(phaseX, phaseY);
        barBuffer.setDataSet(i);
        barBuffer.setInverted(this.mChart.isInverted(iBarDataSet.getAxisDependency()));
        barBuffer.setBarWidth(this.mChart.getBarData().getBarWidth());
        barBuffer.feed(iBarDataSet);
        transformer.pointValuesToPixel(barBuffer.buffer);
        if (iBarDataSet.getColors().size() != 1) {
            z = false;
        }
        if (z) {
            this.mRenderPaint.setColor(iBarDataSet.getColor());
        }
        for (int i3 = 0; i3 < barBuffer.size(); i3 += 4) {
            int i4 = i3 + 3;
            if (this.mViewPortHandler.isInBoundsTop(barBuffer.buffer[i4])) {
                int i5 = i3 + 1;
                if (this.mViewPortHandler.isInBoundsBottom(barBuffer.buffer[i5])) {
                    if (!z) {
                        this.mRenderPaint.setColor(iBarDataSet.getColor(i3 / 4));
                    }
                    float[] fArr = barBuffer.buffer;
                    int i6 = i3 + 2;
                    canvas.drawRect(fArr[i3], fArr[i5], fArr[i6], fArr[i4], this.mRenderPaint);
                    if (z2) {
                        float[] fArr2 = barBuffer.buffer;
                        canvas.drawRect(fArr2[i3], fArr2[i5], fArr2[i6], fArr2[i4], this.mBarBorderPaint);
                    }
                }
            } else {
                return;
            }
        }
    }

    @Override // com.github.mikephil.charting.renderer.DataRenderer, com.github.mikephil.charting.renderer.BarChartRenderer
    public void drawValue(Canvas canvas, String str, float f, float f2, int i) {
        this.mValuePaint.setColor(i);
        canvas.drawText(str, f, f2, this.mValuePaint);
    }

    /* JADX WARNING: Removed duplicated region for block: B:141:0x03b7  */
    /* JADX WARNING: Removed duplicated region for block: B:142:0x03ba  */
    @Override // com.github.mikephil.charting.renderer.DataRenderer, com.github.mikephil.charting.renderer.BarChartRenderer
    public void drawValues(Canvas canvas) {
        int i;
        List list;
        MPPointF mPPointF;
        int i2;
        float[] fArr;
        float[] fArr2;
        int i3;
        float f;
        float f2;
        float f3;
        BarEntry barEntry;
        int i4;
        float f4;
        int i5;
        List list2;
        ValueFormatter valueFormatter;
        BarBuffer barBuffer;
        MPPointF mPPointF2;
        if (isDrawingValuesAllowed(this.mChart)) {
            List dataSets = this.mChart.getBarData().getDataSets();
            float convertDpToPixel = Utils.convertDpToPixel(5.0f);
            boolean isDrawValueAboveBarEnabled = this.mChart.isDrawValueAboveBarEnabled();
            int i6 = 0;
            while (i6 < this.mChart.getBarData().getDataSetCount()) {
                IBarDataSet iBarDataSet = (IBarDataSet) dataSets.get(i6);
                if (!shouldDrawValues(iBarDataSet)) {
                    list = dataSets;
                    i = i6;
                } else {
                    boolean isInverted = this.mChart.isInverted(iBarDataSet.getAxisDependency());
                    applyValueTextStyle(iBarDataSet);
                    float f5 = 2.0f;
                    float calcTextHeight = ((float) Utils.calcTextHeight(this.mValuePaint, "10")) / 2.0f;
                    ValueFormatter valueFormatter2 = iBarDataSet.getValueFormatter();
                    BarBuffer barBuffer2 = this.mBarBuffers[i6];
                    float phaseY = this.mAnimator.getPhaseY();
                    MPPointF instance = MPPointF.getInstance(iBarDataSet.getIconsOffset());
                    instance.x = Utils.convertDpToPixel(instance.x);
                    instance.y = Utils.convertDpToPixel(instance.y);
                    if (iBarDataSet.isStacked()) {
                        list = dataSets;
                        i = i6;
                        mPPointF = instance;
                        Transformer transformer = this.mChart.getTransformer(iBarDataSet.getAxisDependency());
                        int i7 = 0;
                        int i8 = 0;
                        while (true) {
                            if (((float) i7) >= this.mAnimator.getPhaseX() * ((float) iBarDataSet.getEntryCount())) {
                                break;
                            }
                            BarEntry barEntry2 = (BarEntry) iBarDataSet.getEntryForIndex(i7);
                            int valueTextColor = iBarDataSet.getValueTextColor(i7);
                            float[] yVals = barEntry2.getYVals();
                            if (yVals == null) {
                                int i9 = i8 + 1;
                                if (!this.mViewPortHandler.isInBoundsTop(barBuffer2.buffer[i9])) {
                                    break;
                                } else if (this.mViewPortHandler.isInBoundsX(barBuffer2.buffer[i8]) && this.mViewPortHandler.isInBoundsBottom(barBuffer2.buffer[i9])) {
                                    String barLabel = valueFormatter2.getBarLabel(barEntry2);
                                    float calcTextWidth = (float) Utils.calcTextWidth(this.mValuePaint, barLabel);
                                    float f6 = isDrawValueAboveBarEnabled ? convertDpToPixel : -(calcTextWidth + convertDpToPixel);
                                    float f7 = isDrawValueAboveBarEnabled ? -(calcTextWidth + convertDpToPixel) : convertDpToPixel;
                                    if (isInverted) {
                                        f6 = (-f6) - calcTextWidth;
                                        f7 = (-f7) - calcTextWidth;
                                    }
                                    float f8 = f6;
                                    if (iBarDataSet.isDrawValuesEnabled()) {
                                        i2 = i7;
                                        fArr = yVals;
                                        barEntry = barEntry2;
                                        drawValue(canvas, barLabel, barBuffer2.buffer[i8 + 2] + (barEntry2.getY() >= Utils.FLOAT_EPSILON ? f8 : f7), barBuffer2.buffer[i9] + calcTextHeight, valueTextColor);
                                    } else {
                                        barEntry = barEntry2;
                                        i2 = i7;
                                        fArr = yVals;
                                    }
                                    if (barEntry.getIcon() != null && iBarDataSet.isDrawIconsEnabled()) {
                                        Drawable icon = barEntry.getIcon();
                                        float f9 = barBuffer2.buffer[i8 + 2];
                                        if (barEntry.getY() < Utils.FLOAT_EPSILON) {
                                            f8 = f7;
                                        }
                                        Utils.drawImage(canvas, icon, (int) (f9 + f8 + mPPointF.x), (int) (barBuffer2.buffer[i9] + mPPointF.y), icon.getIntrinsicWidth(), icon.getIntrinsicHeight());
                                    }
                                }
                            } else {
                                i2 = i7;
                                fArr = yVals;
                                int length = fArr.length * 2;
                                float[] fArr3 = new float[length];
                                float f10 = -barEntry2.getNegativeSum();
                                int i10 = 0;
                                int i11 = 0;
                                float f11 = Utils.FLOAT_EPSILON;
                                while (i10 < length) {
                                    float f12 = fArr[i11];
                                    int i12 = (f12 > Utils.FLOAT_EPSILON ? 1 : (f12 == Utils.FLOAT_EPSILON ? 0 : -1));
                                    if (i12 == 0 && (f11 == Utils.FLOAT_EPSILON || f10 == Utils.FLOAT_EPSILON)) {
                                        f10 = f12;
                                        f3 = f10;
                                    } else if (i12 >= 0) {
                                        f11 += f12;
                                        f3 = f10;
                                        f10 = f11;
                                    } else {
                                        f3 = f10 - f12;
                                    }
                                    fArr3[i10] = f10 * phaseY;
                                    i10 += 2;
                                    i11++;
                                    f10 = f3;
                                }
                                transformer.pointValuesToPixel(fArr3);
                                int i13 = 0;
                                while (true) {
                                    if (i13 >= length) {
                                        break;
                                    }
                                    float f13 = fArr[i13 / 2];
                                    String barStackedLabel = valueFormatter2.getBarStackedLabel(f13, barEntry2);
                                    float calcTextWidth2 = (float) Utils.calcTextWidth(this.mValuePaint, barStackedLabel);
                                    float f14 = isDrawValueAboveBarEnabled ? convertDpToPixel : -(calcTextWidth2 + convertDpToPixel);
                                    float f15 = isDrawValueAboveBarEnabled ? -(calcTextWidth2 + convertDpToPixel) : convertDpToPixel;
                                    if (isInverted) {
                                        f14 = (-f14) - calcTextWidth2;
                                        f15 = (-f15) - calcTextWidth2;
                                    }
                                    boolean z = (f13 == Utils.FLOAT_EPSILON && f10 == Utils.FLOAT_EPSILON && f11 > Utils.FLOAT_EPSILON) || f13 < Utils.FLOAT_EPSILON;
                                    float f16 = fArr3[i13];
                                    if (z) {
                                        f14 = f15;
                                    }
                                    float f17 = f16 + f14;
                                    float[] fArr4 = barBuffer2.buffer;
                                    float f18 = (fArr4[i8 + 1] + fArr4[i8 + 3]) / 2.0f;
                                    if (!this.mViewPortHandler.isInBoundsTop(f18)) {
                                        break;
                                    }
                                    if (this.mViewPortHandler.isInBoundsX(f17) && this.mViewPortHandler.isInBoundsBottom(f18)) {
                                        if (iBarDataSet.isDrawValuesEnabled()) {
                                            f = f18;
                                            i3 = i13;
                                            fArr2 = fArr3;
                                            f2 = f17;
                                            drawValue(canvas, barStackedLabel, f17, f18 + calcTextHeight, valueTextColor);
                                        } else {
                                            f = f18;
                                            i3 = i13;
                                            fArr2 = fArr3;
                                            f2 = f17;
                                        }
                                        if (barEntry2.getIcon() != null && iBarDataSet.isDrawIconsEnabled()) {
                                            Drawable icon2 = barEntry2.getIcon();
                                            Utils.drawImage(canvas, icon2, (int) (f2 + mPPointF.x), (int) (f + mPPointF.y), icon2.getIntrinsicWidth(), icon2.getIntrinsicHeight());
                                        }
                                    } else {
                                        i3 = i13;
                                        fArr2 = fArr3;
                                    }
                                    i13 = i3 + 2;
                                    length = length;
                                    fArr3 = fArr2;
                                }
                                if (fArr != null) {
                                    i8 += 4;
                                } else {
                                    i8 = (fArr.length * 4) + i8;
                                }
                                i7 = i2 + 1;
                            }
                            if (fArr != null) {
                            }
                            i7 = i2 + 1;
                        }
                    } else {
                        int i14 = 0;
                        while (true) {
                            if (((float) i14) >= this.mAnimator.getPhaseX() * ((float) barBuffer2.buffer.length)) {
                                break;
                            }
                            float[] fArr5 = barBuffer2.buffer;
                            int i15 = i14 + 1;
                            float f19 = (fArr5[i15] + fArr5[i14 + 3]) / f5;
                            if (!this.mViewPortHandler.isInBoundsTop(fArr5[i15])) {
                                break;
                            }
                            if (this.mViewPortHandler.isInBoundsX(barBuffer2.buffer[i14]) && this.mViewPortHandler.isInBoundsBottom(barBuffer2.buffer[i15])) {
                                BarEntry barEntry3 = (BarEntry) iBarDataSet.getEntryForIndex(i14 / 4);
                                float y = barEntry3.getY();
                                String barLabel2 = valueFormatter2.getBarLabel(barEntry3);
                                float calcTextWidth3 = (float) Utils.calcTextWidth(this.mValuePaint, barLabel2);
                                float f20 = isDrawValueAboveBarEnabled ? convertDpToPixel : -(calcTextWidth3 + convertDpToPixel);
                                float f21 = isDrawValueAboveBarEnabled ? -(calcTextWidth3 + convertDpToPixel) : convertDpToPixel;
                                if (isInverted) {
                                    f20 = (-f20) - calcTextWidth3;
                                    f21 = (-f21) - calcTextWidth3;
                                }
                                float f22 = f20;
                                if (iBarDataSet.isDrawValuesEnabled()) {
                                    i4 = i14;
                                    list2 = dataSets;
                                    mPPointF2 = instance;
                                    i5 = i6;
                                    barBuffer = barBuffer2;
                                    f4 = calcTextHeight;
                                    valueFormatter = valueFormatter2;
                                    drawValue(canvas, barLabel2, barBuffer2.buffer[i14 + 2] + (y >= Utils.FLOAT_EPSILON ? f22 : f21), f19 + calcTextHeight, iBarDataSet.getValueTextColor(i14 / 2));
                                } else {
                                    i4 = i14;
                                    list2 = dataSets;
                                    f4 = calcTextHeight;
                                    mPPointF2 = instance;
                                    valueFormatter = valueFormatter2;
                                    i5 = i6;
                                    barBuffer = barBuffer2;
                                }
                                if (barEntry3.getIcon() != null && iBarDataSet.isDrawIconsEnabled()) {
                                    Drawable icon3 = barEntry3.getIcon();
                                    float f23 = barBuffer.buffer[i4 + 2];
                                    if (y < Utils.FLOAT_EPSILON) {
                                        f22 = f21;
                                    }
                                    Utils.drawImage(canvas, icon3, (int) (f23 + f22 + mPPointF2.x), (int) (f19 + mPPointF2.y), icon3.getIntrinsicWidth(), icon3.getIntrinsicHeight());
                                }
                            } else {
                                i4 = i14;
                                list2 = dataSets;
                                i5 = i6;
                                f4 = calcTextHeight;
                                mPPointF2 = instance;
                                barBuffer = barBuffer2;
                                valueFormatter = valueFormatter2;
                            }
                            i14 = i4 + 4;
                            instance = mPPointF2;
                            barBuffer2 = barBuffer;
                            valueFormatter2 = valueFormatter;
                            dataSets = list2;
                            i6 = i5;
                            calcTextHeight = f4;
                            f5 = 2.0f;
                        }
                        list = dataSets;
                        i = i6;
                        mPPointF = instance;
                    }
                    MPPointF.recycleInstance(mPPointF);
                }
                i6 = i + 1;
                dataSets = list;
            }
        }
    }

    @Override // com.github.mikephil.charting.renderer.DataRenderer, com.github.mikephil.charting.renderer.BarChartRenderer
    public void initBuffers() {
        BarData barData = this.mChart.getBarData();
        this.mBarBuffers = new HorizontalBarBuffer[barData.getDataSetCount()];
        for (int i = 0; i < this.mBarBuffers.length; i++) {
            IBarDataSet iBarDataSet = (IBarDataSet) barData.getDataSetByIndex(i);
            this.mBarBuffers[i] = new HorizontalBarBuffer(iBarDataSet.getEntryCount() * 4 * (iBarDataSet.isStacked() ? iBarDataSet.getStackSize() : 1), barData.getDataSetCount(), iBarDataSet.isStacked());
        }
    }

    @Override // com.github.mikephil.charting.renderer.DataRenderer
    public boolean isDrawingValuesAllowed(ChartInterface chartInterface) {
        return ((float) chartInterface.getData().getEntryCount()) < this.mViewPortHandler.getScaleY() * ((float) chartInterface.getMaxVisibleCount());
    }

    @Override // com.github.mikephil.charting.renderer.BarChartRenderer
    public void prepareBarHighlight(float f, float f2, float f3, float f4, Transformer transformer) {
        this.mBarRect.set(f2, f - f4, f3, f + f4);
        transformer.rectToPixelPhaseHorizontal(this.mBarRect, this.mAnimator.getPhaseY());
    }

    @Override // com.github.mikephil.charting.renderer.BarChartRenderer
    public void setHighlightDrawPos(Highlight highlight, RectF rectF) {
        highlight.setDraw(rectF.centerY(), rectF.right);
    }
}
