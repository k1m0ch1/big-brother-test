package com.github.mikephil.charting.renderer;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import com.github.mikephil.charting.animation.ChartAnimator;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.interfaces.datasets.IPieDataSet;
import com.github.mikephil.charting.utils.MPPointF;
import com.github.mikephil.charting.utils.Utils;
import com.github.mikephil.charting.utils.ViewPortHandler;
import com.google.maps.android.R;
import java.lang.ref.WeakReference;
import java.util.List;

public class PieChartRenderer extends DataRenderer {
    public Canvas mBitmapCanvas;
    private RectF mCenterTextLastBounds = new RectF();
    private CharSequence mCenterTextLastValue;
    private StaticLayout mCenterTextLayout;
    private TextPaint mCenterTextPaint;
    public PieChart mChart;
    public WeakReference<Bitmap> mDrawBitmap;
    public Path mDrawCenterTextPathBuffer = new Path();
    public RectF mDrawHighlightedRectF = new RectF();
    private Paint mEntryLabelsPaint;
    private Path mHoleCirclePath = new Path();
    public Paint mHolePaint;
    private RectF mInnerRectBuffer = new RectF();
    private Path mPathBuffer = new Path();
    private RectF[] mRectBuffer = {new RectF(), new RectF(), new RectF()};
    public Paint mTransparentCirclePaint;
    public Paint mValueLinePaint;

    public PieChartRenderer(PieChart pieChart, ChartAnimator chartAnimator, ViewPortHandler viewPortHandler) {
        super(chartAnimator, viewPortHandler);
        this.mChart = pieChart;
        Paint paint = new Paint(1);
        this.mHolePaint = paint;
        paint.setColor(-1);
        this.mHolePaint.setStyle(Paint.Style.FILL);
        Paint paint2 = new Paint(1);
        this.mTransparentCirclePaint = paint2;
        paint2.setColor(-1);
        this.mTransparentCirclePaint.setStyle(Paint.Style.FILL);
        this.mTransparentCirclePaint.setAlpha(R.styleable.AppCompatTheme_textAppearanceSearchResultSubtitle);
        TextPaint textPaint = new TextPaint(1);
        this.mCenterTextPaint = textPaint;
        textPaint.setColor(-16777216);
        this.mCenterTextPaint.setTextSize(Utils.convertDpToPixel(12.0f));
        this.mValuePaint.setTextSize(Utils.convertDpToPixel(13.0f));
        this.mValuePaint.setColor(-1);
        this.mValuePaint.setTextAlign(Paint.Align.CENTER);
        Paint paint3 = new Paint(1);
        this.mEntryLabelsPaint = paint3;
        paint3.setColor(-1);
        this.mEntryLabelsPaint.setTextAlign(Paint.Align.CENTER);
        this.mEntryLabelsPaint.setTextSize(Utils.convertDpToPixel(13.0f));
        Paint paint4 = new Paint(1);
        this.mValueLinePaint = paint4;
        paint4.setStyle(Paint.Style.STROKE);
    }

    public float calculateMinimumRadiusForSpacedSlice(MPPointF mPPointF, float f, float f2, float f3, float f4, float f5, float f6) {
        double d = (double) ((f5 + f6) * 0.017453292f);
        float cos = (((float) Math.cos(d)) * f) + mPPointF.x;
        float sin = (((float) Math.sin(d)) * f) + mPPointF.y;
        double d2 = (double) (((f6 / 2.0f) + f5) * 0.017453292f);
        float cos2 = (((float) Math.cos(d2)) * f) + mPPointF.x;
        float sin2 = (((float) Math.sin(d2)) * f) + mPPointF.y;
        double pow = Math.pow((double) (cos - f3), 2.0d);
        return (float) (((double) (f - ((float) (Math.tan(((180.0d - ((double) f2)) / 2.0d) * 0.017453292519943295d) * (Math.sqrt(Math.pow((double) (sin - f4), 2.0d) + pow) / 2.0d))))) - Math.sqrt(Math.pow((double) (sin2 - ((sin + f4) / 2.0f)), 2.0d) + Math.pow((double) (cos2 - ((cos + f3) / 2.0f)), 2.0d)));
    }

    public void drawCenterText(Canvas canvas) {
        float f;
        MPPointF mPPointF;
        CharSequence centerText = this.mChart.getCenterText();
        if (this.mChart.isDrawCenterTextEnabled() && centerText != null) {
            MPPointF centerCircleBox = this.mChart.getCenterCircleBox();
            MPPointF centerTextOffset = this.mChart.getCenterTextOffset();
            float f2 = centerCircleBox.x + centerTextOffset.x;
            float f3 = centerCircleBox.y + centerTextOffset.y;
            if (!this.mChart.isDrawHoleEnabled() || this.mChart.isDrawSlicesUnderHoleEnabled()) {
                f = this.mChart.getRadius();
            } else {
                f = (this.mChart.getHoleRadius() / 100.0f) * this.mChart.getRadius();
            }
            RectF[] rectFArr = this.mRectBuffer;
            RectF rectF = rectFArr[0];
            rectF.left = f2 - f;
            rectF.top = f3 - f;
            rectF.right = f2 + f;
            rectF.bottom = f3 + f;
            RectF rectF2 = rectFArr[1];
            rectF2.set(rectF);
            float centerTextRadiusPercent = this.mChart.getCenterTextRadiusPercent() / 100.0f;
            if (((double) centerTextRadiusPercent) > Utils.DOUBLE_EPSILON) {
                rectF2.inset((rectF2.width() - (rectF2.width() * centerTextRadiusPercent)) / 2.0f, (rectF2.height() - (rectF2.height() * centerTextRadiusPercent)) / 2.0f);
            }
            if (!centerText.equals(this.mCenterTextLastValue) || !rectF2.equals(this.mCenterTextLastBounds)) {
                this.mCenterTextLastBounds.set(rectF2);
                this.mCenterTextLastValue = centerText;
                mPPointF = centerTextOffset;
                this.mCenterTextLayout = new StaticLayout(centerText, 0, centerText.length(), this.mCenterTextPaint, (int) Math.max(Math.ceil((double) this.mCenterTextLastBounds.width()), 1.0d), Layout.Alignment.ALIGN_CENTER, 1.0f, Utils.FLOAT_EPSILON, false);
            } else {
                mPPointF = centerTextOffset;
            }
            canvas.save();
            Path path = this.mDrawCenterTextPathBuffer;
            path.reset();
            path.addOval(rectF, Path.Direction.CW);
            canvas.clipPath(path);
            canvas.translate(rectF2.left, ((rectF2.height() - ((float) this.mCenterTextLayout.getHeight())) / 2.0f) + rectF2.top);
            this.mCenterTextLayout.draw(canvas);
            canvas.restore();
            MPPointF.recycleInstance(centerCircleBox);
            MPPointF.recycleInstance(mPPointF);
        }
    }

    @Override // com.github.mikephil.charting.renderer.DataRenderer
    public void drawData(Canvas canvas) {
        int chartWidth = (int) this.mViewPortHandler.getChartWidth();
        int chartHeight = (int) this.mViewPortHandler.getChartHeight();
        WeakReference<Bitmap> weakReference = this.mDrawBitmap;
        Bitmap bitmap = weakReference == null ? null : weakReference.get();
        if (!(bitmap != null && bitmap.getWidth() == chartWidth && bitmap.getHeight() == chartHeight)) {
            if (chartWidth > 0 && chartHeight > 0) {
                bitmap = Bitmap.createBitmap(chartWidth, chartHeight, Bitmap.Config.ARGB_4444);
                this.mDrawBitmap = new WeakReference<>(bitmap);
                this.mBitmapCanvas = new Canvas(bitmap);
            } else {
                return;
            }
        }
        bitmap.eraseColor(0);
        for (IPieDataSet iPieDataSet : ((PieData) this.mChart.getData()).getDataSets()) {
            if (iPieDataSet.isVisible() && iPieDataSet.getEntryCount() > 0) {
                drawDataSet(canvas, iPieDataSet);
            }
        }
    }

    public void drawDataSet(Canvas canvas, IPieDataSet iPieDataSet) {
        float f;
        RectF rectF;
        float f2;
        float f3;
        float[] fArr;
        int i;
        int i2;
        float f4;
        float f5;
        RectF rectF2;
        int i3;
        MPPointF mPPointF;
        int i4;
        float f6;
        float f7;
        RectF rectF3;
        float f8;
        float f9;
        MPPointF mPPointF2;
        int i5;
        PieChartRenderer pieChartRenderer = this;
        IPieDataSet iPieDataSet2 = iPieDataSet;
        float rotationAngle = pieChartRenderer.mChart.getRotationAngle();
        float phaseX = pieChartRenderer.mAnimator.getPhaseX();
        float phaseY = pieChartRenderer.mAnimator.getPhaseY();
        RectF circleBox = pieChartRenderer.mChart.getCircleBox();
        int entryCount = iPieDataSet.getEntryCount();
        float[] drawAngles = pieChartRenderer.mChart.getDrawAngles();
        MPPointF centerCircleBox = pieChartRenderer.mChart.getCenterCircleBox();
        float radius = pieChartRenderer.mChart.getRadius();
        boolean z = pieChartRenderer.mChart.isDrawHoleEnabled() && !pieChartRenderer.mChart.isDrawSlicesUnderHoleEnabled();
        float holeRadius = z ? (pieChartRenderer.mChart.getHoleRadius() / 100.0f) * radius : Utils.FLOAT_EPSILON;
        float holeRadius2 = (radius - ((pieChartRenderer.mChart.getHoleRadius() * radius) / 100.0f)) / 2.0f;
        RectF rectF4 = new RectF();
        boolean z2 = z && pieChartRenderer.mChart.isDrawRoundedSlicesEnabled();
        int i6 = 0;
        for (int i7 = 0; i7 < entryCount; i7++) {
            if (Math.abs(((PieEntry) iPieDataSet2.getEntryForIndex(i7)).getY()) > Utils.FLOAT_EPSILON) {
                i6++;
            }
        }
        if (i6 <= 1) {
            f = Utils.FLOAT_EPSILON;
        } else {
            f = pieChartRenderer.getSliceSpace(iPieDataSet2);
        }
        int i8 = 0;
        float f10 = Utils.FLOAT_EPSILON;
        while (i8 < entryCount) {
            float f11 = drawAngles[i8];
            float abs = Math.abs(iPieDataSet2.getEntryForIndex(i8).getY());
            float f12 = Utils.FLOAT_EPSILON;
            if (abs > f12 && (!pieChartRenderer.mChart.needsHighlight(i8) || z2)) {
                boolean z3 = f > Utils.FLOAT_EPSILON && f11 <= 180.0f;
                pieChartRenderer.mRenderPaint.setColor(iPieDataSet2.getColor(i8));
                float f13 = i6 == 1 ? Utils.FLOAT_EPSILON : f / (radius * 0.017453292f);
                float f14 = (((f13 / 2.0f) + f10) * phaseY) + rotationAngle;
                float f15 = (f11 - f13) * phaseY;
                if (f15 < Utils.FLOAT_EPSILON) {
                    f15 = Utils.FLOAT_EPSILON;
                }
                pieChartRenderer.mPathBuffer.reset();
                if (z2) {
                    float f16 = radius - holeRadius2;
                    i2 = i8;
                    i4 = i6;
                    double d = (double) (f14 * 0.017453292f);
                    i = entryCount;
                    fArr = drawAngles;
                    float cos = (((float) Math.cos(d)) * f16) + centerCircleBox.x;
                    float sin = (f16 * ((float) Math.sin(d))) + centerCircleBox.y;
                    rectF4.set(cos - holeRadius2, sin - holeRadius2, cos + holeRadius2, sin + holeRadius2);
                } else {
                    i2 = i8;
                    i4 = i6;
                    i = entryCount;
                    fArr = drawAngles;
                }
                double d2 = (double) (f14 * 0.017453292f);
                f4 = rotationAngle;
                f3 = phaseX;
                float cos2 = (((float) Math.cos(d2)) * radius) + centerCircleBox.x;
                float sin2 = (((float) Math.sin(d2)) * radius) + centerCircleBox.y;
                int i9 = (f15 > 360.0f ? 1 : (f15 == 360.0f ? 0 : -1));
                if (i9 < 0 || f15 % 360.0f > f12) {
                    if (z2) {
                        pieChartRenderer.mPathBuffer.arcTo(rectF4, f14 + 180.0f, -180.0f);
                    }
                    pieChartRenderer.mPathBuffer.arcTo(circleBox, f14, f15);
                } else {
                    pieChartRenderer.mPathBuffer.addCircle(centerCircleBox.x, centerCircleBox.y, radius, Path.Direction.CW);
                }
                RectF rectF5 = pieChartRenderer.mInnerRectBuffer;
                float f17 = centerCircleBox.x;
                float f18 = centerCircleBox.y;
                rectF5.set(f17 - holeRadius, f18 - holeRadius, f17 + holeRadius, f18 + holeRadius);
                if (!z) {
                    rectF2 = rectF4;
                    f5 = radius;
                    mPPointF = centerCircleBox;
                    rectF = circleBox;
                    i3 = i4;
                    f6 = f15;
                    f2 = holeRadius;
                    f7 = 360.0f;
                } else if (holeRadius > Utils.FLOAT_EPSILON || z3) {
                    if (z3) {
                        f8 = f15;
                        rectF = circleBox;
                        i3 = i4;
                        rectF3 = rectF4;
                        f9 = holeRadius;
                        i5 = 1;
                        f5 = radius;
                        mPPointF2 = centerCircleBox;
                        float calculateMinimumRadiusForSpacedSlice = calculateMinimumRadiusForSpacedSlice(centerCircleBox, radius, f11 * phaseY, cos2, sin2, f14, f8);
                        if (calculateMinimumRadiusForSpacedSlice < Utils.FLOAT_EPSILON) {
                            calculateMinimumRadiusForSpacedSlice = -calculateMinimumRadiusForSpacedSlice;
                        }
                        holeRadius = Math.max(f9, calculateMinimumRadiusForSpacedSlice);
                    } else {
                        rectF3 = rectF4;
                        f9 = holeRadius;
                        f5 = radius;
                        mPPointF2 = centerCircleBox;
                        rectF = circleBox;
                        i3 = i4;
                        f8 = f15;
                        i5 = 1;
                    }
                    float f19 = (i3 == i5 || holeRadius == Utils.FLOAT_EPSILON) ? Utils.FLOAT_EPSILON : f / (holeRadius * 0.017453292f);
                    float f20 = (((f19 / 2.0f) + f10) * phaseY) + f4;
                    float f21 = (f11 - f19) * phaseY;
                    if (f21 < Utils.FLOAT_EPSILON) {
                        f21 = Utils.FLOAT_EPSILON;
                    }
                    float f22 = f20 + f21;
                    if (i9 < 0 || f8 % 360.0f > f12) {
                        pieChartRenderer = this;
                        if (z2) {
                            float f23 = f5 - holeRadius2;
                            double d3 = (double) (f22 * 0.017453292f);
                            float cos3 = (((float) Math.cos(d3)) * f23) + mPPointF2.x;
                            float sin3 = (f23 * ((float) Math.sin(d3))) + mPPointF2.y;
                            rectF2 = rectF3;
                            rectF2.set(cos3 - holeRadius2, sin3 - holeRadius2, cos3 + holeRadius2, sin3 + holeRadius2);
                            pieChartRenderer.mPathBuffer.arcTo(rectF2, f22, 180.0f);
                            f2 = f9;
                        } else {
                            rectF2 = rectF3;
                            double d4 = (double) (f22 * 0.017453292f);
                            f2 = f9;
                            pieChartRenderer.mPathBuffer.lineTo((((float) Math.cos(d4)) * holeRadius) + mPPointF2.x, (holeRadius * ((float) Math.sin(d4))) + mPPointF2.y);
                        }
                        pieChartRenderer.mPathBuffer.arcTo(pieChartRenderer.mInnerRectBuffer, f22, -f21);
                    } else {
                        pieChartRenderer = this;
                        pieChartRenderer.mPathBuffer.addCircle(mPPointF2.x, mPPointF2.y, holeRadius, Path.Direction.CCW);
                        f2 = f9;
                        rectF2 = rectF3;
                    }
                    mPPointF = mPPointF2;
                    pieChartRenderer.mPathBuffer.close();
                    pieChartRenderer.mBitmapCanvas.drawPath(pieChartRenderer.mPathBuffer, pieChartRenderer.mRenderPaint);
                    f10 = (f11 * f3) + f10;
                } else {
                    rectF2 = rectF4;
                    f5 = radius;
                    mPPointF = centerCircleBox;
                    rectF = circleBox;
                    i3 = i4;
                    f6 = f15;
                    f7 = 360.0f;
                    f2 = holeRadius;
                }
                if (f6 % f7 > f12) {
                    if (z3) {
                        float calculateMinimumRadiusForSpacedSlice2 = calculateMinimumRadiusForSpacedSlice(mPPointF, f5, f11 * phaseY, cos2, sin2, f14, f6);
                        double d5 = (double) (((f6 / 2.0f) + f14) * 0.017453292f);
                        pieChartRenderer.mPathBuffer.lineTo((((float) Math.cos(d5)) * calculateMinimumRadiusForSpacedSlice2) + mPPointF.x, (calculateMinimumRadiusForSpacedSlice2 * ((float) Math.sin(d5))) + mPPointF.y);
                    } else {
                        pieChartRenderer.mPathBuffer.lineTo(mPPointF.x, mPPointF.y);
                    }
                }
                pieChartRenderer.mPathBuffer.close();
                pieChartRenderer.mBitmapCanvas.drawPath(pieChartRenderer.mPathBuffer, pieChartRenderer.mRenderPaint);
                f10 = (f11 * f3) + f10;
            } else {
                i2 = i8;
                f2 = holeRadius;
                f5 = radius;
                f4 = rotationAngle;
                f3 = phaseX;
                rectF = circleBox;
                i = entryCount;
                fArr = drawAngles;
                f10 = (f11 * phaseX) + f10;
                i3 = i6;
                rectF2 = rectF4;
                mPPointF = centerCircleBox;
            }
            i8 = i2 + 1;
            iPieDataSet2 = iPieDataSet;
            centerCircleBox = mPPointF;
            i6 = i3;
            rectF4 = rectF2;
            radius = f5;
            rotationAngle = f4;
            entryCount = i;
            drawAngles = fArr;
            phaseX = f3;
            holeRadius = f2;
            circleBox = rectF;
        }
        MPPointF.recycleInstance(centerCircleBox);
    }

    public void drawEntryLabel(Canvas canvas, String str, float f, float f2) {
        canvas.drawText(str, f, f2, this.mEntryLabelsPaint);
    }

    @Override // com.github.mikephil.charting.renderer.DataRenderer
    public void drawExtras(Canvas canvas) {
        drawHole(canvas);
        canvas.drawBitmap(this.mDrawBitmap.get(), Utils.FLOAT_EPSILON, Utils.FLOAT_EPSILON, (Paint) null);
        drawCenterText(canvas);
    }

    @Override // com.github.mikephil.charting.renderer.DataRenderer
    public void drawHighlighted(Canvas canvas, Highlight[] highlightArr) {
        boolean z;
        float[] fArr;
        float f;
        MPPointF mPPointF;
        float f2;
        int i;
        RectF rectF;
        float f3;
        IPieDataSet dataSetByIndex;
        float f4;
        int i2;
        float f5;
        int i3;
        float f6;
        float[] fArr2;
        float f7;
        float f8;
        Highlight[] highlightArr2 = highlightArr;
        boolean z2 = this.mChart.isDrawHoleEnabled() && !this.mChart.isDrawSlicesUnderHoleEnabled();
        if (!z2 || !this.mChart.isDrawRoundedSlicesEnabled()) {
            float phaseX = this.mAnimator.getPhaseX();
            float phaseY = this.mAnimator.getPhaseY();
            float rotationAngle = this.mChart.getRotationAngle();
            float[] drawAngles = this.mChart.getDrawAngles();
            float[] absoluteAngles = this.mChart.getAbsoluteAngles();
            MPPointF centerCircleBox = this.mChart.getCenterCircleBox();
            float radius = this.mChart.getRadius();
            float holeRadius = z2 ? (this.mChart.getHoleRadius() / 100.0f) * radius : Utils.FLOAT_EPSILON;
            RectF rectF2 = this.mDrawHighlightedRectF;
            rectF2.set(Utils.FLOAT_EPSILON, Utils.FLOAT_EPSILON, Utils.FLOAT_EPSILON, Utils.FLOAT_EPSILON);
            int i4 = 0;
            while (i4 < highlightArr2.length) {
                int x = (int) highlightArr2[i4].getX();
                if (x < drawAngles.length && (dataSetByIndex = ((PieData) this.mChart.getData()).getDataSetByIndex(highlightArr2[i4].getDataSetIndex())) != null && dataSetByIndex.isHighlightEnabled()) {
                    int entryCount = dataSetByIndex.getEntryCount();
                    int i5 = 0;
                    for (int i6 = 0; i6 < entryCount; i6++) {
                        if (Math.abs(((PieEntry) dataSetByIndex.getEntryForIndex(i6)).getY()) > Utils.FLOAT_EPSILON) {
                            i5++;
                        }
                    }
                    if (x == 0) {
                        i2 = 1;
                        f4 = Utils.FLOAT_EPSILON;
                    } else {
                        f4 = absoluteAngles[x - 1] * phaseX;
                        i2 = 1;
                    }
                    if (i5 <= i2) {
                        f5 = Utils.FLOAT_EPSILON;
                    } else {
                        f5 = dataSetByIndex.getSliceSpace();
                    }
                    float f9 = drawAngles[x];
                    float selectionShift = dataSetByIndex.getSelectionShift();
                    float f10 = radius + selectionShift;
                    rectF2.set(this.mChart.getCircleBox());
                    float f11 = -selectionShift;
                    rectF2.inset(f11, f11);
                    boolean z3 = f5 > Utils.FLOAT_EPSILON && f9 <= 180.0f;
                    this.mRenderPaint.setColor(dataSetByIndex.getColor(x));
                    float f12 = i5 == 1 ? Utils.FLOAT_EPSILON : f5 / (radius * 0.017453292f);
                    float f13 = i5 == 1 ? Utils.FLOAT_EPSILON : f5 / (f10 * 0.017453292f);
                    float f14 = (((f12 / 2.0f) + f4) * phaseY) + rotationAngle;
                    float f15 = (f9 - f12) * phaseY;
                    float f16 = f15 < Utils.FLOAT_EPSILON ? Utils.FLOAT_EPSILON : f15;
                    float f17 = (((f13 / 2.0f) + f4) * phaseY) + rotationAngle;
                    float f18 = (f9 - f13) * phaseY;
                    if (f18 < Utils.FLOAT_EPSILON) {
                        f18 = Utils.FLOAT_EPSILON;
                    }
                    this.mPathBuffer.reset();
                    int i7 = (f16 > 360.0f ? 1 : (f16 == 360.0f ? 0 : -1));
                    if (i7 < 0 || f16 % 360.0f > Utils.FLOAT_EPSILON) {
                        fArr2 = drawAngles;
                        f6 = f4;
                        double d = (double) (f17 * 0.017453292f);
                        i3 = i5;
                        z = z2;
                        this.mPathBuffer.moveTo((((float) Math.cos(d)) * f10) + centerCircleBox.x, (f10 * ((float) Math.sin(d))) + centerCircleBox.y);
                        this.mPathBuffer.arcTo(rectF2, f17, f18);
                    } else {
                        this.mPathBuffer.addCircle(centerCircleBox.x, centerCircleBox.y, f10, Path.Direction.CW);
                        fArr2 = drawAngles;
                        f6 = f4;
                        i3 = i5;
                        z = z2;
                    }
                    if (z3) {
                        double d2 = (double) (f14 * 0.017453292f);
                        i = i4;
                        rectF = rectF2;
                        f2 = holeRadius;
                        mPPointF = centerCircleBox;
                        fArr = fArr2;
                        f7 = calculateMinimumRadiusForSpacedSlice(centerCircleBox, radius, f9 * phaseY, (((float) Math.cos(d2)) * radius) + centerCircleBox.x, (((float) Math.sin(d2)) * radius) + centerCircleBox.y, f14, f16);
                    } else {
                        rectF = rectF2;
                        mPPointF = centerCircleBox;
                        i = i4;
                        f2 = holeRadius;
                        fArr = fArr2;
                        f7 = Utils.FLOAT_EPSILON;
                    }
                    RectF rectF3 = this.mInnerRectBuffer;
                    float f19 = mPPointF.x;
                    float f20 = mPPointF.y;
                    rectF3.set(f19 - f2, f20 - f2, f19 + f2, f20 + f2);
                    if (!z || (f2 <= Utils.FLOAT_EPSILON && !z3)) {
                        f3 = phaseX;
                        f = phaseY;
                        if (f16 % 360.0f > Utils.FLOAT_EPSILON) {
                            if (z3) {
                                double d3 = (double) (((f16 / 2.0f) + f14) * 0.017453292f);
                                this.mPathBuffer.lineTo((((float) Math.cos(d3)) * f7) + mPPointF.x, (f7 * ((float) Math.sin(d3))) + mPPointF.y);
                            } else {
                                this.mPathBuffer.lineTo(mPPointF.x, mPPointF.y);
                            }
                        }
                    } else {
                        if (z3) {
                            if (f7 < Utils.FLOAT_EPSILON) {
                                f7 = -f7;
                            }
                            f8 = Math.max(f2, f7);
                        } else {
                            f8 = f2;
                        }
                        float f21 = (i3 == 1 || f8 == Utils.FLOAT_EPSILON) ? Utils.FLOAT_EPSILON : f5 / (f8 * 0.017453292f);
                        float f22 = (((f21 / 2.0f) + f6) * phaseY) + rotationAngle;
                        float f23 = (f9 - f21) * phaseY;
                        if (f23 < Utils.FLOAT_EPSILON) {
                            f23 = Utils.FLOAT_EPSILON;
                        }
                        float f24 = f22 + f23;
                        if (i7 < 0 || f16 % 360.0f > Utils.FLOAT_EPSILON) {
                            double d4 = (double) (f24 * 0.017453292f);
                            f3 = phaseX;
                            f = phaseY;
                            this.mPathBuffer.lineTo((((float) Math.cos(d4)) * f8) + mPPointF.x, (f8 * ((float) Math.sin(d4))) + mPPointF.y);
                            this.mPathBuffer.arcTo(this.mInnerRectBuffer, f24, -f23);
                        } else {
                            this.mPathBuffer.addCircle(mPPointF.x, mPPointF.y, f8, Path.Direction.CCW);
                            f3 = phaseX;
                            f = phaseY;
                        }
                    }
                    this.mPathBuffer.close();
                    this.mBitmapCanvas.drawPath(this.mPathBuffer, this.mRenderPaint);
                } else {
                    i = i4;
                    rectF = rectF2;
                    f2 = holeRadius;
                    fArr = drawAngles;
                    z = z2;
                    f3 = phaseX;
                    f = phaseY;
                    mPPointF = centerCircleBox;
                }
                i4 = i + 1;
                phaseX = f3;
                rectF2 = rectF;
                holeRadius = f2;
                centerCircleBox = mPPointF;
                phaseY = f;
                drawAngles = fArr;
                z2 = z;
                highlightArr2 = highlightArr;
            }
            MPPointF.recycleInstance(centerCircleBox);
        }
    }

    public void drawHole(Canvas canvas) {
        if (this.mChart.isDrawHoleEnabled() && this.mBitmapCanvas != null) {
            float radius = this.mChart.getRadius();
            float holeRadius = (this.mChart.getHoleRadius() / 100.0f) * radius;
            MPPointF centerCircleBox = this.mChart.getCenterCircleBox();
            if (Color.alpha(this.mHolePaint.getColor()) > 0) {
                this.mBitmapCanvas.drawCircle(centerCircleBox.x, centerCircleBox.y, holeRadius, this.mHolePaint);
            }
            if (Color.alpha(this.mTransparentCirclePaint.getColor()) > 0 && this.mChart.getTransparentCircleRadius() > this.mChart.getHoleRadius()) {
                int alpha = this.mTransparentCirclePaint.getAlpha();
                float transparentCircleRadius = (this.mChart.getTransparentCircleRadius() / 100.0f) * radius;
                this.mTransparentCirclePaint.setAlpha((int) (this.mAnimator.getPhaseY() * this.mAnimator.getPhaseX() * ((float) alpha)));
                this.mHoleCirclePath.reset();
                this.mHoleCirclePath.addCircle(centerCircleBox.x, centerCircleBox.y, transparentCircleRadius, Path.Direction.CW);
                this.mHoleCirclePath.addCircle(centerCircleBox.x, centerCircleBox.y, holeRadius, Path.Direction.CCW);
                this.mBitmapCanvas.drawPath(this.mHoleCirclePath, this.mTransparentCirclePaint);
                this.mTransparentCirclePaint.setAlpha(alpha);
            }
            MPPointF.recycleInstance(centerCircleBox);
        }
    }

    public void drawRoundedSlices(Canvas canvas) {
        float f;
        float f2;
        float[] fArr;
        if (this.mChart.isDrawRoundedSlicesEnabled()) {
            IPieDataSet dataSet = ((PieData) this.mChart.getData()).getDataSet();
            if (dataSet.isVisible()) {
                float phaseX = this.mAnimator.getPhaseX();
                float phaseY = this.mAnimator.getPhaseY();
                MPPointF centerCircleBox = this.mChart.getCenterCircleBox();
                float radius = this.mChart.getRadius();
                float holeRadius = (radius - ((this.mChart.getHoleRadius() * radius) / 100.0f)) / 2.0f;
                float[] drawAngles = this.mChart.getDrawAngles();
                float rotationAngle = this.mChart.getRotationAngle();
                int i = 0;
                while (i < dataSet.getEntryCount()) {
                    float f3 = drawAngles[i];
                    if (Math.abs(dataSet.getEntryForIndex(i).getY()) > Utils.FLOAT_EPSILON) {
                        double d = (double) (radius - holeRadius);
                        double d2 = (double) ((rotationAngle + f3) * phaseY);
                        f = phaseY;
                        fArr = drawAngles;
                        f2 = rotationAngle;
                        double d3 = (double) centerCircleBox.x;
                        this.mRenderPaint.setColor(dataSet.getColor(i));
                        this.mBitmapCanvas.drawCircle((float) (d3 + (Math.cos(Math.toRadians(d2)) * d)), (float) ((Math.sin(Math.toRadians(d2)) * d) + ((double) centerCircleBox.y)), holeRadius, this.mRenderPaint);
                    } else {
                        f = phaseY;
                        fArr = drawAngles;
                        f2 = rotationAngle;
                    }
                    rotationAngle = (f3 * phaseX) + f2;
                    i++;
                    phaseY = f;
                    drawAngles = fArr;
                }
                MPPointF.recycleInstance(centerCircleBox);
            }
        }
    }

    @Override // com.github.mikephil.charting.renderer.DataRenderer
    public void drawValue(Canvas canvas, String str, float f, float f2, int i) {
        this.mValuePaint.setColor(i);
        canvas.drawText(str, f, f2, this.mValuePaint);
    }

    /* JADX WARNING: Removed duplicated region for block: B:11:0x00ae  */
    @Override // com.github.mikephil.charting.renderer.DataRenderer
    public void drawValues(Canvas canvas) {
        MPPointF mPPointF;
        List dataSets;
        int i;
        float f;
        float f2;
        float f3;
        float[] fArr;
        float[] fArr2;
        float f4;
        float f5;
        PieData pieData;
        List list;
        int i2;
        MPPointF mPPointF2;
        float f6;
        float f7;
        MPPointF mPPointF3;
        PieDataSet.ValuePosition valuePosition;
        float f8;
        boolean z;
        PieEntry pieEntry;
        float f9;
        int i3;
        String str;
        Canvas canvas2;
        IPieDataSet iPieDataSet;
        MPPointF mPPointF4;
        MPPointF mPPointF5;
        float f10;
        float f11;
        float f12;
        float f13;
        float f14;
        Canvas canvas3;
        String str2;
        MPPointF centerCircleBox = this.mChart.getCenterCircleBox();
        float radius = this.mChart.getRadius();
        float rotationAngle = this.mChart.getRotationAngle();
        float[] drawAngles = this.mChart.getDrawAngles();
        float[] absoluteAngles = this.mChart.getAbsoluteAngles();
        float phaseX = this.mAnimator.getPhaseX();
        float phaseY = this.mAnimator.getPhaseY();
        float holeRadius = (radius - ((this.mChart.getHoleRadius() * radius) / 100.0f)) / 2.0f;
        float holeRadius2 = this.mChart.getHoleRadius() / 100.0f;
        float f15 = (radius / 10.0f) * 3.6f;
        if (this.mChart.isDrawHoleEnabled()) {
            f15 = (radius - (radius * holeRadius2)) / 2.0f;
            if (!this.mChart.isDrawSlicesUnderHoleEnabled() && this.mChart.isDrawRoundedSlicesEnabled()) {
                mPPointF = centerCircleBox;
                rotationAngle = (float) ((((double) (holeRadius * 360.0f)) / (((double) radius) * 6.283185307179586d)) + ((double) rotationAngle));
                float f16 = rotationAngle;
                float f17 = radius - f15;
                PieData pieData2 = (PieData) this.mChart.getData();
                dataSets = pieData2.getDataSets();
                float yValueSum = pieData2.getYValueSum();
                boolean isDrawEntryLabelsEnabled = this.mChart.isDrawEntryLabelsEnabled();
                canvas.save();
                float convertDpToPixel = Utils.convertDpToPixel(5.0f);
                int i4 = 0;
                i = 0;
                while (i < dataSets.size()) {
                    IPieDataSet iPieDataSet2 = (IPieDataSet) dataSets.get(i);
                    boolean isDrawValuesEnabled = iPieDataSet2.isDrawValuesEnabled();
                    if (isDrawValuesEnabled || isDrawEntryLabelsEnabled) {
                        PieDataSet.ValuePosition xValuePosition = iPieDataSet2.getXValuePosition();
                        PieDataSet.ValuePosition yValuePosition = iPieDataSet2.getYValuePosition();
                        applyValueTextStyle(iPieDataSet2);
                        int i5 = i4;
                        int i6 = i;
                        float convertDpToPixel2 = Utils.convertDpToPixel(4.0f) + ((float) Utils.calcTextHeight(this.mValuePaint, "Q"));
                        ValueFormatter valueFormatter = iPieDataSet2.getValueFormatter();
                        int entryCount = iPieDataSet2.getEntryCount();
                        list = dataSets;
                        pieData = pieData2;
                        this.mValueLinePaint.setColor(iPieDataSet2.getValueLineColor());
                        this.mValueLinePaint.setStrokeWidth(Utils.convertDpToPixel(iPieDataSet2.getValueLineWidth()));
                        float sliceSpace = getSliceSpace(iPieDataSet2);
                        MPPointF instance = MPPointF.getInstance(iPieDataSet2.getIconsOffset());
                        f5 = radius;
                        instance.x = Utils.convertDpToPixel(instance.x);
                        instance.y = Utils.convertDpToPixel(instance.y);
                        int i7 = 0;
                        while (i7 < entryCount) {
                            PieEntry pieEntry2 = (PieEntry) iPieDataSet2.getEntryForIndex(i7);
                            if (i5 == 0) {
                                f6 = Utils.FLOAT_EPSILON;
                            } else {
                                f6 = absoluteAngles[i5 - 1] * phaseX;
                            }
                            float f18 = ((((drawAngles[i5] - ((sliceSpace / (f17 * 0.017453292f)) / 2.0f)) / 2.0f) + f6) * phaseY) + f16;
                            if (this.mChart.isUsePercentValuesEnabled()) {
                                f7 = (pieEntry2.getY() / yValueSum) * 100.0f;
                            } else {
                                f7 = pieEntry2.getY();
                            }
                            String pieLabel = valueFormatter.getPieLabel(f7, pieEntry2);
                            String label = pieEntry2.getLabel();
                            double d = (double) (f18 * 0.017453292f);
                            float cos = (float) Math.cos(d);
                            float sin = (float) Math.sin(d);
                            boolean z2 = isDrawEntryLabelsEnabled && xValuePosition == PieDataSet.ValuePosition.OUTSIDE_SLICE;
                            boolean z3 = isDrawValuesEnabled && yValuePosition == PieDataSet.ValuePosition.OUTSIDE_SLICE;
                            boolean z4 = isDrawEntryLabelsEnabled && xValuePosition == PieDataSet.ValuePosition.INSIDE_SLICE;
                            boolean z5 = isDrawValuesEnabled && yValuePosition == PieDataSet.ValuePosition.INSIDE_SLICE;
                            if (z2 || z3) {
                                float valueLinePart1Length = iPieDataSet2.getValueLinePart1Length();
                                float valueLinePart2Length = iPieDataSet2.getValueLinePart2Length();
                                valuePosition = yValuePosition;
                                float valueLinePart1OffsetPercentage = iPieDataSet2.getValueLinePart1OffsetPercentage() / 100.0f;
                                z = z4;
                                if (this.mChart.isDrawHoleEnabled()) {
                                    float f19 = f5 * holeRadius2;
                                    f8 = holeRadius2;
                                    f10 = f5;
                                    f11 = ze0.a(f10, f19, valueLinePart1OffsetPercentage, f19);
                                } else {
                                    f8 = holeRadius2;
                                    f10 = f5;
                                    f11 = valueLinePart1OffsetPercentage * f10;
                                }
                                float abs = iPieDataSet2.isValueLineVariableLength() ? valueLinePart2Length * f17 * ((float) Math.abs(Math.sin(d))) : valueLinePart2Length * f17;
                                mPPointF4 = mPPointF;
                                float f20 = mPPointF4.x;
                                float f21 = (f11 * cos) + f20;
                                f5 = f10;
                                float f22 = mPPointF4.y;
                                float f23 = (f11 * sin) + f22;
                                float f24 = (valueLinePart1Length + 1.0f) * f17;
                                float f25 = (f24 * cos) + f20;
                                float f26 = f22 + (f24 * sin);
                                double d2 = ((double) f18) % 360.0d;
                                if (d2 < 90.0d || d2 > 270.0d) {
                                    f12 = f25 + abs;
                                    this.mValuePaint.setTextAlign(Paint.Align.LEFT);
                                    if (z2) {
                                        this.mEntryLabelsPaint.setTextAlign(Paint.Align.LEFT);
                                    }
                                    f13 = f12 + convertDpToPixel;
                                } else {
                                    float f27 = f25 - abs;
                                    this.mValuePaint.setTextAlign(Paint.Align.RIGHT);
                                    if (z2) {
                                        this.mEntryLabelsPaint.setTextAlign(Paint.Align.RIGHT);
                                    }
                                    f12 = f27;
                                    f13 = f27 - convertDpToPixel;
                                }
                                if (iPieDataSet2.getValueLineColor() != 1122867) {
                                    if (iPieDataSet2.isUsingSliceColorAsValueLineColor()) {
                                        this.mValueLinePaint.setColor(iPieDataSet2.getColor(i7));
                                    }
                                    i3 = i6;
                                    f9 = sin;
                                    iPieDataSet = iPieDataSet2;
                                    mPPointF3 = instance;
                                    pieEntry = pieEntry2;
                                    f14 = f13;
                                    canvas.drawLine(f21, f23, f25, f26, this.mValueLinePaint);
                                    canvas.drawLine(f25, f26, f12, f26, this.mValueLinePaint);
                                } else {
                                    i3 = i6;
                                    mPPointF3 = instance;
                                    pieEntry = pieEntry2;
                                    f14 = f13;
                                    f9 = sin;
                                    iPieDataSet = iPieDataSet2;
                                }
                                if (!z2 || !z3) {
                                    canvas3 = canvas;
                                    str2 = label;
                                    if (z2) {
                                        if (i7 < pieData.getEntryCount() && str2 != null) {
                                            drawEntryLabel(canvas3, str2, f14, (convertDpToPixel2 / 2.0f) + f26);
                                        }
                                    } else if (z3) {
                                        str = str2;
                                        canvas2 = canvas3;
                                        drawValue(canvas, pieLabel, f14, (convertDpToPixel2 / 2.0f) + f26, iPieDataSet.getValueTextColor(i7));
                                    }
                                } else {
                                    drawValue(canvas, pieLabel, f14, f26, iPieDataSet.getValueTextColor(i7));
                                    if (i7 >= pieData.getEntryCount() || label == null) {
                                        canvas3 = canvas;
                                        str2 = label;
                                    } else {
                                        canvas3 = canvas;
                                        str2 = label;
                                        drawEntryLabel(canvas3, str2, f14, f26 + convertDpToPixel2);
                                    }
                                }
                                str = str2;
                                canvas2 = canvas3;
                            } else {
                                canvas2 = canvas;
                                valuePosition = yValuePosition;
                                z = z4;
                                f8 = holeRadius2;
                                mPPointF4 = mPPointF;
                                i3 = i6;
                                mPPointF3 = instance;
                                pieEntry = pieEntry2;
                                str = label;
                                f9 = sin;
                                iPieDataSet = iPieDataSet2;
                            }
                            if (z || z5) {
                                float f28 = (f17 * cos) + mPPointF4.x;
                                float f29 = (f17 * f9) + mPPointF4.y;
                                this.mValuePaint.setTextAlign(Paint.Align.CENTER);
                                if (z && z5) {
                                    drawValue(canvas, pieLabel, f28, f29, iPieDataSet.getValueTextColor(i7));
                                    if (i7 < pieData.getEntryCount() && str != null) {
                                        drawEntryLabel(canvas2, str, f28, f29 + convertDpToPixel2);
                                    }
                                } else if (z) {
                                    if (i7 < pieData.getEntryCount() && str != null) {
                                        drawEntryLabel(canvas2, str, f28, (convertDpToPixel2 / 2.0f) + f29);
                                    }
                                } else if (z5) {
                                    drawValue(canvas, pieLabel, f28, (convertDpToPixel2 / 2.0f) + f29, iPieDataSet.getValueTextColor(i7));
                                }
                            }
                            if (pieEntry.getIcon() == null || !iPieDataSet.isDrawIconsEnabled()) {
                                mPPointF5 = mPPointF3;
                            } else {
                                Drawable icon = pieEntry.getIcon();
                                mPPointF5 = mPPointF3;
                                float f30 = mPPointF5.y;
                                Utils.drawImage(canvas, icon, (int) (((f17 + f30) * cos) + mPPointF4.x), (int) (((f30 + f17) * f9) + mPPointF4.y + mPPointF5.x), icon.getIntrinsicWidth(), icon.getIntrinsicHeight());
                            }
                            i5++;
                            i7++;
                            instance = mPPointF5;
                            iPieDataSet2 = iPieDataSet;
                            i6 = i3;
                            entryCount = entryCount;
                            f16 = f16;
                            valueFormatter = valueFormatter;
                            absoluteAngles = absoluteAngles;
                            phaseX = phaseX;
                            phaseY = phaseY;
                            sliceSpace = sliceSpace;
                            xValuePosition = xValuePosition;
                            holeRadius2 = f8;
                            yValuePosition = valuePosition;
                            mPPointF = mPPointF4;
                            drawAngles = drawAngles;
                        }
                        f4 = f16;
                        fArr2 = drawAngles;
                        fArr = absoluteAngles;
                        f3 = phaseX;
                        f2 = phaseY;
                        f = holeRadius2;
                        mPPointF2 = mPPointF;
                        i2 = i6;
                        MPPointF.recycleInstance(instance);
                        i4 = i5;
                    } else {
                        list = dataSets;
                        f4 = f16;
                        f5 = radius;
                        fArr2 = drawAngles;
                        fArr = absoluteAngles;
                        f3 = phaseX;
                        f2 = phaseY;
                        f = holeRadius2;
                        pieData = pieData2;
                        mPPointF2 = mPPointF;
                        i2 = i;
                    }
                    i = i2 + 1;
                    mPPointF = mPPointF2;
                    dataSets = list;
                    pieData2 = pieData;
                    radius = f5;
                    f16 = f4;
                    drawAngles = fArr2;
                    absoluteAngles = fArr;
                    phaseX = f3;
                    phaseY = f2;
                    holeRadius2 = f;
                }
                MPPointF.recycleInstance(mPPointF);
                canvas.restore();
            }
        }
        mPPointF = centerCircleBox;
        float f162 = rotationAngle;
        float f172 = radius - f15;
        PieData pieData22 = (PieData) this.mChart.getData();
        dataSets = pieData22.getDataSets();
        float yValueSum2 = pieData22.getYValueSum();
        boolean isDrawEntryLabelsEnabled2 = this.mChart.isDrawEntryLabelsEnabled();
        canvas.save();
        float convertDpToPixel3 = Utils.convertDpToPixel(5.0f);
        int i42 = 0;
        i = 0;
        while (i < dataSets.size()) {
        }
        MPPointF.recycleInstance(mPPointF);
        canvas.restore();
    }

    public TextPaint getPaintCenterText() {
        return this.mCenterTextPaint;
    }

    public Paint getPaintEntryLabels() {
        return this.mEntryLabelsPaint;
    }

    public Paint getPaintHole() {
        return this.mHolePaint;
    }

    public Paint getPaintTransparentCircle() {
        return this.mTransparentCirclePaint;
    }

    public float getSliceSpace(IPieDataSet iPieDataSet) {
        if (!iPieDataSet.isAutomaticallyDisableSliceSpacingEnabled()) {
            return iPieDataSet.getSliceSpace();
        }
        if (iPieDataSet.getSliceSpace() / this.mViewPortHandler.getSmallestContentExtension() > (iPieDataSet.getYMin() / ((PieData) this.mChart.getData()).getYValueSum()) * 2.0f) {
            return Utils.FLOAT_EPSILON;
        }
        return iPieDataSet.getSliceSpace();
    }

    @Override // com.github.mikephil.charting.renderer.DataRenderer
    public void initBuffers() {
    }

    public void releaseBitmap() {
        Canvas canvas = this.mBitmapCanvas;
        if (canvas != null) {
            canvas.setBitmap(null);
            this.mBitmapCanvas = null;
        }
        WeakReference<Bitmap> weakReference = this.mDrawBitmap;
        if (weakReference != null) {
            Bitmap bitmap = weakReference.get();
            if (bitmap != null) {
                bitmap.recycle();
            }
            this.mDrawBitmap.clear();
            this.mDrawBitmap = null;
        }
    }
}
