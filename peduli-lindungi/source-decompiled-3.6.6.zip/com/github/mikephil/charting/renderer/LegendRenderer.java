package com.github.mikephil.charting.renderer;

import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.LegendEntry;
import com.github.mikephil.charting.data.ChartData;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.interfaces.datasets.ICandleDataSet;
import com.github.mikephil.charting.interfaces.datasets.IDataSet;
import com.github.mikephil.charting.interfaces.datasets.IPieDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.github.mikephil.charting.utils.FSize;
import com.github.mikephil.charting.utils.Utils;
import com.github.mikephil.charting.utils.ViewPortHandler;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LegendRenderer extends Renderer {
    public List<LegendEntry> computedEntries = new ArrayList(16);
    public Paint.FontMetrics legendFontMetrics = new Paint.FontMetrics();
    public Legend mLegend;
    public Paint mLegendFormPaint;
    public Paint mLegendLabelPaint;
    private Path mLineFormPath = new Path();

    /* renamed from: com.github.mikephil.charting.renderer.LegendRenderer$1  reason: invalid class name */
    public static /* synthetic */ class AnonymousClass1 {
        public static final /* synthetic */ int[] $SwitchMap$com$github$mikephil$charting$components$Legend$LegendForm;
        public static final /* synthetic */ int[] $SwitchMap$com$github$mikephil$charting$components$Legend$LegendHorizontalAlignment;
        public static final /* synthetic */ int[] $SwitchMap$com$github$mikephil$charting$components$Legend$LegendOrientation;
        public static final /* synthetic */ int[] $SwitchMap$com$github$mikephil$charting$components$Legend$LegendVerticalAlignment;

        /* JADX WARNING: Can't wrap try/catch for region: R(35:0|(2:1|2)|3|5|6|7|9|10|11|12|13|15|16|17|18|19|21|22|23|24|25|27|28|29|30|31|32|33|35|36|37|38|39|40|42) */
        /* JADX WARNING: Can't wrap try/catch for region: R(36:0|1|2|3|5|6|7|9|10|11|12|13|15|16|17|18|19|21|22|23|24|25|27|28|29|30|31|32|33|35|36|37|38|39|40|42) */
        /* JADX WARNING: Code restructure failed: missing block: B:43:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:11:0x001c */
        /* JADX WARNING: Missing exception handler attribute for start block: B:17:0x002a */
        /* JADX WARNING: Missing exception handler attribute for start block: B:23:0x003b */
        /* JADX WARNING: Missing exception handler attribute for start block: B:29:0x004c */
        /* JADX WARNING: Missing exception handler attribute for start block: B:31:0x0052 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:37:0x0063 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:39:0x0069 */
        static {
            Legend.LegendForm.values();
            int[] iArr = new int[6];
            $SwitchMap$com$github$mikephil$charting$components$Legend$LegendForm = iArr;
            try {
                Legend.LegendForm legendForm = Legend.LegendForm.NONE;
                iArr[0] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                int[] iArr2 = $SwitchMap$com$github$mikephil$charting$components$Legend$LegendForm;
                Legend.LegendForm legendForm2 = Legend.LegendForm.EMPTY;
                iArr2[1] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            int[] iArr3 = $SwitchMap$com$github$mikephil$charting$components$Legend$LegendForm;
            Legend.LegendForm legendForm3 = Legend.LegendForm.DEFAULT;
            iArr3[2] = 3;
            try {
                int[] iArr4 = $SwitchMap$com$github$mikephil$charting$components$Legend$LegendForm;
                Legend.LegendForm legendForm4 = Legend.LegendForm.CIRCLE;
                iArr4[4] = 4;
            } catch (NoSuchFieldError unused3) {
            }
            int[] iArr5 = $SwitchMap$com$github$mikephil$charting$components$Legend$LegendForm;
            Legend.LegendForm legendForm5 = Legend.LegendForm.SQUARE;
            iArr5[3] = 5;
            int[] iArr6 = $SwitchMap$com$github$mikephil$charting$components$Legend$LegendForm;
            Legend.LegendForm legendForm6 = Legend.LegendForm.LINE;
            iArr6[5] = 6;
            Legend.LegendOrientation.values();
            int[] iArr7 = new int[2];
            $SwitchMap$com$github$mikephil$charting$components$Legend$LegendOrientation = iArr7;
            Legend.LegendOrientation legendOrientation = Legend.LegendOrientation.HORIZONTAL;
            iArr7[0] = 1;
            int[] iArr8 = $SwitchMap$com$github$mikephil$charting$components$Legend$LegendOrientation;
            Legend.LegendOrientation legendOrientation2 = Legend.LegendOrientation.VERTICAL;
            iArr8[1] = 2;
            Legend.LegendVerticalAlignment.values();
            int[] iArr9 = new int[3];
            $SwitchMap$com$github$mikephil$charting$components$Legend$LegendVerticalAlignment = iArr9;
            Legend.LegendVerticalAlignment legendVerticalAlignment = Legend.LegendVerticalAlignment.TOP;
            iArr9[0] = 1;
            int[] iArr10 = $SwitchMap$com$github$mikephil$charting$components$Legend$LegendVerticalAlignment;
            Legend.LegendVerticalAlignment legendVerticalAlignment2 = Legend.LegendVerticalAlignment.BOTTOM;
            iArr10[2] = 2;
            int[] iArr11 = $SwitchMap$com$github$mikephil$charting$components$Legend$LegendVerticalAlignment;
            Legend.LegendVerticalAlignment legendVerticalAlignment3 = Legend.LegendVerticalAlignment.CENTER;
            iArr11[1] = 3;
            Legend.LegendHorizontalAlignment.values();
            int[] iArr12 = new int[3];
            $SwitchMap$com$github$mikephil$charting$components$Legend$LegendHorizontalAlignment = iArr12;
            Legend.LegendHorizontalAlignment legendHorizontalAlignment = Legend.LegendHorizontalAlignment.LEFT;
            iArr12[0] = 1;
            int[] iArr13 = $SwitchMap$com$github$mikephil$charting$components$Legend$LegendHorizontalAlignment;
            Legend.LegendHorizontalAlignment legendHorizontalAlignment2 = Legend.LegendHorizontalAlignment.RIGHT;
            iArr13[2] = 2;
            int[] iArr14 = $SwitchMap$com$github$mikephil$charting$components$Legend$LegendHorizontalAlignment;
            Legend.LegendHorizontalAlignment legendHorizontalAlignment3 = Legend.LegendHorizontalAlignment.CENTER;
            iArr14[1] = 3;
        }
    }

    public LegendRenderer(ViewPortHandler viewPortHandler, Legend legend) {
        super(viewPortHandler);
        this.mLegend = legend;
        Paint paint = new Paint(1);
        this.mLegendLabelPaint = paint;
        paint.setTextSize(Utils.convertDpToPixel(9.0f));
        this.mLegendLabelPaint.setTextAlign(Paint.Align.LEFT);
        Paint paint2 = new Paint(1);
        this.mLegendFormPaint = paint2;
        paint2.setStyle(Paint.Style.FILL);
    }

    public void computeLegend(ChartData<?> chartData) {
        ChartData<?> chartData2;
        String str;
        ChartData<?> chartData3 = chartData;
        if (!this.mLegend.isLegendCustom()) {
            this.computedEntries.clear();
            int i = 0;
            while (i < chartData.getDataSetCount()) {
                IDataSet dataSetByIndex = chartData3.getDataSetByIndex(i);
                List<Integer> colors = dataSetByIndex.getColors();
                int entryCount = dataSetByIndex.getEntryCount();
                if (dataSetByIndex instanceof IBarDataSet) {
                    IBarDataSet iBarDataSet = (IBarDataSet) dataSetByIndex;
                    if (iBarDataSet.isStacked()) {
                        String[] stackLabels = iBarDataSet.getStackLabels();
                        int i2 = 0;
                        while (i2 < colors.size() && i2 < iBarDataSet.getStackSize()) {
                            this.computedEntries.add(new LegendEntry(stackLabels[i2 % stackLabels.length], dataSetByIndex.getForm(), dataSetByIndex.getFormSize(), dataSetByIndex.getFormLineWidth(), dataSetByIndex.getFormLineDashEffect(), colors.get(i2).intValue()));
                            i2++;
                        }
                        if (iBarDataSet.getLabel() != null) {
                            this.computedEntries.add(new LegendEntry(dataSetByIndex.getLabel(), Legend.LegendForm.NONE, Float.NaN, Float.NaN, null, ColorTemplate.COLOR_NONE));
                        }
                        chartData2 = chartData3;
                        i++;
                        chartData3 = chartData2;
                    }
                }
                if (dataSetByIndex instanceof IPieDataSet) {
                    IPieDataSet iPieDataSet = (IPieDataSet) dataSetByIndex;
                    int i3 = 0;
                    while (i3 < colors.size() && i3 < entryCount) {
                        this.computedEntries.add(new LegendEntry(((PieEntry) iPieDataSet.getEntryForIndex(i3)).getLabel(), dataSetByIndex.getForm(), dataSetByIndex.getFormSize(), dataSetByIndex.getFormLineWidth(), dataSetByIndex.getFormLineDashEffect(), colors.get(i3).intValue()));
                        i3++;
                    }
                    if (iPieDataSet.getLabel() != null) {
                        this.computedEntries.add(new LegendEntry(dataSetByIndex.getLabel(), Legend.LegendForm.NONE, Float.NaN, Float.NaN, null, ColorTemplate.COLOR_NONE));
                    }
                } else {
                    if (dataSetByIndex instanceof ICandleDataSet) {
                        ICandleDataSet iCandleDataSet = (ICandleDataSet) dataSetByIndex;
                        if (iCandleDataSet.getDecreasingColor() != 1122867) {
                            int decreasingColor = iCandleDataSet.getDecreasingColor();
                            int increasingColor = iCandleDataSet.getIncreasingColor();
                            this.computedEntries.add(new LegendEntry(null, dataSetByIndex.getForm(), dataSetByIndex.getFormSize(), dataSetByIndex.getFormLineWidth(), dataSetByIndex.getFormLineDashEffect(), decreasingColor));
                            this.computedEntries.add(new LegendEntry(dataSetByIndex.getLabel(), dataSetByIndex.getForm(), dataSetByIndex.getFormSize(), dataSetByIndex.getFormLineWidth(), dataSetByIndex.getFormLineDashEffect(), increasingColor));
                        }
                    }
                    int i4 = 0;
                    while (i4 < colors.size() && i4 < entryCount) {
                        if (i4 >= colors.size() - 1 || i4 >= entryCount - 1) {
                            str = chartData.getDataSetByIndex(i).getLabel();
                        } else {
                            str = null;
                        }
                        this.computedEntries.add(new LegendEntry(str, dataSetByIndex.getForm(), dataSetByIndex.getFormSize(), dataSetByIndex.getFormLineWidth(), dataSetByIndex.getFormLineDashEffect(), colors.get(i4).intValue()));
                        i4++;
                    }
                }
                chartData2 = chartData;
                i++;
                chartData3 = chartData2;
            }
            if (this.mLegend.getExtraEntries() != null) {
                Collections.addAll(this.computedEntries, this.mLegend.getExtraEntries());
            }
            this.mLegend.setEntries(this.computedEntries);
        }
        Typeface typeface = this.mLegend.getTypeface();
        if (typeface != null) {
            this.mLegendLabelPaint.setTypeface(typeface);
        }
        this.mLegendLabelPaint.setTextSize(this.mLegend.getTextSize());
        this.mLegendLabelPaint.setColor(this.mLegend.getTextColor());
        this.mLegend.calculateDimensions(this.mLegendLabelPaint, this.mViewPortHandler);
    }

    public void drawForm(Canvas canvas, float f, float f2, LegendEntry legendEntry, Legend legend) {
        int i = legendEntry.formColor;
        if (i != 1122868 && i != 1122867 && i != 0) {
            int save = canvas.save();
            Legend.LegendForm legendForm = legendEntry.form;
            if (legendForm == Legend.LegendForm.DEFAULT) {
                legendForm = legend.getForm();
            }
            this.mLegendFormPaint.setColor(legendEntry.formColor);
            float convertDpToPixel = Utils.convertDpToPixel(Float.isNaN(legendEntry.formSize) ? legend.getFormSize() : legendEntry.formSize);
            float f3 = convertDpToPixel / 2.0f;
            int ordinal = legendForm.ordinal();
            if (ordinal != 2) {
                if (ordinal == 3) {
                    this.mLegendFormPaint.setStyle(Paint.Style.FILL);
                    canvas.drawRect(f, f2 - f3, f + convertDpToPixel, f2 + f3, this.mLegendFormPaint);
                } else if (ordinal != 4) {
                    if (ordinal == 5) {
                        float convertDpToPixel2 = Utils.convertDpToPixel(Float.isNaN(legendEntry.formLineWidth) ? legend.getFormLineWidth() : legendEntry.formLineWidth);
                        DashPathEffect dashPathEffect = legendEntry.formLineDashEffect;
                        if (dashPathEffect == null) {
                            dashPathEffect = legend.getFormLineDashEffect();
                        }
                        this.mLegendFormPaint.setStyle(Paint.Style.STROKE);
                        this.mLegendFormPaint.setStrokeWidth(convertDpToPixel2);
                        this.mLegendFormPaint.setPathEffect(dashPathEffect);
                        this.mLineFormPath.reset();
                        this.mLineFormPath.moveTo(f, f2);
                        this.mLineFormPath.lineTo(f + convertDpToPixel, f2);
                        canvas.drawPath(this.mLineFormPath, this.mLegendFormPaint);
                    }
                }
                canvas.restoreToCount(save);
            }
            this.mLegendFormPaint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(f + f3, f2, f3, this.mLegendFormPaint);
            canvas.restoreToCount(save);
        }
    }

    public void drawLabel(Canvas canvas, float f, float f2, String str) {
        canvas.drawText(str, f, f2, this.mLegendLabelPaint);
    }

    public Paint getFormPaint() {
        return this.mLegendFormPaint;
    }

    public Paint getLabelPaint() {
        return this.mLegendLabelPaint;
    }

    /* JADX WARNING: Removed duplicated region for block: B:107:0x0263  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x0156  */
    public void renderLegend(Canvas canvas) {
        float f;
        float f2;
        float f3;
        float f4;
        int ordinal;
        float f5;
        float f6;
        List<Boolean> list;
        List<FSize> list2;
        int i;
        float f7;
        float f8;
        float f9;
        float f10;
        float f11;
        float f12;
        float f13;
        float f14;
        float f15;
        float f16;
        Legend.LegendDirection legendDirection;
        LegendEntry legendEntry;
        float f17;
        float f18;
        float f19;
        float f20;
        double d;
        float f21;
        if (this.mLegend.isEnabled()) {
            Typeface typeface = this.mLegend.getTypeface();
            if (typeface != null) {
                this.mLegendLabelPaint.setTypeface(typeface);
            }
            this.mLegendLabelPaint.setTextSize(this.mLegend.getTextSize());
            this.mLegendLabelPaint.setColor(this.mLegend.getTextColor());
            float lineHeight = Utils.getLineHeight(this.mLegendLabelPaint, this.legendFontMetrics);
            float convertDpToPixel = Utils.convertDpToPixel(this.mLegend.getYEntrySpace()) + Utils.getLineSpacing(this.mLegendLabelPaint, this.legendFontMetrics);
            float calcTextHeight = lineHeight - (((float) Utils.calcTextHeight(this.mLegendLabelPaint, "ABC")) / 2.0f);
            LegendEntry[] entries = this.mLegend.getEntries();
            float convertDpToPixel2 = Utils.convertDpToPixel(this.mLegend.getFormToTextSpace());
            float convertDpToPixel3 = Utils.convertDpToPixel(this.mLegend.getXEntrySpace());
            Legend.LegendOrientation orientation = this.mLegend.getOrientation();
            Legend.LegendHorizontalAlignment horizontalAlignment = this.mLegend.getHorizontalAlignment();
            Legend.LegendVerticalAlignment verticalAlignment = this.mLegend.getVerticalAlignment();
            Legend.LegendDirection direction = this.mLegend.getDirection();
            float convertDpToPixel4 = Utils.convertDpToPixel(this.mLegend.getFormSize());
            float convertDpToPixel5 = Utils.convertDpToPixel(this.mLegend.getStackSpace());
            float yOffset = this.mLegend.getYOffset();
            float xOffset = this.mLegend.getXOffset();
            int ordinal2 = horizontalAlignment.ordinal();
            float f22 = convertDpToPixel5;
            if (ordinal2 != 0) {
                if (ordinal2 == 1) {
                    Legend.LegendOrientation legendOrientation = Legend.LegendOrientation.VERTICAL;
                    if (orientation == legendOrientation) {
                        f20 = this.mViewPortHandler.getChartWidth() / 2.0f;
                        f2 = convertDpToPixel3;
                    } else {
                        f2 = convertDpToPixel3;
                        f20 = this.mViewPortHandler.contentLeft() + (this.mViewPortHandler.contentWidth() / 2.0f);
                    }
                    Legend.LegendDirection legendDirection2 = Legend.LegendDirection.LEFT_TO_RIGHT;
                    f = convertDpToPixel;
                    f4 = (direction == legendDirection2 ? xOffset : -xOffset) + f20;
                    if (orientation == legendOrientation) {
                        double d2 = (double) f4;
                        if (direction == legendDirection2) {
                            f3 = lineHeight;
                            d = (((double) (-this.mLegend.mNeededWidth)) / 2.0d) + ((double) xOffset);
                        } else {
                            f3 = lineHeight;
                            d = (((double) this.mLegend.mNeededWidth) / 2.0d) - ((double) xOffset);
                        }
                        f19 = (float) (d2 + d);
                    }
                } else if (ordinal2 != 2) {
                    f = convertDpToPixel;
                    f2 = convertDpToPixel3;
                    f4 = Utils.FLOAT_EPSILON;
                } else {
                    if (orientation == Legend.LegendOrientation.VERTICAL) {
                        f21 = this.mViewPortHandler.getChartWidth();
                    } else {
                        f21 = this.mViewPortHandler.contentRight();
                    }
                    float f23 = f21 - xOffset;
                    if (direction == Legend.LegendDirection.LEFT_TO_RIGHT) {
                        f23 -= this.mLegend.mNeededWidth;
                    }
                    f = convertDpToPixel;
                    f2 = convertDpToPixel3;
                    f4 = f23;
                }
                f3 = lineHeight;
                ordinal = orientation.ordinal();
                if (ordinal == 0) {
                    float f24 = f22;
                    List<FSize> calculatedLineSizes = this.mLegend.getCalculatedLineSizes();
                    List<FSize> calculatedLabelSizes = this.mLegend.getCalculatedLabelSizes();
                    List<Boolean> calculatedLabelBreakPoints = this.mLegend.getCalculatedLabelBreakPoints();
                    int ordinal3 = verticalAlignment.ordinal();
                    if (ordinal3 != 0) {
                        if (ordinal3 == 1) {
                            yOffset += (this.mViewPortHandler.getChartHeight() - this.mLegend.mNeededHeight) / 2.0f;
                        } else if (ordinal3 != 2) {
                            yOffset = Utils.FLOAT_EPSILON;
                        } else {
                            yOffset = (this.mViewPortHandler.getChartHeight() - yOffset) - this.mLegend.mNeededHeight;
                        }
                    }
                    int length = entries.length;
                    float f25 = f4;
                    int i2 = 0;
                    int i3 = 0;
                    while (i2 < length) {
                        LegendEntry legendEntry2 = entries[i2];
                        boolean z = legendEntry2.form != Legend.LegendForm.NONE;
                        float convertDpToPixel6 = Float.isNaN(legendEntry2.formSize) ? convertDpToPixel4 : Utils.convertDpToPixel(legendEntry2.formSize);
                        if (i2 >= calculatedLabelBreakPoints.size() || !calculatedLabelBreakPoints.get(i2).booleanValue()) {
                            f6 = f25;
                            f5 = yOffset;
                        } else {
                            f5 = f3 + f + yOffset;
                            f6 = f4;
                        }
                        if (f6 == f4 && horizontalAlignment == Legend.LegendHorizontalAlignment.CENTER && i3 < calculatedLineSizes.size()) {
                            if (direction == Legend.LegendDirection.RIGHT_TO_LEFT) {
                                f11 = calculatedLineSizes.get(i3).width;
                            } else {
                                f11 = -calculatedLineSizes.get(i3).width;
                            }
                            f6 += f11 / 2.0f;
                            i3++;
                        }
                        boolean z2 = legendEntry2.label == null;
                        if (z) {
                            if (direction == Legend.LegendDirection.RIGHT_TO_LEFT) {
                                f6 -= convertDpToPixel6;
                            }
                            list2 = calculatedLineSizes;
                            i = i2;
                            list = calculatedLabelBreakPoints;
                            drawForm(canvas, f6, f5 + calcTextHeight, legendEntry2, this.mLegend);
                            f6 = direction == Legend.LegendDirection.LEFT_TO_RIGHT ? f6 + convertDpToPixel6 : f6;
                        } else {
                            list = calculatedLabelBreakPoints;
                            list2 = calculatedLineSizes;
                            i = i2;
                        }
                        if (!z2) {
                            if (z) {
                                f6 += direction == Legend.LegendDirection.RIGHT_TO_LEFT ? -convertDpToPixel2 : convertDpToPixel2;
                            }
                            Legend.LegendDirection legendDirection3 = Legend.LegendDirection.RIGHT_TO_LEFT;
                            if (direction == legendDirection3) {
                                f6 -= calculatedLabelSizes.get(i).width;
                            }
                            drawLabel(canvas, f6, f5 + f3, legendEntry2.label);
                            if (direction == Legend.LegendDirection.LEFT_TO_RIGHT) {
                                f6 += calculatedLabelSizes.get(i).width;
                            }
                            if (direction == legendDirection3) {
                                f8 = f2;
                                f10 = -f8;
                            } else {
                                f8 = f2;
                                f10 = f8;
                            }
                            f25 = f6 + f10;
                            f7 = f24;
                        } else {
                            f8 = f2;
                            if (direction == Legend.LegendDirection.RIGHT_TO_LEFT) {
                                f7 = f24;
                                f9 = -f7;
                            } else {
                                f7 = f24;
                                f9 = f7;
                            }
                            f25 = f6 + f9;
                        }
                        f2 = f8;
                        f24 = f7;
                        i2 = i + 1;
                        yOffset = f5;
                        length = length;
                        i3 = i3;
                        calculatedLineSizes = list2;
                        calculatedLabelBreakPoints = list;
                    }
                    return;
                } else if (ordinal == 1) {
                    int ordinal4 = verticalAlignment.ordinal();
                    if (ordinal4 == 0) {
                        if (horizontalAlignment == Legend.LegendHorizontalAlignment.CENTER) {
                            f17 = Utils.FLOAT_EPSILON;
                        } else {
                            f17 = this.mViewPortHandler.contentTop();
                        }
                        f12 = f17 + yOffset;
                    } else if (ordinal4 == 1) {
                        Legend legend = this.mLegend;
                        f12 = ((this.mViewPortHandler.getChartHeight() / 2.0f) - (legend.mNeededHeight / 2.0f)) + legend.getYOffset();
                    } else if (ordinal4 != 2) {
                        f12 = Utils.FLOAT_EPSILON;
                    } else {
                        if (horizontalAlignment == Legend.LegendHorizontalAlignment.CENTER) {
                            f18 = this.mViewPortHandler.getChartHeight();
                        } else {
                            f18 = this.mViewPortHandler.contentBottom();
                        }
                        f12 = f18 - (this.mLegend.mNeededHeight + yOffset);
                    }
                    float f26 = f12;
                    int i4 = 0;
                    float f27 = Utils.FLOAT_EPSILON;
                    boolean z3 = false;
                    while (i4 < entries.length) {
                        LegendEntry legendEntry3 = entries[i4];
                        boolean z4 = legendEntry3.form != Legend.LegendForm.NONE;
                        float convertDpToPixel7 = Float.isNaN(legendEntry3.formSize) ? convertDpToPixel4 : Utils.convertDpToPixel(legendEntry3.formSize);
                        if (z4) {
                            Legend.LegendDirection legendDirection4 = Legend.LegendDirection.LEFT_TO_RIGHT;
                            f14 = direction == legendDirection4 ? f4 + f27 : f4 - (convertDpToPixel7 - f27);
                            f13 = calcTextHeight;
                            f16 = f22;
                            f15 = f4;
                            legendDirection = direction;
                            drawForm(canvas, f14, f26 + calcTextHeight, legendEntry3, this.mLegend);
                            if (legendDirection == legendDirection4) {
                                f14 += convertDpToPixel7;
                            }
                            legendEntry = legendEntry3;
                        } else {
                            f13 = calcTextHeight;
                            f16 = f22;
                            f15 = f4;
                            legendDirection = direction;
                            legendEntry = legendEntry3;
                            f14 = f15;
                        }
                        String str = legendEntry.label;
                        if (str != null) {
                            if (z4 && !z3) {
                                f14 += legendDirection == Legend.LegendDirection.LEFT_TO_RIGHT ? convertDpToPixel2 : -convertDpToPixel2;
                            } else if (z3) {
                                f14 = f15;
                            }
                            if (legendDirection == Legend.LegendDirection.RIGHT_TO_LEFT) {
                                f14 -= (float) Utils.calcTextWidth(this.mLegendLabelPaint, str);
                            }
                            if (!z3) {
                                drawLabel(canvas, f14, f26 + f3, legendEntry.label);
                            } else {
                                f26 += f3 + f;
                                drawLabel(canvas, f14, f26 + f3, legendEntry.label);
                            }
                            f26 = f3 + f + f26;
                            f27 = Utils.FLOAT_EPSILON;
                        } else {
                            f27 = convertDpToPixel7 + f16 + f27;
                            z3 = true;
                        }
                        i4++;
                        direction = legendDirection;
                        f4 = f15;
                        f22 = f16;
                        calcTextHeight = f13;
                    }
                    return;
                } else {
                    return;
                }
            } else {
                f = convertDpToPixel;
                f2 = convertDpToPixel3;
                f3 = lineHeight;
                if (orientation != Legend.LegendOrientation.VERTICAL) {
                    xOffset += this.mViewPortHandler.contentLeft();
                }
                if (direction == Legend.LegendDirection.RIGHT_TO_LEFT) {
                    f19 = this.mLegend.mNeededWidth + xOffset;
                } else {
                    f4 = xOffset;
                    ordinal = orientation.ordinal();
                    if (ordinal == 0) {
                    }
                }
            }
            f4 = f19;
            ordinal = orientation.ordinal();
            if (ordinal == 0) {
            }
        }
    }
}
