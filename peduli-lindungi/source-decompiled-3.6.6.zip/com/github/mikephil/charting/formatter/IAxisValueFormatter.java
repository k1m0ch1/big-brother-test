package com.github.mikephil.charting.formatter;

import com.github.mikephil.charting.components.AxisBase;

@Deprecated
public interface IAxisValueFormatter {
    @Deprecated
    String getFormattedValue(float f, AxisBase axisBase);
}
