package com.github.mikephil.charting.highlight;

public interface IHighlighter {
    Highlight getHighlight(float f, float f2);
}
