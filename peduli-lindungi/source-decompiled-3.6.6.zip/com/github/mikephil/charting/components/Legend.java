package com.github.mikephil.charting.components;

import android.graphics.DashPathEffect;
import android.graphics.Paint;
import com.github.mikephil.charting.utils.FSize;
import com.github.mikephil.charting.utils.Utils;
import com.github.mikephil.charting.utils.ViewPortHandler;
import java.util.ArrayList;
import java.util.List;

public class Legend extends ComponentBase {
    private List<Boolean> mCalculatedLabelBreakPoints;
    private List<FSize> mCalculatedLabelSizes;
    private List<FSize> mCalculatedLineSizes;
    private LegendDirection mDirection;
    private boolean mDrawInside;
    private LegendEntry[] mEntries;
    private LegendEntry[] mExtraEntries;
    private DashPathEffect mFormLineDashEffect;
    private float mFormLineWidth;
    private float mFormSize;
    private float mFormToTextSpace;
    private LegendHorizontalAlignment mHorizontalAlignment;
    private boolean mIsLegendCustom;
    private float mMaxSizePercent;
    public float mNeededHeight;
    public float mNeededWidth;
    private LegendOrientation mOrientation;
    private LegendForm mShape;
    private float mStackSpace;
    public float mTextHeightMax;
    public float mTextWidthMax;
    private LegendVerticalAlignment mVerticalAlignment;
    private boolean mWordWrapEnabled;
    private float mXEntrySpace;
    private float mYEntrySpace;

    /* renamed from: com.github.mikephil.charting.components.Legend$1  reason: invalid class name */
    public static /* synthetic */ class AnonymousClass1 {
        public static final /* synthetic */ int[] $SwitchMap$com$github$mikephil$charting$components$Legend$LegendOrientation;

        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x000d */
        static {
            LegendOrientation.values();
            int[] iArr = new int[2];
            $SwitchMap$com$github$mikephil$charting$components$Legend$LegendOrientation = iArr;
            LegendOrientation legendOrientation = LegendOrientation.VERTICAL;
            iArr[1] = 1;
            try {
                int[] iArr2 = $SwitchMap$com$github$mikephil$charting$components$Legend$LegendOrientation;
                LegendOrientation legendOrientation2 = LegendOrientation.HORIZONTAL;
                iArr2[0] = 2;
            } catch (NoSuchFieldError unused) {
            }
        }
    }

    public enum LegendDirection {
        LEFT_TO_RIGHT,
        RIGHT_TO_LEFT
    }

    public enum LegendForm {
        NONE,
        EMPTY,
        DEFAULT,
        SQUARE,
        CIRCLE,
        LINE
    }

    public enum LegendHorizontalAlignment {
        LEFT,
        CENTER,
        RIGHT
    }

    public enum LegendOrientation {
        HORIZONTAL,
        VERTICAL
    }

    public enum LegendVerticalAlignment {
        TOP,
        CENTER,
        BOTTOM
    }

    public Legend() {
        this.mEntries = new LegendEntry[0];
        this.mIsLegendCustom = false;
        this.mHorizontalAlignment = LegendHorizontalAlignment.LEFT;
        this.mVerticalAlignment = LegendVerticalAlignment.BOTTOM;
        this.mOrientation = LegendOrientation.HORIZONTAL;
        this.mDrawInside = false;
        this.mDirection = LegendDirection.LEFT_TO_RIGHT;
        this.mShape = LegendForm.SQUARE;
        this.mFormSize = 8.0f;
        this.mFormLineWidth = 3.0f;
        this.mFormLineDashEffect = null;
        this.mXEntrySpace = 6.0f;
        this.mYEntrySpace = Utils.FLOAT_EPSILON;
        this.mFormToTextSpace = 5.0f;
        this.mStackSpace = 3.0f;
        this.mMaxSizePercent = 0.95f;
        this.mNeededWidth = Utils.FLOAT_EPSILON;
        this.mNeededHeight = Utils.FLOAT_EPSILON;
        this.mTextHeightMax = Utils.FLOAT_EPSILON;
        this.mTextWidthMax = Utils.FLOAT_EPSILON;
        this.mWordWrapEnabled = false;
        this.mCalculatedLabelSizes = new ArrayList(16);
        this.mCalculatedLabelBreakPoints = new ArrayList(16);
        this.mCalculatedLineSizes = new ArrayList(16);
        this.mTextSize = Utils.convertDpToPixel(10.0f);
        this.mXOffset = Utils.convertDpToPixel(5.0f);
        this.mYOffset = Utils.convertDpToPixel(3.0f);
    }

    public void calculateDimensions(Paint paint, ViewPortHandler viewPortHandler) {
        int i;
        float f;
        float f2;
        float f3;
        float f4;
        float f5;
        Paint paint2 = paint;
        float convertDpToPixel = Utils.convertDpToPixel(this.mFormSize);
        float convertDpToPixel2 = Utils.convertDpToPixel(this.mStackSpace);
        float convertDpToPixel3 = Utils.convertDpToPixel(this.mFormToTextSpace);
        float convertDpToPixel4 = Utils.convertDpToPixel(this.mXEntrySpace);
        float convertDpToPixel5 = Utils.convertDpToPixel(this.mYEntrySpace);
        boolean z = this.mWordWrapEnabled;
        LegendEntry[] legendEntryArr = this.mEntries;
        int length = legendEntryArr.length;
        this.mTextWidthMax = getMaximumEntryWidth(paint);
        this.mTextHeightMax = getMaximumEntryHeight(paint);
        int ordinal = this.mOrientation.ordinal();
        if (ordinal == 0) {
            float lineHeight = Utils.getLineHeight(paint);
            float lineSpacing = Utils.getLineSpacing(paint) + convertDpToPixel5;
            float contentWidth = viewPortHandler.contentWidth() * this.mMaxSizePercent;
            this.mCalculatedLabelBreakPoints.clear();
            this.mCalculatedLabelSizes.clear();
            this.mCalculatedLineSizes.clear();
            float f6 = Utils.FLOAT_EPSILON;
            int i2 = 0;
            float f7 = Utils.FLOAT_EPSILON;
            int i3 = -1;
            float f8 = Utils.FLOAT_EPSILON;
            while (i2 < length) {
                LegendEntry legendEntry = legendEntryArr[i2];
                boolean z2 = legendEntry.form != LegendForm.NONE;
                if (Float.isNaN(legendEntry.formSize)) {
                    f = convertDpToPixel;
                } else {
                    f = Utils.convertDpToPixel(legendEntry.formSize);
                }
                String str = legendEntry.label;
                this.mCalculatedLabelBreakPoints.add(Boolean.FALSE);
                float f9 = i3 == -1 ? Utils.FLOAT_EPSILON : f6 + convertDpToPixel2;
                if (str != null) {
                    this.mCalculatedLabelSizes.add(Utils.calcTextSize(paint2, str));
                    f6 = f9 + (z2 ? convertDpToPixel3 + f : Utils.FLOAT_EPSILON) + this.mCalculatedLabelSizes.get(i2).width;
                } else {
                    this.mCalculatedLabelSizes.add(FSize.getInstance(Utils.FLOAT_EPSILON, Utils.FLOAT_EPSILON));
                    if (!z2) {
                        f = Utils.FLOAT_EPSILON;
                    }
                    f6 = f9 + f;
                    if (i3 == -1) {
                        i3 = i2;
                    }
                }
                if (str != null || i2 == length - 1) {
                    int i4 = (f8 > Utils.FLOAT_EPSILON ? 1 : (f8 == Utils.FLOAT_EPSILON ? 0 : -1));
                    float f10 = i4 == 0 ? Utils.FLOAT_EPSILON : convertDpToPixel4;
                    if (!z || i4 == 0 || contentWidth - f8 >= f10 + f6) {
                        f3 = f10 + f6 + f8;
                        f2 = f7;
                    } else {
                        this.mCalculatedLineSizes.add(FSize.getInstance(f8, lineHeight));
                        f2 = Math.max(f7, f8);
                        this.mCalculatedLabelBreakPoints.set(i3 > -1 ? i3 : i2, Boolean.TRUE);
                        f3 = f6;
                    }
                    if (i2 == length - 1) {
                        this.mCalculatedLineSizes.add(FSize.getInstance(f3, lineHeight));
                        f2 = Math.max(f2, f3);
                    }
                    f8 = f3;
                } else {
                    f2 = f7;
                }
                if (str != null) {
                    i3 = -1;
                }
                i2++;
                f7 = f2;
                convertDpToPixel4 = convertDpToPixel4;
                legendEntryArr = legendEntryArr;
                lineSpacing = lineSpacing;
                paint2 = paint;
            }
            this.mNeededWidth = f7;
            float size = lineHeight * ((float) this.mCalculatedLineSizes.size());
            if (this.mCalculatedLineSizes.size() == 0) {
                i = 0;
            } else {
                i = this.mCalculatedLineSizes.size() - 1;
            }
            this.mNeededHeight = (lineSpacing * ((float) i)) + size;
        } else if (ordinal == 1) {
            float lineHeight2 = Utils.getLineHeight(paint);
            int i5 = 0;
            float f11 = Utils.FLOAT_EPSILON;
            float f12 = Utils.FLOAT_EPSILON;
            boolean z3 = false;
            float f13 = Utils.FLOAT_EPSILON;
            while (i5 < length) {
                LegendEntry legendEntry2 = legendEntryArr[i5];
                boolean z4 = legendEntry2.form != LegendForm.NONE;
                if (Float.isNaN(legendEntry2.formSize)) {
                    f4 = convertDpToPixel;
                } else {
                    f4 = Utils.convertDpToPixel(legendEntry2.formSize);
                }
                String str2 = legendEntry2.label;
                if (!z3) {
                    f13 = Utils.FLOAT_EPSILON;
                }
                if (z4) {
                    if (z3) {
                        f13 += convertDpToPixel2;
                    }
                    f13 += f4;
                }
                float f14 = f13;
                if (str2 != null) {
                    if (z4 && !z3) {
                        f14 += convertDpToPixel3;
                    } else if (z3) {
                        f11 = Math.max(f11, f14);
                        f12 += lineHeight2 + convertDpToPixel5;
                        f14 = Utils.FLOAT_EPSILON;
                        z3 = false;
                    }
                    f5 = f14 + ((float) Utils.calcTextWidth(paint2, str2));
                    if (i5 < length - 1) {
                        f12 += lineHeight2 + convertDpToPixel5;
                    }
                } else {
                    f5 = f14 + f4;
                    if (i5 < length - 1) {
                        f5 += convertDpToPixel2;
                    }
                    z3 = true;
                }
                f11 = Math.max(f11, f5);
                i5++;
                f13 = f5;
                convertDpToPixel = convertDpToPixel;
            }
            this.mNeededWidth = f11;
            this.mNeededHeight = f12;
        }
        this.mNeededHeight += this.mYOffset;
        this.mNeededWidth += this.mXOffset;
    }

    public List<Boolean> getCalculatedLabelBreakPoints() {
        return this.mCalculatedLabelBreakPoints;
    }

    public List<FSize> getCalculatedLabelSizes() {
        return this.mCalculatedLabelSizes;
    }

    public List<FSize> getCalculatedLineSizes() {
        return this.mCalculatedLineSizes;
    }

    public LegendDirection getDirection() {
        return this.mDirection;
    }

    public LegendEntry[] getEntries() {
        return this.mEntries;
    }

    public LegendEntry[] getExtraEntries() {
        return this.mExtraEntries;
    }

    public LegendForm getForm() {
        return this.mShape;
    }

    public DashPathEffect getFormLineDashEffect() {
        return this.mFormLineDashEffect;
    }

    public float getFormLineWidth() {
        return this.mFormLineWidth;
    }

    public float getFormSize() {
        return this.mFormSize;
    }

    public float getFormToTextSpace() {
        return this.mFormToTextSpace;
    }

    public LegendHorizontalAlignment getHorizontalAlignment() {
        return this.mHorizontalAlignment;
    }

    public float getMaxSizePercent() {
        return this.mMaxSizePercent;
    }

    public float getMaximumEntryHeight(Paint paint) {
        LegendEntry[] legendEntryArr = this.mEntries;
        float f = Utils.FLOAT_EPSILON;
        for (LegendEntry legendEntry : legendEntryArr) {
            String str = legendEntry.label;
            if (str != null) {
                float calcTextHeight = (float) Utils.calcTextHeight(paint, str);
                if (calcTextHeight > f) {
                    f = calcTextHeight;
                }
            }
        }
        return f;
    }

    public float getMaximumEntryWidth(Paint paint) {
        float convertDpToPixel = Utils.convertDpToPixel(this.mFormToTextSpace);
        LegendEntry[] legendEntryArr = this.mEntries;
        float f = Utils.FLOAT_EPSILON;
        float f2 = Utils.FLOAT_EPSILON;
        for (LegendEntry legendEntry : legendEntryArr) {
            float convertDpToPixel2 = Utils.convertDpToPixel(Float.isNaN(legendEntry.formSize) ? this.mFormSize : legendEntry.formSize);
            if (convertDpToPixel2 > f2) {
                f2 = convertDpToPixel2;
            }
            String str = legendEntry.label;
            if (str != null) {
                float calcTextWidth = (float) Utils.calcTextWidth(paint, str);
                if (calcTextWidth > f) {
                    f = calcTextWidth;
                }
            }
        }
        return f + f2 + convertDpToPixel;
    }

    public LegendOrientation getOrientation() {
        return this.mOrientation;
    }

    public float getStackSpace() {
        return this.mStackSpace;
    }

    public LegendVerticalAlignment getVerticalAlignment() {
        return this.mVerticalAlignment;
    }

    public float getXEntrySpace() {
        return this.mXEntrySpace;
    }

    public float getYEntrySpace() {
        return this.mYEntrySpace;
    }

    public boolean isDrawInsideEnabled() {
        return this.mDrawInside;
    }

    public boolean isLegendCustom() {
        return this.mIsLegendCustom;
    }

    public boolean isWordWrapEnabled() {
        return this.mWordWrapEnabled;
    }

    public void resetCustom() {
        this.mIsLegendCustom = false;
    }

    public void setCustom(LegendEntry[] legendEntryArr) {
        this.mEntries = legendEntryArr;
        this.mIsLegendCustom = true;
    }

    public void setDirection(LegendDirection legendDirection) {
        this.mDirection = legendDirection;
    }

    public void setDrawInside(boolean z) {
        this.mDrawInside = z;
    }

    public void setEntries(List<LegendEntry> list) {
        this.mEntries = (LegendEntry[]) list.toArray(new LegendEntry[list.size()]);
    }

    public void setExtra(List<LegendEntry> list) {
        this.mExtraEntries = (LegendEntry[]) list.toArray(new LegendEntry[list.size()]);
    }

    public void setForm(LegendForm legendForm) {
        this.mShape = legendForm;
    }

    public void setFormLineDashEffect(DashPathEffect dashPathEffect) {
        this.mFormLineDashEffect = dashPathEffect;
    }

    public void setFormLineWidth(float f) {
        this.mFormLineWidth = f;
    }

    public void setFormSize(float f) {
        this.mFormSize = f;
    }

    public void setFormToTextSpace(float f) {
        this.mFormToTextSpace = f;
    }

    public void setHorizontalAlignment(LegendHorizontalAlignment legendHorizontalAlignment) {
        this.mHorizontalAlignment = legendHorizontalAlignment;
    }

    public void setMaxSizePercent(float f) {
        this.mMaxSizePercent = f;
    }

    public void setOrientation(LegendOrientation legendOrientation) {
        this.mOrientation = legendOrientation;
    }

    public void setStackSpace(float f) {
        this.mStackSpace = f;
    }

    public void setVerticalAlignment(LegendVerticalAlignment legendVerticalAlignment) {
        this.mVerticalAlignment = legendVerticalAlignment;
    }

    public void setWordWrapEnabled(boolean z) {
        this.mWordWrapEnabled = z;
    }

    public void setXEntrySpace(float f) {
        this.mXEntrySpace = f;
    }

    public void setYEntrySpace(float f) {
        this.mYEntrySpace = f;
    }

    public void setExtra(LegendEntry[] legendEntryArr) {
        if (legendEntryArr == null) {
            legendEntryArr = new LegendEntry[0];
        }
        this.mExtraEntries = legendEntryArr;
    }

    public void setCustom(List<LegendEntry> list) {
        this.mEntries = (LegendEntry[]) list.toArray(new LegendEntry[list.size()]);
        this.mIsLegendCustom = true;
    }

    public void setExtra(int[] iArr, String[] strArr) {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < Math.min(iArr.length, strArr.length); i++) {
            LegendEntry legendEntry = new LegendEntry();
            int i2 = iArr[i];
            legendEntry.formColor = i2;
            legendEntry.label = strArr[i];
            if (i2 == 1122868 || i2 == 0) {
                legendEntry.form = LegendForm.NONE;
            } else if (i2 == 1122867) {
                legendEntry.form = LegendForm.EMPTY;
            }
            arrayList.add(legendEntry);
        }
        this.mExtraEntries = (LegendEntry[]) arrayList.toArray(new LegendEntry[arrayList.size()]);
    }

    public Legend(LegendEntry[] legendEntryArr) {
        this();
        if (legendEntryArr != null) {
            this.mEntries = legendEntryArr;
            return;
        }
        throw new IllegalArgumentException("entries array is NULL");
    }
}
