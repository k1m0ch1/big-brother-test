package com.github.mikephil.charting.utils;

import android.content.res.Resources;
import android.graphics.Color;
import androidx.recyclerview.widget.RecyclerView;
import com.google.maps.android.R;
import java.util.ArrayList;
import java.util.List;
import kotlin.KotlinVersion;

public class ColorTemplate {
    public static final int[] COLORFUL_COLORS = {Color.rgb(193, 37, 82), Color.rgb((int) KotlinVersion.MAX_COMPONENT_VALUE, (int) R.styleable.AppCompatTheme_textAppearanceListItemSecondary, 0), Color.rgb(245, 199, 0), Color.rgb((int) R.styleable.AppCompatTheme_textAppearanceSearchResultTitle, 150, 31), Color.rgb(179, 100, 53)};
    public static final int COLOR_NONE = 1122867;
    public static final int COLOR_SKIP = 1122868;
    public static final int[] JOYFUL_COLORS = {Color.rgb(217, 80, 138), Color.rgb(254, 149, 7), Color.rgb(254, 247, (int) R.styleable.AppCompatTheme_windowFixedWidthMajor), Color.rgb((int) R.styleable.AppCompatTheme_textAppearanceSearchResultTitle, 167, 134), Color.rgb(53, 194, 209)};
    public static final int[] LIBERTY_COLORS = {Color.rgb(207, 248, 246), Color.rgb(148, 212, 212), Color.rgb(136, 180, 187), Color.rgb((int) R.styleable.AppCompatTheme_windowFixedHeightMajor, 174, 175), Color.rgb(42, (int) R.styleable.AppCompatTheme_textColorSearchUrl, 130)};
    public static final int[] MATERIAL_COLORS = {rgb("#2ecc71"), rgb("#f1c40f"), rgb("#e74c3c"), rgb("#3498db")};
    public static final int[] PASTEL_COLORS = {Color.rgb(64, 89, (int) RecyclerView.b0.FLAG_IGNORE), Color.rgb(149, 165, (int) R.styleable.AppCompatTheme_windowNoTitle), Color.rgb(217, 184, 162), Color.rgb(191, 134, 134), Color.rgb(179, 48, 80)};
    public static final int[] VORDIPLOM_COLORS = {Color.rgb(192, (int) KotlinVersion.MAX_COMPONENT_VALUE, 140), Color.rgb((int) KotlinVersion.MAX_COMPONENT_VALUE, 247, 140), Color.rgb((int) KotlinVersion.MAX_COMPONENT_VALUE, 208, 140), Color.rgb(140, 234, (int) KotlinVersion.MAX_COMPONENT_VALUE), Color.rgb((int) KotlinVersion.MAX_COMPONENT_VALUE, 140, 157)};

    public static int colorWithAlpha(int i, int i2) {
        return (i & 16777215) | ((i2 & KotlinVersion.MAX_COMPONENT_VALUE) << 24);
    }

    public static List<Integer> createColors(Resources resources, int[] iArr) {
        ArrayList arrayList = new ArrayList();
        for (int i : iArr) {
            arrayList.add(Integer.valueOf(resources.getColor(i)));
        }
        return arrayList;
    }

    public static int getHoloBlue() {
        return Color.rgb(51, 181, 229);
    }

    public static int rgb(String str) {
        int parseLong = (int) Long.parseLong(str.replace("#", ""), 16);
        return Color.rgb((parseLong >> 16) & KotlinVersion.MAX_COMPONENT_VALUE, (parseLong >> 8) & KotlinVersion.MAX_COMPONENT_VALUE, (parseLong >> 0) & KotlinVersion.MAX_COMPONENT_VALUE);
    }

    public static List<Integer> createColors(int[] iArr) {
        ArrayList arrayList = new ArrayList();
        for (int i : iArr) {
            arrayList.add(Integer.valueOf(i));
        }
        return arrayList;
    }
}
