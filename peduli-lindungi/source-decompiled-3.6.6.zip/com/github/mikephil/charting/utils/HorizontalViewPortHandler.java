package com.github.mikephil.charting.utils;

public class HorizontalViewPortHandler extends ViewPortHandler {
}
