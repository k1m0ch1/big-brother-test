package com.github.razir.progressbutton;

import android.widget.TextView;
import defpackage.sr;
import java.lang.ref.WeakReference;
import kotlin.Metadata;

@Metadata(bv = {1, 0, 3}, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0002\u0018\u00002\u00020\u0001B\u0015\u0012\f\u0010\r\u001a\b\u0012\u0004\u0012\u00020\n0\t¢\u0006\u0004\b\u000e\u0010\u000fJ\u001f\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0007\u0010\bR\u001c\u0010\r\u001a\b\u0012\u0004\u0012\u00020\n0\t8\u0002@\u0002X\u0004¢\u0006\u0006\n\u0004\b\u000b\u0010\f¨\u0006\u0010"}, d2 = {"Lcom/github/razir/progressbutton/ProgressButtonHolder;", "Lwr;", "Lyr;", "source", "Lsr$a;", "event", "", "c", "(Lyr;Lsr$a;)V", "Ljava/lang/ref/WeakReference;", "Landroid/widget/TextView;", "g", "Ljava/lang/ref/WeakReference;", "textView", "<init>", "(Ljava/lang/ref/WeakReference;)V", "progressbutton_release"}, k = 1, mv = {1, 4, 0})
/* compiled from: ProgressButtonHolder.kt */
public final class ProgressButtonHolder implements wr {
    public final WeakReference<TextView> g;

    public ProgressButtonHolder(WeakReference<TextView> weakReference) {
        a56.f(weakReference, "textView");
        this.g = weakReference;
    }

    @Override // defpackage.wr
    public void c(yr yrVar, sr.a aVar) {
        TextView textView;
        a56.f(yrVar, "source");
        a56.f(aVar, "event");
        if (aVar == sr.a.ON_DESTROY && (textView = this.g.get()) != null) {
            a56.b(textView, "it");
            w70.g(textView);
            zr0.b(textView);
            a56.f(textView, "$this$removeTextAnimationAttachViewListener");
            textView.removeOnAttachStateChangeListener(zr0.d);
            textView.removeOnAttachStateChangeListener(zr0.e);
            zr0.a.remove(textView);
        }
    }
}
