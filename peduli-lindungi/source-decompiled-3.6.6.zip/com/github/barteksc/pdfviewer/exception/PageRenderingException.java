package com.github.barteksc.pdfviewer.exception;

public class PageRenderingException extends Exception {
}
