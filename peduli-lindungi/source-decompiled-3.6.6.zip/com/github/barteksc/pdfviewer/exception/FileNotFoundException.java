package com.github.barteksc.pdfviewer.exception;

@Deprecated
public class FileNotFoundException extends RuntimeException {
}
