package com.github.barteksc.pdfviewer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PaintFlagsDrawFilter;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.os.HandlerThread;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.widget.RelativeLayout;
import com.github.mikephil.charting.utils.Utils;
import com.shockwave.pdfium.PdfiumCore;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

public class PDFView extends RelativeLayout {
    public Paint A;
    public Paint B;
    public int C = -1;
    public boolean D = true;
    public PdfiumCore E;
    public qr0 F;
    public boolean G = true;
    public PaintFlagsDrawFilter H = new PaintFlagsDrawFilter(0, 3);
    public int I = 0;
    public List<Integer> J = new ArrayList(10);
    public float g = 1.0f;
    public float h = 1.75f;
    public float i = 3.0f;
    public a j = a.NONE;
    public hr0 k;
    public gr0 l;
    public int m;
    public float n;
    public float o;
    public float p = Utils.FLOAT_EPSILON;
    public float q = Utils.FLOAT_EPSILON;
    public float r = 1.0f;
    public boolean s = true;
    public b t = b.DEFAULT;
    public kr0 u;
    public mr0 v;
    public jr0 w;
    public jr0 x;
    public nr0 y;
    public or0 z;

    public enum a {
        NONE,
        START,
        END
    }

    public enum b {
        DEFAULT,
        LOADED,
        SHOWN,
        ERROR
    }

    public PDFView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        new HandlerThread("PDF renderer");
        if (!isInEditMode()) {
            this.k = new hr0();
            gr0 gr0 = new gr0(this);
            this.l = gr0;
            new ir0(this, gr0);
            this.A = new Paint();
            Paint paint = new Paint();
            this.B = paint;
            paint.setStyle(Paint.Style.STROKE);
            this.E = new PdfiumCore(context);
            setWillNotDraw(false);
        }
    }

    private void setDefaultPage(int i2) {
    }

    private void setInvalidPageColor(int i2) {
        this.C = i2;
    }

    private void setOnDrawAllListener(jr0 jr0) {
        this.x = jr0;
    }

    private void setOnDrawListener(jr0 jr0) {
        this.w = jr0;
    }

    private void setOnPageChangeListener(kr0 kr0) {
        this.u = kr0;
    }

    private void setOnPageErrorListener(lr0 lr0) {
    }

    private void setOnPageScrollListener(mr0 mr0) {
        this.v = mr0;
    }

    private void setOnRenderListener(nr0 nr0) {
        this.y = nr0;
    }

    private void setOnTapListener(or0 or0) {
        this.z = or0;
    }

    private void setScrollHandle(qr0 qr0) {
        this.F = qr0;
    }

    private void setSpacing(int i2) {
        this.I = (int) TypedValue.applyDimension(1, (float) i2, getContext().getResources().getDisplayMetrics());
    }

    public float a() {
        int pageCount = getPageCount();
        if (this.D) {
            return ((((float) pageCount) * this.o) + ((float) ((pageCount - 1) * this.I))) * this.r;
        }
        return ((((float) pageCount) * this.n) + ((float) ((pageCount - 1) * this.I))) * this.r;
    }

    public final float b(int i2) {
        if (this.D) {
            return ((((float) i2) * this.o) + ((float) (i2 * this.I))) * this.r;
        }
        return ((((float) i2) * this.n) + ((float) (i2 * this.I))) * this.r;
    }

    public boolean c() {
        int pageCount = getPageCount();
        int i2 = (pageCount - 1) * this.I;
        if (this.D) {
            if ((((float) pageCount) * this.o) + ((float) i2) < ((float) getHeight())) {
                return true;
            }
            return false;
        } else if ((((float) pageCount) * this.n) + ((float) i2) < ((float) getWidth())) {
            return true;
        } else {
            return false;
        }
    }

    public boolean canScrollHorizontally(int i2) {
        if (this.D) {
            if (i2 < 0 && this.p < Utils.FLOAT_EPSILON) {
                return true;
            }
            if (i2 <= 0 || this.p + (this.n * this.r) <= ((float) getWidth())) {
                return false;
            }
            return true;
        } else if (i2 < 0 && this.p < Utils.FLOAT_EPSILON) {
            return true;
        } else {
            if (i2 <= 0) {
                return false;
            }
            if (a() + this.p > ((float) getWidth())) {
                return true;
            }
            return false;
        }
    }

    public boolean canScrollVertically(int i2) {
        if (this.D) {
            if (i2 < 0 && this.q < Utils.FLOAT_EPSILON) {
                return true;
            }
            if (i2 <= 0) {
                return false;
            }
            if (a() + this.q > ((float) getHeight())) {
                return true;
            }
            return false;
        } else if (i2 < 0 && this.q < Utils.FLOAT_EPSILON) {
            return true;
        } else {
            if (i2 <= 0 || this.q + (this.o * this.r) <= ((float) getHeight())) {
                return false;
            }
            return true;
        }
    }

    public void computeScroll() {
        super.computeScroll();
        if (!isInEditMode()) {
            gr0 gr0 = this.l;
            if (gr0.c.computeScrollOffset()) {
                gr0.a.g((float) gr0.c.getCurrX(), (float) gr0.c.getCurrY(), true);
                gr0.a.e();
            } else if (gr0.d) {
                gr0.d = false;
                gr0.a.f();
                if (gr0.a.getScrollHandle() != null) {
                    gr0.a.getScrollHandle().c();
                }
            }
        }
    }

    public final void d(Canvas canvas, int i2, jr0 jr0) {
        float f;
        if (jr0 != null) {
            boolean z2 = this.D;
            float f2 = Utils.FLOAT_EPSILON;
            if (z2) {
                f = b(i2);
            } else {
                f2 = b(i2);
                f = Utils.FLOAT_EPSILON;
            }
            canvas.translate(f2, f);
            float f3 = this.n;
            float f4 = this.r;
            jr0.a(canvas, f3 * f4, this.o * f4, i2);
            canvas.translate(-f2, -f);
        }
    }

    public void e() {
        float f;
        float f2;
        int i2;
        if (getPageCount() != 0) {
            int i3 = this.I;
            float pageCount = (float) (i3 - (i3 / getPageCount()));
            if (this.D) {
                f2 = this.q;
                f = this.o + pageCount;
                i2 = getHeight();
            } else {
                f2 = this.p;
                f = this.n + pageCount;
                i2 = getWidth();
            }
            int floor = (int) Math.floor((double) ((Math.abs(f2) + (((float) i2) / 2.0f)) / (f * this.r)));
            if (floor >= 0 && floor <= getPageCount() - 1 && floor != getCurrentPage() && !this.s) {
                if (floor <= 0) {
                    floor = 0;
                } else if (floor >= 0) {
                    floor = -1;
                }
                this.m = floor;
                if (this.F != null && !c()) {
                    this.F.a(this.m + 1);
                }
                kr0 kr0 = this.u;
                if (kr0 != null) {
                    kr0.a(this.m, getPageCount());
                }
            }
        }
    }

    public void f() {
        int i2 = (this.n > Utils.FLOAT_EPSILON ? 1 : (this.n == Utils.FLOAT_EPSILON ? 0 : -1));
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x0049  */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x0051  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x006f  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0073  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x00bb  */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x00c3  */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x00e1  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x00e4  */
    public void g(float f, float f2, boolean z2) {
        float a2;
        float f3;
        float f4;
        float a3;
        float f5;
        float f6;
        a aVar = a.START;
        a aVar2 = a.NONE;
        a aVar3 = a.END;
        if (this.D) {
            float f7 = this.n * this.r;
            if (f7 < ((float) getWidth())) {
                f6 = (float) (getWidth() / 2);
                f7 /= 2.0f;
            } else {
                if (f > Utils.FLOAT_EPSILON) {
                    f = Utils.FLOAT_EPSILON;
                } else if (f + f7 < ((float) getWidth())) {
                    f6 = (float) getWidth();
                }
                a3 = a();
                if (a3 >= ((float) getHeight())) {
                    f2 = (((float) getHeight()) - a3) / 2.0f;
                } else if (f2 > Utils.FLOAT_EPSILON) {
                    f2 = Utils.FLOAT_EPSILON;
                } else if (f2 + a3 < ((float) getHeight())) {
                    f2 = (-a3) + ((float) getHeight());
                }
                f5 = this.q;
                if (f2 >= f5) {
                    this.j = aVar3;
                } else if (f2 > f5) {
                    this.j = aVar;
                } else {
                    this.j = aVar2;
                }
            }
            f = f6 - f7;
            a3 = a();
            if (a3 >= ((float) getHeight())) {
            }
            f5 = this.q;
            if (f2 >= f5) {
            }
        } else {
            float f8 = this.o * this.r;
            if (f8 < ((float) getHeight())) {
                f4 = (float) (getHeight() / 2);
                f8 /= 2.0f;
            } else {
                if (f2 > Utils.FLOAT_EPSILON) {
                    f2 = Utils.FLOAT_EPSILON;
                } else if (f2 + f8 < ((float) getHeight())) {
                    f4 = (float) getHeight();
                }
                a2 = a();
                if (a2 >= ((float) getWidth())) {
                    f = (((float) getWidth()) - a2) / 2.0f;
                } else if (f > Utils.FLOAT_EPSILON) {
                    f = Utils.FLOAT_EPSILON;
                } else if (f + a2 < ((float) getWidth())) {
                    f = (-a2) + ((float) getWidth());
                }
                f3 = this.p;
                if (f >= f3) {
                    this.j = aVar3;
                } else if (f > f3) {
                    this.j = aVar;
                } else {
                    this.j = aVar2;
                }
            }
            f2 = f4 - f8;
            a2 = a();
            if (a2 >= ((float) getWidth())) {
            }
            f3 = this.p;
            if (f >= f3) {
            }
        }
        this.p = f;
        this.q = f2;
        float positionOffset = getPositionOffset();
        if (z2 && this.F != null && !c()) {
            this.F.e(positionOffset);
        }
        mr0 mr0 = this.v;
        if (mr0 != null) {
            mr0.a(getCurrentPage(), positionOffset);
        }
        invalidate();
    }

    public int getCurrentPage() {
        return this.m;
    }

    public float getCurrentXOffset() {
        return this.p;
    }

    public float getCurrentYOffset() {
        return this.q;
    }

    public tp3 getDocumentMeta() {
        return null;
    }

    public int getDocumentPageCount() {
        return 0;
    }

    public int[] getFilteredUserPageIndexes() {
        return null;
    }

    public int[] getFilteredUserPages() {
        return null;
    }

    public int getInvalidPageColor() {
        return this.C;
    }

    public float getMaxZoom() {
        return this.i;
    }

    public float getMidZoom() {
        return this.h;
    }

    public float getMinZoom() {
        return this.g;
    }

    public kr0 getOnPageChangeListener() {
        return this.u;
    }

    public mr0 getOnPageScrollListener() {
        return this.v;
    }

    public nr0 getOnRenderListener() {
        return this.y;
    }

    public or0 getOnTapListener() {
        return this.z;
    }

    public float getOptimalPageHeight() {
        return this.o;
    }

    public float getOptimalPageWidth() {
        return this.n;
    }

    public int[] getOriginalUserPages() {
        return null;
    }

    public int getPageCount() {
        return 0;
    }

    public float getPositionOffset() {
        int i2;
        float f;
        float f2;
        if (this.D) {
            f2 = -this.q;
            f = a();
            i2 = getHeight();
        } else {
            f2 = -this.p;
            f = a();
            i2 = getWidth();
        }
        float f3 = f2 / (f - ((float) i2));
        if (f3 <= Utils.FLOAT_EPSILON) {
            return Utils.FLOAT_EPSILON;
        }
        if (f3 >= 1.0f) {
            return 1.0f;
        }
        return f3;
    }

    public a getScrollDir() {
        return this.j;
    }

    public qr0 getScrollHandle() {
        return this.F;
    }

    public int getSpacingPx() {
        return this.I;
    }

    public List<Object> getTableOfContents() {
        return new ArrayList();
    }

    public float getZoom() {
        return this.r;
    }

    public void h(float f, PointF pointF) {
        float f2 = f / this.r;
        this.r = f;
        float f3 = this.q * f2;
        float f4 = pointF.x;
        float f5 = (f4 - (f4 * f2)) + (this.p * f2);
        float f6 = pointF.y;
        g(f5, (f6 - (f2 * f6)) + f3, true);
    }

    public void onDetachedFromWindow() {
        this.l.b();
        hr0 hr0 = this.k;
        synchronized (hr0.d) {
            Iterator<pr0> it = hr0.a.iterator();
            if (!it.hasNext()) {
                hr0.a.clear();
                Iterator<pr0> it2 = hr0.b.iterator();
                if (!it2.hasNext()) {
                    hr0.b.clear();
                } else {
                    Objects.requireNonNull(it2.next());
                    throw null;
                }
            } else {
                Objects.requireNonNull(it.next());
                throw null;
            }
        }
        synchronized (hr0.c) {
            Iterator<pr0> it3 = hr0.c.iterator();
            if (!it3.hasNext()) {
                hr0.c.clear();
            } else {
                Objects.requireNonNull(it3.next());
                throw null;
            }
        }
        this.F = null;
        this.q = Utils.FLOAT_EPSILON;
        this.p = Utils.FLOAT_EPSILON;
        this.r = 1.0f;
        this.s = true;
        this.t = b.DEFAULT;
        super.onDetachedFromWindow();
    }

    public void onDraw(Canvas canvas) {
        List<pr0> list;
        ArrayList arrayList;
        if (!isInEditMode()) {
            if (this.G) {
                canvas.setDrawFilter(this.H);
            }
            Drawable background = getBackground();
            if (background == null) {
                canvas.drawColor(-1);
            } else {
                background.draw(canvas);
            }
            if (!this.s && this.t == b.SHOWN) {
                float f = this.p;
                float f2 = this.q;
                canvas.translate(f, f2);
                hr0 hr0 = this.k;
                synchronized (hr0.c) {
                    list = hr0.c;
                }
                Iterator<pr0> it = list.iterator();
                if (!it.hasNext()) {
                    hr0 hr02 = this.k;
                    synchronized (hr02.d) {
                        arrayList = new ArrayList(hr02.a);
                        arrayList.addAll(hr02.b);
                    }
                    Iterator it2 = arrayList.iterator();
                    if (!it2.hasNext()) {
                        for (Integer num : this.J) {
                            d(canvas, num.intValue(), this.x);
                        }
                        this.J.clear();
                        d(canvas, this.m, this.w);
                        canvas.translate(-f, -f2);
                        return;
                    }
                    Objects.requireNonNull((pr0) it2.next());
                    throw null;
                }
                Objects.requireNonNull(it.next());
                throw null;
            }
        }
    }

    public void onSizeChanged(int i2, int i3, int i4, int i5) {
        if (!isInEditMode() && this.t == b.SHOWN) {
            this.l.b();
            if (!(this.t == b.DEFAULT || getWidth() == 0)) {
                float width = (float) getWidth();
                float height = (float) getHeight();
                float f = (float) 0;
                float f2 = f / f;
                float floor = (float) Math.floor((double) (width / f2));
                if (floor > height) {
                    width = (float) Math.floor((double) (f2 * height));
                } else {
                    height = floor;
                }
                this.n = width;
                this.o = height;
            }
            if (this.D) {
                g(this.p, -b(this.m), true);
            } else {
                g(-b(this.m), this.q, true);
            }
            e();
        }
    }

    public void setMaxZoom(float f) {
        this.i = f;
    }

    public void setMidZoom(float f) {
        this.h = f;
    }

    public void setMinZoom(float f) {
        this.g = f;
    }

    public void setPositionOffset(float f) {
        if (this.D) {
            g(this.p, ((-a()) + ((float) getHeight())) * f, true);
        } else {
            g(((-a()) + ((float) getWidth())) * f, this.q, true);
        }
        e();
    }

    public void setSwipeVertical(boolean z2) {
        this.D = z2;
    }
}
