package com.dpizarro.uipicker.library.picker;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.telkom.tracencare.R;
import java.util.Arrays;
import java.util.List;

public class PickerUIListView extends ListView {
    public static final /* synthetic */ int m = 0;
    public br0 g;
    public boolean h = false;
    public int i;
    public int j;
    public int k;
    public List<String> l;

    public PickerUIListView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        if (isInEditMode()) {
            String[] strArr = new String[10];
            for (int i2 = 0; i2 < 10; i2++) {
                strArr[i2] = ze0.j0("item ", i2);
            }
            List asList = Arrays.asList(strArr);
            br0 br0 = new br0(context, R.layout.pickerui_item, asList, asList.size() / 2, true, true);
            this.g = br0;
            setAdapter((ListAdapter) br0);
            setSelection(asList.size() / 2);
            return;
        }
        this.l = this.l;
        getViewTreeObserver().addOnGlobalLayoutListener(new cr0(this));
        setOnScrollListener(new dr0(this));
        setOnItemClickListener(new er0(this));
    }

    public int a() {
        int pointToPosition = pointToPosition(getWidth() / 2, getHeight() / 2);
        if (!(pointToPosition == -1 || pointToPosition == this.i)) {
            this.i = pointToPosition;
            br0 br0 = this.g;
            br0.i = pointToPosition;
            br0.notifyDataSetChanged();
        }
        return pointToPosition - 2;
    }
}
