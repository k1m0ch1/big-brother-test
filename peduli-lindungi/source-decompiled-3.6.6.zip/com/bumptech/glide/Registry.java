package com.bumptech.glide;

import com.bumptech.glide.load.ImageHeaderParser;
import defpackage.al0;
import defpackage.cl0;
import defpackage.cq0;
import defpackage.po0;
import defpackage.rn0;
import defpackage.to0;
import defpackage.uo0;
import defpackage.wh0;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

public class Registry {
    public final al0 a;
    public final po0 b;
    public final to0 c;
    public final uo0 d;
    public final xh0 e;
    public final rn0 f;
    public final qo0 g;
    public final so0 h = new so0();
    public final ro0 i = new ro0();
    public final in<List<Throwable>> j;

    public static class MissingComponentException extends RuntimeException {
        public MissingComponentException(String str) {
            super(str);
        }
    }

    public static final class NoImageHeaderParserException extends MissingComponentException {
        public NoImageHeaderParserException() {
            super("Failed to find image header parser.");
        }
    }

    public static class NoModelLoaderAvailableException extends MissingComponentException {
        /* JADX WARNING: Illegal instructions before constructor call */
        public NoModelLoaderAvailableException(Object obj) {
            super(r0.toString());
            StringBuilder J0 = ze0.J0("Failed to find any ModelLoaders registered for model class: ");
            J0.append(obj.getClass());
        }

        public <M> NoModelLoaderAvailableException(M m, List<yk0<M, ?>> list) {
            super("Found ModelLoaders for model class: " + list + ", but none that handle this specific model instance: " + ((Object) m));
        }

        public NoModelLoaderAvailableException(Class<?> cls, Class<?> cls2) {
            super("Failed to find any ModelLoaders for model: " + cls + " and data: " + cls2);
        }
    }

    public static class NoResultEncoderAvailableException extends MissingComponentException {
        public NoResultEncoderAvailableException(Class<?> cls) {
            super("Failed to find result encoder for resource class: " + cls + ", you may need to consider registering a new Encoder for the requested type or DiskCacheStrategy.DATA/DiskCacheStrategy.NONE if caching your transformed resource is unnecessary.");
        }
    }

    public static class NoSourceEncoderAvailableException extends MissingComponentException {
        public NoSourceEncoderAvailableException(Class<?> cls) {
            super("Failed to find source encoder for data class: " + cls);
        }
    }

    public Registry() {
        cq0.c cVar = new cq0.c(new kn(20), new dq0(), new eq0());
        this.j = cVar;
        this.a = new al0(cVar);
        this.b = new po0();
        to0 to0 = new to0();
        this.c = to0;
        this.d = new uo0();
        this.e = new xh0();
        this.f = new rn0();
        this.g = new qo0();
        List asList = Arrays.asList("Gif", "Bitmap", "BitmapDrawable");
        ArrayList arrayList = new ArrayList(asList.size());
        arrayList.addAll(asList);
        arrayList.add(0, "legacy_prepend_all");
        arrayList.add("legacy_append");
        synchronized (to0) {
            ArrayList arrayList2 = new ArrayList(to0.a);
            to0.a.clear();
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                to0.a.add((String) it.next());
            }
            Iterator it2 = arrayList2.iterator();
            while (it2.hasNext()) {
                String str = (String) it2.next();
                if (!arrayList.contains(str)) {
                    to0.a.add(str);
                }
            }
        }
    }

    public <Data> Registry a(Class<Data> cls, dh0<Data> dh0) {
        po0 po0 = this.b;
        synchronized (po0) {
            po0.a.add(new po0.a<>(cls, dh0));
        }
        return this;
    }

    public <TResource> Registry b(Class<TResource> cls, qh0<TResource> qh0) {
        uo0 uo0 = this.d;
        synchronized (uo0) {
            uo0.a.add(new uo0.a<>(cls, qh0));
        }
        return this;
    }

    public <Model, Data> Registry c(Class<Model> cls, Class<Data> cls2, zk0<Model, Data> zk0) {
        al0 al0 = this.a;
        synchronized (al0) {
            cl0 cl0 = al0.a;
            synchronized (cl0) {
                cl0.b<?, ?> bVar = new cl0.b<>(cls, cls2, zk0);
                List<cl0.b<?, ?>> list = cl0.a;
                list.add(list.size(), bVar);
            }
            al0.b.a.clear();
        }
        return this;
    }

    public <Data, TResource> Registry d(String str, Class<Data> cls, Class<TResource> cls2, ph0<Data, TResource> ph0) {
        to0 to0 = this.c;
        synchronized (to0) {
            to0.a(str).add(new to0.a<>(cls, cls2, ph0));
        }
        return this;
    }

    public List<ImageHeaderParser> e() {
        List<ImageHeaderParser> list;
        qo0 qo0 = this.g;
        synchronized (qo0) {
            list = qo0.a;
        }
        if (!list.isEmpty()) {
            return list;
        }
        throw new NoImageHeaderParserException();
    }

    public <Model> List<yk0<Model, ?>> f(Model model) {
        List<yk0<Model, ?>> list;
        al0 al0 = this.a;
        Objects.requireNonNull(al0);
        Class<?> cls = model.getClass();
        synchronized (al0) {
            al0.a.C0000a<?> aVar = al0.b.a.get(cls);
            if (aVar == null) {
                list = null;
            } else {
                list = aVar.a;
            }
            if (list == null) {
                list = Collections.unmodifiableList(al0.a.c(cls));
                if (al0.b.a.put(cls, new al0.a.C0000a<>(list)) != null) {
                    throw new IllegalStateException("Already cached loaders for model: " + cls);
                }
            }
        }
        if (!list.isEmpty()) {
            int size = list.size();
            List<yk0<Model, ?>> emptyList = Collections.emptyList();
            boolean z = true;
            for (int i2 = 0; i2 < size; i2++) {
                yk0<Model, ?> yk0 = list.get(i2);
                if (yk0.b(model)) {
                    if (z) {
                        emptyList = new ArrayList<>(size - i2);
                        z = false;
                    }
                    emptyList.add(yk0);
                }
            }
            if (!emptyList.isEmpty()) {
                return emptyList;
            }
            throw new NoModelLoaderAvailableException(model, list);
        }
        throw new NoModelLoaderAvailableException(model);
    }

    public Registry g(wh0.a<?> aVar) {
        xh0 xh0 = this.e;
        synchronized (xh0) {
            xh0.a.put(aVar.a(), aVar);
        }
        return this;
    }

    public <TResource, Transcode> Registry h(Class<TResource> cls, Class<Transcode> cls2, qn0<TResource, Transcode> qn0) {
        rn0 rn0 = this.f;
        synchronized (rn0) {
            rn0.a.add(new rn0.a<>(cls, cls2, qn0));
        }
        return this;
    }
}
