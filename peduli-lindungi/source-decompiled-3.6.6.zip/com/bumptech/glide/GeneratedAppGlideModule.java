package com.bumptech.glide;

import java.util.Set;

public abstract class GeneratedAppGlideModule extends jo0 {
    public abstract Set<Class<?>> c();
}
