package com.bumptech.glide.load;

import java.io.InputStream;
import java.nio.ByteBuffer;

public interface ImageHeaderParser {

    public enum ImageType {
        GIF(true),
        JPEG(false),
        RAW(false),
        PNG_A(true),
        PNG(false),
        WEBP_A(true),
        WEBP(false),
        UNKNOWN(false);
        
        public final boolean g;

        /* access modifiers changed from: public */
        ImageType(boolean z) {
            this.g = z;
        }

        public boolean hasAlpha() {
            return this.g;
        }
    }

    ImageType a(ByteBuffer byteBuffer);

    int b(InputStream inputStream, nj0 nj0);

    ImageType c(InputStream inputStream);
}
