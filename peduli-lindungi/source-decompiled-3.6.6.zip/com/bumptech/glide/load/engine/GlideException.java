package com.bumptech.glide.load.engine;

import android.util.Log;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public final class GlideException extends Exception {
    public static final StackTraceElement[] l = new StackTraceElement[0];
    public final List<Throwable> g;
    public lh0 h;
    public ah0 i;
    public Class<?> j;
    public String k;

    public GlideException(String str) {
        List<Throwable> emptyList = Collections.emptyList();
        this.k = str;
        setStackTrace(l);
        this.g = emptyList;
    }

    public static void b(List<Throwable> list, Appendable appendable) {
        try {
            c(list, appendable);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void c(List<Throwable> list, Appendable appendable) {
        int size = list.size();
        int i2 = 0;
        while (i2 < size) {
            int i3 = i2 + 1;
            appendable.append("Cause (").append(String.valueOf(i3)).append(" of ").append(String.valueOf(size)).append("): ");
            Throwable th = list.get(i2);
            if (th instanceof GlideException) {
                ((GlideException) th).f(appendable);
            } else {
                d(th, appendable);
            }
            i2 = i3;
        }
    }

    public static void d(Throwable th, Appendable appendable) {
        try {
            appendable.append(th.getClass().toString()).append(": ").append(th.getMessage()).append('\n');
        } catch (IOException unused) {
            throw new RuntimeException(th);
        }
    }

    public final void a(Throwable th, List<Throwable> list) {
        if (th instanceof GlideException) {
            for (Throwable th2 : ((GlideException) th).g) {
                a(th2, list);
            }
            return;
        }
        list.add(th);
    }

    public void e(String str) {
        ArrayList arrayList = new ArrayList();
        a(this, arrayList);
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            StringBuilder J0 = ze0.J0("Root cause (");
            int i3 = i2 + 1;
            J0.append(i3);
            J0.append(" of ");
            J0.append(size);
            J0.append(")");
            Log.i(str, J0.toString(), (Throwable) arrayList.get(i2));
            i2 = i3;
        }
    }

    public final void f(Appendable appendable) {
        d(this, appendable);
        b(this.g, new a(appendable));
    }

    public Throwable fillInStackTrace() {
        return this;
    }

    public String getMessage() {
        String str;
        String str2;
        StringBuilder sb = new StringBuilder(71);
        sb.append(this.k);
        String str3 = "";
        if (this.j != null) {
            StringBuilder J0 = ze0.J0(", ");
            J0.append(this.j);
            str = J0.toString();
        } else {
            str = str3;
        }
        sb.append(str);
        if (this.i != null) {
            StringBuilder J02 = ze0.J0(", ");
            J02.append(this.i);
            str2 = J02.toString();
        } else {
            str2 = str3;
        }
        sb.append(str2);
        if (this.h != null) {
            StringBuilder J03 = ze0.J0(", ");
            J03.append(this.h);
            str3 = J03.toString();
        }
        sb.append(str3);
        ArrayList arrayList = new ArrayList();
        a(this, arrayList);
        if (arrayList.isEmpty()) {
            return sb.toString();
        }
        if (arrayList.size() == 1) {
            sb.append("\nThere was 1 cause:");
        } else {
            sb.append("\nThere were ");
            sb.append(arrayList.size());
            sb.append(" causes:");
        }
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            Throwable th = (Throwable) it.next();
            sb.append('\n');
            sb.append(th.getClass().getName());
            sb.append('(');
            sb.append(th.getMessage());
            sb.append(')');
        }
        sb.append("\n call GlideException#logRootCauses(String) for more detail");
        return sb.toString();
    }

    public void printStackTrace() {
        f(System.err);
    }

    @Override // java.lang.Throwable
    public void printStackTrace(PrintStream printStream) {
        f(printStream);
    }

    @Override // java.lang.Throwable
    public void printStackTrace(PrintWriter printWriter) {
        f(printWriter);
    }

    public static final class a implements Appendable {
        public final Appendable g;
        public boolean h = true;

        public a(Appendable appendable) {
            this.g = appendable;
        }

        @Override // java.lang.Appendable
        public Appendable append(char c) {
            boolean z = false;
            if (this.h) {
                this.h = false;
                this.g.append("  ");
            }
            if (c == '\n') {
                z = true;
            }
            this.h = z;
            this.g.append(c);
            return this;
        }

        @Override // java.lang.Appendable
        public Appendable append(CharSequence charSequence) {
            if (charSequence == null) {
                charSequence = "";
            }
            append(charSequence, 0, charSequence.length());
            return this;
        }

        @Override // java.lang.Appendable
        public Appendable append(CharSequence charSequence, int i, int i2) {
            if (charSequence == null) {
                charSequence = "";
            }
            boolean z = false;
            if (this.h) {
                this.h = false;
                this.g.append("  ");
            }
            if (charSequence.length() > 0 && charSequence.charAt(i2 - 1) == '\n') {
                z = true;
            }
            this.h = z;
            this.g.append(charSequence, i, i2);
            return this;
        }
    }

    public GlideException(String str, Throwable th) {
        List<Throwable> singletonList = Collections.singletonList(th);
        this.k = str;
        setStackTrace(l);
        this.g = singletonList;
    }

    public GlideException(String str, List<Throwable> list) {
        this.k = str;
        setStackTrace(l);
        this.g = list;
    }
}
