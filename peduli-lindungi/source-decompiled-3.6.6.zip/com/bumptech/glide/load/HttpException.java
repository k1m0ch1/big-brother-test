package com.bumptech.glide.load;

import java.io.IOException;

public final class HttpException extends IOException {
    public HttpException(int i) {
        super(ze0.j0("Http request failed with status code: ", i), null);
    }

    public HttpException(String str) {
        super(str, null);
    }

    public HttpException(String str, int i) {
        super(str, null);
    }
}
