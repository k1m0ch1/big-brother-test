package com.bumptech.glide.load.resource.bitmap;

import android.util.Log;
import com.bumptech.glide.load.ImageHeaderParser;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.util.Objects;
import kotlin.KotlinVersion;
import kotlin.UByte;

public final class DefaultImageHeaderParser implements ImageHeaderParser {
    public static final byte[] a = "Exif\u0000\u0000".getBytes(Charset.forName("UTF-8"));
    public static final int[] b = {0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 8, 4, 8};

    public interface Reader {

        public static final class EndOfFileException extends IOException {
            public EndOfFileException() {
                super("Unexpectedly reached end of a file");
            }
        }

        long b(long j);

        int c(byte[] bArr, int i);

        short d();

        int e();
    }

    public static final class a implements Reader {
        public final ByteBuffer a;

        public a(ByteBuffer byteBuffer) {
            this.a = byteBuffer;
            byteBuffer.order(ByteOrder.BIG_ENDIAN);
        }

        @Override // com.bumptech.glide.load.resource.bitmap.DefaultImageHeaderParser.Reader
        public long b(long j) {
            int min = (int) Math.min((long) this.a.remaining(), j);
            ByteBuffer byteBuffer = this.a;
            byteBuffer.position(byteBuffer.position() + min);
            return (long) min;
        }

        @Override // com.bumptech.glide.load.resource.bitmap.DefaultImageHeaderParser.Reader
        public int c(byte[] bArr, int i) {
            int min = Math.min(i, this.a.remaining());
            if (min == 0) {
                return -1;
            }
            this.a.get(bArr, 0, min);
            return min;
        }

        @Override // com.bumptech.glide.load.resource.bitmap.DefaultImageHeaderParser.Reader
        public short d() {
            if (this.a.remaining() >= 1) {
                return (short) (this.a.get() & UByte.MAX_VALUE);
            }
            throw new Reader.EndOfFileException();
        }

        @Override // com.bumptech.glide.load.resource.bitmap.DefaultImageHeaderParser.Reader
        public int e() {
            return (d() << 8) | d();
        }
    }

    public static final class b {
        public final ByteBuffer a;

        public b(byte[] bArr, int i) {
            this.a = (ByteBuffer) ByteBuffer.wrap(bArr).order(ByteOrder.BIG_ENDIAN).limit(i);
        }

        public short a(int i) {
            if (this.a.remaining() - i >= 2) {
                return this.a.getShort(i);
            }
            return -1;
        }

        public int b(int i) {
            if (this.a.remaining() - i >= 4) {
                return this.a.getInt(i);
            }
            return -1;
        }
    }

    public static final class c implements Reader {
        public final InputStream a;

        public c(InputStream inputStream) {
            this.a = inputStream;
        }

        @Override // com.bumptech.glide.load.resource.bitmap.DefaultImageHeaderParser.Reader
        public long b(long j) {
            if (j < 0) {
                return 0;
            }
            long j2 = j;
            while (j2 > 0) {
                long skip = this.a.skip(j2);
                if (skip <= 0) {
                    if (this.a.read() == -1) {
                        break;
                    }
                    skip = 1;
                }
                j2 -= skip;
            }
            return j - j2;
        }

        @Override // com.bumptech.glide.load.resource.bitmap.DefaultImageHeaderParser.Reader
        public int c(byte[] bArr, int i) {
            int i2 = 0;
            int i3 = 0;
            while (i2 < i && (i3 = this.a.read(bArr, i2, i - i2)) != -1) {
                i2 += i3;
            }
            if (i2 != 0 || i3 != -1) {
                return i2;
            }
            throw new Reader.EndOfFileException();
        }

        @Override // com.bumptech.glide.load.resource.bitmap.DefaultImageHeaderParser.Reader
        public short d() {
            int read = this.a.read();
            if (read != -1) {
                return (short) read;
            }
            throw new Reader.EndOfFileException();
        }

        @Override // com.bumptech.glide.load.resource.bitmap.DefaultImageHeaderParser.Reader
        public int e() {
            return (d() << 8) | d();
        }
    }

    @Override // com.bumptech.glide.load.ImageHeaderParser
    public ImageHeaderParser.ImageType a(ByteBuffer byteBuffer) {
        Objects.requireNonNull(byteBuffer, "Argument must not be null");
        return d(new a(byteBuffer));
    }

    @Override // com.bumptech.glide.load.ImageHeaderParser
    public int b(InputStream inputStream, nj0 nj0) {
        Objects.requireNonNull(inputStream, "Argument must not be null");
        c cVar = new c(inputStream);
        Objects.requireNonNull(nj0, "Argument must not be null");
        try {
            int e = cVar.e();
            if ((e & 65496) == 65496 || e == 19789 || e == 18761) {
                int e2 = e(cVar);
                if (e2 != -1) {
                    byte[] bArr = (byte[]) nj0.e(e2, byte[].class);
                    try {
                        return f(cVar, bArr, e2);
                    } finally {
                        nj0.d(bArr);
                    }
                } else if (!Log.isLoggable("DfltImageHeaderParser", 3)) {
                    return -1;
                } else {
                    Log.d("DfltImageHeaderParser", "Failed to parse exif segment length, or exif segment not found");
                    return -1;
                }
            } else if (!Log.isLoggable("DfltImageHeaderParser", 3)) {
                return -1;
            } else {
                Log.d("DfltImageHeaderParser", "Parser doesn't handle magic number: " + e);
                return -1;
            }
        } catch (Reader.EndOfFileException unused) {
            return -1;
        }
    }

    @Override // com.bumptech.glide.load.ImageHeaderParser
    public ImageHeaderParser.ImageType c(InputStream inputStream) {
        Objects.requireNonNull(inputStream, "Argument must not be null");
        return d(new c(inputStream));
    }

    public final ImageHeaderParser.ImageType d(Reader reader) {
        try {
            int e = reader.e();
            if (e == 65496) {
                return ImageHeaderParser.ImageType.JPEG;
            }
            int d = (e << 8) | reader.d();
            if (d == 4671814) {
                return ImageHeaderParser.ImageType.GIF;
            }
            int d2 = (d << 8) | reader.d();
            if (d2 == -1991225785) {
                reader.b(21);
                try {
                    return reader.d() >= 3 ? ImageHeaderParser.ImageType.PNG_A : ImageHeaderParser.ImageType.PNG;
                } catch (Reader.EndOfFileException unused) {
                    return ImageHeaderParser.ImageType.PNG;
                }
            } else if (d2 != 1380533830) {
                return ImageHeaderParser.ImageType.UNKNOWN;
            } else {
                reader.b(4);
                if (((reader.e() << 16) | reader.e()) != 1464156752) {
                    return ImageHeaderParser.ImageType.UNKNOWN;
                }
                int e2 = (reader.e() << 16) | reader.e();
                if ((e2 & -256) != 1448097792) {
                    return ImageHeaderParser.ImageType.UNKNOWN;
                }
                int i = e2 & KotlinVersion.MAX_COMPONENT_VALUE;
                if (i == 88) {
                    reader.b(4);
                    return (reader.d() & 16) != 0 ? ImageHeaderParser.ImageType.WEBP_A : ImageHeaderParser.ImageType.WEBP;
                } else if (i != 76) {
                    return ImageHeaderParser.ImageType.WEBP;
                } else {
                    reader.b(4);
                    return (reader.d() & 8) != 0 ? ImageHeaderParser.ImageType.WEBP_A : ImageHeaderParser.ImageType.WEBP;
                }
            }
        } catch (Reader.EndOfFileException unused2) {
            return ImageHeaderParser.ImageType.UNKNOWN;
        }
    }

    public final int e(Reader reader) {
        short d;
        int e;
        long j;
        long b2;
        do {
            short d2 = reader.d();
            if (d2 != 255) {
                if (Log.isLoggable("DfltImageHeaderParser", 3)) {
                    Log.d("DfltImageHeaderParser", "Unknown segmentId=" + ((int) d2));
                }
                return -1;
            }
            d = reader.d();
            if (d == 218) {
                return -1;
            }
            if (d == 217) {
                if (Log.isLoggable("DfltImageHeaderParser", 3)) {
                    Log.d("DfltImageHeaderParser", "Found MARKER_EOI in exif segment");
                }
                return -1;
            }
            e = reader.e() - 2;
            if (d == 225) {
                return e;
            }
            j = (long) e;
            b2 = reader.b(j);
        } while (b2 == j);
        if (Log.isLoggable("DfltImageHeaderParser", 3)) {
            StringBuilder L0 = ze0.L0("Unable to skip enough data, type: ", d, ", wanted to skip: ", e, ", but actually skipped: ");
            L0.append(b2);
            Log.d("DfltImageHeaderParser", L0.toString());
        }
        return -1;
    }

    public final int f(Reader reader, byte[] bArr, int i) {
        ByteOrder byteOrder;
        int c2 = reader.c(bArr, i);
        if (c2 != i) {
            if (Log.isLoggable("DfltImageHeaderParser", 3)) {
                Log.d("DfltImageHeaderParser", "Unable to read exif segment data, length: " + i + ", actually read: " + c2);
            }
            return -1;
        }
        boolean z = bArr != null && i > a.length;
        if (z) {
            int i2 = 0;
            while (true) {
                byte[] bArr2 = a;
                if (i2 >= bArr2.length) {
                    break;
                } else if (bArr[i2] != bArr2[i2]) {
                    z = false;
                    break;
                } else {
                    i2++;
                }
            }
        }
        if (z) {
            b bVar = new b(bArr, i);
            short a2 = bVar.a(6);
            if (a2 == 18761) {
                byteOrder = ByteOrder.LITTLE_ENDIAN;
            } else if (a2 != 19789) {
                if (Log.isLoggable("DfltImageHeaderParser", 3)) {
                    Log.d("DfltImageHeaderParser", "Unknown endianness = " + ((int) a2));
                }
                byteOrder = ByteOrder.BIG_ENDIAN;
            } else {
                byteOrder = ByteOrder.BIG_ENDIAN;
            }
            bVar.a.order(byteOrder);
            int b2 = bVar.b(10) + 6;
            short a3 = bVar.a(b2);
            for (int i3 = 0; i3 < a3; i3++) {
                int i4 = (i3 * 12) + b2 + 2;
                short a4 = bVar.a(i4);
                if (a4 == 274) {
                    short a5 = bVar.a(i4 + 2);
                    if (a5 >= 1 && a5 <= 12) {
                        int b3 = bVar.b(i4 + 4);
                        if (b3 >= 0) {
                            if (Log.isLoggable("DfltImageHeaderParser", 3)) {
                                StringBuilder L0 = ze0.L0("Got tagIndex=", i3, " tagType=", a4, " formatCode=");
                                L0.append((int) a5);
                                L0.append(" componentCount=");
                                L0.append(b3);
                                Log.d("DfltImageHeaderParser", L0.toString());
                            }
                            int i5 = b3 + b[a5];
                            if (i5 <= 4) {
                                int i6 = i4 + 8;
                                if (i6 < 0 || i6 > bVar.a.remaining()) {
                                    if (Log.isLoggable("DfltImageHeaderParser", 3)) {
                                        Log.d("DfltImageHeaderParser", "Illegal tagValueOffset=" + i6 + " tagType=" + ((int) a4));
                                    }
                                } else if (i5 >= 0 && i5 + i6 <= bVar.a.remaining()) {
                                    return bVar.a(i6);
                                } else {
                                    if (Log.isLoggable("DfltImageHeaderParser", 3)) {
                                        Log.d("DfltImageHeaderParser", "Illegal number of bytes for TI tag data tagType=" + ((int) a4));
                                    }
                                }
                            } else if (Log.isLoggable("DfltImageHeaderParser", 3)) {
                                Log.d("DfltImageHeaderParser", "Got byte count > 4, not orientation, continuing, formatCode=" + ((int) a5));
                            }
                        } else if (Log.isLoggable("DfltImageHeaderParser", 3)) {
                            Log.d("DfltImageHeaderParser", "Negative tiff component count");
                        }
                    } else if (Log.isLoggable("DfltImageHeaderParser", 3)) {
                        Log.d("DfltImageHeaderParser", "Got invalid format code = " + ((int) a5));
                    }
                }
            }
            return -1;
        }
        if (Log.isLoggable("DfltImageHeaderParser", 3)) {
            Log.d("DfltImageHeaderParser", "Missing jpeg exif preamble");
        }
        return -1;
    }
}
