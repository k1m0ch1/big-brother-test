package com.datatheorem.android.trustkit.config;

public final class ConfigurationException extends RuntimeException {
    public ConfigurationException(String str) {
        super(str);
    }
}
