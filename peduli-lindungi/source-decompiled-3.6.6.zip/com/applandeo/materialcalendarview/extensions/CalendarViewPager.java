package com.applandeo.materialcalendarview.extensions;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.viewpager.widget.ViewPager;
import java.util.Objects;
import kotlin.Metadata;

@Metadata(bv = {1, 0, 3}, d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\n\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u001d\b\u0007\u0012\u0006\u0010\u0016\u001a\u00020\u0015\u0012\n\b\u0002\u0010\u0018\u001a\u0004\u0018\u00010\u0017¢\u0006\u0004\b\u0019\u0010\u001aJ\u001f\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0004\u001a\u00020\u0002H\u0014¢\u0006\u0004\b\u0006\u0010\u0007J\u0017\u0010\u000b\u001a\u00020\n2\u0006\u0010\t\u001a\u00020\bH\u0016¢\u0006\u0004\b\u000b\u0010\fJ\u0017\u0010\r\u001a\u00020\n2\u0006\u0010\t\u001a\u00020\bH\u0016¢\u0006\u0004\b\r\u0010\fR\"\u0010\u0014\u001a\u00020\n8\u0006@\u0006X\u000e¢\u0006\u0012\n\u0004\b\u000e\u0010\u000f\u001a\u0004\b\u0010\u0010\u0011\"\u0004\b\u0012\u0010\u0013¨\u0006\u001b"}, d2 = {"Lcom/applandeo/materialcalendarview/extensions/CalendarViewPager;", "Landroidx/viewpager/widget/ViewPager;", "", "widthMeasureSpec", "heightMeasureSpec", "", "onMeasure", "(II)V", "Landroid/view/MotionEvent;", "event", "", "onTouchEvent", "(Landroid/view/MotionEvent;)Z", "onInterceptTouchEvent", "n0", "Z", "getSwipeEnabled", "()Z", "setSwipeEnabled", "(Z)V", "swipeEnabled", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "library_release"}, k = 1, mv = {1, 4, 0})
/* compiled from: CalendarViewPager.kt */
public final class CalendarViewPager extends ViewPager {
    public static final /* synthetic */ int o0 = 0;
    public boolean n0 = true;

    /* compiled from: CalendarViewPager.kt */
    public static final class a implements ViewPager.i {
        public final /* synthetic */ CalendarViewPager a;

        /* JADX WARN: Incorrect args count in method signature: ()V */
        public a(CalendarViewPager calendarViewPager) {
            this.a = calendarViewPager;
        }

        @Override // androidx.viewpager.widget.ViewPager.i
        public void a(int i, float f, int i2) {
        }

        @Override // androidx.viewpager.widget.ViewPager.i
        public void b(int i) {
        }

        @Override // androidx.viewpager.widget.ViewPager.i
        public void c(int i) {
            CalendarViewPager calendarViewPager = this.a;
            int i2 = CalendarViewPager.o0;
            Objects.requireNonNull(calendarViewPager);
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public CalendarViewPager(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        a56.f(context, "context");
        b(new a(this));
    }

    public final boolean getSwipeEnabled() {
        return this.n0;
    }

    @Override // androidx.viewpager.widget.ViewPager
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        a56.f(motionEvent, "event");
        return this.n0 && super.onInterceptTouchEvent(motionEvent);
    }

    @Override // androidx.viewpager.widget.ViewPager
    public void onMeasure(int i, int i2) {
        a56.e(this, "<this>");
        a56.e(this, "<this>");
        eo eoVar = new eo(this);
        int i3 = 0;
        while (eoVar.hasNext()) {
            View view = (View) eoVar.next();
            view.measure(i, View.MeasureSpec.makeMeasureSpec(0, 0));
            int measuredHeight = view.getMeasuredHeight();
            if (measuredHeight > i3) {
                i3 = measuredHeight;
            }
        }
        if (i3 != 0) {
            i2 = View.MeasureSpec.makeMeasureSpec(i3, 1073741824);
        }
        super.onMeasure(i, i2);
    }

    @Override // androidx.viewpager.widget.ViewPager
    public boolean onTouchEvent(MotionEvent motionEvent) {
        a56.f(motionEvent, "event");
        return this.n0 && super.onTouchEvent(motionEvent);
    }

    public final void setSwipeEnabled(boolean z) {
        this.n0 = z;
    }
}
