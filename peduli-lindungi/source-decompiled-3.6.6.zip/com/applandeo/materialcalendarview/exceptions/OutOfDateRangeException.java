package com.applandeo.materialcalendarview.exceptions;

import java.util.Objects;
import kotlin.Metadata;

@Metadata(bv = {1, 0, 3}, d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0006\b\b\u0018\u00002\u00060\u0001j\u0002`\u0002J\u0010\u0010\u0004\u001a\u00020\u0003HÖ\u0001¢\u0006\u0004\b\u0004\u0010\u0005J\u0010\u0010\u0007\u001a\u00020\u0006HÖ\u0001¢\u0006\u0004\b\u0007\u0010\bJ\u001a\u0010\f\u001a\u00020\u000b2\b\u0010\n\u001a\u0004\u0018\u00010\tHÖ\u0003¢\u0006\u0004\b\f\u0010\rR\u001c\u0010\u000e\u001a\u00020\u00038\u0016@\u0016X\u0004¢\u0006\f\n\u0004\b\u000e\u0010\u000f\u001a\u0004\b\u0010\u0010\u0005¨\u0006\u0011"}, d2 = {"Lcom/applandeo/materialcalendarview/exceptions/OutOfDateRangeException;", "Ljava/lang/Exception;", "Lkotlin/Exception;", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "message", "Ljava/lang/String;", "getMessage", "library_release"}, k = 1, mv = {1, 4, 0})
/* compiled from: OutOfDateRangeException.kt */
public final class OutOfDateRangeException extends Exception {
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof OutOfDateRangeException)) {
            return false;
        }
        Objects.requireNonNull((OutOfDateRangeException) obj);
        return a56.a(null, null);
    }

    public String getMessage() {
        return null;
    }

    public int hashCode() {
        return 0;
    }

    public String toString() {
        return "OutOfDateRangeException(message=null)";
    }
}
