package com.android.volley;

public class ServerError extends VolleyError {
    public ServerError(if0 if0) {
        super(if0);
    }

    public ServerError() {
    }
}
