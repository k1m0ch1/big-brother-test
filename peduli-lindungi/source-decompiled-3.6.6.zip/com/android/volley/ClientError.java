package com.android.volley;

public class ClientError extends ServerError {
    public ClientError(if0 if0) {
        super(if0);
    }

    public ClientError() {
    }
}
