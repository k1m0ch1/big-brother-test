package com.android.volley;

public class AuthFailureError extends VolleyError {
    public AuthFailureError() {
    }

    public String getMessage() {
        return super.getMessage();
    }

    public AuthFailureError(if0 if0) {
        super(if0);
    }
}
