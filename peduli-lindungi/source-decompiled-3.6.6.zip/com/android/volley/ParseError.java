package com.android.volley;

public class ParseError extends VolleyError {
    public ParseError() {
    }

    public ParseError(if0 if0) {
        super(if0);
    }

    public ParseError(Throwable th) {
        super(th);
    }
}
