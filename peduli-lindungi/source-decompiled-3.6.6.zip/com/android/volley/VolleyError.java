package com.android.volley;

public class VolleyError extends Exception {
    public final if0 g;

    public VolleyError() {
        this.g = null;
    }

    public VolleyError(if0 if0) {
        this.g = if0;
    }

    public VolleyError(Throwable th) {
        super(th);
        this.g = null;
    }
}
