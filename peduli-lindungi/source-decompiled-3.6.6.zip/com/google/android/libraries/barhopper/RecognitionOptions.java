package com.google.android.libraries.barhopper;

import com.google.android.apps.common.proguard.UsedByNative;

@UsedByNative("jni_common.cc")
/* compiled from: com.google.firebase:firebase-ml-vision-barcode-model@@16.1.2 */
public class RecognitionOptions {
    @UsedByNative("jni_common.cc")
    private int barcodeFormats = 0;
    @UsedByNative("jni_common.cc")
    private boolean outputUnrecognizedBarcodes = false;

    public void a(int i) {
        this.barcodeFormats = i;
    }
}
