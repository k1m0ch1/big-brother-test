package com.google.android.libraries.barhopper;

import android.graphics.Bitmap;
import android.util.Log;
import java.io.Closeable;

/* compiled from: com.google.firebase:firebase-ml-vision-barcode-model@@16.1.2 */
public class BarhopperV2 implements Closeable {
    public static final String h = BarhopperV2.class.getSimpleName();
    public long g;

    public BarhopperV2() {
        System.loadLibrary("barhopper_v2");
    }

    public void a() {
        if (this.g != 0) {
            Log.w(h, "Native context already exists.");
            return;
        }
        long createNative = createNative();
        this.g = createNative;
        if (createNative == 0) {
            throw new RuntimeException("Failed to create native context.");
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        long j = this.g;
        if (j != 0) {
            closeNative(j);
            this.g = 0;
        }
    }

    public final native void closeNative(long j);

    public final native long createNative();

    @Override // java.lang.Object
    public void finalize() {
        try {
            close();
        } finally {
            super.finalize();
        }
    }

    public final native Barcode[] recognizeBitmapNative(long j, Bitmap bitmap, RecognitionOptions recognitionOptions);

    public final native Barcode[] recognizeNative(long j, int i, int i2, byte[] bArr, RecognitionOptions recognitionOptions);
}
