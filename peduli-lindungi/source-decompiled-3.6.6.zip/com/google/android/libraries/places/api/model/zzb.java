package com.google.android.libraries.places.api.model;

import java.util.List;
import java.util.Objects;

/* compiled from: com.google.android.libraries.places:places@@2.3.0 */
public abstract class zzb extends AddressComponents {
    private final List<AddressComponent> zza;

    public zzb(List<AddressComponent> list) {
        Objects.requireNonNull(list, "Null asList");
        this.zza = list;
    }

    @Override // com.google.android.libraries.places.api.model.AddressComponents
    public List<AddressComponent> asList() {
        return this.zza;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof AddressComponents) {
            return this.zza.equals(((AddressComponents) obj).asList());
        }
        return false;
    }

    public int hashCode() {
        return this.zza.hashCode() ^ 1000003;
    }

    public String toString() {
        String valueOf = String.valueOf(this.zza);
        return ze0.c0(valueOf.length() + 26, "AddressComponents{asList=", valueOf, "}");
    }
}
