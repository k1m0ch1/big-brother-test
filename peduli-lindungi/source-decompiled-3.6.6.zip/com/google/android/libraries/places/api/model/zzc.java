package com.google.android.libraries.places.api.model;

import com.google.android.libraries.places.api.model.AddressComponent;
import java.util.List;
import java.util.Objects;

/* compiled from: com.google.android.libraries.places:places@@2.3.0 */
public final class zzc extends AddressComponent.Builder {
    private String zza;
    private String zzb;
    private List<String> zzc;

    @Override // com.google.android.libraries.places.api.model.AddressComponent.Builder
    public final AddressComponent.Builder setShortName(String str) {
        this.zzb = str;
        return this;
    }

    @Override // com.google.android.libraries.places.api.model.AddressComponent.Builder
    public final AddressComponent.Builder zza(String str) {
        Objects.requireNonNull(str, "Null name");
        this.zza = str;
        return this;
    }

    @Override // com.google.android.libraries.places.api.model.AddressComponent.Builder
    public final AddressComponent.Builder zza(List<String> list) {
        Objects.requireNonNull(list, "Null types");
        this.zzc = list;
        return this;
    }

    @Override // com.google.android.libraries.places.api.model.AddressComponent.Builder
    public final AddressComponent zza() {
        String str = "";
        if (this.zza == null) {
            str = str.concat(" name");
        }
        if (this.zzc == null) {
            str = String.valueOf(str).concat(" types");
        }
        if (str.isEmpty()) {
            return new zzz(this.zza, this.zzb, this.zzc);
        }
        throw new IllegalStateException(str.length() != 0 ? "Missing required properties:".concat(str) : new String("Missing required properties:"));
    }
}
