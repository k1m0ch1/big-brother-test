package com.google.android.libraries.places.api.model;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.List;

/* compiled from: com.google.android.libraries.places:places@@2.3.0 */
public final class zzab extends zzb {
    public static final Parcelable.Creator<zzab> CREATOR = new zzaa();

    public zzab(List<AddressComponent> list) {
        super(list);
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeList(asList());
    }
}
