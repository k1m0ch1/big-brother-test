package com.google.android.libraries.places.api.model;

import android.os.Parcelable;
import android.text.TextUtils;
import com.google.android.libraries.places.internal.zzft;
import com.google.android.libraries.places.internal.zzgi;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/* compiled from: com.google.android.libraries.places:places@@2.3.0 */
public abstract class OpeningHours implements Parcelable {

    /* compiled from: com.google.android.libraries.places:places@@2.3.0 */
    public static abstract class Builder {
        public OpeningHours build() {
            OpeningHours zza = zza();
            for (String str : zza.getWeekdayText()) {
                zzft.zzb(!TextUtils.isEmpty(str), "WeekdayText must not contain null or empty values.");
            }
            setPeriods(zzgi.zza((Collection) zza.getPeriods()));
            setWeekdayText(zzgi.zza((Collection) zza.getWeekdayText()));
            return zza();
        }

        public abstract Builder setPeriods(List<Period> list);

        public abstract Builder setWeekdayText(List<String> list);

        public abstract OpeningHours zza();
    }

    public static Builder builder() {
        return new zzm().setPeriods(new ArrayList()).setWeekdayText(new ArrayList());
    }

    public abstract List<Period> getPeriods();

    public abstract List<String> getWeekdayText();
}
