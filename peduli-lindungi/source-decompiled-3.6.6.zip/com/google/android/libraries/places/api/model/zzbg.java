package com.google.android.libraries.places.api.model;

import android.os.Parcel;
import android.os.Parcelable;

/* compiled from: com.google.android.libraries.places:places@@2.3.0 */
public final class zzbg implements Parcelable.Creator<TypeFilter> {
    /* Return type fixed from 'java.lang.Object' to match base method */
    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ TypeFilter createFromParcel(Parcel parcel) {
        return TypeFilter.valueOf(parcel.readString());
    }

    /* Return type fixed from 'java.lang.Object[]' to match base method */
    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ TypeFilter[] newArray(int i) {
        return new TypeFilter[i];
    }
}
