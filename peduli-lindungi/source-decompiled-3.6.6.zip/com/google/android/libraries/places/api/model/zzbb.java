package com.google.android.libraries.places.api.model;

import android.os.Parcel;
import android.os.Parcelable;

/* compiled from: com.google.android.libraries.places:places@@2.3.0 */
public final class zzbb implements Parcelable.Creator<DayOfWeek> {
    /* Return type fixed from 'java.lang.Object' to match base method */
    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ DayOfWeek createFromParcel(Parcel parcel) {
        return DayOfWeek.zza(parcel);
    }

    /* Return type fixed from 'java.lang.Object[]' to match base method */
    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ DayOfWeek[] newArray(int i) {
        return new DayOfWeek[i];
    }
}
