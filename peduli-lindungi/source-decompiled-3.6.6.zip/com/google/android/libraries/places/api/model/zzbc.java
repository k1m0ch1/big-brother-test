package com.google.android.libraries.places.api.model;

import android.util.Log;
import com.google.android.libraries.places.internal.zzgm;
import com.google.android.libraries.places.internal.zzgn;
import com.google.android.libraries.places.internal.zzgr;
import j$.util.DesugarTimeZone;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

/* compiled from: com.google.android.libraries.places:places@@2.3.0 */
public final class zzbc {
    private static final zzgn<Integer, DayOfWeek> zza = new zzgm().zza(1, DayOfWeek.SUNDAY).zza(2, DayOfWeek.MONDAY).zza(3, DayOfWeek.TUESDAY).zza(4, DayOfWeek.WEDNESDAY).zza(5, DayOfWeek.THURSDAY).zza(6, DayOfWeek.FRIDAY).zza(7, DayOfWeek.SATURDAY).zza();
    private static final LocalTime zzb = LocalTime.newInstance(23, 59);

    /* JADX WARNING: Removed duplicated region for block: B:26:0x0080  */
    public static Boolean zza(Place place, long j) {
        TimeZone timeZone;
        if (place.getOpeningHours() == null || place.getUtcOffsetMinutes() == null) {
            return null;
        }
        List<Period> periods = place.getOpeningHours().getPeriods();
        if (periods.isEmpty()) {
            return Boolean.FALSE;
        }
        if (periods.size() == 1 && periods.get(0).getClose() == null && periods.get(0).getOpen().getDay() == DayOfWeek.SUNDAY && periods.get(0).getOpen().getTime().getHours() == 0 && periods.get(0).getOpen().getTime().getMinutes() == 0) {
            return Boolean.TRUE;
        }
        for (Period period : periods) {
            if (period.getOpen() == null || period.getClose() == null) {
                return null;
            }
            while (r2.hasNext()) {
            }
        }
        int intValue = place.getUtcOffsetMinutes().intValue();
        String[] availableIDs = TimeZone.getAvailableIDs((int) TimeUnit.MINUTES.toMillis((long) intValue));
        if (availableIDs == null || availableIDs.length <= 0) {
            Log.w("Places", String.format("Cannot find timezone that associates with utcOffsetMinutes %d from Place object.", Integer.valueOf(intValue)));
            timeZone = null;
        } else {
            timeZone = DesugarTimeZone.getTimeZone(availableIDs[0]);
        }
        if (timeZone == null) {
            return null;
        }
        Calendar instance = Calendar.getInstance(timeZone);
        instance.setTimeInMillis(j);
        DayOfWeek dayOfWeek = zza.get(Integer.valueOf(instance.get(7)));
        LocalTime newInstance = LocalTime.newInstance(instance.get(11), instance.get(12));
        EnumMap enumMap = new EnumMap(DayOfWeek.class);
        if (!periods.isEmpty()) {
            Period period2 = periods.get(0);
            int i = 0;
            while (period2 != null) {
                TimeOfWeek open = period2.getOpen();
                TimeOfWeek close = period2.getClose();
                DayOfWeek day = open.getDay();
                LocalTime time = open.getTime();
                if (!(open.getDay() != close.getDay())) {
                    LocalTime time2 = close.getTime();
                    List list = (List) zza(enumMap, day, new ArrayList());
                    list.add(zzgr.zzb(time, time2));
                    enumMap.put((Object) day, (Object) list);
                    i++;
                    period2 = i >= periods.size() ? null : periods.get(i);
                } else {
                    LocalTime localTime = zzb;
                    List list2 = (List) zza(enumMap, day, new ArrayList());
                    list2.add(zzgr.zza(time, localTime));
                    enumMap.put((Object) day, (Object) list2);
                    period2 = Period.builder().setOpen(TimeOfWeek.newInstance(DayOfWeek.values()[(day.ordinal() + 1) % 7], LocalTime.newInstance(0, 0))).setClose(period2.getClose()).build();
                }
            }
        }
        List<zzgr> list3 = (List) enumMap.get(dayOfWeek);
        if (list3 == null) {
            return Boolean.FALSE;
        }
        for (zzgr zzgr : list3) {
            if (zzgr.zzb(newInstance)) {
                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;
    }

    private static <K, V> V zza(Map<K, V> map, K k, V v) {
        return map.containsKey(k) ? map.get(k) : v;
    }
}
