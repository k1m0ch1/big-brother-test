package com.google.android.libraries.places.api.model;

import com.google.android.libraries.places.api.model.AutocompletePrediction;
import com.google.android.libraries.places.api.model.Place;
import java.util.List;
import java.util.Objects;

/* compiled from: com.google.android.libraries.places:places@@2.3.0 */
public abstract class zze extends AutocompletePrediction {
    private final String zza;
    private final Integer zzb;
    private final List<Place.Type> zzc;
    private final String zzd;
    private final String zze;
    private final String zzf;
    private final List<AutocompletePrediction.zza> zzg;
    private final List<AutocompletePrediction.zza> zzh;
    private final List<AutocompletePrediction.zza> zzi;

    public zze(String str, Integer num, List<Place.Type> list, String str2, String str3, String str4, List<AutocompletePrediction.zza> list2, List<AutocompletePrediction.zza> list3, List<AutocompletePrediction.zza> list4) {
        Objects.requireNonNull(str, "Null placeId");
        this.zza = str;
        this.zzb = num;
        Objects.requireNonNull(list, "Null placeTypes");
        this.zzc = list;
        Objects.requireNonNull(str2, "Null fullText");
        this.zzd = str2;
        Objects.requireNonNull(str3, "Null primaryText");
        this.zze = str3;
        Objects.requireNonNull(str4, "Null secondaryText");
        this.zzf = str4;
        this.zzg = list2;
        this.zzh = list3;
        this.zzi = list4;
    }

    public boolean equals(Object obj) {
        Integer num;
        List<AutocompletePrediction.zza> list;
        List<AutocompletePrediction.zza> list2;
        List<AutocompletePrediction.zza> list3;
        if (obj == this) {
            return true;
        }
        if (obj instanceof AutocompletePrediction) {
            AutocompletePrediction autocompletePrediction = (AutocompletePrediction) obj;
            return this.zza.equals(autocompletePrediction.getPlaceId()) && ((num = this.zzb) != null ? num.equals(autocompletePrediction.getDistanceMeters()) : autocompletePrediction.getDistanceMeters() == null) && this.zzc.equals(autocompletePrediction.getPlaceTypes()) && this.zzd.equals(autocompletePrediction.zza()) && this.zze.equals(autocompletePrediction.zzb()) && this.zzf.equals(autocompletePrediction.zzc()) && ((list = this.zzg) != null ? list.equals(autocompletePrediction.zzd()) : autocompletePrediction.zzd() == null) && ((list2 = this.zzh) != null ? list2.equals(autocompletePrediction.zze()) : autocompletePrediction.zze() == null) && ((list3 = this.zzi) != null ? list3.equals(autocompletePrediction.zzf()) : autocompletePrediction.zzf() == null);
        }
    }

    @Override // com.google.android.libraries.places.api.model.AutocompletePrediction
    public Integer getDistanceMeters() {
        return this.zzb;
    }

    @Override // com.google.android.libraries.places.api.model.AutocompletePrediction
    public String getPlaceId() {
        return this.zza;
    }

    @Override // com.google.android.libraries.places.api.model.AutocompletePrediction
    public List<Place.Type> getPlaceTypes() {
        return this.zzc;
    }

    public int hashCode() {
        int hashCode = (this.zza.hashCode() ^ 1000003) * 1000003;
        Integer num = this.zzb;
        int i = 0;
        int hashCode2 = (((((((((hashCode ^ (num == null ? 0 : num.hashCode())) * 1000003) ^ this.zzc.hashCode()) * 1000003) ^ this.zzd.hashCode()) * 1000003) ^ this.zze.hashCode()) * 1000003) ^ this.zzf.hashCode()) * 1000003;
        List<AutocompletePrediction.zza> list = this.zzg;
        int hashCode3 = (hashCode2 ^ (list == null ? 0 : list.hashCode())) * 1000003;
        List<AutocompletePrediction.zza> list2 = this.zzh;
        int hashCode4 = (hashCode3 ^ (list2 == null ? 0 : list2.hashCode())) * 1000003;
        List<AutocompletePrediction.zza> list3 = this.zzi;
        if (list3 != null) {
            i = list3.hashCode();
        }
        return hashCode4 ^ i;
    }

    public String toString() {
        String str = this.zza;
        String valueOf = String.valueOf(this.zzb);
        String valueOf2 = String.valueOf(this.zzc);
        String str2 = this.zzd;
        String str3 = this.zze;
        String str4 = this.zzf;
        String valueOf3 = String.valueOf(this.zzg);
        String valueOf4 = String.valueOf(this.zzh);
        String valueOf5 = String.valueOf(this.zzi);
        StringBuilder I0 = ze0.I0(valueOf5.length() + valueOf4.length() + valueOf3.length() + ze0.U(str4, ze0.U(str3, ze0.U(str2, valueOf2.length() + valueOf.length() + ze0.U(str, 195)))), "AutocompletePrediction{placeId=", str, ", distanceMeters=", valueOf);
        ze0.g(I0, ", placeTypes=", valueOf2, ", fullText=", str2);
        ze0.g(I0, ", primaryText=", str3, ", secondaryText=", str4);
        ze0.g(I0, ", fullTextMatchedSubstrings=", valueOf3, ", primaryTextMatchedSubstrings=", valueOf4);
        I0.append(", secondaryTextMatchedSubstrings=");
        I0.append(valueOf5);
        I0.append("}");
        return I0.toString();
    }

    @Override // com.google.android.libraries.places.api.model.AutocompletePrediction
    public final String zza() {
        return this.zzd;
    }

    @Override // com.google.android.libraries.places.api.model.AutocompletePrediction
    public final String zzb() {
        return this.zze;
    }

    @Override // com.google.android.libraries.places.api.model.AutocompletePrediction
    public final String zzc() {
        return this.zzf;
    }

    @Override // com.google.android.libraries.places.api.model.AutocompletePrediction
    public final List<AutocompletePrediction.zza> zzd() {
        return this.zzg;
    }

    @Override // com.google.android.libraries.places.api.model.AutocompletePrediction
    public final List<AutocompletePrediction.zza> zze() {
        return this.zzh;
    }

    @Override // com.google.android.libraries.places.api.model.AutocompletePrediction
    public final List<AutocompletePrediction.zza> zzf() {
        return this.zzi;
    }
}
