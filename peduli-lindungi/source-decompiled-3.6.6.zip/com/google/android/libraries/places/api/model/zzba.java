package com.google.android.libraries.places.api.model;

import com.google.android.libraries.places.api.model.AutocompletePrediction;

/* compiled from: com.google.android.libraries.places:places@@2.3.0 */
public abstract class zzba {
    public abstract AutocompletePrediction.zza zza();

    public abstract zzba zza(int i);

    public abstract zzba zzb(int i);
}
