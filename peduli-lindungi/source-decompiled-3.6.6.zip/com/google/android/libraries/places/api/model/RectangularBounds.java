package com.google.android.libraries.places.api.model;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;

/* compiled from: com.google.android.libraries.places:places@@2.3.0 */
public abstract class RectangularBounds implements LocationBias, LocationRestriction {

    /* compiled from: com.google.android.libraries.places:places@@2.3.0 */
    public static abstract class zza {
        public abstract zza zza(LatLng latLng);

        public abstract RectangularBounds zza();

        public abstract zza zzb(LatLng latLng);
    }

    public static RectangularBounds newInstance(LatLngBounds latLngBounds) {
        return new zzv().zza(latLngBounds.g).zzb(latLngBounds.h).zza();
    }

    public abstract LatLng getNortheast();

    public abstract LatLng getSouthwest();

    public static RectangularBounds newInstance(LatLng latLng, LatLng latLng2) {
        return newInstance(new LatLngBounds(latLng, latLng2));
    }
}
