package com.google.android.libraries.places.api.model;

import java.util.List;
import java.util.Objects;

/* compiled from: com.google.android.libraries.places:places@@2.3.0 */
public abstract class zza extends AddressComponent {
    private final String zza;
    private final String zzb;
    private final List<String> zzc;

    public zza(String str, String str2, List<String> list) {
        Objects.requireNonNull(str, "Null name");
        this.zza = str;
        this.zzb = str2;
        Objects.requireNonNull(list, "Null types");
        this.zzc = list;
    }

    public boolean equals(Object obj) {
        String str;
        if (obj == this) {
            return true;
        }
        if (obj instanceof AddressComponent) {
            AddressComponent addressComponent = (AddressComponent) obj;
            return this.zza.equals(addressComponent.getName()) && ((str = this.zzb) != null ? str.equals(addressComponent.getShortName()) : addressComponent.getShortName() == null) && this.zzc.equals(addressComponent.getTypes());
        }
    }

    @Override // com.google.android.libraries.places.api.model.AddressComponent
    public String getName() {
        return this.zza;
    }

    @Override // com.google.android.libraries.places.api.model.AddressComponent
    public String getShortName() {
        return this.zzb;
    }

    @Override // com.google.android.libraries.places.api.model.AddressComponent
    public List<String> getTypes() {
        return this.zzc;
    }

    public int hashCode() {
        int hashCode = (this.zza.hashCode() ^ 1000003) * 1000003;
        String str = this.zzb;
        return ((hashCode ^ (str == null ? 0 : str.hashCode())) * 1000003) ^ this.zzc.hashCode();
    }

    public String toString() {
        String str = this.zza;
        String str2 = this.zzb;
        String valueOf = String.valueOf(this.zzc);
        StringBuilder I0 = ze0.I0(valueOf.length() + ze0.U(str2, ze0.U(str, 43)), "AddressComponent{name=", str, ", shortName=", str2);
        I0.append(", types=");
        I0.append(valueOf);
        I0.append("}");
        return I0.toString();
    }
}
