package com.google.android.libraries.places.api.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.libraries.places.api.model.Place;

/* compiled from: com.google.android.libraries.places:places@@2.3.0 */
public final class zzbd implements Parcelable.Creator<Place.BusinessStatus> {
    /* Return type fixed from 'java.lang.Object' to match base method */
    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Place.BusinessStatus createFromParcel(Parcel parcel) {
        return Place.BusinessStatus.valueOf(parcel.readString());
    }

    /* Return type fixed from 'java.lang.Object[]' to match base method */
    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Place.BusinessStatus[] newArray(int i) {
        return new Place.BusinessStatus[i];
    }
}
