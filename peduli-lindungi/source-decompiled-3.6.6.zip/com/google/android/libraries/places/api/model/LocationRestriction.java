package com.google.android.libraries.places.api.model;

import android.os.Parcelable;

/* compiled from: com.google.android.libraries.places:places@@2.3.0 */
public interface LocationRestriction extends Parcelable {
}
