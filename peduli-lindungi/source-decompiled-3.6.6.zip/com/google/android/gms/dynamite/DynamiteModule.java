package com.google.android.gms.dynamite;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.util.DynamiteApi;
import dalvik.system.DelegateLastClassLoader;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.Objects;
import javax.annotation.concurrent.GuardedBy;

/* compiled from: com.google.android.gms:play-services-basement@@17.2.1 */
public final class DynamiteModule {
    @GuardedBy("DynamiteModule.class")
    public static Boolean b = null;
    @GuardedBy("DynamiteModule.class")
    public static z31 c = null;
    @GuardedBy("DynamiteModule.class")
    public static b41 d = null;
    @GuardedBy("DynamiteModule.class")
    public static String e = null;
    @GuardedBy("DynamiteModule.class")
    public static int f = -1;
    public static final ThreadLocal<b> g = new ThreadLocal<>();
    public static final a.b h = new t31();
    public static final a i = new s31();
    public static final a j = new u31();
    public static final a k = new v31();
    public static final a l = new w31();
    public final Context a;

    @DynamiteApi
    /* compiled from: com.google.android.gms:play-services-basement@@17.2.1 */
    public static class DynamiteLoaderClassLoader {
        @GuardedBy("DynamiteLoaderClassLoader.class")
        public static ClassLoader sClassLoader;
    }

    /* compiled from: com.google.android.gms:play-services-basement@@17.2.1 */
    public static class LoadingException extends Exception {
        public LoadingException(String str, t31 t31) {
            super(str);
        }

        public LoadingException(String str, Throwable th, t31 t31) {
            super(str, th);
        }
    }

    /* compiled from: com.google.android.gms:play-services-basement@@17.2.1 */
    public interface a {

        /* renamed from: com.google.android.gms.dynamite.DynamiteModule$a$a  reason: collision with other inner class name */
        /* compiled from: com.google.android.gms:play-services-basement@@17.2.1 */
        public static class C0016a {
            public int a = 0;
            public int b = 0;
            public int c = 0;
        }

        /* compiled from: com.google.android.gms:play-services-basement@@17.2.1 */
        public interface b {
            int a(Context context, String str);

            int b(Context context, String str, boolean z);
        }

        C0016a a(Context context, String str, b bVar);
    }

    /* compiled from: com.google.android.gms:play-services-basement@@17.2.1 */
    public static class b {
        public Cursor a;

        public b() {
        }

        public b(t31 t31) {
        }
    }

    /* compiled from: com.google.android.gms:play-services-basement@@17.2.1 */
    public static class c implements a.b {
        public final int a;

        public c(int i) {
            this.a = i;
        }

        @Override // com.google.android.gms.dynamite.DynamiteModule.a.b
        public final int a(Context context, String str) {
            return this.a;
        }

        @Override // com.google.android.gms.dynamite.DynamiteModule.a.b
        public final int b(Context context, String str, boolean z) {
            return 0;
        }
    }

    public DynamiteModule(Context context) {
        Objects.requireNonNull(context, "null reference");
        this.a = context;
    }

    public static int a(Context context, String str) {
        try {
            ClassLoader classLoader = context.getApplicationContext().getClassLoader();
            StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 61);
            sb.append("com.google.android.gms.dynamite.descriptors.");
            sb.append(str);
            sb.append(".ModuleDescriptor");
            Class<?> loadClass = classLoader.loadClass(sb.toString());
            Field declaredField = loadClass.getDeclaredField("MODULE_ID");
            Field declaredField2 = loadClass.getDeclaredField("MODULE_VERSION");
            if (declaredField.get(null).equals(str)) {
                return declaredField2.getInt(null);
            }
            String valueOf = String.valueOf(declaredField.get(null));
            StringBuilder sb2 = new StringBuilder(valueOf.length() + 51 + String.valueOf(str).length());
            sb2.append("Module descriptor id '");
            sb2.append(valueOf);
            sb2.append("' didn't match expected id '");
            sb2.append(str);
            sb2.append("'");
            Log.e("DynamiteModule", sb2.toString());
            return 0;
        } catch (ClassNotFoundException unused) {
            ze0.W0(ze0.U(str, 45), "Local module descriptor class for ", str, " not found.", "DynamiteModule");
            return 0;
        } catch (Exception e2) {
            String valueOf2 = String.valueOf(e2.getMessage());
            Log.e("DynamiteModule", valueOf2.length() != 0 ? "Failed to load module descriptor class: ".concat(valueOf2) : new String("Failed to load module descriptor class: "));
            return 0;
        }
    }

    public static DynamiteModule c(Context context, a aVar, String str) {
        Cursor cursor;
        ThreadLocal<b> threadLocal = g;
        b bVar = threadLocal.get();
        b bVar2 = new b(null);
        threadLocal.set(bVar2);
        try {
            a.C0016a a2 = aVar.a(context, str, h);
            int i2 = a2.a;
            int i3 = a2.b;
            StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 68 + String.valueOf(str).length());
            sb.append("Considering local module ");
            sb.append(str);
            sb.append(":");
            sb.append(i2);
            sb.append(" and remote module ");
            sb.append(str);
            sb.append(":");
            sb.append(i3);
            Log.i("DynamiteModule", sb.toString());
            int i4 = a2.c;
            if (i4 == 0 || ((i4 == -1 && a2.a == 0) || (i4 == 1 && a2.b == 0))) {
                int i5 = a2.a;
                int i6 = a2.b;
                StringBuilder sb2 = new StringBuilder(91);
                sb2.append("No acceptable module found. Local version is ");
                sb2.append(i5);
                sb2.append(" and remote version is ");
                sb2.append(i6);
                sb2.append(".");
                throw new LoadingException(sb2.toString(), null);
            } else if (i4 == -1) {
                DynamiteModule j2 = j(context, str);
                Cursor cursor2 = bVar2.a;
                if (cursor2 != null) {
                    cursor2.close();
                }
                threadLocal.set(bVar);
                return j2;
            } else if (i4 == 1) {
                try {
                    DynamiteModule e2 = e(context, str, a2.b);
                    Cursor cursor3 = bVar2.a;
                    if (cursor3 != null) {
                        cursor3.close();
                    }
                    threadLocal.set(bVar);
                    return e2;
                } catch (LoadingException e3) {
                    String valueOf = String.valueOf(e3.getMessage());
                    Log.w("DynamiteModule", valueOf.length() != 0 ? "Failed to load remote module: ".concat(valueOf) : new String("Failed to load remote module: "));
                    int i7 = a2.a;
                    if (i7 == 0 || aVar.a(context, str, new c(i7)).c != -1) {
                        throw new LoadingException("Remote load failed. No local fallback found.", e3, null);
                    }
                    return j(context, str);
                }
            } else {
                int i8 = a2.c;
                StringBuilder sb3 = new StringBuilder(47);
                sb3.append("VersionPolicy returned invalid code:");
                sb3.append(i8);
                throw new LoadingException(sb3.toString(), null);
            }
        } finally {
            cursor = bVar2.a;
            if (cursor != null) {
                cursor.close();
            }
            g.set(bVar);
        }
    }

    public static int d(Context context, String str, boolean z) {
        ClassLoader classLoader;
        try {
            synchronized (DynamiteModule.class) {
                Boolean bool = b;
                if (bool == null) {
                    try {
                        Field declaredField = context.getApplicationContext().getClassLoader().loadClass(DynamiteLoaderClassLoader.class.getName()).getDeclaredField("sClassLoader");
                        synchronized (declaredField.getDeclaringClass()) {
                            ClassLoader classLoader2 = (ClassLoader) declaredField.get(null);
                            if (classLoader2 != null) {
                                if (classLoader2 == ClassLoader.getSystemClassLoader()) {
                                    bool = Boolean.FALSE;
                                } else {
                                    try {
                                        f(classLoader2);
                                    } catch (LoadingException unused) {
                                    }
                                    bool = Boolean.TRUE;
                                }
                            } else if ("com.google.android.gms".equals(context.getApplicationContext().getPackageName())) {
                                declaredField.set(null, ClassLoader.getSystemClassLoader());
                                bool = Boolean.FALSE;
                            } else {
                                try {
                                    int i2 = i(context, str, z);
                                    String str2 = e;
                                    if (str2 != null) {
                                        if (!str2.isEmpty()) {
                                            if (Build.VERSION.SDK_INT >= 29) {
                                                classLoader = new DelegateLastClassLoader(e, ClassLoader.getSystemClassLoader());
                                            } else {
                                                classLoader = new x31(e, ClassLoader.getSystemClassLoader());
                                            }
                                            f(classLoader);
                                            declaredField.set(null, classLoader);
                                            b = Boolean.TRUE;
                                            return i2;
                                        }
                                    }
                                    return i2;
                                } catch (LoadingException unused2) {
                                    declaredField.set(null, ClassLoader.getSystemClassLoader());
                                    bool = Boolean.FALSE;
                                    b = bool;
                                    if (!bool.booleanValue()) {
                                        return g(context, str, z);
                                    }
                                    try {
                                        return i(context, str, z);
                                    } catch (LoadingException e2) {
                                        String valueOf = String.valueOf(e2.getMessage());
                                        Log.w("DynamiteModule", valueOf.length() != 0 ? "Failed to retrieve remote module version: ".concat(valueOf) : new String("Failed to retrieve remote module version: "));
                                        return 0;
                                    }
                                }
                            }
                        }
                    } catch (ClassNotFoundException | IllegalAccessException | NoSuchFieldException e3) {
                        String valueOf2 = String.valueOf(e3);
                        StringBuilder sb = new StringBuilder(valueOf2.length() + 30);
                        sb.append("Failed to load module via V2: ");
                        sb.append(valueOf2);
                        Log.w("DynamiteModule", sb.toString());
                        bool = Boolean.FALSE;
                    }
                }
            }
        } catch (Throwable th) {
            try {
                Objects.requireNonNull(context, "null reference");
            } catch (Exception e4) {
                Log.e("CrashUtils", "Error adding exception to DropBox!", e4);
            }
            throw th;
        }
    }

    public static DynamiteModule e(Context context, String str, int i2) {
        Boolean bool;
        h31 h31;
        try {
            synchronized (DynamiteModule.class) {
                bool = b;
            }
            if (bool == null) {
                throw new LoadingException("Failed to determine which loading route to use.", null);
            } else if (bool.booleanValue()) {
                return h(context, str, i2);
            } else {
                StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 51);
                sb.append("Selected remote version of ");
                sb.append(str);
                sb.append(", version >= ");
                sb.append(i2);
                Log.i("DynamiteModule", sb.toString());
                z31 k2 = k(context);
                if (k2 != null) {
                    if (k2.b0() >= 2) {
                        h31 = k2.S(new j31(context), str, i2);
                    } else {
                        Log.w("DynamiteModule", "Dynamite loader version < 2, falling back to createModuleContext");
                        h31 = k2.p0(new j31(context), str, i2);
                    }
                    if (j31.h1(h31) != null) {
                        return new DynamiteModule((Context) j31.h1(h31));
                    }
                    throw new LoadingException("Failed to load remote module.", null);
                }
                throw new LoadingException("Failed to create IDynamiteLoader.", null);
            }
        } catch (RemoteException e2) {
            throw new LoadingException("Failed to load remote module.", e2, null);
        } catch (LoadingException e3) {
            throw e3;
        } catch (Throwable th) {
            try {
                Objects.requireNonNull(context, "null reference");
            } catch (Exception e4) {
                Log.e("CrashUtils", "Error adding exception to DropBox!", e4);
            }
            throw new LoadingException("Failed to load remote module.", th, null);
        }
    }

    @GuardedBy("DynamiteModule.class")
    public static void f(ClassLoader classLoader) {
        b41 b41;
        try {
            IBinder iBinder = (IBinder) classLoader.loadClass("com.google.android.gms.dynamiteloader.DynamiteLoaderV2").getConstructor(new Class[0]).newInstance(new Object[0]);
            if (iBinder == null) {
                b41 = null;
            } else {
                IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.dynamite.IDynamiteLoaderV2");
                if (queryLocalInterface instanceof b41) {
                    b41 = (b41) queryLocalInterface;
                } else {
                    b41 = new a41(iBinder);
                }
            }
            d = b41;
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | NoSuchMethodException | InvocationTargetException e2) {
            throw new LoadingException("Failed to instantiate dynamite loader", e2, null);
        }
    }

    public static int g(Context context, String str, boolean z) {
        z31 k2 = k(context);
        if (k2 == null) {
            return 0;
        }
        try {
            if (k2.b0() >= 2) {
                return k2.n(new j31(context), str, z);
            }
            Log.w("DynamiteModule", "IDynamite loader version < 2, falling back to getModuleVersion2");
            return k2.J(new j31(context), str, z);
        } catch (RemoteException e2) {
            String valueOf = String.valueOf(e2.getMessage());
            Log.w("DynamiteModule", valueOf.length() != 0 ? "Failed to retrieve remote module version: ".concat(valueOf) : new String("Failed to retrieve remote module version: "));
            return 0;
        }
    }

    public static DynamiteModule h(Context context, String str, int i2) {
        b41 b41;
        Boolean valueOf;
        h31 h31;
        StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 51);
        sb.append("Selected remote version of ");
        sb.append(str);
        sb.append(", version >= ");
        sb.append(i2);
        Log.i("DynamiteModule", sb.toString());
        synchronized (DynamiteModule.class) {
            b41 = d;
        }
        if (b41 != null) {
            b bVar = g.get();
            if (bVar == null || bVar.a == null) {
                throw new LoadingException("No result cursor", null);
            }
            Context applicationContext = context.getApplicationContext();
            Cursor cursor = bVar.a;
            new j31(null);
            synchronized (DynamiteModule.class) {
                valueOf = Boolean.valueOf(f >= 2);
            }
            if (valueOf.booleanValue()) {
                Log.v("DynamiteModule", "Dynamite loader version >= 2, using loadModule2NoCrashUtils");
                h31 = b41.I(new j31(applicationContext), str, i2, new j31(cursor));
            } else {
                Log.w("DynamiteModule", "Dynamite loader version < 2, falling back to loadModule2");
                h31 = b41.H(new j31(applicationContext), str, i2, new j31(cursor));
            }
            Context context2 = (Context) j31.h1(h31);
            if (context2 != null) {
                return new DynamiteModule(context2);
            }
            throw new LoadingException("Failed to get module context", null);
        }
        throw new LoadingException("DynamiteLoaderV2 was not cached.", null);
    }

    /* JADX WARNING: Removed duplicated region for block: B:31:0x007f  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x00a3 A[Catch:{ all -> 0x00ac }] */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x00a4 A[Catch:{ all -> 0x00ac }] */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x00b0  */
    public static int i(Context context, String str, boolean z) {
        Throwable th;
        Cursor cursor;
        Exception e2;
        Cursor cursor2 = null;
        try {
            ContentResolver contentResolver = context.getContentResolver();
            String str2 = z ? "api_force_staging" : "api";
            StringBuilder sb = new StringBuilder(str2.length() + 42 + String.valueOf(str).length());
            sb.append("content://com.google.android.gms.chimera/");
            sb.append(str2);
            sb.append("/");
            sb.append(str);
            Cursor query = contentResolver.query(Uri.parse(sb.toString()), null, null, null, null);
            if (query != null) {
                try {
                    if (query.moveToFirst()) {
                        int i2 = query.getInt(0);
                        if (i2 > 0) {
                            synchronized (DynamiteModule.class) {
                                e = query.getString(2);
                                int columnIndex = query.getColumnIndex("loaderVersion");
                                if (columnIndex >= 0) {
                                    f = query.getInt(columnIndex);
                                }
                            }
                            b bVar = g.get();
                            if (bVar != null && bVar.a == null) {
                                bVar.a = query;
                                if (cursor2 != null) {
                                    cursor2.close();
                                }
                                return i2;
                            }
                        }
                        cursor2 = query;
                        if (cursor2 != null) {
                        }
                        return i2;
                    }
                } catch (Exception e3) {
                    cursor = query;
                    e2 = e3;
                    try {
                        if (!(e2 instanceof LoadingException)) {
                            throw e2;
                        }
                        throw new LoadingException("V2 version check failed", e2, null);
                    } catch (Throwable th2) {
                        th = th2;
                        cursor2 = cursor;
                        if (cursor2 != null) {
                        }
                        throw th;
                    }
                } catch (Throwable th3) {
                    cursor2 = query;
                    th = th3;
                    if (cursor2 != null) {
                        cursor2.close();
                    }
                    throw th;
                }
            }
            Log.w("DynamiteModule", "Failed to retrieve remote module version.");
            throw new LoadingException("Failed to connect to dynamite module ContentResolver.", null);
        } catch (Exception e4) {
            e2 = e4;
            cursor = null;
            if (!(e2 instanceof LoadingException)) {
            }
        } catch (Throwable th4) {
            th = th4;
            if (cursor2 != null) {
            }
            throw th;
        }
    }

    public static DynamiteModule j(Context context, String str) {
        String valueOf = String.valueOf(str);
        Log.i("DynamiteModule", valueOf.length() != 0 ? "Selected local version of ".concat(valueOf) : new String("Selected local version of "));
        return new DynamiteModule(context.getApplicationContext());
    }

    public static z31 k(Context context) {
        z31 z31;
        synchronized (DynamiteModule.class) {
            z31 z312 = c;
            if (z312 != null) {
                return z312;
            }
            try {
                IBinder iBinder = (IBinder) context.createPackageContext("com.google.android.gms", 3).getClassLoader().loadClass("com.google.android.gms.chimera.container.DynamiteLoaderImpl").newInstance();
                if (iBinder == null) {
                    z31 = null;
                } else {
                    IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.dynamite.IDynamiteLoader");
                    if (queryLocalInterface instanceof z31) {
                        z31 = (z31) queryLocalInterface;
                    } else {
                        z31 = new y31(iBinder);
                    }
                }
                if (z31 != null) {
                    c = z31;
                    return z31;
                }
            } catch (Exception e2) {
                String valueOf = String.valueOf(e2.getMessage());
                Log.e("DynamiteModule", valueOf.length() != 0 ? "Failed to load IDynamiteLoader from GmsCore: ".concat(valueOf) : new String("Failed to load IDynamiteLoader from GmsCore: "));
            }
            return null;
        }
    }

    public final IBinder b(String str) {
        try {
            return (IBinder) this.a.getClassLoader().loadClass(str).newInstance();
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException e2) {
            throw new LoadingException(str.length() != 0 ? "Failed to instantiate module class: ".concat(str) : new String("Failed to instantiate module class: "), e2, null);
        }
    }
}
