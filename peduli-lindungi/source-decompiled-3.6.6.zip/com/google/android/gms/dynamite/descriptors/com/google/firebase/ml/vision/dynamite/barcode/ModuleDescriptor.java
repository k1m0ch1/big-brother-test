package com.google.android.gms.dynamite.descriptors.com.google.firebase.ml.vision.dynamite.barcode;

import com.google.android.gms.common.util.DynamiteApi;

@DynamiteApi
/* compiled from: com.google.firebase:firebase-ml-vision-barcode-model@@16.1.2 */
public class ModuleDescriptor {
    public static final String MODULE_ID = "com.google.firebase.ml.vision.dynamite.barcode";
    public static final int MODULE_VERSION = 10000;
}
