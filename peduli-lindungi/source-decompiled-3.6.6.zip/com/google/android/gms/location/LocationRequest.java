package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import com.github.mikephil.charting.utils.Utils;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.maps.android.R;
import java.util.Arrays;

public final class LocationRequest extends y01 implements ReflectedParcelable {
    public static final Parcelable.Creator<LocationRequest> CREATOR = new b92();
    public int g;
    public long h;
    public long i;
    public boolean j;
    public long k;
    public int l;
    public float m;
    public long n;

    public LocationRequest() {
        this.g = R.styleable.AppCompatTheme_textAppearanceListItemSecondary;
        this.h = 3600000;
        this.i = 600000;
        this.j = false;
        this.k = Long.MAX_VALUE;
        this.l = Integer.MAX_VALUE;
        this.m = Utils.FLOAT_EPSILON;
        this.n = 0;
    }

    public LocationRequest(int i2, long j2, long j3, boolean z, long j4, int i3, float f, long j5) {
        this.g = i2;
        this.h = j2;
        this.i = j3;
        this.j = z;
        this.k = j4;
        this.l = i3;
        this.m = f;
        this.n = j5;
    }

    public static void y(long j2) {
        if (j2 < 0) {
            StringBuilder sb = new StringBuilder(38);
            sb.append("invalid interval: ");
            sb.append(j2);
            throw new IllegalArgumentException(sb.toString());
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof LocationRequest)) {
            return false;
        }
        LocationRequest locationRequest = (LocationRequest) obj;
        if (this.g == locationRequest.g) {
            long j2 = this.h;
            long j3 = locationRequest.h;
            if (j2 == j3 && this.i == locationRequest.i && this.j == locationRequest.j && this.k == locationRequest.k && this.l == locationRequest.l && this.m == locationRequest.m) {
                long j4 = this.n;
                if (j4 >= j2) {
                    j2 = j4;
                }
                long j5 = locationRequest.n;
                if (j5 >= j3) {
                    j3 = j5;
                }
                if (j2 == j3) {
                    return true;
                }
            }
        }
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.g), Long.valueOf(this.h), Float.valueOf(this.m), Long.valueOf(this.n)});
    }

    public final LocationRequest r(int i2) {
        if (i2 == 100 || i2 == 102 || i2 == 104 || i2 == 105) {
            this.g = i2;
            return this;
        }
        throw new IllegalArgumentException(ze0.Y(28, "invalid quality: ", i2));
    }

    public final String toString() {
        StringBuilder J0 = ze0.J0("Request[");
        int i2 = this.g;
        J0.append(i2 != 100 ? i2 != 102 ? i2 != 104 ? i2 != 105 ? "???" : "PRIORITY_NO_POWER" : "PRIORITY_LOW_POWER" : "PRIORITY_BALANCED_POWER_ACCURACY" : "PRIORITY_HIGH_ACCURACY");
        if (this.g != 105) {
            J0.append(" requested=");
            J0.append(this.h);
            J0.append("ms");
        }
        J0.append(" fastest=");
        J0.append(this.i);
        J0.append("ms");
        if (this.n > this.h) {
            J0.append(" maxWait=");
            J0.append(this.n);
            J0.append("ms");
        }
        if (this.m > Utils.FLOAT_EPSILON) {
            J0.append(" smallestDisplacement=");
            J0.append(this.m);
            J0.append("m");
        }
        long j2 = this.k;
        if (j2 != Long.MAX_VALUE) {
            J0.append(" expireIn=");
            J0.append(j2 - SystemClock.elapsedRealtime());
            J0.append("ms");
        }
        if (this.l != Integer.MAX_VALUE) {
            J0.append(" num=");
            J0.append(this.l);
        }
        J0.append(']');
        return J0.toString();
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        int D0 = ww0.D0(parcel, 20293);
        int i3 = this.g;
        ww0.J1(parcel, 1, 4);
        parcel.writeInt(i3);
        long j2 = this.h;
        ww0.J1(parcel, 2, 8);
        parcel.writeLong(j2);
        long j3 = this.i;
        ww0.J1(parcel, 3, 8);
        parcel.writeLong(j3);
        boolean z = this.j;
        ww0.J1(parcel, 4, 4);
        parcel.writeInt(z ? 1 : 0);
        long j4 = this.k;
        ww0.J1(parcel, 5, 8);
        parcel.writeLong(j4);
        int i4 = this.l;
        ww0.J1(parcel, 6, 4);
        parcel.writeInt(i4);
        float f = this.m;
        ww0.J1(parcel, 7, 4);
        parcel.writeFloat(f);
        long j5 = this.n;
        ww0.J1(parcel, 8, 8);
        parcel.writeLong(j5);
        ww0.I1(parcel, D0);
    }
}
