package com.google.android.gms.location;

import android.location.Location;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public final class LocationResult extends y01 implements ReflectedParcelable {
    public static final Parcelable.Creator<LocationResult> CREATOR = new c92();
    public static final List<Location> h = Collections.emptyList();
    public final List<Location> g;

    public LocationResult(List<Location> list) {
        this.g = list;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof LocationResult)) {
            return false;
        }
        LocationResult locationResult = (LocationResult) obj;
        if (locationResult.g.size() != this.g.size()) {
            return false;
        }
        Iterator<Location> it = this.g.iterator();
        for (Location location : locationResult.g) {
            if (it.next().getTime() != location.getTime()) {
                return false;
            }
        }
        return true;
    }

    public final int hashCode() {
        int i = 17;
        for (Location location : this.g) {
            long time = location.getTime();
            i = (i * 31) + ((int) (time ^ (time >>> 32)));
        }
        return i;
    }

    public final String toString() {
        String valueOf = String.valueOf(this.g);
        return ze0.c0(valueOf.length() + 27, "LocationResult[locations: ", valueOf, "]");
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int D0 = ww0.D0(parcel, 20293);
        ww0.p0(parcel, 1, this.g, false);
        ww0.I1(parcel, D0);
    }
}
