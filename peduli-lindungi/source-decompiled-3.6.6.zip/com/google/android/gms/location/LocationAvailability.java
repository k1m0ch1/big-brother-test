package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.util.Arrays;

public final class LocationAvailability extends y01 implements ReflectedParcelable {
    public static final Parcelable.Creator<LocationAvailability> CREATOR = new a92();
    @Deprecated
    public int g;
    @Deprecated
    public int h;
    public long i;
    public int j;
    public e92[] k;

    public LocationAvailability(int i2, int i3, int i4, long j2, e92[] e92Arr) {
        this.j = i2;
        this.g = i3;
        this.h = i4;
        this.i = j2;
        this.k = e92Arr;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && LocationAvailability.class == obj.getClass()) {
            LocationAvailability locationAvailability = (LocationAvailability) obj;
            return this.g == locationAvailability.g && this.h == locationAvailability.h && this.i == locationAvailability.i && this.j == locationAvailability.j && Arrays.equals(this.k, locationAvailability.k);
        }
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.j), Integer.valueOf(this.g), Integer.valueOf(this.h), Long.valueOf(this.i), this.k});
    }

    public final String toString() {
        boolean z = this.j < 1000;
        StringBuilder sb = new StringBuilder(48);
        sb.append("LocationAvailability[isLocationAvailable: ");
        sb.append(z);
        sb.append("]");
        return sb.toString();
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        int D0 = ww0.D0(parcel, 20293);
        int i3 = this.g;
        ww0.J1(parcel, 1, 4);
        parcel.writeInt(i3);
        int i4 = this.h;
        ww0.J1(parcel, 2, 4);
        parcel.writeInt(i4);
        long j2 = this.i;
        ww0.J1(parcel, 3, 8);
        parcel.writeLong(j2);
        int i5 = this.j;
        ww0.J1(parcel, 4, 4);
        parcel.writeInt(i5);
        ww0.o0(parcel, 5, this.k, i2, false);
        ww0.I1(parcel, D0);
    }
}
