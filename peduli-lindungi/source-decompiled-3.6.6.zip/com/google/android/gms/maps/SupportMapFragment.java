package com.google.android.gms.maps;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.RemoteException;
import android.os.StrictMode;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.maps.model.RuntimeRemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class SupportMapFragment extends Fragment {
    public final b g = new b(this);

    public static class a implements i31 {
        public final Fragment a;
        public final ea2 b;

        public a(Fragment fragment, ea2 ea2) {
            this.b = ea2;
            Objects.requireNonNull(fragment, "null reference");
            this.a = fragment;
        }

        public final void a(y92 y92) {
            try {
                this.b.m0(new qc2(y92));
            } catch (RemoteException e) {
                throw new RuntimeRemoteException(e);
            }
        }
    }

    public static class b extends g31<a> {
        public final Fragment e;
        public k31<a> f;
        public Activity g;
        public final List<y92> h = new ArrayList();

        public b(Fragment fragment) {
            this.e = fragment;
        }

        public final void c() {
            Activity activity = this.g;
            if (activity != null && this.f != null && this.a == null) {
                try {
                    x92.a(activity);
                    ea2 F0 = bb2.a(this.g).F0(new j31(this.g));
                    if (F0 != null) {
                        ((l31) this.f).a(new a(this.e, F0));
                        for (y92 y92 : this.h) {
                            ((a) this.a).a(y92);
                        }
                        this.h.clear();
                    }
                } catch (RemoteException e2) {
                    throw new RuntimeRemoteException(e2);
                } catch (GooglePlayServicesNotAvailableException unused) {
                }
            }
        }
    }

    public void R1(y92 y92) {
        ww0.h("getMapAsync must be called on the main thread.");
        b bVar = this.g;
        T t = bVar.a;
        if (t != null) {
            try {
                ((a) t).b.m0(new qc2(y92));
            } catch (RemoteException e) {
                throw new RuntimeRemoteException(e);
            }
        } else {
            bVar.h.add(y92);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onActivityCreated(Bundle bundle) {
        if (bundle != null) {
            bundle.setClassLoader(SupportMapFragment.class.getClassLoader());
        }
        super.onActivityCreated(bundle);
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        b bVar = this.g;
        bVar.g = activity;
        bVar.c();
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        b bVar = this.g;
        bVar.a(bundle, new m31(bVar, bundle));
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        b bVar = this.g;
        Objects.requireNonNull(bVar);
        FrameLayout frameLayout = new FrameLayout(layoutInflater.getContext());
        bVar.a(bundle, new p31(bVar, frameLayout, layoutInflater, viewGroup, bundle));
        if (bVar.a == null) {
            Object obj = ix0.c;
            ix0 ix0 = ix0.d;
            Context context = frameLayout.getContext();
            int c = ix0.c(context);
            String c2 = i01.c(context, c);
            String b2 = i01.b(context, c);
            LinearLayout linearLayout = new LinearLayout(frameLayout.getContext());
            linearLayout.setOrientation(1);
            linearLayout.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
            frameLayout.addView(linearLayout);
            TextView textView = new TextView(frameLayout.getContext());
            textView.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
            textView.setText(c2);
            linearLayout.addView(textView);
            Intent a2 = ix0.a(context, c, null);
            if (a2 != null) {
                Button button = new Button(context);
                button.setId(16908313);
                button.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
                button.setText(b2);
                linearLayout.addView(button);
                button.setOnClickListener(new o31(context, a2));
            }
        }
        frameLayout.setClickable(true);
        return frameLayout;
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroy() {
        b bVar = this.g;
        T t = bVar.a;
        if (t != null) {
            try {
                ((a) t).b.m();
            } catch (RemoteException e) {
                throw new RuntimeRemoteException(e);
            }
        } else {
            bVar.b(1);
        }
        super.onDestroy();
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        b bVar = this.g;
        T t = bVar.a;
        if (t != null) {
            try {
                ((a) t).b.G0();
            } catch (RemoteException e) {
                throw new RuntimeRemoteException(e);
            }
        } else {
            bVar.b(2);
        }
        super.onDestroyView();
    }

    @Override // androidx.fragment.app.Fragment
    public void onInflate(Activity activity, AttributeSet attributeSet, Bundle bundle) {
        StrictMode.ThreadPolicy threadPolicy = StrictMode.getThreadPolicy();
        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder(threadPolicy).permitAll().build());
        try {
            super.onInflate(activity, attributeSet, bundle);
            b bVar = this.g;
            bVar.g = activity;
            bVar.c();
            GoogleMapOptions r = GoogleMapOptions.r(activity, attributeSet);
            Bundle bundle2 = new Bundle();
            bundle2.putParcelable("MapOptions", r);
            b bVar2 = this.g;
            bVar2.a(bundle, new n31(bVar2, activity, bundle2, bundle));
        } finally {
            StrictMode.setThreadPolicy(threadPolicy);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onLowMemory() {
        T t = this.g.a;
        if (t != null) {
            try {
                ((a) t).b.onLowMemory();
            } catch (RemoteException e) {
                throw new RuntimeRemoteException(e);
            }
        }
        super.onLowMemory();
    }

    @Override // androidx.fragment.app.Fragment
    public void onPause() {
        b bVar = this.g;
        T t = bVar.a;
        if (t != null) {
            try {
                ((a) t).b.D0();
            } catch (RemoteException e) {
                throw new RuntimeRemoteException(e);
            }
        } else {
            bVar.b(5);
        }
        super.onPause();
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        b bVar = this.g;
        bVar.a(null, new q31(bVar));
    }

    @Override // androidx.fragment.app.Fragment
    public void onSaveInstanceState(Bundle bundle) {
        if (bundle != null) {
            bundle.setClassLoader(SupportMapFragment.class.getClassLoader());
        }
        super.onSaveInstanceState(bundle);
        b bVar = this.g;
        T t = bVar.a;
        if (t != null) {
            a aVar = (a) t;
            try {
                Bundle bundle2 = new Bundle();
                ab2.b(bundle, bundle2);
                aVar.b.X0(bundle2);
                ab2.b(bundle2, bundle);
            } catch (RemoteException e) {
                throw new RuntimeRemoteException(e);
            }
        } else {
            Bundle bundle3 = bVar.b;
            if (bundle3 != null) {
                bundle.putAll(bundle3);
            }
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onStart() {
        super.onStart();
        b bVar = this.g;
        bVar.a(null, new r31(bVar));
    }

    @Override // androidx.fragment.app.Fragment
    public void onStop() {
        b bVar = this.g;
        T t = bVar.a;
        if (t != null) {
            try {
                ((a) t).b.g();
            } catch (RemoteException e) {
                throw new RuntimeRemoteException(e);
            }
        } else {
            bVar.b(4);
        }
        super.onStop();
    }

    @Override // androidx.fragment.app.Fragment
    public void setArguments(Bundle bundle) {
        super.setArguments(bundle);
    }
}
