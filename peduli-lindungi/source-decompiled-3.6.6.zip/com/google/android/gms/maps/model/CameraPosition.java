package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.github.mikephil.charting.utils.Utils;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.util.Arrays;

public final class CameraPosition extends y01 implements ReflectedParcelable {
    public static final Parcelable.Creator<CameraPosition> CREATOR = new dc2();
    public final LatLng g;
    public final float h;
    public final float i;
    public final float j;

    public CameraPosition(LatLng latLng, float f, float f2, float f3) {
        ww0.m(latLng, "null camera target");
        ww0.f(Utils.FLOAT_EPSILON <= f2 && f2 <= 90.0f, "Tilt needs to be between 0 and 90 inclusive: %s", Float.valueOf(f2));
        this.g = latLng;
        this.h = f;
        this.i = f2 + Utils.FLOAT_EPSILON;
        this.j = (((double) f3) <= Utils.DOUBLE_EPSILON ? (f3 % 360.0f) + 360.0f : f3) % 360.0f;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof CameraPosition)) {
            return false;
        }
        CameraPosition cameraPosition = (CameraPosition) obj;
        return this.g.equals(cameraPosition.g) && Float.floatToIntBits(this.h) == Float.floatToIntBits(cameraPosition.h) && Float.floatToIntBits(this.i) == Float.floatToIntBits(cameraPosition.i) && Float.floatToIntBits(this.j) == Float.floatToIntBits(cameraPosition.j);
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.g, Float.valueOf(this.h), Float.valueOf(this.i), Float.valueOf(this.j)});
    }

    public final String toString() {
        t01 t01 = new t01(this, null);
        t01.a("target", this.g);
        t01.a("zoom", Float.valueOf(this.h));
        t01.a("tilt", Float.valueOf(this.i));
        t01.a("bearing", Float.valueOf(this.j));
        return t01.toString();
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        int D0 = ww0.D0(parcel, 20293);
        ww0.l0(parcel, 2, this.g, i2, false);
        float f = this.h;
        ww0.J1(parcel, 3, 4);
        parcel.writeFloat(f);
        float f2 = this.i;
        ww0.J1(parcel, 4, 4);
        parcel.writeFloat(f2);
        float f3 = this.j;
        ww0.J1(parcel, 5, 4);
        parcel.writeFloat(f3);
        ww0.I1(parcel, D0);
    }
}
