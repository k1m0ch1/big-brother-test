package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.util.Arrays;

public final class LatLngBounds extends y01 implements ReflectedParcelable {
    public static final Parcelable.Creator<LatLngBounds> CREATOR = new hc2();
    public final LatLng g;
    public final LatLng h;

    public LatLngBounds(LatLng latLng, LatLng latLng2) {
        ww0.m(latLng, "null southwest");
        ww0.m(latLng2, "null northeast");
        double d = latLng2.g;
        double d2 = latLng.g;
        ww0.f(d >= d2, "southern latitude exceeds northern latitude (%s > %s)", Double.valueOf(d2), Double.valueOf(latLng2.g));
        this.g = latLng;
        this.h = latLng2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof LatLngBounds)) {
            return false;
        }
        LatLngBounds latLngBounds = (LatLngBounds) obj;
        return this.g.equals(latLngBounds.g) && this.h.equals(latLngBounds.h);
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.g, this.h});
    }

    public final boolean r(LatLng latLng) {
        double d = latLng.g;
        LatLng latLng2 = this.g;
        if (latLng2.g <= d && d <= this.h.g) {
            double d2 = latLng.h;
            double d3 = latLng2.h;
            double d4 = this.h.h;
            if (d3 > d4 ? d3 <= d2 || d2 <= d4 : d3 <= d2 && d2 <= d4) {
                return true;
            }
        }
        return false;
    }

    public final String toString() {
        t01 t01 = new t01(this, null);
        t01.a("southwest", this.g);
        t01.a("northeast", this.h);
        return t01.toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int D0 = ww0.D0(parcel, 20293);
        ww0.l0(parcel, 2, this.g, i, false);
        ww0.l0(parcel, 3, this.h, i, false);
        ww0.I1(parcel, D0);
    }
}
