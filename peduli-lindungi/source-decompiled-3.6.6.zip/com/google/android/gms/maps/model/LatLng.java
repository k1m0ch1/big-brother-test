package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;

public final class LatLng extends y01 implements ReflectedParcelable {
    public static final Parcelable.Creator<LatLng> CREATOR = new ic2();
    public final double g;
    public final double h;

    public LatLng(double d, double d2) {
        if (-180.0d > d2 || d2 >= 180.0d) {
            this.h = ((((d2 - 180.0d) % 360.0d) + 360.0d) % 360.0d) - 180.0d;
        } else {
            this.h = d2;
        }
        this.g = Math.max(-90.0d, Math.min(90.0d, d));
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof LatLng)) {
            return false;
        }
        LatLng latLng = (LatLng) obj;
        return Double.doubleToLongBits(this.g) == Double.doubleToLongBits(latLng.g) && Double.doubleToLongBits(this.h) == Double.doubleToLongBits(latLng.h);
    }

    public final int hashCode() {
        long doubleToLongBits = Double.doubleToLongBits(this.g);
        long doubleToLongBits2 = Double.doubleToLongBits(this.h);
        return ((((int) (doubleToLongBits ^ (doubleToLongBits >>> 32))) + 31) * 31) + ((int) (doubleToLongBits2 ^ (doubleToLongBits2 >>> 32)));
    }

    public final String toString() {
        double d = this.g;
        double d2 = this.h;
        StringBuilder sb = new StringBuilder(60);
        sb.append("lat/lng: (");
        sb.append(d);
        sb.append(",");
        sb.append(d2);
        sb.append(")");
        return sb.toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int D0 = ww0.D0(parcel, 20293);
        double d = this.g;
        ww0.J1(parcel, 2, 8);
        parcel.writeDouble(d);
        double d2 = this.h;
        ww0.J1(parcel, 3, 8);
        parcel.writeDouble(d2);
        ww0.I1(parcel, D0);
    }
}
