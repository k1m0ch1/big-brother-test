package com.google.android.gms.maps;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import com.github.mikephil.charting.utils.Utils;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;

public final class GoogleMapOptions extends y01 implements ReflectedParcelable {
    public static final Parcelable.Creator<GoogleMapOptions> CREATOR = new pc2();
    public Boolean g;
    public Boolean h;
    public int i = -1;
    public CameraPosition j;
    public Boolean k;
    public Boolean l;
    public Boolean m;
    public Boolean n;
    public Boolean o;
    public Boolean p;
    public Boolean q;
    public Boolean r;
    public Boolean s;
    public Float t = null;
    public Float u = null;
    public LatLngBounds v = null;
    public Boolean w;

    public GoogleMapOptions(byte b, byte b2, int i2, CameraPosition cameraPosition, byte b3, byte b4, byte b5, byte b6, byte b7, byte b8, byte b9, byte b10, byte b11, Float f, Float f2, LatLngBounds latLngBounds, byte b12) {
        this.g = ww0.U0(b);
        this.h = ww0.U0(b2);
        this.i = i2;
        this.j = cameraPosition;
        this.k = ww0.U0(b3);
        this.l = ww0.U0(b4);
        this.m = ww0.U0(b5);
        this.n = ww0.U0(b6);
        this.o = ww0.U0(b7);
        this.p = ww0.U0(b8);
        this.q = ww0.U0(b9);
        this.r = ww0.U0(b10);
        this.s = ww0.U0(b11);
        this.t = f;
        this.u = f2;
        this.v = latLngBounds;
        this.w = ww0.U0(b12);
    }

    public static GoogleMapOptions r(Context context, AttributeSet attributeSet) {
        LatLngBounds latLngBounds = null;
        if (context == null || attributeSet == null) {
            return null;
        }
        Resources resources = context.getResources();
        int[] iArr = aa2.a;
        TypedArray obtainAttributes = resources.obtainAttributes(attributeSet, iArr);
        GoogleMapOptions googleMapOptions = new GoogleMapOptions();
        if (obtainAttributes.hasValue(13)) {
            googleMapOptions.i = obtainAttributes.getInt(13, -1);
        }
        if (obtainAttributes.hasValue(23)) {
            googleMapOptions.g = Boolean.valueOf(obtainAttributes.getBoolean(23, false));
        }
        if (obtainAttributes.hasValue(22)) {
            googleMapOptions.h = Boolean.valueOf(obtainAttributes.getBoolean(22, false));
        }
        if (obtainAttributes.hasValue(14)) {
            googleMapOptions.l = Boolean.valueOf(obtainAttributes.getBoolean(14, true));
        }
        if (obtainAttributes.hasValue(16)) {
            googleMapOptions.p = Boolean.valueOf(obtainAttributes.getBoolean(16, true));
        }
        if (obtainAttributes.hasValue(18)) {
            googleMapOptions.w = Boolean.valueOf(obtainAttributes.getBoolean(18, true));
        }
        if (obtainAttributes.hasValue(17)) {
            googleMapOptions.m = Boolean.valueOf(obtainAttributes.getBoolean(17, true));
        }
        if (obtainAttributes.hasValue(19)) {
            googleMapOptions.o = Boolean.valueOf(obtainAttributes.getBoolean(19, true));
        }
        if (obtainAttributes.hasValue(21)) {
            googleMapOptions.n = Boolean.valueOf(obtainAttributes.getBoolean(21, true));
        }
        if (obtainAttributes.hasValue(20)) {
            googleMapOptions.k = Boolean.valueOf(obtainAttributes.getBoolean(20, true));
        }
        if (obtainAttributes.hasValue(12)) {
            googleMapOptions.q = Boolean.valueOf(obtainAttributes.getBoolean(12, false));
        }
        if (obtainAttributes.hasValue(15)) {
            googleMapOptions.r = Boolean.valueOf(obtainAttributes.getBoolean(15, true));
        }
        if (obtainAttributes.hasValue(0)) {
            googleMapOptions.s = Boolean.valueOf(obtainAttributes.getBoolean(0, false));
        }
        if (obtainAttributes.hasValue(3)) {
            googleMapOptions.t = Float.valueOf(obtainAttributes.getFloat(3, Float.NEGATIVE_INFINITY));
        }
        if (obtainAttributes.hasValue(3)) {
            googleMapOptions.u = Float.valueOf(obtainAttributes.getFloat(2, Float.POSITIVE_INFINITY));
        }
        TypedArray obtainAttributes2 = context.getResources().obtainAttributes(attributeSet, iArr);
        boolean hasValue = obtainAttributes2.hasValue(10);
        float f = Utils.FLOAT_EPSILON;
        Float valueOf = hasValue ? Float.valueOf(obtainAttributes2.getFloat(10, Utils.FLOAT_EPSILON)) : null;
        Float valueOf2 = obtainAttributes2.hasValue(11) ? Float.valueOf(obtainAttributes2.getFloat(11, Utils.FLOAT_EPSILON)) : null;
        Float valueOf3 = obtainAttributes2.hasValue(8) ? Float.valueOf(obtainAttributes2.getFloat(8, Utils.FLOAT_EPSILON)) : null;
        Float valueOf4 = obtainAttributes2.hasValue(9) ? Float.valueOf(obtainAttributes2.getFloat(9, Utils.FLOAT_EPSILON)) : null;
        obtainAttributes2.recycle();
        if (!(valueOf == null || valueOf2 == null || valueOf3 == null || valueOf4 == null)) {
            latLngBounds = new LatLngBounds(new LatLng((double) valueOf.floatValue(), (double) valueOf2.floatValue()), new LatLng((double) valueOf3.floatValue(), (double) valueOf4.floatValue()));
        }
        googleMapOptions.v = latLngBounds;
        TypedArray obtainAttributes3 = context.getResources().obtainAttributes(attributeSet, iArr);
        LatLng latLng = new LatLng((double) (obtainAttributes3.hasValue(4) ? obtainAttributes3.getFloat(4, Utils.FLOAT_EPSILON) : Utils.FLOAT_EPSILON), (double) (obtainAttributes3.hasValue(5) ? obtainAttributes3.getFloat(5, Utils.FLOAT_EPSILON) : Utils.FLOAT_EPSILON));
        float f2 = obtainAttributes3.hasValue(7) ? obtainAttributes3.getFloat(7, Utils.FLOAT_EPSILON) : Utils.FLOAT_EPSILON;
        float f3 = obtainAttributes3.hasValue(1) ? obtainAttributes3.getFloat(1, Utils.FLOAT_EPSILON) : Utils.FLOAT_EPSILON;
        if (obtainAttributes3.hasValue(6)) {
            f = obtainAttributes3.getFloat(6, Utils.FLOAT_EPSILON);
        }
        obtainAttributes3.recycle();
        googleMapOptions.j = new CameraPosition(latLng, f2, f, f3);
        obtainAttributes.recycle();
        return googleMapOptions;
    }

    public final String toString() {
        t01 t01 = new t01(this, null);
        t01.a("MapType", Integer.valueOf(this.i));
        t01.a("LiteMode", this.q);
        t01.a("Camera", this.j);
        t01.a("CompassEnabled", this.l);
        t01.a("ZoomControlsEnabled", this.k);
        t01.a("ScrollGesturesEnabled", this.m);
        t01.a("ZoomGesturesEnabled", this.n);
        t01.a("TiltGesturesEnabled", this.o);
        t01.a("RotateGesturesEnabled", this.p);
        t01.a("ScrollGesturesEnabledDuringRotateOrZoom", this.w);
        t01.a("MapToolbarEnabled", this.r);
        t01.a("AmbientEnabled", this.s);
        t01.a("MinZoomPreference", this.t);
        t01.a("MaxZoomPreference", this.u);
        t01.a("LatLngBoundsForCameraTarget", this.v);
        t01.a("ZOrderOnTop", this.g);
        t01.a("UseViewLifecycleInFragment", this.h);
        return t01.toString();
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        int D0 = ww0.D0(parcel, 20293);
        byte q0 = ww0.q0(this.g);
        ww0.J1(parcel, 2, 4);
        parcel.writeInt(q0);
        byte q02 = ww0.q0(this.h);
        ww0.J1(parcel, 3, 4);
        parcel.writeInt(q02);
        int i3 = this.i;
        ww0.J1(parcel, 4, 4);
        parcel.writeInt(i3);
        ww0.l0(parcel, 5, this.j, i2, false);
        byte q03 = ww0.q0(this.k);
        ww0.J1(parcel, 6, 4);
        parcel.writeInt(q03);
        byte q04 = ww0.q0(this.l);
        ww0.J1(parcel, 7, 4);
        parcel.writeInt(q04);
        byte q05 = ww0.q0(this.m);
        ww0.J1(parcel, 8, 4);
        parcel.writeInt(q05);
        byte q06 = ww0.q0(this.n);
        ww0.J1(parcel, 9, 4);
        parcel.writeInt(q06);
        byte q07 = ww0.q0(this.o);
        ww0.J1(parcel, 10, 4);
        parcel.writeInt(q07);
        byte q08 = ww0.q0(this.p);
        ww0.J1(parcel, 11, 4);
        parcel.writeInt(q08);
        byte q09 = ww0.q0(this.q);
        ww0.J1(parcel, 12, 4);
        parcel.writeInt(q09);
        byte q010 = ww0.q0(this.r);
        ww0.J1(parcel, 14, 4);
        parcel.writeInt(q010);
        byte q011 = ww0.q0(this.s);
        ww0.J1(parcel, 15, 4);
        parcel.writeInt(q011);
        ww0.i0(parcel, 16, this.t, false);
        ww0.i0(parcel, 17, this.u, false);
        ww0.l0(parcel, 18, this.v, i2, false);
        byte q012 = ww0.q0(this.w);
        ww0.J1(parcel, 19, 4);
        parcel.writeInt(q012);
        ww0.I1(parcel, D0);
    }

    public GoogleMapOptions() {
    }
}
