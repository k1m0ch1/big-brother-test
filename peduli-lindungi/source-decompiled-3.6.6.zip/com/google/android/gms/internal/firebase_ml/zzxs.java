package com.google.android.gms.internal.firebase_ml;

import java.io.IOException;

/* compiled from: com.google.firebase:firebase-ml-common@@22.1.2 */
public class zzxs extends IOException {
    public static final /* synthetic */ int g = 0;

    public zzxs(String str) {
        super(str);
    }
}
