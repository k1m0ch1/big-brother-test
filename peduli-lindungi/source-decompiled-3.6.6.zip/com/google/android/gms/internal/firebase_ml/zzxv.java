package com.google.android.gms.internal.firebase_ml;

/* compiled from: com.google.firebase:firebase-ml-common@@22.1.2 */
public final class zzxv extends zzxs {
    public zzxv(String str) {
        super(str);
    }
}
