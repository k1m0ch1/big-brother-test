package com.google.android.gms.internal.firebase_ml;

import androidx.recyclerview.widget.RecyclerView;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/* compiled from: com.google.firebase:firebase-ml-common@@22.1.2 */
public abstract class zzwq extends xj1 {
    public static final Logger b = Logger.getLogger(zzwq.class.getName());
    public static final boolean c = kc1.h;
    public dk1 a;

    /* compiled from: com.google.firebase:firebase-ml-common@@22.1.2 */
    public static class a extends zzwq {
        public final byte[] d;
        public final int e;
        public int f;

        public a(byte[] bArr, int i) {
            super(null);
            if ((i | 0 | (bArr.length - i)) >= 0) {
                this.d = bArr;
                this.f = 0;
                this.e = i;
                return;
            }
            throw new IllegalArgumentException(String.format("Array range is invalid. Buffer.length=%d, offset=%d, length=%d", Integer.valueOf(bArr.length), 0, Integer.valueOf(i)));
        }

        @Override // com.google.android.gms.internal.firebase_ml.zzwq
        public final void J(int i, int i2) {
            y((i << 3) | 0);
            if (i2 >= 0) {
                y(i2);
            } else {
                T((long) i2);
            }
        }

        @Override // com.google.android.gms.internal.firebase_ml.zzwq
        public final void K(int i, int i2) {
            y((i << 3) | 0);
            y(i2);
        }

        @Override // com.google.android.gms.internal.firebase_ml.zzwq
        public final void L(int i, int i2) {
            y((i << 3) | 5);
            z(i2);
        }

        @Override // com.google.android.gms.internal.firebase_ml.zzwq
        public final int S() {
            return this.e - this.f;
        }

        @Override // com.google.android.gms.internal.firebase_ml.zzwq
        public final void T(long j) {
            if (!zzwq.c || S() < 10) {
                while ((j & -128) != 0) {
                    byte[] bArr = this.d;
                    int i = this.f;
                    this.f = i + 1;
                    bArr[i] = (byte) ((((int) j) & 127) | RecyclerView.b0.FLAG_IGNORE);
                    j >>>= 7;
                }
                try {
                    byte[] bArr2 = this.d;
                    int i2 = this.f;
                    this.f = i2 + 1;
                    bArr2[i2] = (byte) ((int) j);
                } catch (IndexOutOfBoundsException e2) {
                    throw new zzb(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.f), Integer.valueOf(this.e), 1), e2);
                }
            } else {
                while ((j & -128) != 0) {
                    byte[] bArr3 = this.d;
                    int i3 = this.f;
                    this.f = i3 + 1;
                    kc1.e(bArr3, (long) i3, (byte) ((((int) j) & 127) | RecyclerView.b0.FLAG_IGNORE));
                    j >>>= 7;
                }
                byte[] bArr4 = this.d;
                int i4 = this.f;
                this.f = i4 + 1;
                kc1.e(bArr4, (long) i4, (byte) ((int) j));
            }
        }

        @Override // com.google.android.gms.internal.firebase_ml.zzwq
        public final void U(long j) {
            try {
                byte[] bArr = this.d;
                int i = this.f;
                int i2 = i + 1;
                this.f = i2;
                bArr[i] = (byte) ((int) j);
                int i3 = i2 + 1;
                this.f = i3;
                bArr[i2] = (byte) ((int) (j >> 8));
                int i4 = i3 + 1;
                this.f = i4;
                bArr[i3] = (byte) ((int) (j >> 16));
                int i5 = i4 + 1;
                this.f = i5;
                bArr[i4] = (byte) ((int) (j >> 24));
                int i6 = i5 + 1;
                this.f = i6;
                bArr[i5] = (byte) ((int) (j >> 32));
                int i7 = i6 + 1;
                this.f = i7;
                bArr[i6] = (byte) ((int) (j >> 40));
                int i8 = i7 + 1;
                this.f = i8;
                bArr[i7] = (byte) ((int) (j >> 48));
                this.f = i8 + 1;
                bArr[i8] = (byte) ((int) (j >> 56));
            } catch (IndexOutOfBoundsException e2) {
                throw new zzb(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.f), Integer.valueOf(this.e), 1), e2);
            }
        }

        public final void V(byte[] bArr, int i, int i2) {
            try {
                System.arraycopy(bArr, i, this.d, this.f, i2);
                this.f += i2;
            } catch (IndexOutOfBoundsException e2) {
                throw new zzb(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.f), Integer.valueOf(this.e), Integer.valueOf(i2)), e2);
            }
        }

        public final void W(zj1 zj1) {
            y(zj1.size());
            zj1.a(this);
        }

        public final void X(String str) {
            int i = this.f;
            try {
                int C = zzwq.C(str.length() * 3);
                int C2 = zzwq.C(str.length());
                if (C2 == C) {
                    int i2 = i + C2;
                    this.f = i2;
                    int b = nc1.a.b(str, this.d, i2, S());
                    this.f = i;
                    y((b - i) - C2);
                    this.f = b;
                    return;
                }
                y(nc1.a(str));
                this.f = nc1.a.b(str, this.d, this.f, S());
            } catch (pc1 e2) {
                this.f = i;
                zzwq.b.logp(Level.WARNING, "com.google.protobuf.CodedOutputStream", "inefficientWriteStringNoTag", "Converting ill-formed UTF-16. Your Protocol Buffer will not round trip correctly!", (Throwable) e2);
                byte[] bytes = str.getBytes(sk1.a);
                try {
                    y(bytes.length);
                    V(bytes, 0, bytes.length);
                } catch (IndexOutOfBoundsException e3) {
                    throw new zzb(e3);
                } catch (zzb e4) {
                    throw e4;
                }
            } catch (IndexOutOfBoundsException e5) {
                throw new zzb(e5);
            }
        }

        @Override // com.google.android.gms.internal.firebase_ml.zzwq
        public final void a(int i, int i2) {
            y((i << 3) | i2);
        }

        @Override // com.google.android.gms.internal.firebase_ml.zzwq
        public final void c(int i, long j) {
            y((i << 3) | 0);
            T(j);
        }

        @Override // com.google.android.gms.internal.firebase_ml.zzwq
        public final void d(int i, zj1 zj1) {
            y((i << 3) | 2);
            W(zj1);
        }

        @Override // com.google.android.gms.internal.firebase_ml.zzwq
        public final void e(int i, ul1 ul1) {
            a(1, 3);
            K(2, i);
            a(3, 2);
            y(ul1.b());
            ul1.f(this);
            a(1, 4);
        }

        @Override // com.google.android.gms.internal.firebase_ml.zzwq
        public final void f(int i, ul1 ul1, km1 km1) {
            y((i << 3) | 2);
            sj1 sj1 = (sj1) ul1;
            int g = sj1.g();
            if (g == -1) {
                g = km1.g(sj1);
                sj1.a(g);
            }
            y(g);
            km1.e(ul1, this.a);
        }

        @Override // com.google.android.gms.internal.firebase_ml.zzwq
        public final void g(int i, boolean z) {
            y((i << 3) | 0);
            w(z ? (byte) 1 : 0);
        }

        @Override // com.google.android.gms.internal.firebase_ml.zzwq
        public final void l(int i, zj1 zj1) {
            a(1, 3);
            K(2, i);
            d(3, zj1);
            a(1, 4);
        }

        @Override // com.google.android.gms.internal.firebase_ml.zzwq
        public final void m(int i, String str) {
            y((i << 3) | 2);
            X(str);
        }

        @Override // com.google.android.gms.internal.firebase_ml.zzwq
        public final void s(int i, long j) {
            y((i << 3) | 1);
            U(j);
        }

        @Override // com.google.android.gms.internal.firebase_ml.zzwq
        public final void w(byte b) {
            try {
                byte[] bArr = this.d;
                int i = this.f;
                this.f = i + 1;
                bArr[i] = b;
            } catch (IndexOutOfBoundsException e2) {
                throw new zzb(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.f), Integer.valueOf(this.e), 1), e2);
            }
        }

        @Override // com.google.android.gms.internal.firebase_ml.zzwq
        public final void x(int i) {
            if (i >= 0) {
                y(i);
            } else {
                T((long) i);
            }
        }

        @Override // com.google.android.gms.internal.firebase_ml.zzwq
        public final void y(int i) {
            if (!zzwq.c || vj1.a() || S() < 5) {
                while ((i & -128) != 0) {
                    byte[] bArr = this.d;
                    int i2 = this.f;
                    this.f = i2 + 1;
                    bArr[i2] = (byte) ((i & 127) | RecyclerView.b0.FLAG_IGNORE);
                    i >>>= 7;
                }
                try {
                    byte[] bArr2 = this.d;
                    int i3 = this.f;
                    this.f = i3 + 1;
                    bArr2[i3] = (byte) i;
                } catch (IndexOutOfBoundsException e2) {
                    throw new zzb(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.f), Integer.valueOf(this.e), 1), e2);
                }
            } else if ((i & -128) == 0) {
                byte[] bArr3 = this.d;
                int i4 = this.f;
                this.f = i4 + 1;
                kc1.e(bArr3, (long) i4, (byte) i);
            } else {
                byte[] bArr4 = this.d;
                int i5 = this.f;
                this.f = i5 + 1;
                kc1.e(bArr4, (long) i5, (byte) (i | RecyclerView.b0.FLAG_IGNORE));
                int i6 = i >>> 7;
                if ((i6 & -128) == 0) {
                    byte[] bArr5 = this.d;
                    int i7 = this.f;
                    this.f = i7 + 1;
                    kc1.e(bArr5, (long) i7, (byte) i6);
                    return;
                }
                byte[] bArr6 = this.d;
                int i8 = this.f;
                this.f = i8 + 1;
                kc1.e(bArr6, (long) i8, (byte) (i6 | RecyclerView.b0.FLAG_IGNORE));
                int i9 = i6 >>> 7;
                if ((i9 & -128) == 0) {
                    byte[] bArr7 = this.d;
                    int i10 = this.f;
                    this.f = i10 + 1;
                    kc1.e(bArr7, (long) i10, (byte) i9);
                    return;
                }
                byte[] bArr8 = this.d;
                int i11 = this.f;
                this.f = i11 + 1;
                kc1.e(bArr8, (long) i11, (byte) (i9 | RecyclerView.b0.FLAG_IGNORE));
                int i12 = i9 >>> 7;
                if ((i12 & -128) == 0) {
                    byte[] bArr9 = this.d;
                    int i13 = this.f;
                    this.f = i13 + 1;
                    kc1.e(bArr9, (long) i13, (byte) i12);
                    return;
                }
                byte[] bArr10 = this.d;
                int i14 = this.f;
                this.f = i14 + 1;
                kc1.e(bArr10, (long) i14, (byte) (i12 | RecyclerView.b0.FLAG_IGNORE));
                byte[] bArr11 = this.d;
                int i15 = this.f;
                this.f = i15 + 1;
                kc1.e(bArr11, (long) i15, (byte) (i12 >>> 7));
            }
        }

        @Override // com.google.android.gms.internal.firebase_ml.zzwq
        public final void z(int i) {
            try {
                byte[] bArr = this.d;
                int i2 = this.f;
                int i3 = i2 + 1;
                this.f = i3;
                bArr[i2] = (byte) i;
                int i4 = i3 + 1;
                this.f = i4;
                bArr[i3] = (byte) (i >> 8);
                int i5 = i4 + 1;
                this.f = i5;
                bArr[i4] = (byte) (i >> 16);
                this.f = i5 + 1;
                bArr[i5] = (byte) (i >>> 24);
            } catch (IndexOutOfBoundsException e2) {
                throw new zzb(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.f), Integer.valueOf(this.e), 1), e2);
            }
        }
    }

    /* compiled from: com.google.firebase:firebase-ml-common@@22.1.2 */
    public static class zzb extends IOException {
        public zzb() {
            super("CodedOutputStream was writing to a flat byte array and ran out of space.");
        }

        public zzb(Throwable th) {
            super("CodedOutputStream was writing to a flat byte array and ran out of space.", th);
        }

        /* JADX WARNING: Illegal instructions before constructor call */
        public zzb(String str, Throwable th) {
            super(r3.length() != 0 ? "CodedOutputStream was writing to a flat byte array and ran out of space.: ".concat(r3) : new String("CodedOutputStream was writing to a flat byte array and ran out of space.: "), th);
            String valueOf = String.valueOf(str);
        }
    }

    public zzwq() {
    }

    public static int A(int i) {
        return C(i << 3);
    }

    public static int B(int i) {
        if (i >= 0) {
            return C(i);
        }
        return 10;
    }

    public static int C(int i) {
        if ((i & -128) == 0) {
            return 1;
        }
        if ((i & -16384) == 0) {
            return 2;
        }
        if ((-2097152 & i) == 0) {
            return 3;
        }
        return (i & -268435456) == 0 ? 4 : 5;
    }

    public static int D(int i) {
        return C(E(i));
    }

    public static int E(int i) {
        return (i >> 31) ^ (i << 1);
    }

    public static int F(int i, long j) {
        return h(j) + C(i << 3);
    }

    public static int G(int i, long j) {
        return h(j(j)) + C(i << 3);
    }

    public static int H(int i) {
        return C(i << 3) + 8;
    }

    public static int I(int i) {
        return C(i << 3) + 8;
    }

    public static int M(int i, int i2) {
        return B(i2) + C(i << 3);
    }

    public static int N(int i, int i2) {
        return C(i2) + C(i << 3);
    }

    public static int O(int i, int i2) {
        return C(E(i2)) + C(i << 3);
    }

    public static int P(int i) {
        return C(i << 3) + 4;
    }

    public static int Q(int i) {
        return C(i << 3) + 4;
    }

    public static int R(int i, int i2) {
        return B(i2) + C(i << 3);
    }

    public static int b(ul1 ul1, km1 km1) {
        sj1 sj1 = (sj1) ul1;
        int g = sj1.g();
        if (g == -1) {
            g = km1.g(sj1);
            sj1.a(g);
        }
        return C(g) + g;
    }

    public static int h(long j) {
        int i;
        if ((-128 & j) == 0) {
            return 1;
        }
        if (j < 0) {
            return 10;
        }
        if ((-34359738368L & j) != 0) {
            i = 6;
            j >>>= 28;
        } else {
            i = 2;
        }
        if ((-2097152 & j) != 0) {
            i += 2;
            j >>>= 14;
        }
        return (j & -16384) != 0 ? i + 1 : i;
    }

    public static int i(long j) {
        return h(j(j));
    }

    public static long j(long j) {
        return (j >> 63) ^ (j << 1);
    }

    public static int k(int i) {
        return C(i << 3) + 4;
    }

    public static int n(int i) {
        return C(i << 3) + 8;
    }

    public static int o(int i) {
        return C(i << 3) + 1;
    }

    public static int p(int i, zj1 zj1) {
        int C = C(i << 3);
        int size = zj1.size();
        return C(size) + size + C;
    }

    @Deprecated
    public static int q(int i, ul1 ul1, km1 km1) {
        int C = C(i << 3) << 1;
        sj1 sj1 = (sj1) ul1;
        int g = sj1.g();
        if (g == -1) {
            g = km1.g(sj1);
            sj1.a(g);
        }
        return C + g;
    }

    public static int r(int i, String str) {
        return t(str) + C(i << 3);
    }

    public static int t(String str) {
        int i;
        try {
            i = nc1.a(str);
        } catch (pc1 unused) {
            i = str.getBytes(sk1.a).length;
        }
        return C(i) + i;
    }

    public static int u(int i, long j) {
        return h(j) + C(i << 3);
    }

    public static int v(zj1 zj1) {
        int size = zj1.size();
        return C(size) + size;
    }

    public abstract void J(int i, int i2);

    public abstract void K(int i, int i2);

    public abstract void L(int i, int i2);

    public abstract int S();

    public abstract void T(long j);

    public abstract void U(long j);

    public abstract void a(int i, int i2);

    public abstract void c(int i, long j);

    public abstract void d(int i, zj1 zj1);

    public abstract void e(int i, ul1 ul1);

    public abstract void f(int i, ul1 ul1, km1 km1);

    public abstract void g(int i, boolean z);

    public abstract void l(int i, zj1 zj1);

    public abstract void m(int i, String str);

    public abstract void s(int i, long j);

    public abstract void w(byte b2);

    public abstract void x(int i);

    public abstract void y(int i);

    public abstract void z(int i);

    public zzwq(ck1 ck1) {
    }
}
