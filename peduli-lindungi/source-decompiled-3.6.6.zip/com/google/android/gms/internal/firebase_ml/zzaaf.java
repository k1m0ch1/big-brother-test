package com.google.android.gms.internal.firebase_ml;

/* compiled from: com.google.firebase:firebase-ml-common@@22.1.2 */
public final class zzaaf extends RuntimeException {
    public zzaaf() {
        super("Message was missing required fields.  (Lite runtime could not determine which fields were missing).");
    }
}
