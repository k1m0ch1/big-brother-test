package com.google.android.gms.internal.firebase_ml;

/* compiled from: com.google.firebase:firebase-ml-vision@@24.1.0 */
public final class zzgf extends zzhg {
}
