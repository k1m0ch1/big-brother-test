package com.google.android.gms.internal.clearcut;

import com.google.maps.android.R;
import java.io.IOException;

public final class zzft extends IOException {
    /* JADX WARNING: Illegal instructions before constructor call */
    public zzft(int i, int i2) {
        super(r0.toString());
        StringBuilder sb = new StringBuilder((int) R.styleable.AppCompatTheme_textColorAlertDialogListItem);
        sb.append("CodedOutputStream was writing to a flat byte array and ran out of space (pos ");
        sb.append(i);
        sb.append(" limit ");
        sb.append(i2);
        sb.append(").");
    }
}
