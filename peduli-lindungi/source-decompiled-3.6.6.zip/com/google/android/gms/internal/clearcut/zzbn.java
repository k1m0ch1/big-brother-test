package com.google.android.gms.internal.clearcut;

import androidx.recyclerview.widget.RecyclerView;
import java.io.IOException;
import java.nio.BufferOverflowException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class zzbn extends e61 {
    public static final Logger b = Logger.getLogger(zzbn.class.getName());
    public static final boolean c = q91.h;
    public n61 a;

    public static class a extends zzbn {
        public final byte[] d;
        public final int e;
        public final int f;
        public int g;

        public a(byte[] bArr, int i, int i2) {
            super(null);
            Objects.requireNonNull(bArr, "buffer");
            int i3 = i + i2;
            if ((i | i2 | (bArr.length - i3)) >= 0) {
                this.d = bArr;
                this.e = i;
                this.g = i;
                this.f = i3;
                return;
            }
            throw new IllegalArgumentException(String.format("Array range is invalid. Buffer.length=%d, offset=%d, length=%d", Integer.valueOf(bArr.length), Integer.valueOf(i), Integer.valueOf(i2)));
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void A(int i, int i2) {
            V((i << 3) | 0);
            if (i2 >= 0) {
                V(i2);
            } else {
                u((long) i2);
            }
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void B(int i, long j) {
            V((i << 3) | 1);
            E(j);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void D(int i, int i2) {
            V((i << 3) | 0);
            V(i2);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void E(long j) {
            try {
                byte[] bArr = this.d;
                int i = this.g;
                int i2 = i + 1;
                this.g = i2;
                bArr[i] = (byte) ((int) j);
                int i3 = i2 + 1;
                this.g = i3;
                bArr[i2] = (byte) ((int) (j >> 8));
                int i4 = i3 + 1;
                this.g = i4;
                bArr[i3] = (byte) ((int) (j >> 16));
                int i5 = i4 + 1;
                this.g = i5;
                bArr[i4] = (byte) ((int) (j >> 24));
                int i6 = i5 + 1;
                this.g = i6;
                bArr[i5] = (byte) ((int) (j >> 32));
                int i7 = i6 + 1;
                this.g = i7;
                bArr[i6] = (byte) ((int) (j >> 40));
                int i8 = i7 + 1;
                this.g = i8;
                bArr[i7] = (byte) ((int) (j >> 48));
                this.g = i8 + 1;
                bArr[i8] = (byte) ((int) (j >> 56));
            } catch (IndexOutOfBoundsException e2) {
                throw new zzc(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.g), Integer.valueOf(this.f), 1), e2);
            }
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void I(int i, int i2) {
            V((i << 3) | 5);
            W(i2);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void U(int i) {
            if (i >= 0) {
                V(i);
            } else {
                u((long) i);
            }
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void V(int i) {
            if (!zzbn.c || l() < 10) {
                while ((i & -128) != 0) {
                    byte[] bArr = this.d;
                    int i2 = this.g;
                    this.g = i2 + 1;
                    bArr[i2] = (byte) ((i & 127) | RecyclerView.b0.FLAG_IGNORE);
                    i >>>= 7;
                }
                try {
                    byte[] bArr2 = this.d;
                    int i3 = this.g;
                    this.g = i3 + 1;
                    bArr2[i3] = (byte) i;
                } catch (IndexOutOfBoundsException e2) {
                    throw new zzc(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.g), Integer.valueOf(this.f), 1), e2);
                }
            } else {
                while ((i & -128) != 0) {
                    byte[] bArr3 = this.d;
                    int i4 = this.g;
                    this.g = i4 + 1;
                    q91.g(bArr3, (long) i4, (byte) ((i & 127) | RecyclerView.b0.FLAG_IGNORE));
                    i >>>= 7;
                }
                byte[] bArr4 = this.d;
                int i5 = this.g;
                this.g = i5 + 1;
                q91.g(bArr4, (long) i5, (byte) i);
            }
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void W(int i) {
            try {
                byte[] bArr = this.d;
                int i2 = this.g;
                int i3 = i2 + 1;
                this.g = i3;
                bArr[i2] = (byte) i;
                int i4 = i3 + 1;
                this.g = i4;
                bArr[i3] = (byte) (i >> 8);
                int i5 = i4 + 1;
                this.g = i5;
                bArr[i4] = (byte) (i >> 16);
                this.g = i5 + 1;
                bArr[i5] = i >> 24;
            } catch (IndexOutOfBoundsException e2) {
                throw new zzc(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.g), Integer.valueOf(this.f), 1), e2);
            }
        }

        @Override // defpackage.e61
        public final void a(byte[] bArr, int i, int i2) {
            c(bArr, i, i2);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public void b() {
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void c(byte[] bArr, int i, int i2) {
            try {
                System.arraycopy(bArr, i, this.d, this.g, i2);
                this.g += i2;
            } catch (IndexOutOfBoundsException e2) {
                throw new zzc(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.g), Integer.valueOf(this.f), Integer.valueOf(i2)), e2);
            }
        }

        public final void c0(f61 f61) {
            V(f61.size());
            f61.f(this);
        }

        public final void d0(h81 h81) {
            V(h81.j());
            h81.g(this);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void e(byte b) {
            try {
                byte[] bArr = this.d;
                int i = this.g;
                this.g = i + 1;
                bArr[i] = b;
            } catch (IndexOutOfBoundsException e2) {
                throw new zzc(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.g), Integer.valueOf(this.f), 1), e2);
            }
        }

        public final void e0(String str) {
            int i = this.g;
            try {
                int Z = zzbn.Z(str.length() * 3);
                int Z2 = zzbn.Z(str.length());
                if (Z2 == Z) {
                    int i2 = i + Z2;
                    this.g = i2;
                    int b = s91.b(str, this.d, i2, l());
                    this.g = i;
                    V((b - i) - Z2);
                    this.g = b;
                    return;
                }
                V(s91.a(str));
                this.g = s91.b(str, this.d, this.g, l());
            } catch (v91 e2) {
                this.g = i;
                k(str, e2);
            } catch (IndexOutOfBoundsException e3) {
                throw new zzc(e3);
            }
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void f(int i, long j) {
            V((i << 3) | 0);
            u(j);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void g(int i, f61 f61) {
            V((i << 3) | 2);
            c0(f61);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void h(int i, h81 h81) {
            V((i << 3) | 2);
            d0(h81);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void i(int i, h81 h81, x81 x81) {
            V((i << 3) | 2);
            w51 w51 = (w51) h81;
            int c = w51.c();
            if (c == -1) {
                c = x81.h(w51);
                w51.a(c);
            }
            V(c);
            x81.f(h81, this.a);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void j(int i, String str) {
            V((i << 3) | 2);
            e0(str);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final int l() {
            return this.f - this.g;
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void q(int i, int i2) {
            V((i << 3) | i2);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void r(int i, f61 f61) {
            q(1, 3);
            D(2, i);
            g(3, f61);
            q(1, 4);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void s(int i, h81 h81) {
            q(1, 3);
            D(2, i);
            h(3, h81);
            q(1, 4);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void t(int i, boolean z) {
            V((i << 3) | 0);
            e(z ? (byte) 1 : 0);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void u(long j) {
            if (!zzbn.c || l() < 10) {
                while ((j & -128) != 0) {
                    byte[] bArr = this.d;
                    int i = this.g;
                    this.g = i + 1;
                    bArr[i] = (byte) ((((int) j) & 127) | RecyclerView.b0.FLAG_IGNORE);
                    j >>>= 7;
                }
                try {
                    byte[] bArr2 = this.d;
                    int i2 = this.g;
                    this.g = i2 + 1;
                    bArr2[i2] = (byte) ((int) j);
                } catch (IndexOutOfBoundsException e2) {
                    throw new zzc(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.g), Integer.valueOf(this.f), 1), e2);
                }
            } else {
                while ((j & -128) != 0) {
                    byte[] bArr3 = this.d;
                    int i3 = this.g;
                    this.g = i3 + 1;
                    q91.g(bArr3, (long) i3, (byte) ((((int) j) & 127) | RecyclerView.b0.FLAG_IGNORE));
                    j >>>= 7;
                }
                byte[] bArr4 = this.d;
                int i4 = this.g;
                this.g = i4 + 1;
                q91.g(bArr4, (long) i4, (byte) ((int) j));
            }
        }
    }

    public static final class b extends a {
        public final ByteBuffer h;
        public int i;

        public b(ByteBuffer byteBuffer) {
            super(byteBuffer.array(), byteBuffer.position() + byteBuffer.arrayOffset(), byteBuffer.remaining());
            this.h = byteBuffer;
            this.i = byteBuffer.position();
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn.a, com.google.android.gms.internal.clearcut.zzbn
        public final void b() {
            this.h.position(this.i + (this.g - this.e));
        }
    }

    public static final class c extends zzbn {
        public final ByteBuffer d;
        public final ByteBuffer e;

        public c(ByteBuffer byteBuffer) {
            super(null);
            this.d = byteBuffer;
            this.e = byteBuffer.duplicate().order(ByteOrder.LITTLE_ENDIAN);
            byteBuffer.position();
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void A(int i, int i2) {
            V((i << 3) | 0);
            if (i2 >= 0) {
                V(i2);
            } else {
                u((long) i2);
            }
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void B(int i, long j) {
            V((i << 3) | 1);
            E(j);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void D(int i, int i2) {
            V((i << 3) | 0);
            V(i2);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void E(long j) {
            try {
                this.e.putLong(j);
            } catch (BufferOverflowException e2) {
                throw new zzc(e2);
            }
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void I(int i, int i2) {
            V((i << 3) | 5);
            W(i2);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void U(int i) {
            if (i >= 0) {
                V(i);
            } else {
                u((long) i);
            }
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void V(int i) {
            while ((i & -128) != 0) {
                this.e.put((byte) ((i & 127) | RecyclerView.b0.FLAG_IGNORE));
                i >>>= 7;
            }
            try {
                this.e.put((byte) i);
            } catch (BufferOverflowException e2) {
                throw new zzc(e2);
            }
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void W(int i) {
            try {
                this.e.putInt(i);
            } catch (BufferOverflowException e2) {
                throw new zzc(e2);
            }
        }

        @Override // defpackage.e61
        public final void a(byte[] bArr, int i, int i2) {
            c(bArr, i, i2);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void b() {
            this.d.position(this.e.position());
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void c(byte[] bArr, int i, int i2) {
            try {
                this.e.put(bArr, i, i2);
            } catch (IndexOutOfBoundsException e2) {
                throw new zzc(e2);
            } catch (BufferOverflowException e3) {
                throw new zzc(e3);
            }
        }

        public final void c0(f61 f61) {
            V(f61.size());
            f61.f(this);
        }

        public final void d0(h81 h81, x81 x81) {
            w51 w51 = (w51) h81;
            int c = w51.c();
            if (c == -1) {
                c = x81.h(w51);
                w51.a(c);
            }
            V(c);
            x81.f(h81, this.a);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void e(byte b) {
            try {
                this.e.put(b);
            } catch (BufferOverflowException e2) {
                throw new zzc(e2);
            }
        }

        public final void e0(h81 h81) {
            V(h81.j());
            h81.g(this);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void f(int i, long j) {
            V((i << 3) | 0);
            u(j);
        }

        public final void f0(String str) {
            int position = this.e.position();
            try {
                int Z = zzbn.Z(str.length() * 3);
                int Z2 = zzbn.Z(str.length());
                if (Z2 == Z) {
                    int position2 = this.e.position() + Z2;
                    this.e.position(position2);
                    try {
                        s91.c(str, this.e);
                        int position3 = this.e.position();
                        this.e.position(position);
                        V(position3 - position2);
                        this.e.position(position3);
                    } catch (IndexOutOfBoundsException e2) {
                        throw new zzc(e2);
                    }
                } else {
                    V(s91.a(str));
                    try {
                        s91.c(str, this.e);
                    } catch (IndexOutOfBoundsException e3) {
                        throw new zzc(e3);
                    }
                }
            } catch (v91 e4) {
                this.e.position(position);
                k(str, e4);
            } catch (IllegalArgumentException e5) {
                throw new zzc(e5);
            }
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void g(int i, f61 f61) {
            V((i << 3) | 2);
            c0(f61);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void h(int i, h81 h81) {
            V((i << 3) | 2);
            e0(h81);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void i(int i, h81 h81, x81 x81) {
            V((i << 3) | 2);
            d0(h81, x81);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void j(int i, String str) {
            V((i << 3) | 2);
            f0(str);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final int l() {
            return this.e.remaining();
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void q(int i, int i2) {
            V((i << 3) | i2);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void r(int i, f61 f61) {
            q(1, 3);
            D(2, i);
            g(3, f61);
            q(1, 4);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void s(int i, h81 h81) {
            q(1, 3);
            D(2, i);
            h(3, h81);
            q(1, 4);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void t(int i, boolean z) {
            V((i << 3) | 0);
            e(z ? (byte) 1 : 0);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void u(long j) {
            while ((-128 & j) != 0) {
                this.e.put((byte) ((((int) j) & 127) | RecyclerView.b0.FLAG_IGNORE));
                j >>>= 7;
            }
            try {
                this.e.put((byte) ((int) j));
            } catch (BufferOverflowException e2) {
                throw new zzc(e2);
            }
        }
    }

    public static final class d extends zzbn {
        public final ByteBuffer d;
        public final ByteBuffer e;
        public final long f;
        public final long g;
        public final long h;
        public final long i;
        public long j;

        public d(ByteBuffer byteBuffer) {
            super(null);
            this.d = byteBuffer;
            this.e = byteBuffer.duplicate().order(ByteOrder.LITTLE_ENDIAN);
            long k = q91.f.k(byteBuffer, q91.j);
            this.f = k;
            long position = ((long) byteBuffer.position()) + k;
            this.g = position;
            long limit = k + ((long) byteBuffer.limit());
            this.h = limit;
            this.i = limit - 10;
            this.j = position;
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void A(int i2, int i3) {
            V((i2 << 3) | 0);
            if (i3 >= 0) {
                V(i3);
            } else {
                u((long) i3);
            }
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void B(int i2, long j2) {
            V((i2 << 3) | 1);
            E(j2);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void D(int i2, int i3) {
            V((i2 << 3) | 0);
            V(i3);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void E(long j2) {
            this.e.putLong((int) (this.j - this.f), j2);
            this.j += 8;
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void I(int i2, int i3) {
            V((i2 << 3) | 5);
            W(i3);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void U(int i2) {
            if (i2 >= 0) {
                V(i2);
            } else {
                u((long) i2);
            }
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void V(int i2) {
            if (this.j <= this.i) {
                while ((i2 & -128) != 0) {
                    long j2 = this.j;
                    this.j = j2 + 1;
                    q91.f.b(j2, (byte) ((i2 & 127) | RecyclerView.b0.FLAG_IGNORE));
                    i2 >>>= 7;
                }
                long j3 = this.j;
                this.j = 1 + j3;
                q91.f.b(j3, (byte) i2);
                return;
            }
            while (true) {
                long j4 = this.j;
                if (j4 >= this.h) {
                    throw new zzc(String.format("Pos: %d, limit: %d, len: %d", Long.valueOf(this.j), Long.valueOf(this.h), 1));
                } else if ((i2 & -128) == 0) {
                    this.j = 1 + j4;
                    q91.f.b(j4, (byte) i2);
                    return;
                } else {
                    this.j = j4 + 1;
                    q91.f.b(j4, (byte) ((i2 & 127) | RecyclerView.b0.FLAG_IGNORE));
                    i2 >>>= 7;
                }
            }
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void W(int i2) {
            this.e.putInt((int) (this.j - this.f), i2);
            this.j += 4;
        }

        @Override // defpackage.e61
        public final void a(byte[] bArr, int i2, int i3) {
            c(bArr, i2, i3);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void b() {
            this.d.position((int) (this.j - this.f));
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void c(byte[] bArr, int i2, int i3) {
            if (bArr != null && i2 >= 0 && i3 >= 0 && bArr.length - i3 >= i2) {
                long j2 = (long) i3;
                long j3 = this.j;
                if (this.h - j2 >= j3) {
                    q91.f.h(bArr, (long) i2, j3, j2);
                    this.j += j2;
                    return;
                }
            }
            Objects.requireNonNull(bArr, "value");
            throw new zzc(String.format("Pos: %d, limit: %d, len: %d", Long.valueOf(this.j), Long.valueOf(this.h), Integer.valueOf(i3)));
        }

        public final void c0(f61 f61) {
            V(f61.size());
            f61.f(this);
        }

        public final void d0(h81 h81, x81 x81) {
            w51 w51 = (w51) h81;
            int c = w51.c();
            if (c == -1) {
                c = x81.h(w51);
                w51.a(c);
            }
            V(c);
            x81.f(h81, this.a);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void e(byte b) {
            long j2 = this.j;
            if (j2 < this.h) {
                this.j = 1 + j2;
                q91.f.b(j2, b);
                return;
            }
            throw new zzc(String.format("Pos: %d, limit: %d, len: %d", Long.valueOf(this.j), Long.valueOf(this.h), 1));
        }

        public final void e0(h81 h81) {
            V(h81.j());
            h81.g(this);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void f(int i2, long j2) {
            V((i2 << 3) | 0);
            u(j2);
        }

        public final void f0(String str) {
            long j2 = this.j;
            try {
                int Z = zzbn.Z(str.length() * 3);
                int Z2 = zzbn.Z(str.length());
                if (Z2 == Z) {
                    int i2 = ((int) (this.j - this.f)) + Z2;
                    this.e.position(i2);
                    s91.c(str, this.e);
                    int position = this.e.position() - i2;
                    V(position);
                    this.j += (long) position;
                    return;
                }
                int a = s91.a(str);
                V(a);
                this.e.position((int) (this.j - this.f));
                s91.c(str, this.e);
                this.j += (long) a;
            } catch (v91 e2) {
                this.j = j2;
                this.e.position((int) (j2 - this.f));
                k(str, e2);
            } catch (IllegalArgumentException e3) {
                throw new zzc(e3);
            } catch (IndexOutOfBoundsException e4) {
                throw new zzc(e4);
            }
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void g(int i2, f61 f61) {
            V((i2 << 3) | 2);
            c0(f61);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void h(int i2, h81 h81) {
            V((i2 << 3) | 2);
            e0(h81);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void i(int i2, h81 h81, x81 x81) {
            V((i2 << 3) | 2);
            d0(h81, x81);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void j(int i2, String str) {
            V((i2 << 3) | 2);
            f0(str);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final int l() {
            return (int) (this.h - this.j);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void q(int i2, int i3) {
            V((i2 << 3) | i3);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void r(int i2, f61 f61) {
            q(1, 3);
            D(2, i2);
            g(3, f61);
            q(1, 4);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void s(int i2, h81 h81) {
            q(1, 3);
            D(2, i2);
            h(3, h81);
            q(1, 4);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void t(int i2, boolean z) {
            V((i2 << 3) | 0);
            e(z ? (byte) 1 : 0);
        }

        @Override // com.google.android.gms.internal.clearcut.zzbn
        public final void u(long j2) {
            if (this.j <= this.i) {
                while (true) {
                    int i2 = ((j2 & -128) > 0 ? 1 : ((j2 & -128) == 0 ? 0 : -1));
                    long j3 = this.j;
                    if (i2 == 0) {
                        this.j = 1 + j3;
                        q91.f.b(j3, (byte) ((int) j2));
                        return;
                    }
                    this.j = j3 + 1;
                    q91.f.b(j3, (byte) ((((int) j2) & 127) | RecyclerView.b0.FLAG_IGNORE));
                    j2 >>>= 7;
                }
            } else {
                while (true) {
                    long j4 = this.j;
                    if (j4 >= this.h) {
                        throw new zzc(String.format("Pos: %d, limit: %d, len: %d", Long.valueOf(this.j), Long.valueOf(this.h), 1));
                    } else if ((j2 & -128) == 0) {
                        this.j = 1 + j4;
                        q91.f.b(j4, (byte) ((int) j2));
                        return;
                    } else {
                        this.j = j4 + 1;
                        q91.f.b(j4, (byte) ((((int) j2) & 127) | RecyclerView.b0.FLAG_IGNORE));
                        j2 >>>= 7;
                    }
                }
            }
        }
    }

    public static class zzc extends IOException {
        public zzc() {
            super("CodedOutputStream was writing to a flat byte array and ran out of space.");
        }

        /* JADX WARNING: Illegal instructions before constructor call */
        public zzc(String str) {
            super(r3.length() != 0 ? "CodedOutputStream was writing to a flat byte array and ran out of space.: ".concat(r3) : new String("CodedOutputStream was writing to a flat byte array and ran out of space.: "));
            String valueOf = String.valueOf(str);
        }

        /* JADX WARNING: Illegal instructions before constructor call */
        public zzc(String str, Throwable th) {
            super(r3.length() != 0 ? "CodedOutputStream was writing to a flat byte array and ran out of space.: ".concat(r3) : new String("CodedOutputStream was writing to a flat byte array and ran out of space.: "), th);
            String valueOf = String.valueOf(str);
        }

        public zzc(Throwable th) {
            super("CodedOutputStream was writing to a flat byte array and ran out of space.", th);
        }
    }

    public zzbn() {
    }

    public zzbn(m61 m61) {
    }

    public static int C(int i, long j) {
        return H(j) + X(i);
    }

    public static int F(int i, long j) {
        return H(j) + X(i);
    }

    public static int G(int i, long j) {
        return H(R(j)) + X(i);
    }

    public static int H(long j) {
        int i;
        if ((-128 & j) == 0) {
            return 1;
        }
        if (j < 0) {
            return 10;
        }
        if ((-34359738368L & j) != 0) {
            i = 6;
            j >>>= 28;
        } else {
            i = 2;
        }
        if ((-2097152 & j) != 0) {
            i += 2;
            j >>>= 14;
        }
        return (j & -16384) != 0 ? i + 1 : i;
    }

    public static int J(int i) {
        return X(i) + 8;
    }

    public static int K(int i, int i2) {
        return Y(i2) + X(i);
    }

    public static int L(long j) {
        return H(R(j));
    }

    public static int M(int i) {
        return X(i) + 8;
    }

    public static int N(int i, int i2) {
        return Z(i2) + X(i);
    }

    public static int O(String str) {
        int i;
        try {
            i = s91.a(str);
        } catch (v91 unused) {
            i = str.getBytes(g71.a).length;
        }
        return Z(i) + i;
    }

    public static int P(int i, int i2) {
        return Z(b0(i2)) + X(i);
    }

    public static int Q(int i) {
        return X(i) + 4;
    }

    public static long R(long j) {
        return (j >> 63) ^ (j << 1);
    }

    public static int S(int i) {
        return X(i) + 4;
    }

    public static int T(int i, int i2) {
        return Y(i2) + X(i);
    }

    public static int X(int i) {
        return Z(i << 3);
    }

    public static int Y(int i) {
        if (i >= 0) {
            return Z(i);
        }
        return 10;
    }

    public static int Z(int i) {
        if ((i & -128) == 0) {
            return 1;
        }
        if ((i & -16384) == 0) {
            return 2;
        }
        if ((-2097152 & i) == 0) {
            return 3;
        }
        return (i & -268435456) == 0 ? 4 : 5;
    }

    public static int a0(int i) {
        return Z(b0(i));
    }

    public static int b0(int i) {
        return (i >> 31) ^ (i << 1);
    }

    public static int d(p71 p71) {
        int a2 = p71.a();
        return Z(a2) + a2;
    }

    public static int m(int i) {
        return X(i) + 4;
    }

    public static int n(int i, String str) {
        return O(str) + X(i);
    }

    public static int o(f61 f61) {
        int size = f61.size();
        return Z(size) + size;
    }

    public static int p(h81 h81, x81 x81) {
        w51 w51 = (w51) h81;
        int c2 = w51.c();
        if (c2 == -1) {
            c2 = x81.h(w51);
            w51.a(c2);
        }
        return Z(c2) + c2;
    }

    public static int v(int i) {
        return X(i) + 8;
    }

    public static int w(int i) {
        return X(i) + 1;
    }

    public static int x(int i, f61 f61) {
        int X = X(i);
        int size = f61.size();
        return Z(size) + size + X;
    }

    public static int y(int i, h81 h81) {
        int X = X(i);
        int j = h81.j();
        return X + Z(j) + j;
    }

    @Deprecated
    public static int z(int i, h81 h81, x81 x81) {
        int X = X(i) << 1;
        w51 w51 = (w51) h81;
        int c2 = w51.c();
        if (c2 == -1) {
            c2 = x81.h(w51);
            w51.a(c2);
        }
        return X + c2;
    }

    public abstract void A(int i, int i2);

    public abstract void B(int i, long j);

    public abstract void D(int i, int i2);

    public abstract void E(long j);

    public abstract void I(int i, int i2);

    public abstract void U(int i);

    public abstract void V(int i);

    public abstract void W(int i);

    public abstract void b();

    public abstract void c(byte[] bArr, int i, int i2);

    public abstract void e(byte b2);

    public abstract void f(int i, long j);

    public abstract void g(int i, f61 f61);

    public abstract void h(int i, h81 h81);

    public abstract void i(int i, h81 h81, x81 x81);

    public abstract void j(int i, String str);

    public final void k(String str, v91 v91) {
        b.logp(Level.WARNING, "com.google.protobuf.CodedOutputStream", "inefficientWriteStringNoTag", "Converting ill-formed UTF-16. Your Protocol Buffer will not round trip correctly!", (Throwable) v91);
        byte[] bytes = str.getBytes(g71.a);
        try {
            V(bytes.length);
            a(bytes, 0, bytes.length);
        } catch (IndexOutOfBoundsException e) {
            throw new zzc(e);
        } catch (zzc e2) {
            throw e2;
        }
    }

    public abstract int l();

    public abstract void q(int i, int i2);

    public abstract void r(int i, f61 f61);

    public abstract void s(int i, h81 h81);

    public abstract void t(int i, boolean z);

    public abstract void u(long j);
}
