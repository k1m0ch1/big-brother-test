package com.google.android.gms.internal.clearcut;

public final class zzcp extends zzco {
    public zzcp(String str) {
        super(str);
    }
}
