package com.google.android.gms.internal.clearcut;

public final class zzew extends RuntimeException {
    public zzew() {
        super("Message was missing required fields.  (Lite runtime could not determine which fields were missing).");
    }
}
