package com.google.android.gms.internal.measurement;

/* compiled from: com.google.android.gms:play-services-measurement-base@@18.0.0 */
public final class zzkq extends RuntimeException {
    public zzkq() {
        super("Message was missing required fields.  (Lite runtime could not determine which fields were missing).");
    }
}
