package com.google.android.gms.internal.measurement;

/* compiled from: com.google.android.gms:play-services-measurement-base@@18.0.0 */
public final class zzii extends zzij {
    public zzii(String str) {
        super(str);
    }
}
