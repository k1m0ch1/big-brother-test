package com.google.android.gms.internal.measurement;

import androidx.recyclerview.widget.RecyclerView;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/* compiled from: com.google.android.gms:play-services-measurement-base@@18.0.0 */
public abstract class zzhi extends ot1 {
    public static final Logger b = Logger.getLogger(zzhi.class.getName());
    public static final boolean c = cx1.g;
    public zt1 a;

    /* compiled from: com.google.android.gms:play-services-measurement-base@@18.0.0 */
    public static class a extends zzhi {
        public final byte[] d;
        public final int e;
        public int f;

        public a(byte[] bArr, int i) {
            super(null);
            if ((i | 0 | (bArr.length - i)) >= 0) {
                this.d = bArr;
                this.f = 0;
                this.e = i;
                return;
            }
            throw new IllegalArgumentException(String.format("Array range is invalid. Buffer.length=%d, offset=%d, length=%d", Integer.valueOf(bArr.length), 0, Integer.valueOf(i)));
        }

        @Override // com.google.android.gms.internal.measurement.zzhi
        public final void A(long j) {
            try {
                byte[] bArr = this.d;
                int i = this.f;
                int i2 = i + 1;
                this.f = i2;
                bArr[i] = (byte) ((int) j);
                int i3 = i2 + 1;
                this.f = i3;
                bArr[i2] = (byte) ((int) (j >> 8));
                int i4 = i3 + 1;
                this.f = i4;
                bArr[i3] = (byte) ((int) (j >> 16));
                int i5 = i4 + 1;
                this.f = i5;
                bArr[i4] = (byte) ((int) (j >> 24));
                int i6 = i5 + 1;
                this.f = i6;
                bArr[i5] = (byte) ((int) (j >> 32));
                int i7 = i6 + 1;
                this.f = i7;
                bArr[i6] = (byte) ((int) (j >> 40));
                int i8 = i7 + 1;
                this.f = i8;
                bArr[i7] = (byte) ((int) (j >> 48));
                this.f = i8 + 1;
                bArr[i8] = (byte) ((int) (j >> 56));
            } catch (IndexOutOfBoundsException e2) {
                throw new zza(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.f), Integer.valueOf(this.e), 1), e2);
            }
        }

        @Override // com.google.android.gms.internal.measurement.zzhi
        public final void C(int i) {
            try {
                byte[] bArr = this.d;
                int i2 = this.f;
                int i3 = i2 + 1;
                this.f = i3;
                bArr[i2] = (byte) i;
                int i4 = i3 + 1;
                this.f = i4;
                bArr[i3] = (byte) (i >> 8);
                int i5 = i4 + 1;
                this.f = i5;
                bArr[i4] = (byte) (i >> 16);
                this.f = i5 + 1;
                bArr[i5] = (byte) (i >>> 24);
            } catch (IndexOutOfBoundsException e2) {
                throw new zza(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.f), Integer.valueOf(this.e), 1), e2);
            }
        }

        @Override // com.google.android.gms.internal.measurement.zzhi
        public final void G(int i, int i2) {
            r((i << 3) | 5);
            C(i2);
        }

        public final void W(nt1 nt1) {
            r(nt1.b());
            nt1.p(this);
        }

        public final void X(vv1 vv1) {
            r(vv1.c());
            vv1.e(this);
        }

        public final void Y(String str) {
            int i = this.f;
            try {
                int L = zzhi.L(str.length() * 3);
                int L2 = zzhi.L(str.length());
                if (L2 == L) {
                    int i2 = i + L2;
                    this.f = i2;
                    int b = dx1.a.b(str, this.d, i2, a());
                    this.f = i;
                    r((b - i) - L2);
                    this.f = b;
                    return;
                }
                r(dx1.a(str));
                this.f = dx1.a.b(str, this.d, this.f, a());
            } catch (hx1 e2) {
                this.f = i;
                zzhi.b.logp(Level.WARNING, "com.google.protobuf.CodedOutputStream", "inefficientWriteStringNoTag", "Converting ill-formed UTF-16. Your Protocol Buffer will not round trip correctly!", (Throwable) e2);
                byte[] bytes = str.getBytes(pu1.a);
                try {
                    r(bytes.length);
                    Z(bytes, 0, bytes.length);
                } catch (IndexOutOfBoundsException e3) {
                    throw new zza(e3);
                } catch (zza e4) {
                    throw e4;
                }
            } catch (IndexOutOfBoundsException e5) {
                throw new zza(e5);
            }
        }

        public final void Z(byte[] bArr, int i, int i2) {
            try {
                System.arraycopy(bArr, i, this.d, this.f, i2);
                this.f += i2;
            } catch (IndexOutOfBoundsException e2) {
                throw new zza(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.f), Integer.valueOf(this.e), Integer.valueOf(i2)), e2);
            }
        }

        @Override // com.google.android.gms.internal.measurement.zzhi
        public final int a() {
            return this.e - this.f;
        }

        @Override // com.google.android.gms.internal.measurement.zzhi
        public final void d(byte b) {
            try {
                byte[] bArr = this.d;
                int i = this.f;
                this.f = i + 1;
                bArr[i] = b;
            } catch (IndexOutOfBoundsException e2) {
                throw new zza(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.f), Integer.valueOf(this.e), 1), e2);
            }
        }

        @Override // com.google.android.gms.internal.measurement.zzhi
        public final void e(int i) {
            if (i >= 0) {
                r(i);
            } else {
                m((long) i);
            }
        }

        @Override // com.google.android.gms.internal.measurement.zzhi
        public final void f(int i, int i2) {
            r((i << 3) | i2);
        }

        @Override // com.google.android.gms.internal.measurement.zzhi
        public final void g(int i, long j) {
            r((i << 3) | 0);
            m(j);
        }

        @Override // com.google.android.gms.internal.measurement.zzhi
        public final void h(int i, nt1 nt1) {
            r((i << 3) | 2);
            W(nt1);
        }

        @Override // com.google.android.gms.internal.measurement.zzhi
        public final void i(int i, vv1 vv1) {
            f(1, 3);
            y(2, i);
            f(3, 2);
            X(vv1);
            f(1, 4);
        }

        @Override // com.google.android.gms.internal.measurement.zzhi
        public final void j(int i, vv1 vv1, jw1 jw1) {
            r((i << 3) | 2);
            ft1 ft1 = (ft1) vv1;
            int i2 = ft1.i();
            if (i2 == -1) {
                i2 = jw1.zzb(ft1);
                ft1.k(i2);
            }
            r(i2);
            jw1.a(vv1, this.a);
        }

        @Override // com.google.android.gms.internal.measurement.zzhi
        public final void k(int i, String str) {
            r((i << 3) | 2);
            Y(str);
        }

        @Override // com.google.android.gms.internal.measurement.zzhi
        public final void l(int i, boolean z) {
            r((i << 3) | 0);
            d(z ? (byte) 1 : 0);
        }

        @Override // com.google.android.gms.internal.measurement.zzhi
        public final void m(long j) {
            if (!zzhi.c || a() < 10) {
                while ((j & -128) != 0) {
                    byte[] bArr = this.d;
                    int i = this.f;
                    this.f = i + 1;
                    bArr[i] = (byte) ((((int) j) & 127) | RecyclerView.b0.FLAG_IGNORE);
                    j >>>= 7;
                }
                try {
                    byte[] bArr2 = this.d;
                    int i2 = this.f;
                    this.f = i2 + 1;
                    bArr2[i2] = (byte) ((int) j);
                } catch (IndexOutOfBoundsException e2) {
                    throw new zza(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.f), Integer.valueOf(this.e), 1), e2);
                }
            } else {
                while ((j & -128) != 0) {
                    byte[] bArr3 = this.d;
                    int i3 = this.f;
                    this.f = i3 + 1;
                    cx1.g(bArr3, (long) i3, (byte) ((((int) j) & 127) | RecyclerView.b0.FLAG_IGNORE));
                    j >>>= 7;
                }
                byte[] bArr4 = this.d;
                int i4 = this.f;
                this.f = i4 + 1;
                cx1.g(bArr4, (long) i4, (byte) ((int) j));
            }
        }

        @Override // com.google.android.gms.internal.measurement.zzhi
        public final void r(int i) {
            if (!zzhi.c || kt1.a() || a() < 5) {
                while ((i & -128) != 0) {
                    byte[] bArr = this.d;
                    int i2 = this.f;
                    this.f = i2 + 1;
                    bArr[i2] = (byte) ((i & 127) | RecyclerView.b0.FLAG_IGNORE);
                    i >>>= 7;
                }
                try {
                    byte[] bArr2 = this.d;
                    int i3 = this.f;
                    this.f = i3 + 1;
                    bArr2[i3] = (byte) i;
                } catch (IndexOutOfBoundsException e2) {
                    throw new zza(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.f), Integer.valueOf(this.e), 1), e2);
                }
            } else if ((i & -128) == 0) {
                byte[] bArr3 = this.d;
                int i4 = this.f;
                this.f = i4 + 1;
                cx1.g(bArr3, (long) i4, (byte) i);
            } else {
                byte[] bArr4 = this.d;
                int i5 = this.f;
                this.f = i5 + 1;
                cx1.g(bArr4, (long) i5, (byte) (i | RecyclerView.b0.FLAG_IGNORE));
                int i6 = i >>> 7;
                if ((i6 & -128) == 0) {
                    byte[] bArr5 = this.d;
                    int i7 = this.f;
                    this.f = i7 + 1;
                    cx1.g(bArr5, (long) i7, (byte) i6);
                    return;
                }
                byte[] bArr6 = this.d;
                int i8 = this.f;
                this.f = i8 + 1;
                cx1.g(bArr6, (long) i8, (byte) (i6 | RecyclerView.b0.FLAG_IGNORE));
                int i9 = i6 >>> 7;
                if ((i9 & -128) == 0) {
                    byte[] bArr7 = this.d;
                    int i10 = this.f;
                    this.f = i10 + 1;
                    cx1.g(bArr7, (long) i10, (byte) i9);
                    return;
                }
                byte[] bArr8 = this.d;
                int i11 = this.f;
                this.f = i11 + 1;
                cx1.g(bArr8, (long) i11, (byte) (i9 | RecyclerView.b0.FLAG_IGNORE));
                int i12 = i9 >>> 7;
                if ((i12 & -128) == 0) {
                    byte[] bArr9 = this.d;
                    int i13 = this.f;
                    this.f = i13 + 1;
                    cx1.g(bArr9, (long) i13, (byte) i12);
                    return;
                }
                byte[] bArr10 = this.d;
                int i14 = this.f;
                this.f = i14 + 1;
                cx1.g(bArr10, (long) i14, (byte) (i12 | RecyclerView.b0.FLAG_IGNORE));
                byte[] bArr11 = this.d;
                int i15 = this.f;
                this.f = i15 + 1;
                cx1.g(bArr11, (long) i15, (byte) (i12 >>> 7));
            }
        }

        @Override // com.google.android.gms.internal.measurement.zzhi
        public final void s(int i, int i2) {
            r((i << 3) | 0);
            if (i2 >= 0) {
                r(i2);
            } else {
                m((long) i2);
            }
        }

        @Override // com.google.android.gms.internal.measurement.zzhi
        public final void t(int i, nt1 nt1) {
            f(1, 3);
            y(2, i);
            h(3, nt1);
            f(1, 4);
        }

        @Override // com.google.android.gms.internal.measurement.zzhi
        public final void y(int i, int i2) {
            r((i << 3) | 0);
            r(i2);
        }

        @Override // com.google.android.gms.internal.measurement.zzhi
        public final void z(int i, long j) {
            r((i << 3) | 1);
            A(j);
        }
    }

    /* compiled from: com.google.android.gms:play-services-measurement-base@@18.0.0 */
    public static class zza extends IOException {
        public zza() {
            super("CodedOutputStream was writing to a flat byte array and ran out of space.");
        }

        public zza(Throwable th) {
            super("CodedOutputStream was writing to a flat byte array and ran out of space.", th);
        }

        /* JADX WARNING: Illegal instructions before constructor call */
        public zza(String str, Throwable th) {
            super(r3.length() != 0 ? "CodedOutputStream was writing to a flat byte array and ran out of space.: ".concat(r3) : new String("CodedOutputStream was writing to a flat byte array and ran out of space.: "), th);
            String valueOf = String.valueOf(str);
        }
    }

    public zzhi() {
    }

    public static int B(int i, long j) {
        return F(j) + L(i << 3);
    }

    public static int D(int i) {
        return L(i << 3);
    }

    public static int E(int i, long j) {
        return F(j) + L(i << 3);
    }

    public static int F(long j) {
        int i;
        if ((-128 & j) == 0) {
            return 1;
        }
        if (j < 0) {
            return 10;
        }
        if ((-34359738368L & j) != 0) {
            i = 6;
            j >>>= 28;
        } else {
            i = 2;
        }
        if ((-2097152 & j) != 0) {
            i += 2;
            j >>>= 14;
        }
        return (j & -16384) != 0 ? i + 1 : i;
    }

    public static int H(int i) {
        if (i >= 0) {
            return L(i);
        }
        return 10;
    }

    public static int I(int i, int i2) {
        return H(i2) + L(i << 3);
    }

    public static int J(int i, long j) {
        return F(R(j)) + L(i << 3);
    }

    public static int K(long j) {
        return F(R(j));
    }

    public static int L(int i) {
        if ((i & -128) == 0) {
            return 1;
        }
        if ((i & -16384) == 0) {
            return 2;
        }
        if ((-2097152 & i) == 0) {
            return 3;
        }
        return (i & -268435456) == 0 ? 4 : 5;
    }

    public static int M(int i, int i2) {
        return L(i2) + L(i << 3);
    }

    public static int N(int i) {
        return L(i << 3) + 8;
    }

    public static int O(int i) {
        return L(V(i));
    }

    public static int P(int i, int i2) {
        return L(V(i2)) + L(i << 3);
    }

    public static int Q(int i) {
        return L(i << 3) + 8;
    }

    public static long R(long j) {
        return (j >> 63) ^ (j << 1);
    }

    public static int S(int i) {
        return L(i << 3) + 4;
    }

    public static int T(int i) {
        return L(i << 3) + 4;
    }

    public static int U(int i, int i2) {
        return H(i2) + L(i << 3);
    }

    public static int V(int i) {
        return (i >> 31) ^ (i << 1);
    }

    public static int b(av1 av1) {
        int a2 = av1.a();
        return L(a2) + a2;
    }

    public static int c(vv1 vv1, jw1 jw1) {
        ft1 ft1 = (ft1) vv1;
        int i = ft1.i();
        if (i == -1) {
            i = jw1.zzb(ft1);
            ft1.k(i);
        }
        return L(i) + i;
    }

    public static int n(int i) {
        return L(i << 3) + 4;
    }

    public static int o(int i, String str) {
        return q(str) + L(i << 3);
    }

    public static int p(nt1 nt1) {
        int b2 = nt1.b();
        return L(b2) + b2;
    }

    public static int q(String str) {
        int i;
        try {
            i = dx1.a(str);
        } catch (hx1 unused) {
            i = str.getBytes(pu1.a).length;
        }
        return L(i) + i;
    }

    public static int u(int i) {
        return L(i << 3) + 8;
    }

    public static int v(int i) {
        return L(i << 3) + 1;
    }

    public static int w(int i, nt1 nt1) {
        int L = L(i << 3);
        int b2 = nt1.b();
        return L(b2) + b2 + L;
    }

    @Deprecated
    public static int x(int i, vv1 vv1, jw1 jw1) {
        int L = L(i << 3) << 1;
        ft1 ft1 = (ft1) vv1;
        int i2 = ft1.i();
        if (i2 == -1) {
            i2 = jw1.zzb(ft1);
            ft1.k(i2);
        }
        return L + i2;
    }

    public abstract void A(long j);

    public abstract void C(int i);

    public abstract void G(int i, int i2);

    public abstract int a();

    public abstract void d(byte b2);

    public abstract void e(int i);

    public abstract void f(int i, int i2);

    public abstract void g(int i, long j);

    public abstract void h(int i, nt1 nt1);

    public abstract void i(int i, vv1 vv1);

    public abstract void j(int i, vv1 vv1, jw1 jw1);

    public abstract void k(int i, String str);

    public abstract void l(int i, boolean z);

    public abstract void m(long j);

    public abstract void r(int i);

    public abstract void s(int i, int i2);

    public abstract void t(int i, nt1 nt1);

    public abstract void y(int i, int i2);

    public abstract void z(int i, long j);

    public zzhi(xt1 xt1) {
    }
}
