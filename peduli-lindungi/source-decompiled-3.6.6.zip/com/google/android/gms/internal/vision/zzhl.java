package com.google.android.gms.internal.vision;

import androidx.recyclerview.widget.RecyclerView;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/* compiled from: com.google.android.gms:play-services-vision-common@@19.1.2 */
public abstract class zzhl extends l42 {
    public static final Logger b = Logger.getLogger(zzhl.class.getName());
    public static final boolean c = c82.h;
    public v42 a;

    /* compiled from: com.google.android.gms:play-services-vision-common@@19.1.2 */
    public static class a extends zzhl {
        public final byte[] d;
        public final int e;
        public int f;

        public a(byte[] bArr, int i) {
            super(null);
            if ((i | 0 | (bArr.length - i)) >= 0) {
                this.d = bArr;
                this.f = 0;
                this.e = i;
                return;
            }
            throw new IllegalArgumentException(String.format("Array range is invalid. Buffer.length=%d, offset=%d, length=%d", Integer.valueOf(bArr.length), 0, Integer.valueOf(i)));
        }

        @Override // com.google.android.gms.internal.vision.zzhl
        public final void A(byte b) {
            try {
                byte[] bArr = this.d;
                int i = this.f;
                this.f = i + 1;
                bArr[i] = b;
            } catch (IndexOutOfBoundsException e2) {
                throw new zza(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.f), Integer.valueOf(this.e), 1), e2);
            }
        }

        @Override // com.google.android.gms.internal.vision.zzhl
        public final void B(int i, long j) {
            r((i << 3) | 1);
            S(j);
        }

        @Override // com.google.android.gms.internal.vision.zzhl
        public final int G() {
            return this.e - this.f;
        }

        @Override // com.google.android.gms.internal.vision.zzhl
        public final void I(int i, int i2) {
            r((i << 3) | 0);
            if (i2 >= 0) {
                r(i2);
            } else {
                R((long) i2);
            }
        }

        @Override // com.google.android.gms.internal.vision.zzhl
        public final void J(int i, int i2) {
            r((i << 3) | 0);
            r(i2);
        }

        @Override // com.google.android.gms.internal.vision.zzhl
        public final void K(int i, int i2) {
            r((i << 3) | 5);
            s(i2);
        }

        @Override // com.google.android.gms.internal.vision.zzhl
        public final void R(long j) {
            if (!zzhl.c || G() < 10) {
                while ((j & -128) != 0) {
                    byte[] bArr = this.d;
                    int i = this.f;
                    this.f = i + 1;
                    bArr[i] = (byte) ((((int) j) & 127) | RecyclerView.b0.FLAG_IGNORE);
                    j >>>= 7;
                }
                try {
                    byte[] bArr2 = this.d;
                    int i2 = this.f;
                    this.f = i2 + 1;
                    bArr2[i2] = (byte) ((int) j);
                } catch (IndexOutOfBoundsException e2) {
                    throw new zza(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.f), Integer.valueOf(this.e), 1), e2);
                }
            } else {
                while ((j & -128) != 0) {
                    byte[] bArr3 = this.d;
                    int i3 = this.f;
                    this.f = i3 + 1;
                    c82.f(bArr3, (long) i3, (byte) ((((int) j) & 127) | RecyclerView.b0.FLAG_IGNORE));
                    j >>>= 7;
                }
                byte[] bArr4 = this.d;
                int i4 = this.f;
                this.f = i4 + 1;
                c82.f(bArr4, (long) i4, (byte) ((int) j));
            }
        }

        @Override // com.google.android.gms.internal.vision.zzhl
        public final void S(long j) {
            try {
                byte[] bArr = this.d;
                int i = this.f;
                int i2 = i + 1;
                this.f = i2;
                bArr[i] = (byte) ((int) j);
                int i3 = i2 + 1;
                this.f = i3;
                bArr[i2] = (byte) ((int) (j >> 8));
                int i4 = i3 + 1;
                this.f = i4;
                bArr[i3] = (byte) ((int) (j >> 16));
                int i5 = i4 + 1;
                this.f = i5;
                bArr[i4] = (byte) ((int) (j >> 24));
                int i6 = i5 + 1;
                this.f = i6;
                bArr[i5] = (byte) ((int) (j >> 32));
                int i7 = i6 + 1;
                this.f = i7;
                bArr[i6] = (byte) ((int) (j >> 40));
                int i8 = i7 + 1;
                this.f = i8;
                bArr[i7] = (byte) ((int) (j >> 48));
                this.f = i8 + 1;
                bArr[i8] = (byte) ((int) (j >> 56));
            } catch (IndexOutOfBoundsException e2) {
                throw new zza(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.f), Integer.valueOf(this.e), 1), e2);
            }
        }

        public final void W(byte[] bArr, int i, int i2) {
            try {
                System.arraycopy(bArr, i, this.d, this.f, i2);
                this.f += i2;
            } catch (IndexOutOfBoundsException e2) {
                throw new zza(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.f), Integer.valueOf(this.e), Integer.valueOf(i2)), e2);
            }
        }

        public final void X(k42 k42) {
            r(k42.size());
            k42.f(this);
        }

        public final void Y(t62 t62) {
            r(t62.c());
            t62.g(this);
        }

        public final void Z(String str) {
            int i = this.f;
            try {
                int v = zzhl.v(str.length() * 3);
                int v2 = zzhl.v(str.length());
                if (v2 == v) {
                    int i2 = i + v2;
                    this.f = i2;
                    int b = d82.a.b(str, this.d, i2, G());
                    this.f = i;
                    r((b - i) - v2);
                    this.f = b;
                    return;
                }
                r(d82.a(str));
                this.f = d82.a.b(str, this.d, this.f, G());
            } catch (h82 e2) {
                this.f = i;
                zzhl.b.logp(Level.WARNING, "com.google.protobuf.CodedOutputStream", "inefficientWriteStringNoTag", "Converting ill-formed UTF-16. Your Protocol Buffer will not round trip correctly!", (Throwable) e2);
                byte[] bytes = str.getBytes(m52.a);
                try {
                    r(bytes.length);
                    W(bytes, 0, bytes.length);
                } catch (IndexOutOfBoundsException e3) {
                    throw new zza(e3);
                } catch (zza e4) {
                    throw e4;
                }
            } catch (IndexOutOfBoundsException e5) {
                throw new zza(e5);
            }
        }

        @Override // com.google.android.gms.internal.vision.zzhl
        public final void a(int i, int i2) {
            r((i << 3) | i2);
        }

        @Override // com.google.android.gms.internal.vision.zzhl
        public final void d(int i, long j) {
            r((i << 3) | 0);
            R(j);
        }

        @Override // com.google.android.gms.internal.vision.zzhl
        public final void e(int i, k42 k42) {
            r((i << 3) | 2);
            X(k42);
        }

        @Override // com.google.android.gms.internal.vision.zzhl
        public final void f(int i, t62 t62) {
            a(1, 3);
            J(2, i);
            a(3, 2);
            Y(t62);
            a(1, 4);
        }

        @Override // com.google.android.gms.internal.vision.zzhl
        public final void g(int i, t62 t62, i72 i72) {
            r((i << 3) | 2);
            b42 b42 = (b42) t62;
            int h = b42.h();
            if (h == -1) {
                h = i72.h(b42);
                b42.a(h);
            }
            r(h);
            i72.i(t62, this.a);
        }

        @Override // com.google.android.gms.internal.vision.zzhl
        public final void h(int i, String str) {
            r((i << 3) | 2);
            Z(str);
        }

        @Override // com.google.android.gms.internal.vision.zzhl
        public final void i(int i, boolean z) {
            r((i << 3) | 0);
            A(z ? (byte) 1 : 0);
        }

        @Override // com.google.android.gms.internal.vision.zzhl
        public final void n(int i, k42 k42) {
            a(1, 3);
            J(2, i);
            e(3, k42);
            a(1, 4);
        }

        @Override // com.google.android.gms.internal.vision.zzhl
        public final void q(int i) {
            if (i >= 0) {
                r(i);
            } else {
                R((long) i);
            }
        }

        @Override // com.google.android.gms.internal.vision.zzhl
        public final void r(int i) {
            if (!zzhl.c || h42.a() || G() < 5) {
                while ((i & -128) != 0) {
                    byte[] bArr = this.d;
                    int i2 = this.f;
                    this.f = i2 + 1;
                    bArr[i2] = (byte) ((i & 127) | RecyclerView.b0.FLAG_IGNORE);
                    i >>>= 7;
                }
                try {
                    byte[] bArr2 = this.d;
                    int i3 = this.f;
                    this.f = i3 + 1;
                    bArr2[i3] = (byte) i;
                } catch (IndexOutOfBoundsException e2) {
                    throw new zza(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.f), Integer.valueOf(this.e), 1), e2);
                }
            } else if ((i & -128) == 0) {
                byte[] bArr3 = this.d;
                int i4 = this.f;
                this.f = i4 + 1;
                c82.f(bArr3, (long) i4, (byte) i);
            } else {
                byte[] bArr4 = this.d;
                int i5 = this.f;
                this.f = i5 + 1;
                c82.f(bArr4, (long) i5, (byte) (i | RecyclerView.b0.FLAG_IGNORE));
                int i6 = i >>> 7;
                if ((i6 & -128) == 0) {
                    byte[] bArr5 = this.d;
                    int i7 = this.f;
                    this.f = i7 + 1;
                    c82.f(bArr5, (long) i7, (byte) i6);
                    return;
                }
                byte[] bArr6 = this.d;
                int i8 = this.f;
                this.f = i8 + 1;
                c82.f(bArr6, (long) i8, (byte) (i6 | RecyclerView.b0.FLAG_IGNORE));
                int i9 = i6 >>> 7;
                if ((i9 & -128) == 0) {
                    byte[] bArr7 = this.d;
                    int i10 = this.f;
                    this.f = i10 + 1;
                    c82.f(bArr7, (long) i10, (byte) i9);
                    return;
                }
                byte[] bArr8 = this.d;
                int i11 = this.f;
                this.f = i11 + 1;
                c82.f(bArr8, (long) i11, (byte) (i9 | RecyclerView.b0.FLAG_IGNORE));
                int i12 = i9 >>> 7;
                if ((i12 & -128) == 0) {
                    byte[] bArr9 = this.d;
                    int i13 = this.f;
                    this.f = i13 + 1;
                    c82.f(bArr9, (long) i13, (byte) i12);
                    return;
                }
                byte[] bArr10 = this.d;
                int i14 = this.f;
                this.f = i14 + 1;
                c82.f(bArr10, (long) i14, (byte) (i12 | RecyclerView.b0.FLAG_IGNORE));
                byte[] bArr11 = this.d;
                int i15 = this.f;
                this.f = i15 + 1;
                c82.f(bArr11, (long) i15, (byte) (i12 >>> 7));
            }
        }

        @Override // com.google.android.gms.internal.vision.zzhl
        public final void s(int i) {
            try {
                byte[] bArr = this.d;
                int i2 = this.f;
                int i3 = i2 + 1;
                this.f = i3;
                bArr[i2] = (byte) i;
                int i4 = i3 + 1;
                this.f = i4;
                bArr[i3] = (byte) (i >> 8);
                int i5 = i4 + 1;
                this.f = i5;
                bArr[i4] = (byte) (i >> 16);
                this.f = i5 + 1;
                bArr[i5] = (byte) (i >>> 24);
            } catch (IndexOutOfBoundsException e2) {
                throw new zza(String.format("Pos: %d, limit: %d, len: %d", Integer.valueOf(this.f), Integer.valueOf(this.e), 1), e2);
            }
        }
    }

    /* compiled from: com.google.android.gms:play-services-vision-common@@19.1.2 */
    public static class zza extends IOException {
        public zza() {
            super("CodedOutputStream was writing to a flat byte array and ran out of space.");
        }

        public zza(Throwable th) {
            super("CodedOutputStream was writing to a flat byte array and ran out of space.", th);
        }

        /* JADX WARNING: Illegal instructions before constructor call */
        public zza(String str, Throwable th) {
            super(r3.length() != 0 ? "CodedOutputStream was writing to a flat byte array and ran out of space.: ".concat(r3) : new String("CodedOutputStream was writing to a flat byte array and ran out of space.: "), th);
            String valueOf = String.valueOf(str);
        }
    }

    public zzhl() {
    }

    public static int C(int i, long j) {
        return T(j) + v(i << 3);
    }

    public static int D(int i, long j) {
        return T(j) + v(i << 3);
    }

    public static int E(int i, long j) {
        return T(j(j)) + v(i << 3);
    }

    public static int F(int i) {
        return v(i << 3) + 8;
    }

    public static int H(int i) {
        return v(i << 3) + 8;
    }

    public static int L(int i, int i2) {
        return u(i2) + v(i << 3);
    }

    public static int M(int i, int i2) {
        return v(i2) + v(i << 3);
    }

    public static int N(int i, int i2) {
        return v(x(i2)) + v(i << 3);
    }

    public static int O(int i) {
        return v(i << 3) + 4;
    }

    public static int P(int i) {
        return v(i << 3) + 4;
    }

    public static int Q(int i, int i2) {
        return u(i2) + v(i << 3);
    }

    public static int T(long j) {
        int i;
        if ((-128 & j) == 0) {
            return 1;
        }
        if (j < 0) {
            return 10;
        }
        if ((-34359738368L & j) != 0) {
            i = 6;
            j >>>= 28;
        } else {
            i = 2;
        }
        if ((-2097152 & j) != 0) {
            i += 2;
            j >>>= 14;
        }
        return (j & -16384) != 0 ? i + 1 : i;
    }

    public static int U(long j) {
        return T(j(j));
    }

    public static int V(String str) {
        int i;
        try {
            i = d82.a(str);
        } catch (h82 unused) {
            i = str.getBytes(m52.a).length;
        }
        return v(i) + i;
    }

    public static int b(x52 x52) {
        int b2 = x52.b();
        return v(b2) + b2;
    }

    public static int c(t62 t62, i72 i72) {
        b42 b42 = (b42) t62;
        int h = b42.h();
        if (h == -1) {
            h = i72.h(b42);
            b42.a(h);
        }
        return v(h) + h;
    }

    public static long j(long j) {
        return (j >> 63) ^ (j << 1);
    }

    public static int k(int i) {
        return v(i << 3) + 4;
    }

    public static int l(int i, String str) {
        return V(str) + v(i << 3);
    }

    public static int m(k42 k42) {
        int size = k42.size();
        return v(size) + size;
    }

    public static int o(int i) {
        return v(i << 3) + 8;
    }

    public static int p(int i) {
        return v(i << 3) + 1;
    }

    public static int t(int i) {
        return v(i << 3);
    }

    public static int u(int i) {
        if (i >= 0) {
            return v(i);
        }
        return 10;
    }

    public static int v(int i) {
        if ((i & -128) == 0) {
            return 1;
        }
        if ((i & -16384) == 0) {
            return 2;
        }
        if ((-2097152 & i) == 0) {
            return 3;
        }
        return (i & -268435456) == 0 ? 4 : 5;
    }

    public static int w(int i) {
        return v(x(i));
    }

    public static int x(int i) {
        return (i >> 31) ^ (i << 1);
    }

    public static int y(int i, k42 k42) {
        int v = v(i << 3);
        int size = k42.size();
        return v(size) + size + v;
    }

    @Deprecated
    public static int z(int i, t62 t62, i72 i72) {
        int v = v(i << 3) << 1;
        b42 b42 = (b42) t62;
        int h = b42.h();
        if (h == -1) {
            h = i72.h(b42);
            b42.a(h);
        }
        return v + h;
    }

    public abstract void A(byte b2);

    public abstract void B(int i, long j);

    public abstract int G();

    public abstract void I(int i, int i2);

    public abstract void J(int i, int i2);

    public abstract void K(int i, int i2);

    public abstract void R(long j);

    public abstract void S(long j);

    public abstract void a(int i, int i2);

    public abstract void d(int i, long j);

    public abstract void e(int i, k42 k42);

    public abstract void f(int i, t62 t62);

    public abstract void g(int i, t62 t62, i72 i72);

    public abstract void h(int i, String str);

    public abstract void i(int i, boolean z);

    public abstract void n(int i, k42 k42);

    public abstract void q(int i);

    public abstract void r(int i);

    public abstract void s(int i);

    public zzhl(t42 t42) {
    }
}
