package com.google.android.gms.internal.vision;

import java.io.IOException;

/* compiled from: com.google.android.gms:play-services-vision-common@@19.1.2 */
public class zzin extends IOException {
    public static final /* synthetic */ int g = 0;

    public zzin(String str) {
        super(str);
    }

    public static zzin a() {
        return new zzin("While parsing a protocol message, the input ended unexpectedly in the middle of a field.  This could mean either that the input has been truncated or that an embedded message misreported its own length.");
    }

    public static zzin b() {
        return new zzin("CodedInputStream encountered an embedded string or message which claimed to have negative size.");
    }

    public static zzin c() {
        return new zzin("Protocol message contained an invalid tag (zero).");
    }

    public static zzin d() {
        return new zzin("Failed to parse the message.");
    }

    public static zzin e() {
        return new zzin("Protocol message had invalid UTF-8.");
    }
}
