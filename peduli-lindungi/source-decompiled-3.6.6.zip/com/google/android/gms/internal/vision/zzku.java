package com.google.android.gms.internal.vision;

/* compiled from: com.google.android.gms:play-services-vision-common@@19.1.2 */
public final class zzku extends RuntimeException {
    public zzku() {
        super("Message was missing required fields.  (Lite runtime could not determine which fields were missing).");
    }
}
