package com.google.android.gms.internal.vision;

/* compiled from: com.google.android.gms:play-services-vision-common@@19.1.2 */
public final class zzim extends zzin {
    public zzim(String str) {
        super(str);
    }
}
