package com.google.android.gms.common.data;

import android.database.CursorWindow;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import com.google.android.gms.common.annotation.KeepName;
import java.io.Closeable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

@KeepName
/* compiled from: com.google.android.gms:play-services-base@@17.1.0 */
public final class DataHolder extends y01 implements Closeable {
    public static final Parcelable.Creator<DataHolder> CREATOR = new d01();
    public final int g;
    public final String[] h;
    public Bundle i;
    public final CursorWindow[] j;
    public final int k;
    public final Bundle l;
    public int[] m;
    public boolean n = false;
    public boolean o = true;

    /* compiled from: com.google.android.gms:play-services-base@@17.1.0 */
    public static class zaa extends RuntimeException {
    }

    static {
        Objects.requireNonNull(new String[0], "null reference");
        new ArrayList();
        new HashMap();
    }

    public DataHolder(int i2, String[] strArr, CursorWindow[] cursorWindowArr, int i3, Bundle bundle) {
        this.g = i2;
        this.h = strArr;
        this.j = cursorWindowArr;
        this.k = i3;
        this.l = bundle;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        synchronized (this) {
            if (!this.n) {
                this.n = true;
                int i2 = 0;
                while (true) {
                    CursorWindow[] cursorWindowArr = this.j;
                    if (i2 >= cursorWindowArr.length) {
                        break;
                    }
                    cursorWindowArr[i2].close();
                    i2++;
                }
            }
        }
    }

    @Override // java.lang.Object
    public final void finalize() {
        boolean z;
        try {
            if (this.o && this.j.length > 0) {
                synchronized (this) {
                    z = this.n;
                }
                if (!z) {
                    close();
                    String obj = toString();
                    StringBuilder sb = new StringBuilder(String.valueOf(obj).length() + 178);
                    sb.append("Internal data leak within a DataBuffer object detected!  Be sure to explicitly call release() on all DataBuffer extending objects when you are done with them. (internal object: ");
                    sb.append(obj);
                    sb.append(")");
                    Log.e("DataBuffer", sb.toString());
                }
            }
        } finally {
            super.finalize();
        }
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        int D0 = ww0.D0(parcel, 20293);
        ww0.n0(parcel, 1, this.h, false);
        ww0.o0(parcel, 2, this.j, i2, false);
        int i3 = this.k;
        ww0.J1(parcel, 3, 4);
        parcel.writeInt(i3);
        ww0.f0(parcel, 4, this.l, false);
        int i4 = this.g;
        ww0.J1(parcel, vf0.DEFAULT_IMAGE_TIMEOUT_MS, 4);
        parcel.writeInt(i4);
        ww0.I1(parcel, D0);
        if ((i2 & 1) != 0) {
            close();
        }
    }
}
