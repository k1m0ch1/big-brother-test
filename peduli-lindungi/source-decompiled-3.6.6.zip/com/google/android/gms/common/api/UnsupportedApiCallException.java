package com.google.android.gms.common.api;

/* compiled from: com.google.android.gms:play-services-basement@@17.2.1 */
public final class UnsupportedApiCallException extends UnsupportedOperationException {
    public final hx0 g;

    public UnsupportedApiCallException(hx0 hx0) {
        this.g = hx0;
    }

    public final String getMessage() {
        String valueOf = String.valueOf(this.g);
        return ze0.b0(valueOf.length() + 8, "Missing ", valueOf);
    }
}
