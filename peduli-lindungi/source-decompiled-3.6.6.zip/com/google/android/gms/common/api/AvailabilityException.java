package com.google.android.gms.common.api;

import android.text.TextUtils;
import defpackage.sg;
import java.util.ArrayList;
import java.util.Iterator;

/* compiled from: com.google.android.gms:play-services-base@@17.1.0 */
public class AvailabilityException extends Exception {
    public final mg<yx0<?>, fx0> g;

    public String getMessage() {
        ArrayList arrayList = new ArrayList();
        Iterator it = ((sg.c) this.g.keySet()).iterator();
        boolean z = true;
        while (true) {
            sg.a aVar = (sg.a) it;
            if (!aVar.hasNext()) {
                break;
            }
            yx0 yx0 = (yx0) aVar.next();
            fx0 fx0 = this.g.get(yx0);
            if (fx0.y()) {
                z = false;
            }
            String str = yx0.b.c;
            String valueOf = String.valueOf(fx0);
            StringBuilder sb = new StringBuilder(valueOf.length() + String.valueOf(str).length() + 2);
            sb.append(str);
            sb.append(": ");
            sb.append(valueOf);
            arrayList.add(sb.toString());
        }
        StringBuilder sb2 = new StringBuilder();
        if (z) {
            sb2.append("None of the queried APIs are available. ");
        } else {
            sb2.append("Some of the queried APIs are unavailable. ");
        }
        sb2.append(TextUtils.join("; ", arrayList));
        return sb2.toString();
    }
}
