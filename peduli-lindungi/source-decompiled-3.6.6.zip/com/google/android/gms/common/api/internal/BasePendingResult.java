package com.google.android.gms.common.api.internal;

import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.util.Pair;
import com.google.android.gms.common.annotation.KeepName;
import com.google.android.gms.common.api.Status;
import defpackage.sx0;
import defpackage.vx0;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicReference;

@KeepName
/* compiled from: com.google.android.gms:play-services-base@@17.1.0 */
public abstract class BasePendingResult<R extends vx0> extends sx0<R> {
    public static final ThreadLocal<Boolean> k = new vz0();
    public final Object a;
    public final a<R> b;
    public final CountDownLatch c;
    public final ArrayList<sx0.a> d;
    public final AtomicReference<kz0> e;
    public R f;
    public Status g;
    public volatile boolean h;
    public boolean i;
    public boolean j;
    @KeepName
    public b mResultGuardian;

    /* compiled from: com.google.android.gms:play-services-base@@17.1.0 */
    public static class a<R extends vx0> extends g51 {
        public a(Looper looper) {
            super(looper);
        }

        /* JADX DEBUG: Multi-variable search result rejected for r0v2, resolved type: wx0 */
        /* JADX WARN: Multi-variable type inference failed */
        public void handleMessage(Message message) {
            int i = message.what;
            if (i == 1) {
                Pair pair = (Pair) message.obj;
                wx0 wx0 = (wx0) pair.first;
                vx0 vx0 = (vx0) pair.second;
                try {
                    wx0.a(vx0);
                } catch (RuntimeException e) {
                    BasePendingResult.g(vx0);
                    throw e;
                }
            } else if (i != 2) {
                Log.wtf("BasePendingResult", ze0.Y(45, "Don't know how to handle message: ", i), new Exception());
            } else {
                ((BasePendingResult) message.obj).h(Status.m);
            }
        }
    }

    /* compiled from: com.google.android.gms:play-services-base@@17.1.0 */
    public final class b {
        public b(vz0 vz0) {
        }

        public final void finalize() {
            BasePendingResult.g(BasePendingResult.this.f);
            super.finalize();
        }
    }

    @Deprecated
    public BasePendingResult() {
        this.a = new Object();
        this.c = new CountDownLatch(1);
        this.d = new ArrayList<>();
        this.e = new AtomicReference<>();
        this.j = false;
        this.b = new a<>(Looper.getMainLooper());
        new WeakReference(null);
    }

    public static void g(vx0 vx0) {
        if (vx0 instanceof tx0) {
            try {
                ((tx0) vx0).a();
            } catch (RuntimeException e2) {
                String valueOf = String.valueOf(vx0);
                StringBuilder sb = new StringBuilder(valueOf.length() + 18);
                sb.append("Unable to release ");
                sb.append(valueOf);
                Log.w("BasePendingResult", sb.toString(), e2);
            }
        }
    }

    public final void a(sx0.a aVar) {
        ww0.e(true, "Callback cannot be null.");
        synchronized (this.a) {
            if (d()) {
                aVar.a(this.g);
            } else {
                this.d.add(aVar);
            }
        }
    }

    public abstract R b(Status status);

    public final R c() {
        R r;
        synchronized (this.a) {
            ww0.o(!this.h, "Result has already been consumed.");
            ww0.o(d(), "Result is not ready.");
            r = this.f;
            this.f = null;
            this.h = true;
        }
        kz0 andSet = this.e.getAndSet(null);
        if (andSet != null) {
            andSet.a(this);
        }
        return r;
    }

    public final boolean d() {
        return this.c.getCount() == 0;
    }

    public final void e(R r) {
        synchronized (this.a) {
            if (!this.i) {
                d();
                boolean z = true;
                ww0.o(!d(), "Results have already been set");
                if (this.h) {
                    z = false;
                }
                ww0.o(z, "Result has already been consumed");
                f(r);
                return;
            }
            g(r);
        }
    }

    public final void f(R r) {
        this.f = r;
        this.c.countDown();
        this.g = this.f.a();
        if (this.f instanceof tx0) {
            this.mResultGuardian = new b(null);
        }
        ArrayList<sx0.a> arrayList = this.d;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            sx0.a aVar = arrayList.get(i2);
            i2++;
            aVar.a(this.g);
        }
        this.d.clear();
    }

    public final void h(Status status) {
        synchronized (this.a) {
            if (!d()) {
                e(b(status));
                this.i = true;
            }
        }
    }

    public BasePendingResult(rx0 rx0) {
        this.a = new Object();
        this.c = new CountDownLatch(1);
        this.d = new ArrayList<>();
        this.e = new AtomicReference<>();
        this.j = false;
        this.b = new a<>(rx0 != null ? rx0.b() : Looper.getMainLooper());
        new WeakReference(rx0);
    }
}
