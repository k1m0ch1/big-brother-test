package com.google.android.gms.common.api.internal;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Keep;
import androidx.fragment.app.Fragment;
import java.lang.ref.WeakReference;

/* compiled from: com.google.android.gms:play-services-basement@@17.2.1 */
public class LifecycleCallback {
    public final fy0 g;

    public LifecycleCallback(fy0 fy0) {
        this.g = fy0;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0031, code lost:
        if (r2 != false) goto L_0x0033;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x006f, code lost:
        if (r1 != null) goto L_0x00a2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x0082, code lost:
        if (r2 != false) goto L_0x0084;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:5:0x001d, code lost:
        if (r1 != null) goto L_0x00a2;
     */
    public static fy0 c(Activity activity) {
        zz0 zz0;
        fy0 fy0;
        Fragment fragment;
        ww0.m(activity, "Activity must not be null");
        if (activity instanceof vp) {
            vp vpVar = (vp) activity;
            WeakReference<zz0> weakReference = zz0.j.get(vpVar);
            if (weakReference != null) {
                fy0 fy02 = (zz0) weakReference.get();
                zz0 = fy02;
            }
            try {
                Fragment fragment2 = (zz0) vpVar.getSupportFragmentManager().I("SupportLifecycleFragmentImpl");
                if (fragment2 != null) {
                    boolean isRemoving = fragment2.isRemoving();
                    fragment = fragment2;
                }
                Fragment zz02 = new zz0();
                sp spVar = new sp(vpVar.getSupportFragmentManager());
                spVar.f(0, zz02, "SupportLifecycleFragmentImpl", 1);
                spVar.k();
                fragment = zz02;
                zz0.j.put(vpVar, new WeakReference<>(fragment));
                zz0 = fragment;
            } catch (ClassCastException e) {
                throw new IllegalStateException("Fragment with tag SupportLifecycleFragmentImpl is not a SupportLifecycleFragmentImpl", e);
            }
        } else {
            WeakReference<yz0> weakReference2 = yz0.j.get(activity);
            if (weakReference2 != null) {
                fy0 fy03 = (yz0) weakReference2.get();
                zz0 = fy03;
            }
            try {
                yz0 yz0 = (yz0) activity.getFragmentManager().findFragmentByTag("LifecycleFragmentImpl");
                if (yz0 != null) {
                    boolean isRemoving2 = yz0.isRemoving();
                    fy0 = yz0;
                }
                yz0 yz02 = new yz0();
                activity.getFragmentManager().beginTransaction().add(yz02, "LifecycleFragmentImpl").commitAllowingStateLoss();
                fy0 = yz02;
                yz0.j.put(activity, new WeakReference<>(fy0));
                zz0 = fy0;
            } catch (ClassCastException e2) {
                throw new IllegalStateException("Fragment with tag LifecycleFragmentImpl is not a LifecycleFragmentImpl", e2);
            }
        }
        return zz0;
    }

    @Keep
    private static fy0 getChimeraLifecycleFragmentImpl(ey0 ey0) {
        throw new IllegalStateException("Method not available in SDK.");
    }

    public void a() {
    }

    public Activity b() {
        return this.g.z1();
    }

    public void d(int i, int i2, Intent intent) {
    }

    public void e(Bundle bundle) {
    }

    public void f() {
    }

    public void g(Bundle bundle) {
    }

    public void h() {
    }

    public void i() {
    }
}
