package com.google.android.gms.common.api.internal;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

/* compiled from: com.google.android.gms:play-services-base@@17.1.0 */
public final class zabq extends BroadcastReceiver {
    public Context a;
    public final uz0 b;

    public zabq(uz0 uz0) {
        this.b = uz0;
    }

    public final synchronized void a() {
        Context context = this.a;
        if (context != null) {
            context.unregisterReceiver(this);
        }
        this.a = null;
    }

    public final void onReceive(Context context, Intent intent) {
        Uri data = intent.getData();
        if ("com.google.android.gms".equals(data != null ? data.getSchemeSpecificPart() : null)) {
            uz0 uz0 = this.b;
            uz0.b.h.k();
            if (uz0.a.isShowing()) {
                uz0.a.dismiss();
            }
            a();
        }
    }
}
