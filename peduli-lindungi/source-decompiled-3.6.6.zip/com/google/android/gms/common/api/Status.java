package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.util.Arrays;

/* compiled from: com.google.android.gms:play-services-basement@@17.2.1 */
public final class Status extends y01 implements vx0, ReflectedParcelable {
    public static final Parcelable.Creator<Status> CREATOR = new c01();
    public static final Status k = new Status(0);
    public static final Status l = new Status(14);
    public static final Status m = new Status(15);
    public static final Status n = new Status(16);
    public final int g;
    public final int h;
    public final String i;
    public final PendingIntent j;

    static {
        new Status(8);
        new Status(17);
        new Status(18);
    }

    public Status(int i2, int i3, String str, PendingIntent pendingIntent) {
        this.g = i2;
        this.h = i3;
        this.i = str;
        this.j = pendingIntent;
    }

    @Override // defpackage.vx0
    public final Status a() {
        return this;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof Status)) {
            return false;
        }
        Status status = (Status) obj;
        if (this.g != status.g || this.h != status.h || !ww0.D(this.i, status.i) || !ww0.D(this.j, status.j)) {
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.g), Integer.valueOf(this.h), this.i, this.j});
    }

    public final boolean r() {
        return this.h <= 0;
    }

    public final String toString() {
        t01 t01 = new t01(this, null);
        String str = this.i;
        if (str == null) {
            str = px0.getStatusCodeString(this.h);
        }
        t01.a("statusCode", str);
        t01.a("resolution", this.j);
        return t01.toString();
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        int D0 = ww0.D0(parcel, 20293);
        int i3 = this.h;
        ww0.J1(parcel, 1, 4);
        parcel.writeInt(i3);
        ww0.m0(parcel, 2, this.i, false);
        ww0.l0(parcel, 3, this.j, i2, false);
        int i4 = this.g;
        ww0.J1(parcel, vf0.DEFAULT_IMAGE_TIMEOUT_MS, 4);
        parcel.writeInt(i4);
        ww0.I1(parcel, D0);
    }

    public Status(int i2) {
        this(1, i2, null, null);
    }

    public Status(int i2, String str) {
        this(1, i2, str, null);
    }
}
