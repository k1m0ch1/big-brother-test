package com.google.android.gms.common.api;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import com.google.android.gms.common.annotation.KeepName;

@KeepName
/* compiled from: com.google.android.gms:play-services-base@@17.1.0 */
public class GoogleApiActivity extends Activity implements DialogInterface.OnCancelListener {
    public static final /* synthetic */ int h = 0;
    public int g = 0;

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 1) {
            boolean booleanExtra = getIntent().getBooleanExtra("notify_manager", true);
            this.g = 0;
            setResult(i2, intent);
            if (booleanExtra) {
                cy0 b = cy0.b(this);
                if (i2 == -1) {
                    Handler handler = b.k;
                    handler.sendMessage(handler.obtainMessage(3));
                } else if (i2 == 0) {
                    fx0 fx0 = new fx0(13, null);
                    int intExtra = getIntent().getIntExtra("failing_client_id", -1);
                    if (!b.d(fx0, intExtra)) {
                        Handler handler2 = b.k;
                        handler2.sendMessage(handler2.obtainMessage(5, intExtra, 0, fx0));
                    }
                }
            }
        } else if (i == 2) {
            this.g = 0;
            setResult(i2, intent);
        }
        finish();
    }

    public void onCancel(DialogInterface dialogInterface) {
        this.g = 0;
        setResult(0);
        finish();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (bundle != null) {
            this.g = bundle.getInt("resolution");
        }
        if (this.g != 1) {
            Bundle extras = getIntent().getExtras();
            if (extras == null) {
                Log.e("GoogleApiActivity", "Activity started without extras");
                finish();
                return;
            }
            PendingIntent pendingIntent = (PendingIntent) extras.get("pending_intent");
            Integer num = (Integer) extras.get("error_code");
            if (pendingIntent == null && num == null) {
                Log.e("GoogleApiActivity", "Activity started without resolution");
                finish();
            } else if (pendingIntent != null) {
                try {
                    startIntentSenderForResult(pendingIntent.getIntentSender(), 1, null, 0, 0, 0);
                    this.g = 1;
                } catch (IntentSender.SendIntentException e) {
                    Log.e("GoogleApiActivity", "Failed to launch pendingIntent", e);
                    finish();
                }
            } else {
                Object obj = ix0.c;
                ix0.d.e(this, num.intValue(), 2, this);
                this.g = 1;
            }
        }
    }

    public void onSaveInstanceState(Bundle bundle) {
        bundle.putInt("resolution", this.g);
        super.onSaveInstanceState(bundle);
    }
}
