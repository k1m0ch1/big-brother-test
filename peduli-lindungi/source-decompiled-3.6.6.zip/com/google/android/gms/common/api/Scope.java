package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;

/* compiled from: com.google.android.gms:play-services-basement@@17.2.1 */
public final class Scope extends y01 implements ReflectedParcelable {
    public static final Parcelable.Creator<Scope> CREATOR = new b01();
    public final int g;
    public final String h;

    public Scope(int i, String str) {
        ww0.j(str, "scopeUri must not be null or empty");
        this.g = i;
        this.h = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Scope)) {
            return false;
        }
        return this.h.equals(((Scope) obj).h);
    }

    public final int hashCode() {
        return this.h.hashCode();
    }

    public final String toString() {
        return this.h;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int D0 = ww0.D0(parcel, 20293);
        int i2 = this.g;
        ww0.J1(parcel, 1, 4);
        parcel.writeInt(i2);
        ww0.m0(parcel, 2, this.h, false);
        ww0.I1(parcel, D0);
    }

    public Scope(String str) {
        ww0.j(str, "scopeUri must not be null or empty");
        this.g = 1;
        this.h = str;
    }
}
