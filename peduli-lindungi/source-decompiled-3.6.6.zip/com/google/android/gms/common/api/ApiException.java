package com.google.android.gms.common.api;

/* compiled from: com.google.android.gms:play-services-basement@@17.2.1 */
public class ApiException extends Exception {
    @Deprecated
    public final Status g;

    /* JADX WARNING: Illegal instructions before constructor call */
    public ApiException(Status status) {
        super(r3.toString());
        int i = status.h;
        String str = status.i;
        str = str == null ? "" : str;
        StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 13);
        sb.append(i);
        sb.append(": ");
        sb.append(str);
        this.g = status;
    }
}
