package com.google.android.gms.common.util;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Target({ElementType.TYPE})
/* compiled from: com.google.android.gms:play-services-basement@@17.2.1 */
public @interface DynamiteApi {
}
