package com.google.android.gms.common;

/* compiled from: com.google.android.gms:play-services-basement@@17.2.1 */
public class UserRecoverableException extends Exception {
}
