package com.google.android.gms.common.server.response;

/* compiled from: com.google.android.gms:play-services-base@@17.1.0 */
public class FastParser$ParseException extends Exception {
}
