package com.google.android.gms.common;

/* compiled from: com.google.android.gms:play-services-basement@@17.2.1 */
public final class GooglePlayServicesNotAvailableException extends Exception {
    public final int g;

    public GooglePlayServicesNotAvailableException(int i) {
        this.g = i;
    }
}
