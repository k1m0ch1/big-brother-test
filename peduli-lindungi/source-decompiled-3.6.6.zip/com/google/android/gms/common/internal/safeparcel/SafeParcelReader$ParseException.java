package com.google.android.gms.common.internal.safeparcel;

import android.os.Parcel;

/* compiled from: com.google.android.gms:play-services-basement@@17.2.1 */
public class SafeParcelReader$ParseException extends RuntimeException {
    /* JADX WARNING: Illegal instructions before constructor call */
    public SafeParcelReader$ParseException(String str, Parcel parcel) {
        super(r2.toString());
        int dataPosition = parcel.dataPosition();
        int dataSize = parcel.dataSize();
        StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 41);
        sb.append(str);
        sb.append(" Parcel: pos=");
        sb.append(dataPosition);
        sb.append(" size=");
        sb.append(dataSize);
    }
}
