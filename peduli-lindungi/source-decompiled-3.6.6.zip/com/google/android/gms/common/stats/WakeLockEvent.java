package com.google.android.gms.common.stats;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.List;

/* compiled from: com.google.android.gms:play-services-basement@@17.2.1 */
public final class WakeLockEvent extends StatsEvent {
    public static final Parcelable.Creator<WakeLockEvent> CREATOR = new d21();
    public final int g;
    public final long h;
    public int i;
    public final String j;
    public final String k;
    public final String l;
    public final int m;
    public final List<String> n;
    public final String o;
    public final long p;
    public int q;
    public final String r;
    public final float s;
    public final long t;
    public final boolean u;
    public long v = -1;

    public WakeLockEvent(int i2, long j2, int i3, String str, int i4, List<String> list, String str2, long j3, int i5, String str3, String str4, float f, long j4, String str5, boolean z) {
        this.g = i2;
        this.h = j2;
        this.i = i3;
        this.j = str;
        this.k = str3;
        this.l = str5;
        this.m = i4;
        this.n = list;
        this.o = str2;
        this.p = j3;
        this.q = i5;
        this.r = str4;
        this.s = f;
        this.t = j4;
        this.u = z;
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        int D0 = ww0.D0(parcel, 20293);
        int i3 = this.g;
        ww0.J1(parcel, 1, 4);
        parcel.writeInt(i3);
        long j2 = this.h;
        ww0.J1(parcel, 2, 8);
        parcel.writeLong(j2);
        ww0.m0(parcel, 4, this.j, false);
        int i4 = this.m;
        ww0.J1(parcel, 5, 4);
        parcel.writeInt(i4);
        List<String> list = this.n;
        if (list != null) {
            int D02 = ww0.D0(parcel, 6);
            parcel.writeStringList(list);
            ww0.I1(parcel, D02);
        }
        long j3 = this.p;
        ww0.J1(parcel, 8, 8);
        parcel.writeLong(j3);
        ww0.m0(parcel, 10, this.k, false);
        int i5 = this.i;
        ww0.J1(parcel, 11, 4);
        parcel.writeInt(i5);
        ww0.m0(parcel, 12, this.o, false);
        ww0.m0(parcel, 13, this.r, false);
        int i6 = this.q;
        ww0.J1(parcel, 14, 4);
        parcel.writeInt(i6);
        float f = this.s;
        ww0.J1(parcel, 15, 4);
        parcel.writeFloat(f);
        long j4 = this.t;
        ww0.J1(parcel, 16, 8);
        parcel.writeLong(j4);
        ww0.m0(parcel, 17, this.l, false);
        boolean z = this.u;
        ww0.J1(parcel, 18, 4);
        parcel.writeInt(z ? 1 : 0);
        ww0.I1(parcel, D0);
    }
}
