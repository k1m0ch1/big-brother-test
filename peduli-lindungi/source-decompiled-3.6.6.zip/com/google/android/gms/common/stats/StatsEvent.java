package com.google.android.gms.common.stats;

import android.text.TextUtils;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.util.List;

/* compiled from: com.google.android.gms:play-services-basement@@17.2.1 */
public abstract class StatsEvent extends y01 implements ReflectedParcelable {
    public String toString() {
        String str;
        WakeLockEvent wakeLockEvent = (WakeLockEvent) this;
        long j = wakeLockEvent.h;
        int i = wakeLockEvent.i;
        long j2 = wakeLockEvent.v;
        String str2 = wakeLockEvent.j;
        int i2 = wakeLockEvent.m;
        List<String> list = wakeLockEvent.n;
        String str3 = "";
        if (list == null) {
            str = str3;
        } else {
            str = TextUtils.join(",", list);
        }
        int i3 = wakeLockEvent.q;
        String str4 = wakeLockEvent.k;
        if (str4 == null) {
            str4 = str3;
        }
        String str5 = wakeLockEvent.r;
        if (str5 == null) {
            str5 = str3;
        }
        float f = wakeLockEvent.s;
        String str6 = wakeLockEvent.l;
        if (str6 != null) {
            str3 = str6;
        }
        boolean z = wakeLockEvent.u;
        StringBuilder sb = new StringBuilder(str3.length() + str5.length() + str4.length() + ze0.U(str, ze0.U(str2, 51)));
        sb.append("\t");
        sb.append(str2);
        sb.append("\t");
        sb.append(i2);
        sb.append("\t");
        sb.append(str);
        sb.append("\t");
        sb.append(i3);
        ze0.g(sb, "\t", str4, "\t", str5);
        sb.append("\t");
        sb.append(f);
        sb.append("\t");
        sb.append(str3);
        sb.append("\t");
        sb.append(z);
        String sb2 = sb.toString();
        StringBuilder sb3 = new StringBuilder(ze0.U(sb2, 53));
        sb3.append(j);
        sb3.append("\t");
        sb3.append(i);
        sb3.append("\t");
        sb3.append(j2);
        sb3.append(sb2);
        return sb3.toString();
    }
}
