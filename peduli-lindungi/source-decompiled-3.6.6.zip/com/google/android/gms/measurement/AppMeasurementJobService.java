package com.google.android.gms.measurement;

import android.annotation.TargetApi;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Intent;

@TargetApi(24)
/* compiled from: com.google.android.gms:play-services-measurement@@18.0.0 */
public final class AppMeasurementJobService extends JobService implements xm2 {
    public tm2<AppMeasurementJobService> g;

    @Override // defpackage.xm2
    public final void a(Intent intent) {
    }

    @Override // defpackage.xm2
    @TargetApi(24)
    public final void b(JobParameters jobParameters, boolean z) {
        jobFinished(jobParameters, false);
    }

    public final tm2<AppMeasurementJobService> c() {
        if (this.g == null) {
            this.g = new tm2<>(this);
        }
        return this.g;
    }

    public final void onCreate() {
        super.onCreate();
        yi2.c(c().a, null, null).d().n.a("Local AppMeasurementService is starting up");
    }

    public final void onDestroy() {
        yi2.c(c().a, null, null).d().n.a("Local AppMeasurementService is shutting down");
        super.onDestroy();
    }

    public final void onRebind(Intent intent) {
        c().c(intent);
    }

    public final boolean onStartJob(JobParameters jobParameters) {
        tm2<AppMeasurementJobService> c = c();
        uh2 d = yi2.c(c.a, null, null).d();
        String string = jobParameters.getExtras().getString("action");
        d.n.b("Local AppMeasurementJobService called. action", string);
        if (!"com.google.android.gms.measurement.UPLOAD".equals(string)) {
            return true;
        }
        vm2 vm2 = new vm2(c, d, jobParameters);
        on2 c2 = on2.c(c.a);
        c2.a().t(new ym2(c2, vm2));
        return true;
    }

    public final boolean onStopJob(JobParameters jobParameters) {
        return false;
    }

    public final boolean onUnbind(Intent intent) {
        c().a(intent);
        return true;
    }

    @Override // defpackage.xm2
    public final boolean zza(int i) {
        throw new UnsupportedOperationException();
    }
}
