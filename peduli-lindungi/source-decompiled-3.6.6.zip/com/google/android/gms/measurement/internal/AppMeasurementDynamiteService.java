package com.google.android.gms.measurement.internal;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import com.google.android.gms.common.util.DynamiteApi;
import com.google.maps.android.BuildConfig;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;

@DynamiteApi
/* compiled from: com.google.android.gms:play-services-measurement-sdk@@18.0.0 */
public class AppMeasurementDynamiteService extends w12 {
    public yi2 a = null;
    public final Map<Integer, dk2> b = new mg();

    /* compiled from: com.google.android.gms:play-services-measurement-sdk@@18.0.0 */
    public class a implements ak2 {
        public vo1 a;

        public a(vo1 vo1) {
            this.a = vo1;
        }
    }

    /* compiled from: com.google.android.gms:play-services-measurement-sdk@@18.0.0 */
    public class b implements dk2 {
        public vo1 a;

        public b(vo1 vo1) {
            this.a = vo1;
        }

        @Override // defpackage.dk2
        public final void a(String str, String str2, Bundle bundle, long j) {
            try {
                this.a.B(str, str2, bundle, j);
            } catch (RemoteException e) {
                AppMeasurementDynamiteService.this.a.d().i.b("Event listener threw exception", e);
            }
        }
    }

    @Override // defpackage.x12
    public void beginAdUnitExposure(String str, long j) {
        g1();
        this.a.y().t(str, j);
    }

    @Override // defpackage.x12
    public void clearConditionalUserProperty(String str, String str2, Bundle bundle) {
        g1();
        this.a.q().P(str, str2, bundle);
    }

    @Override // defpackage.x12
    public void clearMeasurementEnabled(long j) {
        g1();
        gk2 q = this.a.q();
        q.r();
        q.a().t(new yk2(q, null));
    }

    @Override // defpackage.x12
    public void endAdUnitExposure(String str, long j) {
        g1();
        this.a.y().w(str, j);
    }

    public final void g1() {
        if (this.a == null) {
            throw new IllegalStateException("Attempting to perform action before initialize.");
        }
    }

    @Override // defpackage.x12
    public void generateEventId(y12 y12) {
        g1();
        this.a.r().I(y12, this.a.r().r0());
    }

    @Override // defpackage.x12
    public void getAppInstanceId(y12 y12) {
        g1();
        this.a.a().t(new ek2(this, y12));
    }

    @Override // defpackage.x12
    public void getCachedAppInstanceId(y12 y12) {
        g1();
        this.a.r().K(y12, this.a.q().g.get());
    }

    @Override // defpackage.x12
    public void getConditionalUserProperties(String str, String str2, y12 y12) {
        g1();
        this.a.a().t(new dn2(this, y12, str, str2));
    }

    @Override // defpackage.x12
    public void getCurrentScreenClass(y12 y12) {
        g1();
        ml2 ml2 = this.a.q().a.u().c;
        this.a.r().K(y12, ml2 != null ? ml2.b : null);
    }

    @Override // defpackage.x12
    public void getCurrentScreenName(y12 y12) {
        g1();
        ml2 ml2 = this.a.q().a.u().c;
        this.a.r().K(y12, ml2 != null ? ml2.a : null);
    }

    @Override // defpackage.x12
    public void getGmpAppId(y12 y12) {
        g1();
        this.a.r().K(y12, this.a.q().M());
    }

    @Override // defpackage.x12
    public void getMaxUserProperties(String str, y12 y12) {
        g1();
        this.a.q();
        ww0.i(str);
        this.a.r().H(y12, 25);
    }

    @Override // defpackage.x12
    public void getTestFlag(y12 y12, int i) {
        g1();
        if (i == 0) {
            yn2 r = this.a.r();
            gk2 q = this.a.q();
            Objects.requireNonNull(q);
            AtomicReference atomicReference = new AtomicReference();
            r.K(y12, (String) q.a().q(atomicReference, 15000, "String test flag value", new qk2(q, atomicReference)));
        } else if (i == 1) {
            yn2 r2 = this.a.r();
            gk2 q2 = this.a.q();
            Objects.requireNonNull(q2);
            AtomicReference atomicReference2 = new AtomicReference();
            r2.I(y12, ((Long) q2.a().q(atomicReference2, 15000, "long test flag value", new xk2(q2, atomicReference2))).longValue());
        } else if (i == 2) {
            yn2 r3 = this.a.r();
            gk2 q3 = this.a.q();
            Objects.requireNonNull(q3);
            AtomicReference atomicReference3 = new AtomicReference();
            double doubleValue = ((Double) q3.a().q(atomicReference3, 15000, "double test flag value", new zk2(q3, atomicReference3))).doubleValue();
            Bundle bundle = new Bundle();
            bundle.putDouble("r", doubleValue);
            try {
                y12.c(bundle);
            } catch (RemoteException e) {
                r3.a.d().i.b("Error returning double value to wrapper", e);
            }
        } else if (i == 3) {
            yn2 r4 = this.a.r();
            gk2 q4 = this.a.q();
            Objects.requireNonNull(q4);
            AtomicReference atomicReference4 = new AtomicReference();
            r4.H(y12, ((Integer) q4.a().q(atomicReference4, 15000, "int test flag value", new wk2(q4, atomicReference4))).intValue());
        } else if (i == 4) {
            yn2 r5 = this.a.r();
            gk2 q5 = this.a.q();
            Objects.requireNonNull(q5);
            AtomicReference atomicReference5 = new AtomicReference();
            r5.M(y12, ((Boolean) q5.a().q(atomicReference5, 15000, "boolean test flag value", new hk2(q5, atomicReference5))).booleanValue());
        }
    }

    @Override // defpackage.x12
    public void getUserProperties(String str, String str2, boolean z, y12 y12) {
        g1();
        this.a.a().t(new el2(this, y12, str, str2, z));
    }

    @Override // defpackage.x12
    public void initForTests(Map map) {
        g1();
    }

    @Override // defpackage.x12
    public void initialize(h31 h31, yo1 yo1, long j) {
        Context context = (Context) j31.h1(h31);
        yi2 yi2 = this.a;
        if (yi2 == null) {
            this.a = yi2.c(context, yo1, Long.valueOf(j));
        } else {
            yi2.d().i.a("Attempting to initialize multiple times");
        }
    }

    @Override // defpackage.x12
    public void isDataCollectionEnabled(y12 y12) {
        g1();
        this.a.a().t(new co2(this, y12));
    }

    @Override // defpackage.x12
    public void logEvent(String str, String str2, Bundle bundle, boolean z, boolean z2, long j) {
        g1();
        this.a.q().G(str, str2, bundle, z, z2, j);
    }

    @Override // defpackage.x12
    public void logEventAndBundle(String str, String str2, Bundle bundle, y12 y12, long j) {
        Bundle bundle2;
        g1();
        ww0.i(str2);
        if (bundle == null) {
            bundle2 = new Bundle();
        }
        bundle2.putString("_o", "app");
        this.a.a().t(new cm2(this, y12, new rd2(str2, new qd2(bundle), "app", j), str));
    }

    @Override // defpackage.x12
    public void logHealthData(int i, String str, h31 h31, h31 h312, h31 h313) {
        Object obj;
        Object obj2;
        g1();
        Object obj3 = null;
        if (h31 == null) {
            obj = null;
        } else {
            obj = j31.h1(h31);
        }
        if (h312 == null) {
            obj2 = null;
        } else {
            obj2 = j31.h1(h312);
        }
        if (h313 != null) {
            obj3 = j31.h1(h313);
        }
        this.a.d().u(i, true, false, str, obj, obj2, obj3);
    }

    @Override // defpackage.x12
    public void onActivityCreated(h31 h31, Bundle bundle, long j) {
        g1();
        cl2 cl2 = this.a.q().c;
        if (cl2 != null) {
            this.a.q().K();
            cl2.onActivityCreated((Activity) j31.h1(h31), bundle);
        }
    }

    @Override // defpackage.x12
    public void onActivityDestroyed(h31 h31, long j) {
        g1();
        cl2 cl2 = this.a.q().c;
        if (cl2 != null) {
            this.a.q().K();
            cl2.onActivityDestroyed((Activity) j31.h1(h31));
        }
    }

    @Override // defpackage.x12
    public void onActivityPaused(h31 h31, long j) {
        g1();
        cl2 cl2 = this.a.q().c;
        if (cl2 != null) {
            this.a.q().K();
            cl2.onActivityPaused((Activity) j31.h1(h31));
        }
    }

    @Override // defpackage.x12
    public void onActivityResumed(h31 h31, long j) {
        g1();
        cl2 cl2 = this.a.q().c;
        if (cl2 != null) {
            this.a.q().K();
            cl2.onActivityResumed((Activity) j31.h1(h31));
        }
    }

    @Override // defpackage.x12
    public void onActivitySaveInstanceState(h31 h31, y12 y12, long j) {
        g1();
        cl2 cl2 = this.a.q().c;
        Bundle bundle = new Bundle();
        if (cl2 != null) {
            this.a.q().K();
            cl2.onActivitySaveInstanceState((Activity) j31.h1(h31), bundle);
        }
        try {
            y12.c(bundle);
        } catch (RemoteException e) {
            this.a.d().i.b("Error returning bundle value to wrapper", e);
        }
    }

    @Override // defpackage.x12
    public void onActivityStarted(h31 h31, long j) {
        g1();
        if (this.a.q().c != null) {
            this.a.q().K();
            Activity activity = (Activity) j31.h1(h31);
        }
    }

    @Override // defpackage.x12
    public void onActivityStopped(h31 h31, long j) {
        g1();
        if (this.a.q().c != null) {
            this.a.q().K();
            Activity activity = (Activity) j31.h1(h31);
        }
    }

    @Override // defpackage.x12
    public void performAction(Bundle bundle, y12 y12, long j) {
        g1();
        y12.c(null);
    }

    @Override // defpackage.x12
    public void registerOnMeasurementEventListener(vo1 vo1) {
        dk2 dk2;
        g1();
        synchronized (this.b) {
            dk2 = this.b.get(Integer.valueOf(vo1.zza()));
            if (dk2 == null) {
                dk2 = new b(vo1);
                this.b.put(Integer.valueOf(vo1.zza()), dk2);
            }
        }
        gk2 q = this.a.q();
        q.r();
        if (!q.e.add(dk2)) {
            q.d().i.a("OnEventListener already registered");
        }
    }

    @Override // defpackage.x12
    public void resetAnalyticsData(long j) {
        g1();
        gk2 q = this.a.q();
        q.g.set(null);
        q.a().t(new pk2(q, j));
    }

    @Override // defpackage.x12
    public void setConditionalUserProperty(Bundle bundle, long j) {
        g1();
        if (bundle == null) {
            this.a.d().f.a("Conditional user property must not be null");
        } else {
            this.a.q().w(bundle, j);
        }
    }

    @Override // defpackage.x12
    public void setConsent(Bundle bundle, long j) {
        g1();
        gk2 q = this.a.q();
        if (my1.a() && q.a.g.s(null, td2.H0)) {
            q.v(bundle, 30, j);
        }
    }

    @Override // defpackage.x12
    public void setConsentThirdParty(Bundle bundle, long j) {
        g1();
        gk2 q = this.a.q();
        if (my1.a() && q.a.g.s(null, td2.I0)) {
            q.v(bundle, 10, j);
        }
    }

    @Override // defpackage.x12
    public void setCurrentScreen(h31 h31, String str, String str2, long j) {
        g1();
        ll2 u = this.a.u();
        Activity activity = (Activity) j31.h1(h31);
        if (!u.a.g.x().booleanValue()) {
            u.d().k.a("setCurrentScreen cannot be called while screen reporting is disabled.");
        } else if (u.c == null) {
            u.d().k.a("setCurrentScreen cannot be called while no activity active");
        } else if (u.f.get(activity) == null) {
            u.d().k.a("setCurrentScreen must be called with an activity in the activity lifecycle");
        } else {
            if (str2 == null) {
                str2 = ll2.v(activity.getClass().getCanonicalName());
            }
            boolean o0 = yn2.o0(u.c.b, str2);
            boolean o02 = yn2.o0(u.c.a, str);
            if (o0 && o02) {
                u.d().k.a("setCurrentScreen cannot be called with the same class and name");
            } else if (str != null && (str.length() <= 0 || str.length() > 100)) {
                u.d().k.b("Invalid screen name length in setCurrentScreen. Length", Integer.valueOf(str.length()));
            } else if (str2 == null || (str2.length() > 0 && str2.length() <= 100)) {
                u.d().n.c("Setting current screen to name, class", str == null ? BuildConfig.TRAVIS : str, str2);
                ml2 ml2 = new ml2(str, str2, u.h().r0());
                u.f.put(activity, ml2);
                u.x(activity, ml2, true);
            } else {
                u.d().k.b("Invalid class name length in setCurrentScreen. Length", Integer.valueOf(str2.length()));
            }
        }
    }

    @Override // defpackage.x12
    public void setDataCollectionEnabled(boolean z) {
        g1();
        gk2 q = this.a.q();
        q.r();
        q.a().t(new kk2(q, z));
    }

    @Override // defpackage.x12
    public void setDefaultEventParameters(Bundle bundle) {
        Bundle bundle2;
        g1();
        gk2 q = this.a.q();
        if (bundle == null) {
            bundle2 = null;
        } else {
            bundle2 = new Bundle(bundle);
        }
        q.a().t(new fk2(q, bundle2));
    }

    @Override // defpackage.x12
    public void setEventInterceptor(vo1 vo1) {
        g1();
        a aVar = new a(vo1);
        if (this.a.a().w()) {
            this.a.q().z(aVar);
        } else {
            this.a.a().t(new bo2(this, aVar));
        }
    }

    @Override // defpackage.x12
    public void setInstanceIdProvider(wo1 wo1) {
        g1();
    }

    @Override // defpackage.x12
    public void setMeasurementEnabled(boolean z, long j) {
        g1();
        gk2 q = this.a.q();
        Boolean valueOf = Boolean.valueOf(z);
        q.r();
        q.a().t(new yk2(q, valueOf));
    }

    @Override // defpackage.x12
    public void setMinimumSessionDuration(long j) {
        g1();
        gk2 q = this.a.q();
        q.a().t(new mk2(q, j));
    }

    @Override // defpackage.x12
    public void setSessionTimeoutDuration(long j) {
        g1();
        gk2 q = this.a.q();
        q.a().t(new lk2(q, j));
    }

    @Override // defpackage.x12
    public void setUserId(String str, long j) {
        g1();
        this.a.q().J(null, "_id", str, true, j);
    }

    @Override // defpackage.x12
    public void setUserProperty(String str, String str2, h31 h31, boolean z, long j) {
        g1();
        this.a.q().J(str, str2, j31.h1(h31), z, j);
    }

    @Override // defpackage.x12
    public void unregisterOnMeasurementEventListener(vo1 vo1) {
        dk2 remove;
        g1();
        synchronized (this.b) {
            remove = this.b.remove(Integer.valueOf(vo1.zza()));
        }
        if (remove == null) {
            remove = new b(vo1);
        }
        gk2 q = this.a.q();
        q.r();
        if (!q.e.remove(remove)) {
            q.d().i.a("OnEventListener had not been registered");
        }
    }
}
