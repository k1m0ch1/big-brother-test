package com.google.android.gms.measurement;

import android.app.Service;
import android.app.job.JobParameters;
import android.content.Intent;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;
import android.util.SparseArray;
import androidx.legacy.content.WakefulBroadcastReceiver;
import java.util.Objects;

/* compiled from: com.google.android.gms:play-services-measurement@@18.0.0 */
public final class AppMeasurementService extends Service implements xm2 {
    public tm2<AppMeasurementService> g;

    @Override // defpackage.xm2
    public final void a(Intent intent) {
        SparseArray<PowerManager.WakeLock> sparseArray = WakefulBroadcastReceiver.a;
        int intExtra = intent.getIntExtra("androidx.contentpager.content.wakelockid", 0);
        if (intExtra != 0) {
            SparseArray<PowerManager.WakeLock> sparseArray2 = WakefulBroadcastReceiver.a;
            synchronized (sparseArray2) {
                PowerManager.WakeLock wakeLock = sparseArray2.get(intExtra);
                if (wakeLock != null) {
                    wakeLock.release();
                    sparseArray2.remove(intExtra);
                    return;
                }
                Log.w("WakefulBroadcastReceiv.", "No active wake lock id #" + intExtra);
            }
        }
    }

    @Override // defpackage.xm2
    public final void b(JobParameters jobParameters, boolean z) {
        throw new UnsupportedOperationException();
    }

    public final tm2<AppMeasurementService> c() {
        if (this.g == null) {
            this.g = new tm2<>(this);
        }
        return this.g;
    }

    public final IBinder onBind(Intent intent) {
        tm2<AppMeasurementService> c = c();
        Objects.requireNonNull(c);
        if (intent == null) {
            c.b().f.a("onBind called with null intent");
            return null;
        }
        String action = intent.getAction();
        if ("com.google.android.gms.measurement.START".equals(action)) {
            return new dj2(on2.c(c.a));
        }
        c.b().i.b("onBind received unknown action", action);
        return null;
    }

    public final void onCreate() {
        super.onCreate();
        yi2.c(c().a, null, null).d().n.a("Local AppMeasurementService is starting up");
    }

    public final void onDestroy() {
        yi2.c(c().a, null, null).d().n.a("Local AppMeasurementService is shutting down");
        super.onDestroy();
    }

    public final void onRebind(Intent intent) {
        c().c(intent);
    }

    public final int onStartCommand(Intent intent, int i, int i2) {
        tm2<AppMeasurementService> c = c();
        uh2 d = yi2.c(c.a, null, null).d();
        if (intent == null) {
            d.i.a("AppMeasurementService started with null intent");
            return 2;
        }
        String action = intent.getAction();
        d.n.c("Local AppMeasurementService called. startId, action", Integer.valueOf(i2), action);
        if (!"com.google.android.gms.measurement.UPLOAD".equals(action)) {
            return 2;
        }
        wm2 wm2 = new wm2(c, i2, d, intent);
        on2 c2 = on2.c(c.a);
        c2.a().t(new ym2(c2, wm2));
        return 2;
    }

    public final boolean onUnbind(Intent intent) {
        c().a(intent);
        return true;
    }

    @Override // defpackage.xm2
    public final boolean zza(int i) {
        return stopSelfResult(i);
    }
}
