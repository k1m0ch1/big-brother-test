package com.google.android.gms.measurement;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import android.util.SparseArray;
import androidx.legacy.content.WakefulBroadcastReceiver;
import java.util.Objects;

/* compiled from: com.google.android.gms:play-services-measurement@@18.0.0 */
public final class AppMeasurementReceiver extends WakefulBroadcastReceiver implements ui2 {
    public ri2 c;

    public final void onReceive(Context context, Intent intent) {
        if (this.c == null) {
            this.c = new ri2(this);
        }
        ri2 ri2 = this.c;
        Objects.requireNonNull(ri2);
        uh2 d = yi2.c(context, null, null).d();
        if (intent == null) {
            d.i.a("Receiver called with null intent");
            return;
        }
        String action = intent.getAction();
        d.n.b("Local receiver got", action);
        if ("com.google.android.gms.measurement.UPLOAD".equals(action)) {
            Intent className = new Intent().setClassName(context, "com.google.android.gms.measurement.AppMeasurementService");
            className.setAction("com.google.android.gms.measurement.UPLOAD");
            d.n.a("Starting wakeful intent.");
            Objects.requireNonNull((AppMeasurementReceiver) ri2.a);
            SparseArray<PowerManager.WakeLock> sparseArray = WakefulBroadcastReceiver.a;
            synchronized (sparseArray) {
                int i = WakefulBroadcastReceiver.b;
                int i2 = i + 1;
                WakefulBroadcastReceiver.b = i2;
                if (i2 <= 0) {
                    WakefulBroadcastReceiver.b = 1;
                }
                className.putExtra("androidx.contentpager.content.wakelockid", i);
                ComponentName startService = context.startService(className);
                if (startService != null) {
                    PowerManager.WakeLock newWakeLock = ((PowerManager) context.getSystemService("power")).newWakeLock(1, "androidx.core:wake:" + startService.flattenToShortString());
                    newWakeLock.setReferenceCounted(false);
                    newWakeLock.acquire(60000);
                    sparseArray.put(i, newWakeLock);
                }
            }
        } else if ("com.android.vending.INSTALL_REFERRER".equals(action)) {
            d.i.a("Install Referrer Broadcasts are deprecated");
        }
    }
}
