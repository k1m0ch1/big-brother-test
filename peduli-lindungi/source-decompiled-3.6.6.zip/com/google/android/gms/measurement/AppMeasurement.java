package com.google.android.gms.measurement;

import android.content.Context;
import android.os.Bundle;
import android.os.SystemClock;
import androidx.annotation.Keep;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;

@Deprecated
/* compiled from: com.google.android.gms:play-services-measurement-impl@@18.0.0 */
public class AppMeasurement {
    public static volatile AppMeasurement d;
    public final yi2 a;
    public final fl2 b;
    public final boolean c;

    /* compiled from: com.google.android.gms:play-services-measurement-impl@@18.0.0 */
    public static class ConditionalUserProperty {
        @Keep
        public boolean mActive;
        @Keep
        public String mAppId;
        @Keep
        public long mCreationTimestamp;
        @Keep
        public String mExpiredEventName;
        @Keep
        public Bundle mExpiredEventParams;
        @Keep
        public String mName;
        @Keep
        public String mOrigin;
        @Keep
        public long mTimeToLive;
        @Keep
        public String mTimedOutEventName;
        @Keep
        public Bundle mTimedOutEventParams;
        @Keep
        public String mTriggerEventName;
        @Keep
        public long mTriggerTimeout;
        @Keep
        public String mTriggeredEventName;
        @Keep
        public Bundle mTriggeredEventParams;
        @Keep
        public long mTriggeredTimestamp;
        @Keep
        public Object mValue;

        public ConditionalUserProperty() {
        }

        public final Bundle a() {
            Bundle bundle = new Bundle();
            String str = this.mAppId;
            if (str != null) {
                bundle.putString("app_id", str);
            }
            String str2 = this.mOrigin;
            if (str2 != null) {
                bundle.putString("origin", str2);
            }
            String str3 = this.mName;
            if (str3 != null) {
                bundle.putString("name", str3);
            }
            Object obj = this.mValue;
            if (obj != null) {
                ww0.i1(bundle, obj);
            }
            String str4 = this.mTriggerEventName;
            if (str4 != null) {
                bundle.putString("trigger_event_name", str4);
            }
            bundle.putLong("trigger_timeout", this.mTriggerTimeout);
            String str5 = this.mTimedOutEventName;
            if (str5 != null) {
                bundle.putString("timed_out_event_name", str5);
            }
            Bundle bundle2 = this.mTimedOutEventParams;
            if (bundle2 != null) {
                bundle.putBundle("timed_out_event_params", bundle2);
            }
            String str6 = this.mTriggeredEventName;
            if (str6 != null) {
                bundle.putString("triggered_event_name", str6);
            }
            Bundle bundle3 = this.mTriggeredEventParams;
            if (bundle3 != null) {
                bundle.putBundle("triggered_event_params", bundle3);
            }
            bundle.putLong("time_to_live", this.mTimeToLive);
            String str7 = this.mExpiredEventName;
            if (str7 != null) {
                bundle.putString("expired_event_name", str7);
            }
            Bundle bundle4 = this.mExpiredEventParams;
            if (bundle4 != null) {
                bundle.putBundle("expired_event_params", bundle4);
            }
            bundle.putLong("creation_timestamp", this.mCreationTimestamp);
            bundle.putBoolean("active", this.mActive);
            bundle.putLong("triggered_timestamp", this.mTriggeredTimestamp);
            return bundle;
        }

        public ConditionalUserProperty(Bundle bundle) {
            Objects.requireNonNull(bundle, "null reference");
            this.mAppId = (String) ww0.V0(bundle, "app_id", String.class, null);
            this.mOrigin = (String) ww0.V0(bundle, "origin", String.class, null);
            this.mName = (String) ww0.V0(bundle, "name", String.class, null);
            this.mValue = ww0.V0(bundle, "value", Object.class, null);
            this.mTriggerEventName = (String) ww0.V0(bundle, "trigger_event_name", String.class, null);
            this.mTriggerTimeout = ((Long) ww0.V0(bundle, "trigger_timeout", Long.class, 0L)).longValue();
            this.mTimedOutEventName = (String) ww0.V0(bundle, "timed_out_event_name", String.class, null);
            this.mTimedOutEventParams = (Bundle) ww0.V0(bundle, "timed_out_event_params", Bundle.class, null);
            this.mTriggeredEventName = (String) ww0.V0(bundle, "triggered_event_name", String.class, null);
            this.mTriggeredEventParams = (Bundle) ww0.V0(bundle, "triggered_event_params", Bundle.class, null);
            this.mTimeToLive = ((Long) ww0.V0(bundle, "time_to_live", Long.class, 0L)).longValue();
            this.mExpiredEventName = (String) ww0.V0(bundle, "expired_event_name", String.class, null);
            this.mExpiredEventParams = (Bundle) ww0.V0(bundle, "expired_event_params", Bundle.class, null);
            this.mActive = ((Boolean) ww0.V0(bundle, "active", Boolean.class, Boolean.FALSE)).booleanValue();
            this.mCreationTimestamp = ((Long) ww0.V0(bundle, "creation_timestamp", Long.class, 0L)).longValue();
            this.mTriggeredTimestamp = ((Long) ww0.V0(bundle, "triggered_timestamp", Long.class, 0L)).longValue();
        }
    }

    public AppMeasurement(yi2 yi2) {
        Objects.requireNonNull(yi2, "null reference");
        this.a = yi2;
        this.b = null;
        this.c = false;
    }

    @Keep
    @Deprecated
    public static AppMeasurement getInstance(Context context) {
        fl2 fl2;
        if (d == null) {
            synchronized (AppMeasurement.class) {
                if (d == null) {
                    try {
                        fl2 = (fl2) Class.forName("com.google.firebase.analytics.FirebaseAnalytics").getDeclaredMethod("getScionFrontendApiImplementation", Context.class, Bundle.class).invoke(null, context, null);
                    } catch (ClassNotFoundException unused) {
                        fl2 = null;
                    }
                    if (fl2 != null) {
                        d = new AppMeasurement(fl2);
                    } else {
                        d = new AppMeasurement(yi2.c(context, new yo1(0, 0, true, null, null, null, null), null));
                    }
                }
            }
        }
        return d;
    }

    @Keep
    public void beginAdUnitExposure(String str) {
        if (this.c) {
            this.b.zza(str);
            return;
        }
        cd2 y = this.a.y();
        Objects.requireNonNull((g21) this.a.n);
        y.t(str, SystemClock.elapsedRealtime());
    }

    @Keep
    public void clearConditionalUserProperty(String str, String str2, Bundle bundle) {
        if (this.c) {
            this.b.f(str, str2, bundle);
        } else {
            this.a.q().P(str, str2, bundle);
        }
    }

    @Keep
    public void endAdUnitExposure(String str) {
        if (this.c) {
            this.b.d(str);
            return;
        }
        cd2 y = this.a.y();
        Objects.requireNonNull((g21) this.a.n);
        y.w(str, SystemClock.elapsedRealtime());
    }

    @Keep
    public long generateEventId() {
        if (this.c) {
            return this.b.zze();
        }
        return this.a.r().r0();
    }

    @Keep
    public String getAppInstanceId() {
        if (this.c) {
            return this.b.zzc();
        }
        return this.a.q().g.get();
    }

    @Keep
    public List<ConditionalUserProperty> getConditionalUserProperties(String str, String str2) {
        List<Bundle> list;
        int i = 0;
        if (this.c) {
            list = this.b.b(str, str2);
        } else {
            gk2 q = this.a.q();
            if (q.a().w()) {
                q.d().f.a("Cannot get conditional user properties from analytics worker thread");
                list = new ArrayList<>(0);
            } else if (mo2.a()) {
                q.d().f.a("Cannot get conditional user properties from main thread");
                list = new ArrayList<>(0);
            } else {
                AtomicReference atomicReference = new AtomicReference();
                q.a.a().q(atomicReference, 5000, "get conditional user properties", new sk2(q, atomicReference, str, str2));
                List list2 = (List) atomicReference.get();
                if (list2 == null) {
                    q.d().f.b("Timed out waiting for get conditional user properties", null);
                    list = new ArrayList<>();
                } else {
                    list = yn2.h0(list2);
                }
            }
        }
        if (list != null) {
            i = list.size();
        }
        ArrayList arrayList = new ArrayList(i);
        for (Bundle bundle : list) {
            arrayList.add(new ConditionalUserProperty(bundle));
        }
        return arrayList;
    }

    @Keep
    public String getCurrentScreenClass() {
        if (this.c) {
            return this.b.zzb();
        }
        ml2 ml2 = this.a.q().a.u().c;
        if (ml2 != null) {
            return ml2.b;
        }
        return null;
    }

    @Keep
    public String getCurrentScreenName() {
        if (this.c) {
            return this.b.zza();
        }
        ml2 ml2 = this.a.q().a.u().c;
        if (ml2 != null) {
            return ml2.a;
        }
        return null;
    }

    @Keep
    public String getGmpAppId() {
        if (this.c) {
            return this.b.zzd();
        }
        return this.a.q().M();
    }

    @Keep
    public int getMaxUserProperties(String str) {
        if (this.c) {
            return this.b.a(str);
        }
        this.a.q();
        ww0.i(str);
        return 25;
    }

    @Keep
    public Map<String, Object> getUserProperties(String str, String str2, boolean z) {
        if (this.c) {
            return this.b.e(str, str2, z);
        }
        gk2 q = this.a.q();
        if (q.a().w()) {
            q.d().f.a("Cannot get user properties from analytics worker thread");
            return Collections.emptyMap();
        } else if (mo2.a()) {
            q.d().f.a("Cannot get user properties from main thread");
            return Collections.emptyMap();
        } else {
            AtomicReference atomicReference = new AtomicReference();
            q.a.a().q(atomicReference, 5000, "get user properties", new vk2(q, atomicReference, str, str2, z));
            List<xn2> list = (List) atomicReference.get();
            if (list == null) {
                q.d().f.b("Timed out waiting for handle get user properties, includeInternal", Boolean.valueOf(z));
                return Collections.emptyMap();
            }
            mg mgVar = new mg(list.size());
            for (xn2 xn2 : list) {
                mgVar.put(xn2.h, xn2.r());
            }
            return mgVar;
        }
    }

    @Keep
    public void logEventInternal(String str, String str2, Bundle bundle) {
        if (this.c) {
            this.b.g(str, str2, bundle);
        } else {
            this.a.q().F(str, str2, bundle);
        }
    }

    @Keep
    public void setConditionalUserProperty(ConditionalUserProperty conditionalUserProperty) {
        Objects.requireNonNull(conditionalUserProperty, "null reference");
        if (this.c) {
            this.b.c(conditionalUserProperty.a());
            return;
        }
        gk2 q = this.a.q();
        Bundle a2 = conditionalUserProperty.a();
        Objects.requireNonNull((g21) q.a.n);
        q.w(a2, System.currentTimeMillis());
    }

    public AppMeasurement(fl2 fl2) {
        Objects.requireNonNull(fl2, "null reference");
        this.b = fl2;
        this.a = null;
        this.c = true;
    }
}
