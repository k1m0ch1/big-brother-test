package com.google.android.gms.dynamic;

/* compiled from: com.google.android.gms:play-services-basement@@17.2.1 */
public class RemoteCreator$RemoteCreatorException extends Exception {
}
