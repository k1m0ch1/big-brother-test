package com.google.android.gms.auth;

public class UserRecoverableAuthException extends GoogleAuthException {
}
