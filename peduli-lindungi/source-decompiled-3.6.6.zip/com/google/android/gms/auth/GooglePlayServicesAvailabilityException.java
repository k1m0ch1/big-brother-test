package com.google.android.gms.auth;

public class GooglePlayServicesAvailabilityException extends UserRecoverableAuthException {
}
