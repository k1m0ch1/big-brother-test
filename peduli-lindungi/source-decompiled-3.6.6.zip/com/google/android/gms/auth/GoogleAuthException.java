package com.google.android.gms.auth;

public class GoogleAuthException extends Exception {
}
