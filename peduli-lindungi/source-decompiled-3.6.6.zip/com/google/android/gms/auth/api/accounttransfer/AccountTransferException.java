package com.google.android.gms.auth.api.accounttransfer;

import com.google.android.gms.common.api.ApiException;

public class AccountTransferException extends ApiException {
}
