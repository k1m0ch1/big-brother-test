package com.google.android.gms.auth.api.signin;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

/* compiled from: com.google.android.gms:play-services-base@@17.1.0 */
public class GoogleSignInAccount extends y01 implements ReflectedParcelable {
    public static final Parcelable.Creator<GoogleSignInAccount> CREATOR = new vw0();
    public final int g;
    public String h;
    public String i;
    public String j;
    public String k;
    public Uri l;
    public String m;
    public long n;
    public String o;
    public List<Scope> p;
    public String q;
    public String r;
    public Set<Scope> s = new HashSet();

    public GoogleSignInAccount(int i2, String str, String str2, String str3, String str4, Uri uri, String str5, long j2, String str6, List<Scope> list, String str7, String str8) {
        this.g = i2;
        this.h = str;
        this.i = str2;
        this.j = str3;
        this.k = str4;
        this.l = uri;
        this.m = str5;
        this.n = j2;
        this.o = str6;
        this.p = list;
        this.q = str7;
        this.r = str8;
    }

    public static GoogleSignInAccount y(String str) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        JSONObject jSONObject = new JSONObject(str);
        String optString = jSONObject.optString("photoUrl", null);
        Uri parse = !TextUtils.isEmpty(optString) ? Uri.parse(optString) : null;
        long parseLong = Long.parseLong(jSONObject.getString("expirationTime"));
        HashSet hashSet = new HashSet();
        JSONArray jSONArray = jSONObject.getJSONArray("grantedScopes");
        int length = jSONArray.length();
        for (int i2 = 0; i2 < length; i2++) {
            hashSet.add(new Scope(jSONArray.getString(i2)));
        }
        String optString2 = jSONObject.optString("id");
        String optString3 = jSONObject.optString("tokenId", null);
        String optString4 = jSONObject.optString("email", null);
        String optString5 = jSONObject.optString("displayName", null);
        String optString6 = jSONObject.optString("givenName", null);
        String optString7 = jSONObject.optString("familyName", null);
        Long valueOf = Long.valueOf(parseLong);
        String string = jSONObject.getString("obfuscatedIdentifier");
        if (valueOf == null) {
            valueOf = Long.valueOf(System.currentTimeMillis() / 1000);
        }
        long longValue = valueOf.longValue();
        ww0.i(string);
        GoogleSignInAccount googleSignInAccount = new GoogleSignInAccount(3, optString2, optString3, optString4, optString5, parse, null, longValue, string, new ArrayList(hashSet), optString6, optString7);
        googleSignInAccount.m = jSONObject.optString("serverAuthCode", null);
        return googleSignInAccount;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof GoogleSignInAccount)) {
            return false;
        }
        GoogleSignInAccount googleSignInAccount = (GoogleSignInAccount) obj;
        return googleSignInAccount.o.equals(this.o) && googleSignInAccount.r().equals(r());
    }

    public int hashCode() {
        return r().hashCode() + ze0.f0(this.o, 527, 31);
    }

    public Set<Scope> r() {
        HashSet hashSet = new HashSet(this.p);
        hashSet.addAll(this.s);
        return hashSet;
    }

    public void writeToParcel(Parcel parcel, int i2) {
        int D0 = ww0.D0(parcel, 20293);
        int i3 = this.g;
        ww0.J1(parcel, 1, 4);
        parcel.writeInt(i3);
        ww0.m0(parcel, 2, this.h, false);
        ww0.m0(parcel, 3, this.i, false);
        ww0.m0(parcel, 4, this.j, false);
        ww0.m0(parcel, 5, this.k, false);
        ww0.l0(parcel, 6, this.l, i2, false);
        ww0.m0(parcel, 7, this.m, false);
        long j2 = this.n;
        ww0.J1(parcel, 8, 8);
        parcel.writeLong(j2);
        ww0.m0(parcel, 9, this.o, false);
        ww0.p0(parcel, 10, this.p, false);
        ww0.m0(parcel, 11, this.q, false);
        ww0.m0(parcel, 12, this.r, false);
        ww0.I1(parcel, D0);
    }
}
