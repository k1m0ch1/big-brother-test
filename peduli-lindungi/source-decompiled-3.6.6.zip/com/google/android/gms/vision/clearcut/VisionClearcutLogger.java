package com.google.android.gms.vision.clearcut;

import android.content.Context;
import android.util.Log;
import androidx.annotation.Keep;
import com.google.android.gms.internal.vision.zzhl;
import defpackage.q32;
import defpackage.xw0;
import java.io.IOException;
import java.util.Objects;
import java.util.logging.Logger;

@Keep
/* compiled from: com.google.android.gms:play-services-vision-common@@19.1.2 */
public class VisionClearcutLogger {
    private final xw0 zzcd;
    private boolean zzce = true;

    public VisionClearcutLogger(Context context) {
        this.zzcd = new xw0(context, "VISION", null, false, new r81(context), g21.a, new fb1(context));
    }

    public final void zzb(int i, q32 q32) {
        Objects.requireNonNull(q32);
        try {
            int c = q32.c();
            byte[] bArr = new byte[c];
            Logger logger = zzhl.b;
            zzhl.a aVar = new zzhl.a(bArr, c);
            q32.g(aVar);
            if (aVar.G() != 0) {
                throw new IllegalStateException("Did not write as much data as expected.");
            } else if (i < 0 || i > 3) {
                Object[] objArr = {Integer.valueOf(i)};
                if (Log.isLoggable("Vision", 4)) {
                    Log.i("Vision", String.format("Illegal event code: %d", objArr));
                }
            } else {
                try {
                    if (this.zzce) {
                        xw0 xw0 = this.zzcd;
                        Objects.requireNonNull(xw0);
                        xw0.a aVar2 = new xw0.a(bArr, null);
                        aVar2.e.k = i;
                        aVar2.a();
                        return;
                    }
                    q32.a m = q32.m();
                    try {
                        w42 w42 = w42.c;
                        if (w42 == null) {
                            synchronized (w42.class) {
                                w42 = w42.c;
                                if (w42 == null) {
                                    w42 = k52.a(w42.class);
                                    w42.c = w42;
                                }
                            }
                        }
                        m.h(bArr, 0, c, w42);
                        Object[] objArr2 = {m.toString()};
                        if (Log.isLoggable("Vision", 6)) {
                            Log.e("Vision", String.format("Would have logged:\n%s", objArr2));
                        }
                    } catch (Exception e) {
                        ww0.B(e, "Parsing error", new Object[0]);
                    }
                } catch (Exception e2) {
                    v22.a.a(e2);
                    ww0.B(e2, "Failed to log", new Object[0]);
                }
            }
        } catch (IOException e3) {
            String name = q32.class.getName();
            StringBuilder I0 = ze0.I0(name.length() + 62 + 10, "Serializing ", name, " to a ", "byte array");
            I0.append(" threw an IOException (should never happen).");
            throw new RuntimeException(I0.toString(), e3);
        }
    }
}
