package com.google.android.gms.vision.clearcut;

import android.os.Bundle;
import androidx.annotation.Keep;
import defpackage.rx0;

@Keep
/* compiled from: com.google.android.gms:play-services-vision-common@@19.1.2 */
public class LoggingConnectionCallbacks implements rx0.a, rx0.b {
    @Override // defpackage.by0
    public void onConnected(Bundle bundle) {
        throw new NoSuchMethodError();
    }

    @Override // defpackage.hy0
    public void onConnectionFailed(fx0 fx0) {
        throw new NoSuchMethodError();
    }

    @Override // defpackage.by0
    public void onConnectionSuspended(int i) {
        throw new NoSuchMethodError();
    }
}
