package com.google.android.gms.vision.clearcut;

import android.content.Context;
import android.util.Log;
import androidx.annotation.Keep;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

@Keep
/* compiled from: com.google.android.gms:play-services-vision-common@@19.1.2 */
public class DynamiteClearcutLogger {
    private static final ExecutorService zzbv;
    private ks2 zzbw = new ks2();
    private VisionClearcutLogger zzbx;

    static {
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(2, 2, 60, TimeUnit.SECONDS, new LinkedBlockingQueue(), Executors.defaultThreadFactory());
        threadPoolExecutor.allowCoreThreadTimeOut(true);
        zzbv = Executors.unconfigurableExecutorService(threadPoolExecutor);
    }

    public DynamiteClearcutLogger(Context context) {
        this.zzbx = new VisionClearcutLogger(context);
    }

    public final void zza(int i, q32 q32) {
        boolean z;
        if (i == 3) {
            ks2 ks2 = this.zzbw;
            synchronized (ks2.b) {
                long currentTimeMillis = System.currentTimeMillis();
                if (ks2.c + ks2.a > currentTimeMillis) {
                    z = false;
                } else {
                    ks2.c = currentTimeMillis;
                    z = true;
                }
            }
            if (!z) {
                Object[] objArr = new Object[0];
                if (Log.isLoggable("Vision", 2)) {
                    Log.v("Vision", String.format("Skipping image analysis log due to rate limiting", objArr));
                    return;
                }
                return;
            }
        }
        zzbv.execute(new js2(this, i, q32));
    }
}
