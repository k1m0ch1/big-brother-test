package com.google.android.gms.vision.clearcut;

import android.content.Context;
import android.content.pm.PackageManager;
import androidx.annotation.Keep;
import com.google.android.gms.internal.vision.zzku;
import defpackage.c32;

@Keep
/* compiled from: com.google.android.gms:play-services-vision-common@@19.1.2 */
public class LogUtils {
    public static c32 zza(Context context) {
        c32.a o = c32.o();
        String packageName = context.getPackageName();
        if (o.i) {
            o.j();
            o.i = false;
        }
        c32.m((c32) o.h, packageName);
        String zzb = zzb(context);
        if (zzb != null) {
            if (o.i) {
                o.j();
                o.i = false;
            }
            c32.n((c32) o.h, zzb);
        }
        l52 l52 = (l52) o.k();
        if (l52.isInitialized()) {
            return (c32) l52;
        }
        throw new zzku();
    }

    private static String zzb(Context context) {
        try {
            return q21.a(context).b(context.getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            ww0.B(e, "Unable to find calling package info for %s", context.getPackageName());
            return null;
        }
    }
}
