package com.google.android.gms.vision.face.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import com.github.mikephil.charting.utils.Utils;
import com.google.android.apps.common.proguard.UsedByNative;

@UsedByNative("wrapper.cc")
/* compiled from: com.google.android.gms:play-services-vision@@20.1.2 */
public class FaceParcel extends y01 {
    public static final Parcelable.Creator<FaceParcel> CREATOR = new ns2();
    public final int g;
    public final int h;
    public final float i;
    public final float j;
    public final float k;
    public final float l;
    public final float m;
    public final float n;
    public final float o;
    public final LandmarkParcel[] p;
    public final float q;
    public final float r;
    public final float s;
    public final ls2[] t;
    public final float u;

    public FaceParcel(int i2, int i3, float f, float f2, float f3, float f4, float f5, float f6, float f7, LandmarkParcel[] landmarkParcelArr, float f8, float f9, float f10, ls2[] ls2Arr, float f11) {
        this.g = i2;
        this.h = i3;
        this.i = f;
        this.j = f2;
        this.k = f3;
        this.l = f4;
        this.m = f5;
        this.n = f6;
        this.o = f7;
        this.p = landmarkParcelArr;
        this.q = f8;
        this.r = f9;
        this.s = f10;
        this.t = ls2Arr;
        this.u = f11;
    }

    public void writeToParcel(Parcel parcel, int i2) {
        int D0 = ww0.D0(parcel, 20293);
        int i3 = this.g;
        ww0.J1(parcel, 1, 4);
        parcel.writeInt(i3);
        int i4 = this.h;
        ww0.J1(parcel, 2, 4);
        parcel.writeInt(i4);
        float f = this.i;
        ww0.J1(parcel, 3, 4);
        parcel.writeFloat(f);
        float f2 = this.j;
        ww0.J1(parcel, 4, 4);
        parcel.writeFloat(f2);
        float f3 = this.k;
        ww0.J1(parcel, 5, 4);
        parcel.writeFloat(f3);
        float f4 = this.l;
        ww0.J1(parcel, 6, 4);
        parcel.writeFloat(f4);
        float f5 = this.m;
        ww0.J1(parcel, 7, 4);
        parcel.writeFloat(f5);
        float f6 = this.n;
        ww0.J1(parcel, 8, 4);
        parcel.writeFloat(f6);
        ww0.o0(parcel, 9, this.p, i2, false);
        float f7 = this.q;
        ww0.J1(parcel, 10, 4);
        parcel.writeFloat(f7);
        float f8 = this.r;
        ww0.J1(parcel, 11, 4);
        parcel.writeFloat(f8);
        float f9 = this.s;
        ww0.J1(parcel, 12, 4);
        parcel.writeFloat(f9);
        ww0.o0(parcel, 13, this.t, i2, false);
        float f10 = this.o;
        ww0.J1(parcel, 14, 4);
        parcel.writeFloat(f10);
        float f11 = this.u;
        ww0.J1(parcel, 15, 4);
        parcel.writeFloat(f11);
        ww0.I1(parcel, D0);
    }

    @UsedByNative("wrapper.cc")
    public FaceParcel(int i2, int i3, float f, float f2, float f3, float f4, float f5, float f6, LandmarkParcel[] landmarkParcelArr, float f7, float f8, float f9) {
        this(i2, i3, f, f2, f3, f4, f5, f6, Utils.FLOAT_EPSILON, landmarkParcelArr, f7, f8, f9, new ls2[0], -1.0f);
    }
}
