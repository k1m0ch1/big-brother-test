package com.google.android.gms.vision.face.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.apps.common.proguard.UsedByNative;

@UsedByNative("wrapper.cc")
/* compiled from: com.google.android.gms:play-services-vision@@20.1.2 */
public final class LandmarkParcel extends y01 {
    public static final Parcelable.Creator<LandmarkParcel> CREATOR = new os2();
    public final int g;
    public final float h;
    public final float i;
    public final int j;

    @UsedByNative("wrapper.cc")
    public LandmarkParcel(int i2, float f, float f2, int i3) {
        this.g = i2;
        this.h = f;
        this.i = f2;
        this.j = i3;
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        int D0 = ww0.D0(parcel, 20293);
        int i3 = this.g;
        ww0.J1(parcel, 1, 4);
        parcel.writeInt(i3);
        float f = this.h;
        ww0.J1(parcel, 2, 4);
        parcel.writeFloat(f);
        float f2 = this.i;
        ww0.J1(parcel, 3, 4);
        parcel.writeFloat(f2);
        int i4 = this.j;
        ww0.J1(parcel, 4, 4);
        parcel.writeInt(i4);
        ww0.I1(parcel, D0);
    }
}
