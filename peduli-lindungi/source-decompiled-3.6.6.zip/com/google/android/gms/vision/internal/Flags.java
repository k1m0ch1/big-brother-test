package com.google.android.gms.vision.internal;

import androidx.annotation.Keep;
import defpackage.c41;

@Keep
/* compiled from: com.google.android.gms:play-services-vision-common@@19.1.2 */
public class Flags {
    private static final c41<Boolean> zzdr = new c41.a(0, "vision:product_barcode_value_logging_enabled", Boolean.TRUE);

    private Flags() {
    }
}
