package com.google.android.datatransport.runtime.scheduling.jobscheduling;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.util.Base64;
import defpackage.ft0;
import defpackage.mt0;

public class JobInfoSchedulerService extends JobService {
    public static final /* synthetic */ int g = 0;

    public boolean onStartJob(JobParameters jobParameters) {
        String string = jobParameters.getExtras().getString("backendName");
        String string2 = jobParameters.getExtras().getString("extras");
        int i = jobParameters.getExtras().getInt("priority");
        int i2 = jobParameters.getExtras().getInt("attemptNumber");
        rt0.c(getApplicationContext());
        mt0.a a = mt0.a();
        a.b(string);
        a.c(ow0.b(i));
        if (string2 != null) {
            ((ft0.b) a).b = Base64.decode(string2, 0);
        }
        av0 av0 = rt0.a().d;
        av0.e.execute(new vu0(av0, a.a(), i2, new tu0(this, jobParameters)));
        return true;
    }

    public boolean onStopJob(JobParameters jobParameters) {
        return true;
    }
}
