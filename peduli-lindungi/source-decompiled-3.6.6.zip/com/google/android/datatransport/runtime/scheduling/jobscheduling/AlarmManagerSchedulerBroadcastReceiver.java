package com.google.android.datatransport.runtime.scheduling.jobscheduling;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Base64;
import defpackage.ft0;
import defpackage.mt0;

public class AlarmManagerSchedulerBroadcastReceiver extends BroadcastReceiver {
    public static final /* synthetic */ int a = 0;

    public void onReceive(Context context, Intent intent) {
        String queryParameter = intent.getData().getQueryParameter("backendName");
        String queryParameter2 = intent.getData().getQueryParameter("extras");
        int intValue = Integer.valueOf(intent.getData().getQueryParameter("priority")).intValue();
        int i = intent.getExtras().getInt("attemptNumber");
        rt0.c(context);
        mt0.a a2 = mt0.a();
        a2.b(queryParameter);
        a2.c(ow0.b(intValue));
        if (queryParameter2 != null) {
            ((ft0.b) a2).b = Base64.decode(queryParameter2, 0);
        }
        av0 av0 = rt0.a().d;
        av0.e.execute(new vu0(av0, a2.a(), i, pu0.g));
    }
}
