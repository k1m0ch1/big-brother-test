package com.google.android.datatransport.runtime.synchronization;

public class SynchronizationException extends RuntimeException {
    public SynchronizationException(String str, Throwable th) {
        super(str, th);
    }
}
