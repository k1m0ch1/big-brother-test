package com.google.android.datatransport.cct;

import androidx.annotation.Keep;

@Keep
public class CctBackendFactory implements xt0 {
    @Override // defpackage.xt0
    public gu0 create(bu0 bu0) {
        return new dt0(bu0.a(), bu0.d(), bu0.c());
    }
}
