package com.afollestad.date.view;

import android.content.Context;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.telkom.tracencare.R;
import kotlin.Metadata;
import kotlin.TypeCastException;

@Metadata(bv = {1, 0, 3}, d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0000\u0018\u00002\u00020\u0001B\u0019\u0012\u0006\u0010\u0017\u001a\u00020\u0016\u0012\b\u0010\u0019\u001a\u0004\u0018\u00010\u0018¢\u0006\u0004\b\u001a\u0010\u001bJ\u000f\u0010\u0003\u001a\u00020\u0002H\u0014¢\u0006\u0004\b\u0003\u0010\u0004J\u001f\u0010\b\u001a\u00020\u00022\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\u0005H\u0014¢\u0006\u0004\b\b\u0010\tJ\u0017\u0010\f\u001a\u00020\u00022\u0006\u0010\u000b\u001a\u00020\nH\u0016¢\u0006\u0004\b\f\u0010\rR\u0016\u0010\u0011\u001a\u00020\u000e8\u0002@\u0002X\u0004¢\u0006\u0006\n\u0004\b\u000f\u0010\u0010R\u0016\u0010\u0015\u001a\u00020\u00128\u0002@\u0002X.¢\u0006\u0006\n\u0004\b\u0013\u0010\u0014¨\u0006\u001c"}, d2 = {"Lcom/afollestad/date/view/DayOfMonthRootView;", "Landroid/widget/FrameLayout;", "", "onFinishInflate", "()V", "", "widthMeasureSpec", "heightMeasureSpec", "onMeasure", "(II)V", "", "enabled", "setEnabled", "(Z)V", "", "g", "F", "ratio", "Landroid/widget/TextView;", "h", "Landroid/widget/TextView;", "textView", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "com.afollestad.date-picker"}, k = 1, mv = {1, 4, 0})
/* compiled from: DayOfMonthRootView.kt */
public final class DayOfMonthRootView extends FrameLayout {
    public final float g;
    public TextView h;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DayOfMonthRootView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        a56.f(context, "context");
        a56.f(context, "$this$getFloat");
        TypedValue typedValue = new TypedValue();
        context.getResources().getValue(R.dimen.day_of_month_height_ratio, typedValue, true);
        this.g = typedValue.getFloat();
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        View childAt = getChildAt(0);
        if (childAt != null) {
            this.h = (TextView) childAt;
            return;
        }
        throw new TypeCastException("null cannot be cast to non-null type android.widget.TextView");
    }

    public void onMeasure(int i, int i2) {
        int size = View.MeasureSpec.getSize(i);
        int i3 = (int) (((float) size) * this.g);
        setMeasuredDimension(size, i3);
        TextView textView = this.h;
        if (textView != null) {
            textView.measure(View.MeasureSpec.makeMeasureSpec(i3, 1073741824), View.MeasureSpec.makeMeasureSpec(i3, 1073741824));
        } else {
            a56.l("textView");
            throw null;
        }
    }

    public void setEnabled(boolean z) {
        super.setEnabled(z);
        TextView textView = this.h;
        if (textView != null) {
            textView.setEnabled(z);
        } else {
            a56.l("textView");
            throw null;
        }
    }
}
