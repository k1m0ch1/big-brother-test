package com.afollestad.date;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.telkom.tracencare.R;
import defpackage.ey;
import defpackage.h;
import defpackage.h70;
import java.util.Calendar;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Objects;
import kotlin.Metadata;
import kotlin.TypeCastException;
import kotlin.Unit;

@Metadata(bv = {1, 0, 3}, d1 = {"\u0000v\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u0019\u0012\u0006\u0010A\u001a\u00020@\u0012\b\u0010C\u001a\u0004\u0018\u00010B¢\u0006\u0004\bD\u0010EJ\u0011\u0010\u0003\u001a\u0004\u0018\u00010\u0002H\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u000f\u0010\u0005\u001a\u0004\u0018\u00010\u0002¢\u0006\u0004\b\u0005\u0010\u0004J\u0015\u0010\b\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u0002¢\u0006\u0004\b\b\u0010\tJ\u000f\u0010\n\u001a\u0004\u0018\u00010\u0002¢\u0006\u0004\b\n\u0010\u0004J\u0015\u0010\u000b\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u0002¢\u0006\u0004\b\u000b\u0010\tJ\u000f\u0010\f\u001a\u00020\u0007H\u0014¢\u0006\u0004\b\f\u0010\rJ\u0011\u0010\u000f\u001a\u0004\u0018\u00010\u000eH\u0014¢\u0006\u0004\b\u000f\u0010\u0010J\u0019\u0010\u0012\u001a\u00020\u00072\b\u0010\u0011\u001a\u0004\u0018\u00010\u000eH\u0014¢\u0006\u0004\b\u0012\u0010\u0013J\u000f\u0010\u0014\u001a\u00020\u0007H\u0014¢\u0006\u0004\b\u0014\u0010\rJ\u001f\u0010\u0018\u001a\u00020\u00072\u0006\u0010\u0016\u001a\u00020\u00152\u0006\u0010\u0017\u001a\u00020\u0015H\u0014¢\u0006\u0004\b\u0018\u0010\u0019J7\u0010 \u001a\u00020\u00072\u0006\u0010\u001b\u001a\u00020\u001a2\u0006\u0010\u001c\u001a\u00020\u00152\u0006\u0010\u001d\u001a\u00020\u00152\u0006\u0010\u001e\u001a\u00020\u00152\u0006\u0010\u001f\u001a\u00020\u0015H\u0014¢\u0006\u0004\b \u0010!R\u0016\u0010%\u001a\u00020\"8\u0002@\u0002X\u0004¢\u0006\u0006\n\u0004\b#\u0010$R\u0016\u0010)\u001a\u00020&8\u0002@\u0002X\u0004¢\u0006\u0006\n\u0004\b'\u0010(R\u0016\u0010,\u001a\u00020*8\u0002@\u0002X\u0004¢\u0006\u0006\n\u0004\b&\u0010+R\u0016\u00100\u001a\u00020-8\u0002@\u0002X\u0004¢\u0006\u0006\n\u0004\b.\u0010/R\u0016\u00104\u001a\u0002018\u0002@\u0002X\u0004¢\u0006\u0006\n\u0004\b2\u00103R\u001c\u0010:\u001a\u0002058\u0000@\u0000X\u0004¢\u0006\f\n\u0004\b6\u00107\u001a\u0004\b8\u00109R\u001c\u0010?\u001a\u00020;8\u0000@\u0000X\u0004¢\u0006\f\n\u0004\b-\u0010<\u001a\u0004\b=\u0010>¨\u0006F"}, d2 = {"Lcom/afollestad/date/DatePicker;", "Landroid/view/ViewGroup;", "Ljava/util/Calendar;", "getDate", "()Ljava/util/Calendar;", "getMinDate", "calendar", "", "setMinDate", "(Ljava/util/Calendar;)V", "getMaxDate", "setMaxDate", "onAttachedToWindow", "()V", "Landroid/os/Parcelable;", "onSaveInstanceState", "()Landroid/os/Parcelable;", "state", "onRestoreInstanceState", "(Landroid/os/Parcelable;)V", "onFinishInflate", "", "widthMeasureSpec", "heightMeasureSpec", "onMeasure", "(II)V", "", "changed", "left", "top", "right", "bottom", "onLayout", "(ZIIII)V", "Lt60;", "l", "Lt60;", "monthAdapter", "Lj;", "m", "Lj;", "monthItemRenderer", "Lu60;", "Lu60;", "monthItemAdapter", "Lh;", "i", "Lh;", "layoutManager", "Lx60;", "k", "Lx60;", "yearAdapter", "Lb70;", "g", "Lb70;", "getController$com_afollestad_date_picker", "()Lb70;", "controller", "Lc70;", "Lc70;", "getMinMaxController$com_afollestad_date_picker", "()Lc70;", "minMaxController", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "com.afollestad.date-picker"}, k = 1, mv = {1, 4, 0})
/* compiled from: DatePicker.kt */
public final class DatePicker extends ViewGroup {
    public static final /* synthetic */ int n = 0;
    public final b70 g;
    public final c70 h;
    public final defpackage.h i;
    public final u60 j;
    public final x60 k;
    public final t60 l;
    public final defpackage.j m;

    /* compiled from: kotlin-style lambda group */
    public static final class a extends c56 implements e46<Integer, Unit> {
        public final /* synthetic */ int g;
        public final /* synthetic */ Object h;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(int i, Object obj) {
            super(1);
            this.g = i;
            this.h = obj;
        }

        /* Return type fixed from 'java.lang.Object' to match base method */
        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object] */
        @Override // defpackage.e46
        public final Unit invoke(Integer num) {
            int i;
            int i2 = this.g;
            Integer num2 = null;
            if (i2 == 0) {
                int intValue = num.intValue();
                b70 controller$com_afollestad_date_picker = ((DatePicker) this.h).getController$com_afollestad_date_picker();
                controller$com_afollestad_date_picker.m.invoke();
                k70 k70 = controller$com_afollestad_date_picker.c;
                if (k70 != null) {
                    Calendar b = r60.b(k70, 1);
                    a56.f(b, "$this$month");
                    b.set(2, intValue);
                    controller$com_afollestad_date_picker.d(b);
                    controller$com_afollestad_date_picker.b(b);
                    controller$com_afollestad_date_picker.g.a();
                    return Unit.INSTANCE;
                }
                a56.k();
                throw null;
            } else if (i2 == 1) {
                int intValue2 = num.intValue();
                b70 controller$com_afollestad_date_picker2 = ((DatePicker) this.h).getController$com_afollestad_date_picker();
                k70 k702 = controller$com_afollestad_date_picker2.c;
                if (k702 != null) {
                    i = k702.a;
                } else {
                    j70 j70 = controller$com_afollestad_date_picker2.e;
                    if (j70 != null) {
                        i = j70.a;
                    } else {
                        a56.k();
                        throw null;
                    }
                }
                Integer valueOf = Integer.valueOf(intValue2);
                j70 j702 = controller$com_afollestad_date_picker2.e;
                if (j702 != null) {
                    num2 = Integer.valueOf(j702.b);
                }
                Calendar invoke = controller$com_afollestad_date_picker2.n.invoke();
                if (valueOf != null) {
                    pu.r(invoke, valueOf.intValue());
                }
                pu.q(invoke, i);
                if (num2 != null) {
                    int intValue3 = num2.intValue();
                    a56.f(invoke, "$this$dayOfMonth");
                    invoke.set(5, intValue3);
                }
                controller$com_afollestad_date_picker2.c(invoke, true);
                controller$com_afollestad_date_picker2.m.invoke();
                return Unit.INSTANCE;
            } else {
                throw null;
            }
        }
    }

    /* compiled from: kotlin-style lambda group */
    public static final class b extends c56 implements t36<Typeface> {
        public static final b h = new b(0);
        public static final b i = new b(1);
        public final /* synthetic */ int g;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public b(int i2) {
            super(0);
            this.g = i2;
        }

        /* Return type fixed from 'java.lang.Object' to match base method */
        @Override // defpackage.t36
        public final Typeface invoke() {
            int i2 = this.g;
            if (i2 == 0) {
                q70 q70 = q70.b;
                return q70.a("sans-serif-medium");
            } else if (i2 == 1) {
                q70 q702 = q70.b;
                return q70.a("sans-serif");
            } else {
                throw null;
            }
        }
    }

    /* compiled from: DatePicker.kt */
    public static final /* synthetic */ class c extends y46 implements i46<Calendar, Calendar, Unit> {
        public c(defpackage.h hVar) {
            super(2, hVar);
        }

        @Override // defpackage.r46, defpackage.w66
        public final String getName() {
            return "setHeadersContent";
        }

        @Override // defpackage.r46
        public final z66 getOwner() {
            return s56.a(defpackage.h.class);
        }

        @Override // defpackage.r46
        public final String getSignature() {
            return "setHeadersContent(Ljava/util/Calendar;Ljava/util/Calendar;)V";
        }

        /* Return type fixed from 'java.lang.Object' to match base method */
        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object, java.lang.Object] */
        @Override // defpackage.i46
        public Unit invoke(Calendar calendar, Calendar calendar2) {
            Calendar calendar3 = calendar;
            Calendar calendar4 = calendar2;
            a56.f(calendar3, "p1");
            a56.f(calendar4, "p2");
            defpackage.h hVar = (defpackage.h) this.receiver;
            Objects.requireNonNull(hVar);
            a56.f(calendar3, "currentMonth");
            a56.f(calendar4, "selectedDate");
            TextView textView = hVar.i;
            e70 e70 = hVar.t;
            Objects.requireNonNull(e70);
            a56.f(calendar3, "calendar");
            String format = e70.a.format(calendar3.getTime());
            a56.b(format, "monthAndYearFormatter.format(calendar.time)");
            textView.setText(format);
            TextView textView2 = hVar.f;
            e70 e702 = hVar.t;
            Objects.requireNonNull(e702);
            a56.f(calendar4, "calendar");
            String format2 = e702.b.format(calendar4.getTime());
            a56.b(format2, "yearFormatter.format(calendar.time)");
            textView2.setText(format2);
            TextView textView3 = hVar.g;
            e70 e703 = hVar.t;
            Objects.requireNonNull(e703);
            a56.f(calendar4, "calendar");
            String format3 = e703.c.format(calendar4.getTime());
            a56.b(format3, "dateFormatter.format(calendar.time)");
            textView3.setText(format3);
            return Unit.INSTANCE;
        }
    }

    /* compiled from: DatePicker.kt */
    public static final /* synthetic */ class d extends y46 implements e46<List<? extends h70>, Unit> {
        public d(DatePicker datePicker) {
            super(1, datePicker);
        }

        @Override // defpackage.r46, defpackage.w66
        public final String getName() {
            return "renderMonthItems";
        }

        @Override // defpackage.r46
        public final z66 getOwner() {
            return s56.a(DatePicker.class);
        }

        @Override // defpackage.r46
        public final String getSignature() {
            return "renderMonthItems(Ljava/util/List;)V";
        }

        /* Return type fixed from 'java.lang.Object' to match base method */
        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object] */
        @Override // defpackage.e46
        public Unit invoke(List<? extends h70> list) {
            List<? extends h70> list2 = list;
            a56.f(list2, "p1");
            DatePicker datePicker = (DatePicker) this.receiver;
            int i = DatePicker.n;
            Objects.requireNonNull(datePicker);
            for (T t : list2) {
                if (t instanceof h70.a) {
                    if (t != null) {
                        T t2 = t;
                        datePicker.k.e(Integer.valueOf(t2.b.b));
                        x60 x60 = datePicker.k;
                        Integer num = x60.a;
                        Integer valueOf = num != null ? Integer.valueOf(x60.c(num.intValue())) : null;
                        if (valueOf != null) {
                            datePicker.i.m.k0(valueOf.intValue() - 2);
                        }
                        datePicker.l.c(Integer.valueOf(t2.b.a));
                        Integer num2 = datePicker.l.a;
                        if (num2 != null) {
                            datePicker.i.n.k0(num2.intValue() - 2);
                        }
                        u60 u60 = datePicker.j;
                        List<? extends h70> list3 = u60.a;
                        u60.a = list2;
                        a56.f(u60, "adapter");
                        if (list3 != null) {
                            ey.d a = ey.a(new i70(list3, list2), true);
                            a56.b(a, "DiffUtil.calculateDiff(\n…thNewDays\n        )\n    )");
                            a.a(new yx(u60));
                        } else {
                            u60.notifyDataSetChanged();
                        }
                        return Unit.INSTANCE;
                    }
                    throw new TypeCastException("null cannot be cast to non-null type com.afollestad.date.data.MonthItem.DayOfMonth");
                }
            }
            throw new NoSuchElementException("Collection contains no element matching the predicate.");
        }
    }

    /* compiled from: DatePicker.kt */
    public static final /* synthetic */ class e extends y46 implements e46<Boolean, Unit> {
        public e(defpackage.h hVar) {
            super(1, hVar);
        }

        @Override // defpackage.r46, defpackage.w66
        public final String getName() {
            return "showOrHideGoPrevious";
        }

        @Override // defpackage.r46
        public final z66 getOwner() {
            return s56.a(defpackage.h.class);
        }

        @Override // defpackage.r46
        public final String getSignature() {
            return "showOrHideGoPrevious(Z)V";
        }

        /* Return type fixed from 'java.lang.Object' to match base method */
        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object] */
        @Override // defpackage.e46
        public Unit invoke(Boolean bool) {
            r60.m(((defpackage.h) this.receiver).h, bool.booleanValue());
            return Unit.INSTANCE;
        }
    }

    /* compiled from: DatePicker.kt */
    public static final /* synthetic */ class f extends y46 implements e46<Boolean, Unit> {
        public f(defpackage.h hVar) {
            super(1, hVar);
        }

        @Override // defpackage.r46, defpackage.w66
        public final String getName() {
            return "showOrHideGoNext";
        }

        @Override // defpackage.r46
        public final z66 getOwner() {
            return s56.a(defpackage.h.class);
        }

        @Override // defpackage.r46
        public final String getSignature() {
            return "showOrHideGoNext(Z)V";
        }

        /* Return type fixed from 'java.lang.Object' to match base method */
        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object] */
        @Override // defpackage.e46
        public Unit invoke(Boolean bool) {
            r60.m(((defpackage.h) this.receiver).j, bool.booleanValue());
            return Unit.INSTANCE;
        }
    }

    /* compiled from: DatePicker.kt */
    public static final class g extends c56 implements t36<Unit> {
        public final /* synthetic */ DatePicker g;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public g(DatePicker datePicker) {
            super(0);
            this.g = datePicker;
        }

        /* Return type fixed from 'java.lang.Object' to match base method */
        @Override // defpackage.t36
        public Unit invoke() {
            this.g.i.a(h.c.CALENDAR);
            return Unit.INSTANCE;
        }
    }

    /* compiled from: DatePicker.kt */
    public static final class h extends c56 implements e46<h70.a, Unit> {
        public final /* synthetic */ DatePicker g;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public h(DatePicker datePicker) {
            super(1);
            this.g = datePicker;
        }

        /* Return type fixed from 'java.lang.Object' to match base method */
        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object] */
        @Override // defpackage.e46
        public Unit invoke(h70.a aVar) {
            h70.a aVar2 = aVar;
            a56.f(aVar2, "it");
            b70 controller$com_afollestad_date_picker = this.g.getController$com_afollestad_date_picker();
            int i = aVar2.c;
            if (!controller$com_afollestad_date_picker.a) {
                Calendar invoke = controller$com_afollestad_date_picker.n.invoke();
                pu.p(invoke, i);
                controller$com_afollestad_date_picker.c(invoke, true);
            } else {
                Calendar calendar = controller$com_afollestad_date_picker.f;
                if (calendar == null) {
                    calendar = controller$com_afollestad_date_picker.n.invoke();
                }
                k70 k70 = controller$com_afollestad_date_picker.c;
                if (k70 != null) {
                    Calendar b = r60.b(k70, i);
                    j70 n = r60.n(b);
                    controller$com_afollestad_date_picker.e = n;
                    controller$com_afollestad_date_picker.f = n.a();
                    controller$com_afollestad_date_picker.g.a();
                    controller$com_afollestad_date_picker.a(calendar, new a70(b));
                    controller$com_afollestad_date_picker.b(b);
                } else {
                    a56.k();
                    throw null;
                }
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: DatePicker.kt */
    public static final /* synthetic */ class i extends y46 implements t36<Unit> {
        public i(b70 b70) {
            super(0, b70);
        }

        @Override // defpackage.r46, defpackage.w66
        public final String getName() {
            return "previousMonth";
        }

        @Override // defpackage.r46
        public final z66 getOwner() {
            return s56.a(b70.class);
        }

        @Override // defpackage.r46
        public final String getSignature() {
            return "previousMonth()V";
        }

        /* Return type fixed from 'java.lang.Object' to match base method */
        @Override // defpackage.t36
        public Unit invoke() {
            b70 b70 = (b70) this.receiver;
            b70.m.invoke();
            k70 k70 = b70.c;
            if (k70 != null) {
                Calendar g = pu.g(r60.b(k70, 1));
                b70.d(g);
                b70.b(g);
                b70.g.a();
                return Unit.INSTANCE;
            }
            a56.k();
            throw null;
        }
    }

    /* compiled from: DatePicker.kt */
    public static final /* synthetic */ class j extends y46 implements t36<Unit> {
        public j(b70 b70) {
            super(0, b70);
        }

        @Override // defpackage.r46, defpackage.w66
        public final String getName() {
            return "nextMonth";
        }

        @Override // defpackage.r46
        public final z66 getOwner() {
            return s56.a(b70.class);
        }

        @Override // defpackage.r46
        public final String getSignature() {
            return "nextMonth()V";
        }

        /* Return type fixed from 'java.lang.Object' to match base method */
        @Override // defpackage.t36
        public Unit invoke() {
            b70 b70 = (b70) this.receiver;
            b70.m.invoke();
            k70 k70 = b70.c;
            if (k70 != null) {
                Calendar k = pu.k(r60.b(k70, 1));
                b70.d(k);
                b70.b(k);
                b70.g.a();
                return Unit.INSTANCE;
            }
            a56.k();
            throw null;
        }
    }

    /* JADX INFO: finally extract failed */
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DatePicker(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        a56.f(context, "context");
        c70 c70 = new c70();
        this.h = c70;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, s60.a);
        try {
            a56.b(obtainStyledAttributes, "ta");
            a56.f(context, "context");
            a56.f(obtainStyledAttributes, "typedArray");
            a56.f(this, "container");
            View.inflate(context, R.layout.date_picker, this);
            defpackage.h hVar = new defpackage.h(context, obtainStyledAttributes, this, new d70(context, obtainStyledAttributes));
            this.i = hVar;
            this.g = new b70(new d70(context, obtainStyledAttributes), c70, new c(hVar), new d(this), new e(hVar), new f(hVar), new g(this), null, RecyclerView.b0.FLAG_IGNORE);
            Typeface f2 = r60.f(obtainStyledAttributes, context, 3, b.h);
            Typeface f3 = r60.f(obtainStyledAttributes, context, 4, b.i);
            defpackage.j jVar = new defpackage.j(context, obtainStyledAttributes, f3, c70);
            this.m = jVar;
            obtainStyledAttributes.recycle();
            u60 u60 = new u60(jVar, new h(this));
            this.j = u60;
            x60 x60 = new x60(f3, f2, hVar.a, new a(1, this));
            this.k = x60;
            t60 t60 = new t60(hVar.a, f3, f2, new e70(), new a(0, this));
            this.l = t60;
            a56.f(u60, "monthItemAdapter");
            a56.f(x60, "yearAdapter");
            a56.f(t60, "monthAdapter");
            hVar.l.setAdapter(u60);
            hVar.m.setAdapter(x60);
            hVar.n.setAdapter(t60);
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    public final b70 getController$com_afollestad_date_picker() {
        return this.g;
    }

    public final Calendar getDate() {
        b70 b70 = this.g;
        if (b70.h.b(b70.e) || b70.h.a(b70.e)) {
            return null;
        }
        return b70.f;
    }

    public final Calendar getMaxDate() {
        j70 j70 = this.h.b;
        if (j70 != null) {
            return j70.a();
        }
        return null;
    }

    public final Calendar getMinDate() {
        j70 j70 = this.h.a;
        if (j70 != null) {
            return j70.a();
        }
        return null;
    }

    public final c70 getMinMaxController$com_afollestad_date_picker() {
        return this.h;
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        b70 b70 = this.g;
        if (!b70.a) {
            Calendar invoke = b70.n.invoke();
            j70 n2 = r60.n(invoke);
            if (b70.h.a(n2)) {
                j70 j70 = b70.h.b;
                invoke = j70 != null ? j70.a() : null;
                if (invoke == null) {
                    a56.k();
                    throw null;
                }
            } else if (b70.h.b(n2)) {
                j70 j702 = b70.h.a;
                invoke = j702 != null ? j702.a() : null;
                if (invoke == null) {
                    a56.k();
                    throw null;
                }
            }
            b70.c(invoke, false);
        }
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        defpackage.h hVar = this.i;
        i iVar = new i(this.g);
        j jVar = new j(this.g);
        Objects.requireNonNull(hVar);
        a56.f(iVar, "onGoToPrevious");
        a56.f(jVar, "onGoToNext");
        r60.j(hVar.h, new defpackage.g(0, iVar));
        r60.j(hVar.j, new defpackage.g(1, jVar));
    }

    public void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        int i6;
        int i7;
        defpackage.h hVar = this.i;
        r60.k(hVar.f, i3, 0, 0, 0, 14);
        r60.k(hVar.g, hVar.f.getBottom(), 0, 0, 0, 14);
        h.d dVar = hVar.v;
        h.d dVar2 = h.d.PORTRAIT;
        if (dVar == dVar2) {
            i6 = i2;
        } else {
            i6 = hVar.g.getRight();
        }
        TextView textView = hVar.i;
        int measuredWidth = (i4 - ((i4 - i6) / 2)) - (textView.getMeasuredWidth() / 2);
        if (hVar.v == dVar2) {
            i7 = hVar.g.getBottom() + hVar.o;
        } else {
            i7 = hVar.o;
        }
        r60.k(textView, i7, measuredWidth, 0, 0, 12);
        r60.k(hVar.k, hVar.i.getBottom(), i6, 0, 0, 12);
        r60.k(hVar.l, hVar.k.getBottom(), i6 + hVar.e, 0, 0, 12);
        int bottom = ((hVar.i.getBottom() - (hVar.i.getMeasuredHeight() / 2)) - (hVar.h.getMeasuredHeight() / 2)) + hVar.p;
        r60.k(hVar.h, bottom, hVar.l.getLeft() + hVar.e, 0, 0, 12);
        r60.k(hVar.j, bottom, (hVar.l.getRight() - hVar.j.getMeasuredWidth()) - hVar.e, 0, 0, 12);
        hVar.m.layout(hVar.l.getLeft(), hVar.l.getTop(), hVar.l.getRight(), hVar.l.getBottom());
        hVar.n.layout(hVar.l.getLeft(), hVar.l.getTop(), hVar.l.getRight(), hVar.l.getBottom());
    }

    public void onMeasure(int i2, int i3) {
        int i4;
        int i5;
        int i6;
        int i7;
        defpackage.h hVar = this.i;
        Objects.requireNonNull(hVar);
        h.d dVar = h.d.PORTRAIT;
        int size = View.MeasureSpec.getSize(i2);
        int size2 = View.MeasureSpec.getSize(i3);
        int i8 = size / hVar.s;
        hVar.f.measure(View.MeasureSpec.makeMeasureSpec(i8, 1073741824), View.MeasureSpec.makeMeasureSpec(0, 0));
        TextView textView = hVar.g;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i8, 1073741824);
        if (size2 <= 0 || hVar.v == dVar) {
            i4 = View.MeasureSpec.makeMeasureSpec(0, 0);
        } else {
            i4 = View.MeasureSpec.makeMeasureSpec(size2 - hVar.f.getMeasuredHeight(), 1073741824);
        }
        textView.measure(makeMeasureSpec, i4);
        int i9 = hVar.v == dVar ? size : size - i8;
        hVar.i.measure(View.MeasureSpec.makeMeasureSpec(i9, Integer.MIN_VALUE), View.MeasureSpec.makeMeasureSpec(hVar.q, 1073741824));
        hVar.k.measure(View.MeasureSpec.makeMeasureSpec(i9, 1073741824), View.MeasureSpec.makeMeasureSpec(hVar.r, 1073741824));
        if (hVar.v == dVar) {
            i6 = hVar.i.getMeasuredHeight() + hVar.g.getMeasuredHeight() + hVar.f.getMeasuredHeight();
            i5 = hVar.k.getMeasuredHeight();
        } else {
            i6 = hVar.i.getMeasuredHeight();
            i5 = hVar.k.getMeasuredHeight();
        }
        int i10 = i5 + i6;
        int i11 = i9 - (hVar.e * 2);
        RecyclerView recyclerView = hVar.l;
        int makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i11, 1073741824);
        if (size2 > 0) {
            i7 = View.MeasureSpec.makeMeasureSpec(size2 - i10, Integer.MIN_VALUE);
        } else {
            i7 = View.MeasureSpec.makeMeasureSpec(0, 0);
        }
        recyclerView.measure(makeMeasureSpec2, i7);
        int i12 = i11 / 7;
        hVar.h.measure(View.MeasureSpec.makeMeasureSpec(i12, 1073741824), View.MeasureSpec.makeMeasureSpec(i12, 1073741824));
        hVar.j.measure(View.MeasureSpec.makeMeasureSpec(i12, 1073741824), View.MeasureSpec.makeMeasureSpec(i12, 1073741824));
        hVar.m.measure(View.MeasureSpec.makeMeasureSpec(hVar.l.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(hVar.l.getMeasuredHeight(), 1073741824));
        hVar.n.measure(View.MeasureSpec.makeMeasureSpec(hVar.l.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(hVar.l.getMeasuredHeight(), 1073741824));
        h.e eVar = hVar.u;
        eVar.a = size;
        int measuredHeight = hVar.l.getMeasuredHeight() + i10 + hVar.p + hVar.o;
        eVar.b = measuredHeight;
        setMeasuredDimension(eVar.a, measuredHeight);
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof s70) {
            s70 s70 = (s70) parcelable;
            super.onRestoreInstanceState(s70.getSuperState());
            Calendar calendar = s70.g;
            if (calendar != null) {
                this.g.c(calendar, false);
                return;
            }
            return;
        }
        super.onRestoreInstanceState(parcelable);
    }

    public Parcelable onSaveInstanceState() {
        return new s70(getDate(), super.onSaveInstanceState());
    }

    public final void setMaxDate(Calendar calendar) {
        a56.f(calendar, "calendar");
        c70 c70 = this.h;
        Objects.requireNonNull(c70);
        a56.f(calendar, "date");
        c70.b = r60.n(calendar);
        c70.c();
    }

    public final void setMinDate(Calendar calendar) {
        a56.f(calendar, "calendar");
        c70 c70 = this.h;
        Objects.requireNonNull(c70);
        a56.f(calendar, "date");
        c70.a = r60.n(calendar);
        c70.c();
    }
}
