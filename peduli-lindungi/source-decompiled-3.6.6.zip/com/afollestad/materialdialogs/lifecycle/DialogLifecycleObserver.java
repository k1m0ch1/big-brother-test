package com.afollestad.materialdialogs.lifecycle;

import defpackage.sr;
import kotlin.Metadata;
import kotlin.Unit;

@Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0000\u0018\u00002\u00020\u0001B\u0015\u0012\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00020\u0006¢\u0006\u0004\b\n\u0010\u000bJ\u000f\u0010\u0003\u001a\u00020\u0002H\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u000f\u0010\u0005\u001a\u00020\u0002H\u0007¢\u0006\u0004\b\u0005\u0010\u0004R\u001c\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00020\u00068\u0002@\u0002X\u0004¢\u0006\u0006\n\u0004\b\u0007\u0010\b¨\u0006\f"}, d2 = {"Lcom/afollestad/materialdialogs/lifecycle/DialogLifecycleObserver;", "Lxr;", "", "onDestroy", "()V", "onPause", "Lkotlin/Function0;", "g", "Lt36;", "dismiss", "<init>", "(Lt36;)V", "lifecycle"}, k = 1, mv = {1, 4, 0})
/* compiled from: DialogLifecycleObserver.kt */
public final class DialogLifecycleObserver implements xr {
    public final t36<Unit> g;

    public DialogLifecycleObserver(t36<Unit> t36) {
        a56.f(t36, "dismiss");
        this.g = t36;
    }

    @gs(sr.a.ON_DESTROY)
    public final void onDestroy() {
        this.g.invoke();
    }

    @gs(sr.a.ON_PAUSE)
    public final void onPause() {
        this.g.invoke();
    }
}
