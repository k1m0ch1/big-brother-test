package com.afollestad.materialdialogs.datetime.internal;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.util.Calendar;
import kotlin.Metadata;
import kotlin.Unit;

@Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u001d\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J#\u0010\u0007\u001a\u00020\u00062\b\u0010\u0003\u001a\u0004\u0018\u00010\u00022\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004H\u0016¢\u0006\u0004\b\u0007\u0010\b¨\u0006\t"}, d2 = {"com/afollestad/materialdialogs/datetime/internal/TimeChangeListener$receiver$1", "Landroid/content/BroadcastReceiver;", "Landroid/content/Context;", "context", "Landroid/content/Intent;", "intent", "", "onReceive", "(Landroid/content/Context;Landroid/content/Intent;)V", "datetime"}, k = 1, mv = {1, 4, 0})
/* compiled from: TimeChangeListener.kt */
public final class TimeChangeListener$receiver$1 extends BroadcastReceiver {
    public final /* synthetic */ TimeChangeListener a;

    /* JADX WARN: Incorrect args count in method signature: ()V */
    public TimeChangeListener$receiver$1(TimeChangeListener timeChangeListener) {
        this.a = timeChangeListener;
    }

    public void onReceive(Context context, Intent intent) {
        Calendar instance = Calendar.getInstance();
        int i = instance.get(11);
        int i2 = instance.get(12);
        TimeChangeListener timeChangeListener = this.a;
        T t = timeChangeListener.e;
        if (t == null) {
            return;
        }
        if (timeChangeListener.a != i || timeChangeListener.b != i2) {
            e46<? super T, Unit> e46 = timeChangeListener.f;
            if (e46 != null) {
                e46.invoke(t);
            }
            TimeChangeListener timeChangeListener2 = this.a;
            timeChangeListener2.a = i;
            timeChangeListener2.b = i2;
        }
    }
}
