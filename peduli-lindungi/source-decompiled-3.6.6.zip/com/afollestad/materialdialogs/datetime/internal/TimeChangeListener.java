package com.afollestad.materialdialogs.datetime.internal;

import android.content.Context;
import android.content.IntentFilter;
import kotlin.Unit;

/* compiled from: TimeChangeListener.kt */
public final class TimeChangeListener<T> {
    public int a = -1;
    public int b = -1;
    public final TimeChangeListener$receiver$1 c;
    public Context d;
    public final T e;
    public e46<? super T, Unit> f;

    public TimeChangeListener(Context context, T t, e46<? super T, Unit> e46) {
        this.d = context;
        this.e = t;
        this.f = e46;
        TimeChangeListener$receiver$1 timeChangeListener$receiver$1 = new TimeChangeListener$receiver$1(this);
        this.c = timeChangeListener$receiver$1;
        if (this.d == null) {
            throw new IllegalArgumentException("Required value was null.".toString());
        } else if (t == null) {
            throw new IllegalArgumentException("Required value was null.".toString());
        } else if (this.f != null) {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.intent.action.TIME_TICK");
            intentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
            intentFilter.addAction("android.intent.action.TIME_SET");
            Context context2 = this.d;
            if (context2 != null) {
                context2.registerReceiver(timeChangeListener$receiver$1, intentFilter);
            } else {
                a56.k();
                throw null;
            }
        } else {
            throw new IllegalArgumentException("Required value was null.".toString());
        }
    }
}
