package com.afollestad.materialdialogs.datetime.internal;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import androidx.viewpager.widget.ViewPager;
import kotlin.Metadata;
import kotlin.Unit;

@Metadata(bv = {1, 0, 3}, d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0000\u0018\u00002\u00020\u0001B\u001b\u0012\u0006\u0010\t\u001a\u00020\b\u0012\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\n¢\u0006\u0004\b\f\u0010\rJ\u001f\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0004\u001a\u00020\u0002H\u0014¢\u0006\u0004\b\u0006\u0010\u0007¨\u0006\u000e"}, d2 = {"Lcom/afollestad/materialdialogs/datetime/internal/WrapContentViewPager;", "Landroidx/viewpager/widget/ViewPager;", "", "widthMeasureSpec", "heightMeasureSpec", "", "onMeasure", "(II)V", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "datetime"}, k = 1, mv = {1, 4, 0})
/* compiled from: WrapContentViewPager.kt */
public final class WrapContentViewPager extends ViewPager {

    /* compiled from: WrapContentViewPager.kt */
    public static final class a extends c56 implements e46<View, Unit> {
        public final /* synthetic */ int g;
        public final /* synthetic */ p56 h;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(int i, p56 p56) {
            super(1);
            this.g = i;
            this.h = p56;
        }

        /* Return type fixed from 'java.lang.Object' to match base method */
        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object] */
        @Override // defpackage.e46
        public Unit invoke(View view) {
            View view2 = view;
            a56.f(view2, "child");
            view2.measure(this.g, View.MeasureSpec.makeMeasureSpec(0, 0));
            int measuredHeight = view2.getMeasuredHeight();
            p56 p56 = this.h;
            if (measuredHeight > p56.g) {
                p56.g = measuredHeight;
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WrapContentViewPager(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        a56.f(context, "context");
    }

    @Override // androidx.viewpager.widget.ViewPager
    public void onMeasure(int i, int i2) {
        p56 p56 = new p56();
        p56.g = 0;
        a aVar = new a(i, p56);
        int childCount = getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            a56.b(childAt, "child");
            aVar.invoke(childAt);
        }
        int size = View.MeasureSpec.getSize(i2);
        if (p56.g > size) {
            p56.g = size;
        }
        int i4 = p56.g;
        if (i4 != 0) {
            i2 = View.MeasureSpec.makeMeasureSpec(i4, 1073741824);
        }
        super.onMeasure(i, i2);
    }
}
