package com.afollestad.materialdialogs.internal.message;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.afollestad.materialdialogs.internal.list.DialogRecyclerView;
import com.afollestad.materialdialogs.internal.main.DialogLayout;
import com.afollestad.materialdialogs.internal.main.DialogScrollView;
import com.telkom.tracencare.R;
import kotlin.Lazy;
import kotlin.LazyKt__LazyJVMKt;
import kotlin.Metadata;
import kotlin.TypeCastException;

@Metadata(bv = {1, 0, 3}, d1 = {"\u0000Z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001B\u001b\u0012\u0006\u0010G\u001a\u00020F\u0012\n\b\u0002\u0010I\u001a\u0004\u0018\u00010H¢\u0006\u0004\bJ\u0010KJ;\u0010\n\u001a\u00020\u00042\n\b\u0001\u0010\u0003\u001a\u0004\u0018\u00010\u00022\b\u0010\u0005\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\u0006¢\u0006\u0004\b\n\u0010\u000bJ!\u0010\u000f\u001a\u00020\u000e2\b\b\u0002\u0010\f\u001a\u00020\u00022\b\b\u0002\u0010\r\u001a\u00020\u0002¢\u0006\u0004\b\u000f\u0010\u0010J\u001f\u0010\u0013\u001a\u00020\u000e2\u0006\u0010\u0011\u001a\u00020\u00022\u0006\u0010\u0012\u001a\u00020\u0002H\u0014¢\u0006\u0004\b\u0013\u0010\u0010J7\u0010\u0017\u001a\u00020\u000e2\u0006\u0010\u0014\u001a\u00020\u00062\u0006\u0010\u0015\u001a\u00020\u00022\u0006\u0010\f\u001a\u00020\u00022\u0006\u0010\u0016\u001a\u00020\u00022\u0006\u0010\r\u001a\u00020\u0002H\u0014¢\u0006\u0004\b\u0017\u0010\u0018J\u0017\u0010\u0019\u001a\u00020\u000e2\u0006\u0010\b\u001a\u00020\u0006H\u0002¢\u0006\u0004\b\u0019\u0010\u001aR$\u0010\"\u001a\u0004\u0018\u00010\u001b8\u0006@\u0006X\u000e¢\u0006\u0012\n\u0004\b\u001c\u0010\u001d\u001a\u0004\b\u001e\u0010\u001f\"\u0004\b \u0010!R$\u0010*\u001a\u0004\u0018\u00010#8\u0006@\u0006X\u000e¢\u0006\u0012\n\u0004\b$\u0010%\u001a\u0004\b&\u0010'\"\u0004\b(\u0010)R$\u00101\u001a\u0004\u0018\u00010\u00048\u0006@\u0006X\u000e¢\u0006\u0012\n\u0004\b+\u0010,\u001a\u0004\b-\u0010.\"\u0004\b/\u00100R\u0018\u00105\u001a\u0004\u0018\u0001028\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b3\u00104R\u0018\u00109\u001a\u0004\u0018\u0001068B@\u0002X\u0004¢\u0006\u0006\u001a\u0004\b7\u00108R\u0016\u0010<\u001a\u00020\u00068\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b:\u0010;R\u001d\u0010A\u001a\u00020\u00028B@\u0002X\u0002¢\u0006\f\n\u0004\b=\u0010>\u001a\u0004\b?\u0010@R\u0018\u0010E\u001a\u0004\u0018\u00010B8\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\bC\u0010D¨\u0006L"}, d2 = {"Lcom/afollestad/materialdialogs/internal/message/DialogContentLayout;", "Landroid/widget/FrameLayout;", "", "res", "Landroid/view/View;", "view", "", "scrollable", "noVerticalPadding", "horizontalPadding", "b", "(Ljava/lang/Integer;Landroid/view/View;ZZZ)Landroid/view/View;", "top", "bottom", "", "c", "(II)V", "widthMeasureSpec", "heightMeasureSpec", "onMeasure", "changed", "left", "right", "onLayout", "(ZIIII)V", "a", "(Z)V", "Lcom/afollestad/materialdialogs/internal/main/DialogScrollView;", "k", "Lcom/afollestad/materialdialogs/internal/main/DialogScrollView;", "getScrollView", "()Lcom/afollestad/materialdialogs/internal/main/DialogScrollView;", "setScrollView", "(Lcom/afollestad/materialdialogs/internal/main/DialogScrollView;)V", "scrollView", "Lcom/afollestad/materialdialogs/internal/list/DialogRecyclerView;", "l", "Lcom/afollestad/materialdialogs/internal/list/DialogRecyclerView;", "getRecyclerView", "()Lcom/afollestad/materialdialogs/internal/list/DialogRecyclerView;", "setRecyclerView", "(Lcom/afollestad/materialdialogs/internal/list/DialogRecyclerView;)V", "recyclerView", "m", "Landroid/view/View;", "getCustomView", "()Landroid/view/View;", "setCustomView", "(Landroid/view/View;)V", "customView", "Landroid/widget/TextView;", "h", "Landroid/widget/TextView;", "messageTextView", "Lcom/afollestad/materialdialogs/internal/main/DialogLayout;", "getRootLayout", "()Lcom/afollestad/materialdialogs/internal/main/DialogLayout;", "rootLayout", "i", "Z", "useHorizontalPadding", "j", "Lkotlin/Lazy;", "getFrameHorizontalMargin", "()I", "frameHorizontalMargin", "Landroid/view/ViewGroup;", "g", "Landroid/view/ViewGroup;", "scrollFrame", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "core"}, k = 1, mv = {1, 4, 0})
/* compiled from: DialogContentLayout.kt */
public final class DialogContentLayout extends FrameLayout {
    public static final /* synthetic */ g76[] n = {s56.c(new l56(s56.a(DialogContentLayout.class), "frameHorizontalMargin", "getFrameHorizontalMargin()I"))};
    public ViewGroup g;
    public TextView h;
    public boolean i;
    public final Lazy j = LazyKt__LazyJVMKt.lazy(new a(this));
    public DialogScrollView k;
    public DialogRecyclerView l;
    public View m;

    /* compiled from: DialogContentLayout.kt */
    public static final class a extends c56 implements t36<Integer> {
        public final /* synthetic */ DialogContentLayout g;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(DialogContentLayout dialogContentLayout) {
            super(0);
            this.g = dialogContentLayout;
        }

        /* Return type fixed from 'java.lang.Object' to match base method */
        @Override // defpackage.t36
        public Integer invoke() {
            return Integer.valueOf(this.g.getResources().getDimensionPixelSize(R.dimen.md_dialog_frame_margin_horizontal));
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DialogContentLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        a56.f(context, "context");
    }

    private final int getFrameHorizontalMargin() {
        Lazy lazy = this.j;
        g76 g76 = n[0];
        return ((Number) lazy.getValue()).intValue();
    }

    private final DialogLayout getRootLayout() {
        ViewParent parent = getParent();
        if (parent != null) {
            return (DialogLayout) parent;
        }
        throw new TypeCastException("null cannot be cast to non-null type com.afollestad.materialdialogs.internal.main.DialogLayout");
    }

    public final void a(boolean z) {
        if (this.k == null) {
            DialogScrollView dialogScrollView = (DialogScrollView) w70.A(this, R.layout.md_dialog_stub_scrollview, this);
            dialogScrollView.setRootView(getRootLayout());
            View childAt = dialogScrollView.getChildAt(0);
            if (childAt != null) {
                this.g = (ViewGroup) childAt;
                if (!z) {
                    m80 m80 = m80.a;
                    m80.f(m80, dialogScrollView, 0, 0, 0, m80.b(dialogScrollView, R.dimen.md_dialog_frame_margin_vertical), 7);
                }
                this.k = dialogScrollView;
                addView(dialogScrollView);
                return;
            }
            throw new TypeCastException("null cannot be cast to non-null type android.view.ViewGroup");
        }
    }

    public final View b(Integer num, View view, boolean z, boolean z2, boolean z3) {
        if (this.m == null) {
            if (!(view == null || view.getParent() == null)) {
                ViewParent parent = view.getParent();
                if (!(parent instanceof ViewGroup)) {
                    parent = null;
                }
                ViewGroup viewGroup = (ViewGroup) parent;
                if (viewGroup != null) {
                    viewGroup.removeView(view);
                }
            }
            if (z) {
                this.i = false;
                a(z2);
                if (view == null) {
                    if (num != null) {
                        view = (View) w70.A(this, num.intValue(), this.g);
                    } else {
                        a56.k();
                        throw null;
                    }
                }
                this.m = view;
                ViewGroup viewGroup2 = this.g;
                if (viewGroup2 != null) {
                    if (view == null) {
                        view = null;
                    } else if (z3) {
                        int frameHorizontalMargin = getFrameHorizontalMargin();
                        int frameHorizontalMargin2 = getFrameHorizontalMargin();
                        int paddingTop = view.getPaddingTop();
                        int paddingBottom = view.getPaddingBottom();
                        if (!(frameHorizontalMargin == view.getPaddingLeft() && paddingTop == view.getPaddingTop() && frameHorizontalMargin2 == view.getPaddingRight() && paddingBottom == view.getPaddingBottom())) {
                            view.setPadding(frameHorizontalMargin, paddingTop, frameHorizontalMargin2, paddingBottom);
                        }
                    }
                    viewGroup2.addView(view);
                } else {
                    a56.k();
                    throw null;
                }
            } else {
                this.i = z3;
                if (view == null) {
                    if (num != null) {
                        view = (View) w70.A(this, num.intValue(), this);
                    } else {
                        a56.k();
                        throw null;
                    }
                }
                this.m = view;
                addView(view);
            }
            View view2 = this.m;
            if (view2 != null) {
                return view2;
            }
            a56.k();
            throw null;
        }
        throw new IllegalStateException("Custom view already set.".toString());
    }

    public final void c(int i2, int i3) {
        if (i2 != -1) {
            View childAt = getChildAt(0);
            int paddingLeft = (!true || !true || childAt == null) ? 0 : childAt.getPaddingLeft();
            if (true && true) {
                i2 = childAt != null ? childAt.getPaddingTop() : 0;
            }
            int paddingRight = (!true || !true || childAt == null) ? 0 : childAt.getPaddingRight();
            int paddingBottom = (!true || !true || childAt == null) ? 0 : childAt.getPaddingBottom();
            if (!((childAt != null && paddingLeft == childAt.getPaddingLeft() && i2 == childAt.getPaddingTop() && paddingRight == childAt.getPaddingRight() && paddingBottom == childAt.getPaddingBottom()) || childAt == null)) {
                childAt.setPadding(paddingLeft, i2, paddingRight, paddingBottom);
            }
        }
        if (i3 != -1) {
            View childAt2 = getChildAt(getChildCount() - 1);
            int paddingLeft2 = (!true || !true || childAt2 == null) ? 0 : childAt2.getPaddingLeft();
            int paddingTop = (!true || !true || childAt2 == null) ? 0 : childAt2.getPaddingTop();
            int paddingRight2 = (!true || !true || childAt2 == null) ? 0 : childAt2.getPaddingRight();
            if (true && true) {
                i3 = childAt2 != null ? childAt2.getPaddingBottom() : 0;
            }
            if ((childAt2 == null || paddingLeft2 != childAt2.getPaddingLeft() || paddingTop != childAt2.getPaddingTop() || paddingRight2 != childAt2.getPaddingRight() || i3 != childAt2.getPaddingBottom()) && childAt2 != null) {
                childAt2.setPadding(paddingLeft2, paddingTop, paddingRight2, i3);
            }
        }
    }

    public final View getCustomView() {
        return this.m;
    }

    public final DialogRecyclerView getRecyclerView() {
        return this.l;
    }

    public final DialogScrollView getScrollView() {
        return this.k;
    }

    public void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        int i6;
        int i7;
        int childCount = getChildCount();
        int i8 = 0;
        int i9 = 0;
        while (i8 < childCount) {
            View childAt = getChildAt(i8);
            a56.b(childAt, "currentChild");
            int measuredHeight = childAt.getMeasuredHeight() + i9;
            if (!a56.a(childAt, this.m) || !this.i) {
                i6 = getMeasuredWidth();
                i7 = 0;
            } else {
                i7 = getFrameHorizontalMargin();
                i6 = getMeasuredWidth() - getFrameHorizontalMargin();
            }
            childAt.layout(i7, i9, i6, measuredHeight);
            i8++;
            i9 = measuredHeight;
        }
    }

    public void onMeasure(int i2, int i3) {
        int i4;
        int size = View.MeasureSpec.getSize(i2);
        int size2 = View.MeasureSpec.getSize(i3);
        DialogScrollView dialogScrollView = this.k;
        if (dialogScrollView != null) {
            dialogScrollView.measure(View.MeasureSpec.makeMeasureSpec(size, 1073741824), View.MeasureSpec.makeMeasureSpec(size2, Integer.MIN_VALUE));
        }
        DialogScrollView dialogScrollView2 = this.k;
        int measuredHeight = dialogScrollView2 != null ? dialogScrollView2.getMeasuredHeight() : 0;
        int i5 = size2 - measuredHeight;
        int childCount = this.k != null ? getChildCount() - 1 : getChildCount();
        if (childCount == 0) {
            setMeasuredDimension(size, measuredHeight);
            return;
        }
        int i6 = i5 / childCount;
        int childCount2 = getChildCount();
        for (int i7 = 0; i7 < childCount2; i7++) {
            View childAt = getChildAt(i7);
            a56.b(childAt, "currentChild");
            int id = childAt.getId();
            DialogScrollView dialogScrollView3 = this.k;
            if (dialogScrollView3 == null || id != dialogScrollView3.getId()) {
                if (!a56.a(childAt, this.m) || !this.i) {
                    i4 = View.MeasureSpec.makeMeasureSpec(size, 1073741824);
                } else {
                    i4 = View.MeasureSpec.makeMeasureSpec(size - (getFrameHorizontalMargin() * 2), 1073741824);
                }
                childAt.measure(i4, View.MeasureSpec.makeMeasureSpec(i6, Integer.MIN_VALUE));
                measuredHeight = childAt.getMeasuredHeight() + measuredHeight;
            }
        }
        setMeasuredDimension(size, measuredHeight);
    }

    public final void setCustomView(View view) {
        this.m = view;
    }

    public final void setRecyclerView(DialogRecyclerView dialogRecyclerView) {
        this.l = dialogRecyclerView;
    }

    public final void setScrollView(DialogScrollView dialogScrollView) {
        this.k = dialogScrollView;
    }
}
