package com.afollestad.materialdialogs.internal.list;

import android.content.Context;
import android.util.AttributeSet;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import kotlin.Metadata;
import kotlin.Unit;

@Metadata(bv = {1, 0, 3}, d1 = {"\u00005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004*\u0001\u0012\b\u0007\u0018\u00002\u00020\u0001B\u001b\u0012\u0006\u0010\u0017\u001a\u00020\u0016\u0012\n\b\u0002\u0010\u0019\u001a\u0004\u0018\u00010\u0018¢\u0006\u0004\b\u001a\u0010\u001bJ\r\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0003\u0010\u0004J\u000f\u0010\u0005\u001a\u00020\u0002H\u0014¢\u0006\u0004\b\u0005\u0010\u0004J\u000f\u0010\u0006\u001a\u00020\u0002H\u0014¢\u0006\u0004\b\u0006\u0010\u0004J/\u0010\f\u001a\u00020\u00022\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\t\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\u0007H\u0014¢\u0006\u0004\b\f\u0010\rJ\u000f\u0010\u000f\u001a\u00020\u000eH\u0002¢\u0006\u0004\b\u000f\u0010\u0010J\u000f\u0010\u0011\u001a\u00020\u000eH\u0002¢\u0006\u0004\b\u0011\u0010\u0010R\u0016\u0010\u0015\u001a\u00020\u00128\u0002@\u0002X\u0004¢\u0006\u0006\n\u0004\b\u0013\u0010\u0014¨\u0006\u001c"}, d2 = {"Lcom/afollestad/materialdialogs/internal/list/DialogRecyclerView;", "Landroidx/recyclerview/widget/RecyclerView;", "", "t0", "()V", "onAttachedToWindow", "onDetachedFromWindow", "", "left", "top", "oldl", "oldt", "onScrollChanged", "(IIII)V", "", "v0", "()Z", "u0", "com/afollestad/materialdialogs/internal/list/DialogRecyclerView$b", "O0", "Lcom/afollestad/materialdialogs/internal/list/DialogRecyclerView$b;", "scrollListeners", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "core"}, k = 1, mv = {1, 4, 0})
/* compiled from: DialogRecyclerView.kt */
public final class DialogRecyclerView extends RecyclerView {
    public final b O0 = new b(this);

    /* compiled from: DialogRecyclerView.kt */
    public static final class a extends c56 implements e46<DialogRecyclerView, Unit> {
        public static final a g = new a();

        public a() {
            super(1);
        }

        /* Return type fixed from 'java.lang.Object' to match base method */
        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object] */
        /* JADX WARNING: Code restructure failed: missing block: B:10:0x0027, code lost:
            if ((r3.u0() && r3.v0()) != false) goto L_0x0029;
         */
        @Override // defpackage.e46
        public Unit invoke(DialogRecyclerView dialogRecyclerView) {
            DialogRecyclerView dialogRecyclerView2 = dialogRecyclerView;
            a56.f(dialogRecyclerView2, "$receiver");
            dialogRecyclerView2.t0();
            int i = 1;
            if (!(dialogRecyclerView2.getChildCount() == 0 || dialogRecyclerView2.getMeasuredHeight() == 0)) {
            }
            i = 2;
            dialogRecyclerView2.setOverScrollMode(i);
            return Unit.INSTANCE;
        }
    }

    /* compiled from: DialogRecyclerView.kt */
    public static final class b extends RecyclerView.r {
        public final /* synthetic */ DialogRecyclerView a;

        /* JADX WARN: Incorrect args count in method signature: ()V */
        public b(DialogRecyclerView dialogRecyclerView) {
            this.a = dialogRecyclerView;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.r
        public void onScrolled(RecyclerView recyclerView, int i, int i2) {
            a56.f(recyclerView, "recyclerView");
            super.onScrolled(recyclerView, i, i2);
            this.a.t0();
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DialogRecyclerView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        a56.f(context, "context");
    }

    @Override // androidx.recyclerview.widget.RecyclerView
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        a aVar = a.g;
        a56.f(this, "$this$waitForWidth");
        a56.f(aVar, "block");
        if (getMeasuredWidth() <= 0 || getMeasuredHeight() <= 0) {
            getViewTreeObserver().addOnGlobalLayoutListener(new l80(this, aVar));
        } else {
            aVar.invoke(this);
        }
        h(this.O0);
    }

    @Override // androidx.recyclerview.widget.RecyclerView
    public void onDetachedFromWindow() {
        f0(this.O0);
        super.onDetachedFromWindow();
    }

    public void onScrollChanged(int i, int i2, int i3, int i4) {
        super.onScrollChanged(i, i2, i3, i4);
        t0();
    }

    public final void t0() {
        if (getChildCount() == 0 || getMeasuredHeight() == 0) {
        }
    }

    public final boolean u0() {
        RecyclerView.e adapter = getAdapter();
        if (adapter != null) {
            a56.b(adapter, "adapter!!");
            int itemCount = adapter.getItemCount() - 1;
            RecyclerView.m layoutManager = getLayoutManager();
            if (layoutManager instanceof LinearLayoutManager) {
                if (((LinearLayoutManager) layoutManager).l1() == itemCount) {
                    return true;
                }
            } else if (!(layoutManager instanceof GridLayoutManager) || ((GridLayoutManager) layoutManager).l1() != itemCount) {
                return false;
            } else {
                return true;
            }
            return false;
        }
        a56.k();
        throw null;
    }

    public final boolean v0() {
        RecyclerView.m layoutManager = getLayoutManager();
        if (layoutManager instanceof LinearLayoutManager) {
            if (((LinearLayoutManager) layoutManager).h1() == 0) {
                return true;
            }
        } else if (!(layoutManager instanceof GridLayoutManager) || ((GridLayoutManager) layoutManager).h1() != 0) {
            return false;
        } else {
            return true;
        }
        return false;
    }
}
