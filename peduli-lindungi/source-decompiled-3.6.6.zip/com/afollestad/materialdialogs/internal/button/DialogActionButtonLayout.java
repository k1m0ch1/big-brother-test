package com.afollestad.materialdialogs.internal.button;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.recyclerview.widget.RecyclerView;
import com.afollestad.materialdialogs.internal.list.DialogRecyclerView;
import com.github.mikephil.charting.utils.Utils;
import com.telkom.tracencare.R;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import kotlin.Metadata;
import kotlin.TypeCastException;

@Metadata(bv = {1, 0, 3}, d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001B\u001b\u0012\u0006\u0010<\u001a\u00020;\u0012\n\b\u0002\u0010>\u001a\u0004\u0018\u00010=¢\u0006\u0004\b?\u0010@J\u000f\u0010\u0003\u001a\u00020\u0002H\u0014¢\u0006\u0004\b\u0003\u0010\u0004J\u001f\u0010\b\u001a\u00020\u00022\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\u0005H\u0014¢\u0006\u0004\b\b\u0010\tJ7\u0010\u0010\u001a\u00020\u00022\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\u00052\u0006\u0010\r\u001a\u00020\u00052\u0006\u0010\u000e\u001a\u00020\u00052\u0006\u0010\u000f\u001a\u00020\u0005H\u0014¢\u0006\u0004\b\u0010\u0010\u0011J\u0017\u0010\u0014\u001a\u00020\u00022\u0006\u0010\u0013\u001a\u00020\u0012H\u0014¢\u0006\u0004\b\u0014\u0010\u0015R\u0016\u0010\u0018\u001a\u00020\u00058\u0002@\u0002X\u0004¢\u0006\u0006\n\u0004\b\u0016\u0010\u0017R\u0016\u0010\u001a\u001a\u00020\u00058\u0002@\u0002X\u0004¢\u0006\u0006\n\u0004\b\u0019\u0010\u0017R\"\u0010!\u001a\u00020\n8\u0000@\u0000X\u000e¢\u0006\u0012\n\u0004\b\u001b\u0010\u001c\u001a\u0004\b\u001d\u0010\u001e\"\u0004\b\u001f\u0010 R(\u0010*\u001a\b\u0012\u0004\u0012\u00020#0\"8\u0006@\u0006X.¢\u0006\u0012\n\u0004\b$\u0010%\u001a\u0004\b&\u0010'\"\u0004\b(\u0010)R\"\u00102\u001a\u00020+8\u0006@\u0006X.¢\u0006\u0012\n\u0004\b,\u0010-\u001a\u0004\b.\u0010/\"\u0004\b0\u00101R\u0019\u00104\u001a\b\u0012\u0004\u0012\u00020#0\"8F@\u0006¢\u0006\u0006\u001a\u0004\b3\u0010'R\u0016\u00106\u001a\u00020\u00058\u0002@\u0002X\u0004¢\u0006\u0006\n\u0004\b5\u0010\u0017R\u0016\u00108\u001a\u00020\u00058\u0002@\u0002X\u0004¢\u0006\u0006\n\u0004\b7\u0010\u0017R\u0016\u0010:\u001a\u00020\u00058\u0002@\u0002X\u0004¢\u0006\u0006\n\u0004\b9\u0010\u0017¨\u0006A"}, d2 = {"Lcom/afollestad/materialdialogs/internal/button/DialogActionButtonLayout;", "Lj80;", "", "onFinishInflate", "()V", "", "widthMeasureSpec", "heightMeasureSpec", "onMeasure", "(II)V", "", "changed", "left", "top", "right", "bottom", "onLayout", "(ZIIII)V", "Landroid/graphics/Canvas;", "canvas", "onDraw", "(Landroid/graphics/Canvas;)V", "l", "I", "buttonFramePaddingNeutral", "m", "buttonFrameSpecHeight", "p", "Z", "getStackButtons$core", "()Z", "setStackButtons$core", "(Z)V", "stackButtons", "", "Lcom/afollestad/materialdialogs/internal/button/DialogActionButton;", "q", "[Lcom/afollestad/materialdialogs/internal/button/DialogActionButton;", "getActionButtons", "()[Lcom/afollestad/materialdialogs/internal/button/DialogActionButton;", "setActionButtons", "([Lcom/afollestad/materialdialogs/internal/button/DialogActionButton;)V", "actionButtons", "Landroidx/appcompat/widget/AppCompatCheckBox;", "r", "Landroidx/appcompat/widget/AppCompatCheckBox;", "getCheckBoxPrompt", "()Landroidx/appcompat/widget/AppCompatCheckBox;", "setCheckBoxPrompt", "(Landroidx/appcompat/widget/AppCompatCheckBox;)V", "checkBoxPrompt", "getVisibleButtons", "visibleButtons", "o", "checkBoxPromptMarginHorizontal", "n", "checkBoxPromptMarginVertical", "k", "buttonFramePadding", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "core"}, k = 1, mv = {1, 4, 0})
/* compiled from: DialogActionButtonLayout.kt */
public final class DialogActionButtonLayout extends j80 {
    public final int k;
    public final int l;
    public final int m;
    public final int n;
    public final int o;
    public boolean p;
    public DialogActionButton[] q;
    public AppCompatCheckBox r;

    @Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\u0010\u0006\u001a\u00020\u00032\u000e\u0010\u0002\u001a\n \u0001*\u0004\u0018\u00010\u00000\u0000H\n¢\u0006\u0004\b\u0004\u0010\u0005"}, d2 = {"Landroid/view/View;", "kotlin.jvm.PlatformType", "it", "", "onClick", "(Landroid/view/View;)V", "<anonymous>"}, k = 3, mv = {1, 4, 0})
    /* compiled from: DialogActionButtonLayout.kt */
    public static final class a implements View.OnClickListener {
        public final /* synthetic */ DialogActionButtonLayout g;
        public final /* synthetic */ x70 h;

        public a(DialogActionButtonLayout dialogActionButtonLayout, x70 x70) {
            this.g = dialogActionButtonLayout;
            this.h = x70;
        }

        public final void onClick(View view) {
            v70 dialog = this.g.getDialog();
            x70 x70 = this.h;
            Objects.requireNonNull(dialog);
            a56.f(x70, "which");
            int ordinal = x70.ordinal();
            if (ordinal == 0) {
                w70.B(dialog.q, dialog);
                a56.f(dialog, "$this$getListAdapter");
                DialogRecyclerView recyclerView = dialog.n.getContentLayout().getRecyclerView();
                i80 i80 = null;
                RecyclerView.e adapter = recyclerView != null ? recyclerView.getAdapter() : null;
                if (adapter instanceof i80) {
                    i80 = adapter;
                }
                i80 i802 = i80;
                if (i802 != null) {
                    i802.a();
                }
            } else if (ordinal == 1) {
                w70.B(dialog.r, dialog);
            } else if (ordinal == 2) {
                w70.B(dialog.s, dialog);
            }
            if (dialog.h) {
                dialog.dismiss();
            }
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DialogActionButtonLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        a56.f(context, "context");
        m80 m80 = m80.a;
        this.k = m80.b(this, R.dimen.md_action_button_frame_padding) - m80.b(this, R.dimen.md_action_button_inset_horizontal);
        this.l = m80.b(this, R.dimen.md_action_button_frame_padding_neutral);
        this.m = m80.b(this, R.dimen.md_action_button_frame_spec_height);
        this.n = m80.b(this, R.dimen.md_checkbox_prompt_margin_vertical);
        this.o = m80.b(this, R.dimen.md_checkbox_prompt_margin_horizontal);
    }

    public final DialogActionButton[] getActionButtons() {
        DialogActionButton[] dialogActionButtonArr = this.q;
        if (dialogActionButtonArr != null) {
            return dialogActionButtonArr;
        }
        a56.l("actionButtons");
        throw null;
    }

    public final AppCompatCheckBox getCheckBoxPrompt() {
        AppCompatCheckBox appCompatCheckBox = this.r;
        if (appCompatCheckBox != null) {
            return appCompatCheckBox;
        }
        a56.l("checkBoxPrompt");
        throw null;
    }

    public final boolean getStackButtons$core() {
        return this.p;
    }

    public final DialogActionButton[] getVisibleButtons() {
        DialogActionButton[] dialogActionButtonArr = this.q;
        if (dialogActionButtonArr != null) {
            ArrayList arrayList = new ArrayList();
            for (DialogActionButton dialogActionButton : dialogActionButtonArr) {
                if (w70.I(dialogActionButton)) {
                    arrayList.add(dialogActionButton);
                }
            }
            Object[] array = arrayList.toArray(new DialogActionButton[0]);
            if (array != null) {
                return (DialogActionButton[]) array;
            }
            throw new TypeCastException("null cannot be cast to non-null type kotlin.Array<T>");
        }
        a56.l("actionButtons");
        throw null;
    }

    public void onDraw(Canvas canvas) {
        a56.f(canvas, "canvas");
        super.onDraw(canvas);
        if (getDrawDivider()) {
            canvas.drawLine(Utils.FLOAT_EPSILON, Utils.FLOAT_EPSILON, (float) getMeasuredWidth(), (float) getDividerHeight(), a());
        }
    }

    public void onFinishInflate() {
        x70 x70;
        super.onFinishInflate();
        View findViewById = findViewById(R.id.md_button_positive);
        a56.b(findViewById, "findViewById(R.id.md_button_positive)");
        View findViewById2 = findViewById(R.id.md_button_negative);
        a56.b(findViewById2, "findViewById(R.id.md_button_negative)");
        View findViewById3 = findViewById(R.id.md_button_neutral);
        a56.b(findViewById3, "findViewById(R.id.md_button_neutral)");
        this.q = new DialogActionButton[]{(DialogActionButton) findViewById, (DialogActionButton) findViewById2, (DialogActionButton) findViewById3};
        View findViewById4 = findViewById(R.id.md_checkbox_prompt);
        a56.b(findViewById4, "findViewById(R.id.md_checkbox_prompt)");
        this.r = (AppCompatCheckBox) findViewById4;
        DialogActionButton[] dialogActionButtonArr = this.q;
        if (dialogActionButtonArr != null) {
            int length = dialogActionButtonArr.length;
            for (int i = 0; i < length; i++) {
                DialogActionButton dialogActionButton = dialogActionButtonArr[i];
                if (i == 0) {
                    x70 = x70.POSITIVE;
                } else if (i == 1) {
                    x70 = x70.NEGATIVE;
                } else if (i == 2) {
                    x70 = x70.NEUTRAL;
                } else {
                    throw new IndexOutOfBoundsException(i + " is not an action button index.");
                }
                dialogActionButton.setOnClickListener(new a(this, x70));
            }
            return;
        }
        a56.l("actionButtons");
        throw null;
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        List<DialogActionButton> list;
        int i5;
        int i6;
        int i7;
        int i8;
        if (w70.Z(this)) {
            AppCompatCheckBox appCompatCheckBox = this.r;
            if (appCompatCheckBox != null) {
                if (w70.I(appCompatCheckBox)) {
                    if (w70.G(this)) {
                        i7 = getMeasuredWidth() - this.o;
                        i6 = this.n;
                        AppCompatCheckBox appCompatCheckBox2 = this.r;
                        if (appCompatCheckBox2 != null) {
                            i5 = i7 - appCompatCheckBox2.getMeasuredWidth();
                            AppCompatCheckBox appCompatCheckBox3 = this.r;
                            if (appCompatCheckBox3 != null) {
                                i8 = appCompatCheckBox3.getMeasuredHeight();
                            } else {
                                a56.l("checkBoxPrompt");
                                throw null;
                            }
                        } else {
                            a56.l("checkBoxPrompt");
                            throw null;
                        }
                    } else {
                        i5 = this.o;
                        i6 = this.n;
                        AppCompatCheckBox appCompatCheckBox4 = this.r;
                        if (appCompatCheckBox4 != null) {
                            i7 = appCompatCheckBox4.getMeasuredWidth() + i5;
                            AppCompatCheckBox appCompatCheckBox5 = this.r;
                            if (appCompatCheckBox5 != null) {
                                i8 = appCompatCheckBox5.getMeasuredHeight();
                            } else {
                                a56.l("checkBoxPrompt");
                                throw null;
                            }
                        } else {
                            a56.l("checkBoxPrompt");
                            throw null;
                        }
                    }
                    int i9 = i8 + i6;
                    AppCompatCheckBox appCompatCheckBox6 = this.r;
                    if (appCompatCheckBox6 != null) {
                        appCompatCheckBox6.layout(i5, i6, i7, i9);
                    } else {
                        a56.l("checkBoxPrompt");
                        throw null;
                    }
                }
                boolean z2 = true;
                if (this.p) {
                    int i10 = this.k;
                    int measuredWidth = getMeasuredWidth() - this.k;
                    int measuredHeight = getMeasuredHeight();
                    DialogActionButton[] visibleButtons = getVisibleButtons();
                    a56.e(visibleButtons, "$this$reversed");
                    if (visibleButtons.length != 0) {
                        z2 = false;
                    }
                    if (z2) {
                        list = z16.g;
                    } else {
                        list = ww5.g3(visibleButtons);
                        a56.e(list, "$this$reverse");
                        Collections.reverse(list);
                    }
                    for (DialogActionButton dialogActionButton : list) {
                        int i11 = measuredHeight - this.m;
                        dialogActionButton.layout(i10, i11, measuredWidth, measuredHeight);
                        measuredHeight = i11;
                    }
                    return;
                }
                int measuredHeight2 = getMeasuredHeight() - this.m;
                int measuredHeight3 = getMeasuredHeight();
                if (w70.G(this)) {
                    DialogActionButton[] dialogActionButtonArr = this.q;
                    if (dialogActionButtonArr != null) {
                        if (w70.I(dialogActionButtonArr[2])) {
                            DialogActionButton[] dialogActionButtonArr2 = this.q;
                            if (dialogActionButtonArr2 != null) {
                                DialogActionButton dialogActionButton2 = dialogActionButtonArr2[2];
                                int measuredWidth2 = getMeasuredWidth() - this.l;
                                dialogActionButton2.layout(measuredWidth2 - dialogActionButton2.getMeasuredWidth(), measuredHeight2, measuredWidth2, measuredHeight3);
                            } else {
                                a56.l("actionButtons");
                                throw null;
                            }
                        }
                        int i12 = this.k;
                        DialogActionButton[] dialogActionButtonArr3 = this.q;
                        if (dialogActionButtonArr3 != null) {
                            if (w70.I(dialogActionButtonArr3[0])) {
                                DialogActionButton[] dialogActionButtonArr4 = this.q;
                                if (dialogActionButtonArr4 != null) {
                                    DialogActionButton dialogActionButton3 = dialogActionButtonArr4[0];
                                    int measuredWidth3 = dialogActionButton3.getMeasuredWidth() + i12;
                                    dialogActionButton3.layout(i12, measuredHeight2, measuredWidth3, measuredHeight3);
                                    i12 = measuredWidth3;
                                } else {
                                    a56.l("actionButtons");
                                    throw null;
                                }
                            }
                            DialogActionButton[] dialogActionButtonArr5 = this.q;
                            if (dialogActionButtonArr5 == null) {
                                a56.l("actionButtons");
                                throw null;
                            } else if (w70.I(dialogActionButtonArr5[1])) {
                                DialogActionButton[] dialogActionButtonArr6 = this.q;
                                if (dialogActionButtonArr6 != null) {
                                    DialogActionButton dialogActionButton4 = dialogActionButtonArr6[1];
                                    dialogActionButton4.layout(i12, measuredHeight2, dialogActionButton4.getMeasuredWidth() + i12, measuredHeight3);
                                    return;
                                }
                                a56.l("actionButtons");
                                throw null;
                            }
                        } else {
                            a56.l("actionButtons");
                            throw null;
                        }
                    } else {
                        a56.l("actionButtons");
                        throw null;
                    }
                } else {
                    DialogActionButton[] dialogActionButtonArr7 = this.q;
                    if (dialogActionButtonArr7 != null) {
                        if (w70.I(dialogActionButtonArr7[2])) {
                            DialogActionButton[] dialogActionButtonArr8 = this.q;
                            if (dialogActionButtonArr8 != null) {
                                DialogActionButton dialogActionButton5 = dialogActionButtonArr8[2];
                                int i13 = this.l;
                                dialogActionButton5.layout(i13, measuredHeight2, dialogActionButton5.getMeasuredWidth() + i13, measuredHeight3);
                            } else {
                                a56.l("actionButtons");
                                throw null;
                            }
                        }
                        int measuredWidth4 = getMeasuredWidth() - this.k;
                        DialogActionButton[] dialogActionButtonArr9 = this.q;
                        if (dialogActionButtonArr9 != null) {
                            if (w70.I(dialogActionButtonArr9[0])) {
                                DialogActionButton[] dialogActionButtonArr10 = this.q;
                                if (dialogActionButtonArr10 != null) {
                                    DialogActionButton dialogActionButton6 = dialogActionButtonArr10[0];
                                    int measuredWidth5 = measuredWidth4 - dialogActionButton6.getMeasuredWidth();
                                    dialogActionButton6.layout(measuredWidth5, measuredHeight2, measuredWidth4, measuredHeight3);
                                    measuredWidth4 = measuredWidth5;
                                } else {
                                    a56.l("actionButtons");
                                    throw null;
                                }
                            }
                            DialogActionButton[] dialogActionButtonArr11 = this.q;
                            if (dialogActionButtonArr11 == null) {
                                a56.l("actionButtons");
                                throw null;
                            } else if (w70.I(dialogActionButtonArr11[1])) {
                                DialogActionButton[] dialogActionButtonArr12 = this.q;
                                if (dialogActionButtonArr12 != null) {
                                    DialogActionButton dialogActionButton7 = dialogActionButtonArr12[1];
                                    dialogActionButton7.layout(measuredWidth4 - dialogActionButton7.getMeasuredWidth(), measuredHeight2, measuredWidth4, measuredHeight3);
                                    return;
                                }
                                a56.l("actionButtons");
                                throw null;
                            }
                        } else {
                            a56.l("actionButtons");
                            throw null;
                        }
                    } else {
                        a56.l("actionButtons");
                        throw null;
                    }
                }
            } else {
                a56.l("checkBoxPrompt");
                throw null;
            }
        }
    }

    public void onMeasure(int i, int i2) {
        int i3 = 0;
        if (!w70.Z(this)) {
            setMeasuredDimension(0, 0);
            return;
        }
        int size = View.MeasureSpec.getSize(i);
        AppCompatCheckBox appCompatCheckBox = this.r;
        if (appCompatCheckBox != null) {
            if (w70.I(appCompatCheckBox)) {
                int i4 = size - (this.o * 2);
                AppCompatCheckBox appCompatCheckBox2 = this.r;
                if (appCompatCheckBox2 != null) {
                    appCompatCheckBox2.measure(View.MeasureSpec.makeMeasureSpec(i4, Integer.MIN_VALUE), View.MeasureSpec.makeMeasureSpec(0, 0));
                } else {
                    a56.l("checkBoxPrompt");
                    throw null;
                }
            }
            Context context = getDialog().getContext();
            a56.b(context, "dialog.context");
            Context context2 = getDialog().t;
            DialogActionButton[] visibleButtons = getVisibleButtons();
            for (DialogActionButton dialogActionButton : visibleButtons) {
                dialogActionButton.a(context, context2, this.p);
                if (this.p) {
                    dialogActionButton.measure(View.MeasureSpec.makeMeasureSpec(size, 1073741824), View.MeasureSpec.makeMeasureSpec(this.m, 1073741824));
                } else {
                    dialogActionButton.measure(View.MeasureSpec.makeMeasureSpec(0, 0), View.MeasureSpec.makeMeasureSpec(this.m, 1073741824));
                }
            }
            boolean z = true;
            if ((!(getVisibleButtons().length == 0)) && !this.p) {
                int i5 = 0;
                for (DialogActionButton dialogActionButton2 : getVisibleButtons()) {
                    i5 += dialogActionButton2.getMeasuredWidth();
                }
                if (i5 >= size && !this.p) {
                    this.p = true;
                    DialogActionButton[] visibleButtons2 = getVisibleButtons();
                    for (DialogActionButton dialogActionButton3 : visibleButtons2) {
                        dialogActionButton3.a(context, context2, true);
                        dialogActionButton3.measure(View.MeasureSpec.makeMeasureSpec(size, 1073741824), View.MeasureSpec.makeMeasureSpec(this.m, 1073741824));
                    }
                }
            }
            if (getVisibleButtons().length != 0) {
                z = false;
            }
            if (!z) {
                if (this.p) {
                    i3 = this.m * getVisibleButtons().length;
                } else {
                    i3 = this.m;
                }
            }
            AppCompatCheckBox appCompatCheckBox3 = this.r;
            if (appCompatCheckBox3 != null) {
                if (w70.I(appCompatCheckBox3)) {
                    AppCompatCheckBox appCompatCheckBox4 = this.r;
                    if (appCompatCheckBox4 != null) {
                        i3 += (this.n * 2) + appCompatCheckBox4.getMeasuredHeight();
                    } else {
                        a56.l("checkBoxPrompt");
                        throw null;
                    }
                }
                setMeasuredDimension(size, i3);
                return;
            }
            a56.l("checkBoxPrompt");
            throw null;
        }
        a56.l("checkBoxPrompt");
        throw null;
    }

    public final void setActionButtons(DialogActionButton[] dialogActionButtonArr) {
        a56.f(dialogActionButtonArr, "<set-?>");
        this.q = dialogActionButtonArr;
    }

    public final void setCheckBoxPrompt(AppCompatCheckBox appCompatCheckBox) {
        a56.f(appCompatCheckBox, "<set-?>");
        this.r = appCompatCheckBox;
    }

    public final void setStackButtons$core(boolean z) {
        this.p = z;
    }
}
