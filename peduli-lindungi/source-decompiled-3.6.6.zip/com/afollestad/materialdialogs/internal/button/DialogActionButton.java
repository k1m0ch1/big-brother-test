package com.afollestad.materialdialogs.internal.button;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.util.AttributeSet;
import androidx.appcompat.widget.AppCompatButton;
import com.telkom.tracencare.R;
import kotlin.KotlinVersion;
import kotlin.Metadata;

@Metadata(bv = {1, 0, 3}, d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u001b\u0012\u0006\u0010\u0013\u001a\u00020\u0002\u0012\n\b\u0002\u0010\u0015\u001a\u0004\u0018\u00010\u0014¢\u0006\u0004\b\u0016\u0010\u0017J'\u0010\b\u001a\u00020\u00072\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0004\u001a\u00020\u00022\u0006\u0010\u0006\u001a\u00020\u0005H\u0000¢\u0006\u0004\b\b\u0010\tJ\u0017\u0010\u000b\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\u0005H\u0016¢\u0006\u0004\b\u000b\u0010\fR\u0016\u0010\u0010\u001a\u00020\r8\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b\u000e\u0010\u000fR\u0016\u0010\u0012\u001a\u00020\r8\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b\u0011\u0010\u000f¨\u0006\u0018"}, d2 = {"Lcom/afollestad/materialdialogs/internal/button/DialogActionButton;", "Landroidx/appcompat/widget/AppCompatButton;", "Landroid/content/Context;", "baseContext", "appContext", "", "stacked", "", "a", "(Landroid/content/Context;Landroid/content/Context;Z)V", "enabled", "setEnabled", "(Z)V", "", "j", "I", "disabledColor", "i", "enabledColor", "context", "Landroid/util/AttributeSet;", "attrs", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "core"}, k = 1, mv = {1, 4, 0})
/* compiled from: DialogActionButton.kt */
public final class DialogActionButton extends AppCompatButton {
    public int i;
    public int j;

    /* compiled from: kotlin-style lambda group */
    public static final class a extends c56 implements t36<Integer> {
        public final /* synthetic */ int g;
        public final /* synthetic */ Object h;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(int i, Object obj) {
            super(0);
            this.g = i;
            this.h = obj;
        }

        /* Return type fixed from 'java.lang.Object' to match base method */
        @Override // defpackage.t36
        public final Integer invoke() {
            int i;
            int i2;
            int i3 = this.g;
            if (i3 == 0) {
                Context context = (Context) this.h;
                Integer valueOf = Integer.valueOf((int) R.attr.colorPrimary);
                a56.f(context, "context");
                if (valueOf != null) {
                    TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(new int[]{valueOf.intValue()});
                    try {
                        i = obtainStyledAttributes.getColor(0, 0);
                    } finally {
                        obtainStyledAttributes.recycle();
                    }
                } else {
                    i = wk.b(context, 0);
                }
                return Integer.valueOf(i);
            } else if (i3 == 1) {
                Context context2 = (Context) this.h;
                Integer valueOf2 = Integer.valueOf((int) R.attr.colorPrimary);
                a56.f(context2, "context");
                if (valueOf2 != null) {
                    TypedArray obtainStyledAttributes2 = context2.getTheme().obtainStyledAttributes(new int[]{valueOf2.intValue()});
                    try {
                        i2 = obtainStyledAttributes2.getColor(0, 0);
                    } finally {
                        obtainStyledAttributes2.recycle();
                    }
                } else {
                    i2 = wk.b(context2, 0);
                }
                return Integer.valueOf(Color.argb((int) (((float) KotlinVersion.MAX_COMPONENT_VALUE) * 0.12f), Color.red(i2), Color.green(i2), Color.blue(i2)));
            } else {
                throw null;
            }
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DialogActionButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        a56.f(context, "context");
        setClickable(true);
        setFocusable(true);
    }

    public final void a(Context context, Context context2, boolean z) {
        int e;
        a56.f(context, "baseContext");
        a56.f(context2, "appContext");
        m80 m80 = m80.a;
        a56.f(context2, "context");
        TypedArray obtainStyledAttributes = context2.getTheme().obtainStyledAttributes(new int[]{R.attr.md_button_casing});
        try {
            setSupportAllCaps(obtainStyledAttributes.getInt(0, 1) == 1);
            boolean z2 = w70.z(context2);
            this.i = m80.e(m80, context2, null, Integer.valueOf((int) R.attr.md_color_button_text), new a(0, context2), 2);
            this.j = m80.e(m80, context, Integer.valueOf(z2 ? R.color.md_disabled_text_light_theme : R.color.md_disabled_text_dark_theme), null, null, 12);
            setTextColor(this.i);
            Integer valueOf = Integer.valueOf((int) R.attr.md_button_selector);
            Drawable drawable = null;
            a56.f(context, "context");
            if (valueOf != null) {
                TypedArray obtainStyledAttributes2 = context.getTheme().obtainStyledAttributes(new int[]{valueOf.intValue()});
                try {
                    drawable = obtainStyledAttributes2.getDrawable(0);
                } finally {
                    obtainStyledAttributes2.recycle();
                }
            }
            if ((drawable instanceof RippleDrawable) && (e = m80.e(m80, context, null, Integer.valueOf((int) R.attr.md_ripple_color), new a(1, context2), 2)) != 0) {
                ((RippleDrawable) drawable).setColor(ColorStateList.valueOf(e));
            }
            setBackground(drawable);
            if (z) {
                a56.f(this, "$this$setGravityEndCompat");
                setTextAlignment(6);
                setGravity(8388629);
            } else {
                setGravity(17);
            }
            setEnabled(isEnabled());
        } finally {
            obtainStyledAttributes.recycle();
        }
    }

    public void setEnabled(boolean z) {
        super.setEnabled(z);
        setTextColor(z ? this.i : this.j);
    }
}
