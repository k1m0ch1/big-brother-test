package com.afollestad.materialdialogs.internal.main;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import com.afollestad.materialdialogs.internal.button.DialogActionButton;
import com.afollestad.materialdialogs.internal.button.DialogActionButtonLayout;
import com.afollestad.materialdialogs.internal.message.DialogContentLayout;
import com.github.mikephil.charting.utils.Utils;
import com.telkom.tracencare.R;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TypeCastException;

@Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0014\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u0019\u0012\u0006\u0010w\u001a\u00020v\u0012\b\u0010y\u001a\u0004\u0018\u00010x¢\u0006\u0004\bz\u0010{J!\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0003\u001a\u00020\u00022\b\b\u0002\u0010\u0005\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u0007\u0010\bJ\u000f\u0010\n\u001a\u00020\tH\u0014¢\u0006\u0004\b\n\u0010\u000bJ\u001d\u0010\u000f\u001a\u00020\t2\u0006\u0010\r\u001a\u00020\f2\u0006\u0010\u000e\u001a\u00020\f¢\u0006\u0004\b\u000f\u0010\u0010J\u000f\u0010\u0011\u001a\u00020\tH\u0014¢\u0006\u0004\b\u0011\u0010\u000bJ\u001f\u0010\u0014\u001a\u00020\t2\u0006\u0010\u0012\u001a\u00020\u00022\u0006\u0010\u0013\u001a\u00020\u0002H\u0014¢\u0006\u0004\b\u0014\u0010\u0015J7\u0010\u001b\u001a\u00020\t2\u0006\u0010\u0016\u001a\u00020\f2\u0006\u0010\u0017\u001a\u00020\u00022\u0006\u0010\u0018\u001a\u00020\u00022\u0006\u0010\u0019\u001a\u00020\u00022\u0006\u0010\u001a\u001a\u00020\u0002H\u0014¢\u0006\u0004\b\u001b\u0010\u001cJ\u0017\u0010\u001f\u001a\u00020\t2\u0006\u0010\u001e\u001a\u00020\u001dH\u0014¢\u0006\u0004\b\u001f\u0010 J\u0017\u0010!\u001a\u00020\t2\u0006\u0010\u001e\u001a\u00020\u001dH\u0014¢\u0006\u0004\b!\u0010 R\u0018\u0010$\u001a\u0004\u0018\u00010\u00068\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b\"\u0010#R\"\u0010,\u001a\u00020%8\u0006@\u0006X.¢\u0006\u0012\n\u0004\b&\u0010'\u001a\u0004\b(\u0010)\"\u0004\b*\u0010+R\u0016\u0010/\u001a\u00020\f8\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b-\u0010.R$\u00107\u001a\u0004\u0018\u0001008\u0006@\u0006X\u000e¢\u0006\u0012\n\u0004\b1\u00102\u001a\u0004\b3\u00104\"\u0004\b5\u00106R\"\u0010?\u001a\u0002088\u0006@\u0006X.¢\u0006\u0012\n\u0004\b9\u0010:\u001a\u0004\b;\u0010<\"\u0004\b=\u0010>R\"\u0010G\u001a\u00020@8\u0006@\u0006X.¢\u0006\u0012\n\u0004\bA\u0010B\u001a\u0004\bC\u0010D\"\u0004\bE\u0010FR*\u0010P\u001a\u00020H2\u0006\u0010I\u001a\u00020H8\u0006@FX\u000e¢\u0006\u0012\n\u0004\bJ\u0010K\u001a\u0004\bL\u0010M\"\u0004\bN\u0010OR\u0016\u0010S\u001a\u00020\u00028\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\bQ\u0010RR\u0016\u0010W\u001a\u00020T8\u0002@\u0002X\u0004¢\u0006\u0006\n\u0004\bU\u0010VR*\u0010]\u001a\u00020\f2\u0006\u0010I\u001a\u00020\f8\u0006@FX\u000e¢\u0006\u0012\n\u0004\bX\u0010.\u001a\u0004\bY\u0010Z\"\u0004\b[\u0010\\R\u001c\u0010a\u001a\u00020\u00028\u0000@\u0000X\u0004¢\u0006\f\n\u0004\b^\u0010R\u001a\u0004\b_\u0010`R\u0016\u0010e\u001a\u00020b8\u0002@\u0002X\u0004¢\u0006\u0006\n\u0004\bc\u0010dR\u001c\u0010h\u001a\u00020\u00028\u0000@\u0000X\u0004¢\u0006\f\n\u0004\bf\u0010R\u001a\u0004\bg\u0010`R\"\u0010p\u001a\u00020i8\u0006@\u0006X\u000e¢\u0006\u0012\n\u0004\bj\u0010k\u001a\u0004\bl\u0010m\"\u0004\bn\u0010oR\"\u0010u\u001a\u00020\u00028\u0006@\u0006X\u000e¢\u0006\u0012\n\u0004\bq\u0010R\u001a\u0004\br\u0010`\"\u0004\bs\u0010t¨\u0006|"}, d2 = {"Lcom/afollestad/materialdialogs/internal/main/DialogLayout;", "Landroid/widget/FrameLayout;", "", "color", "", "alpha", "Landroid/graphics/Paint;", "c", "(IF)Landroid/graphics/Paint;", "", "onFinishInflate", "()V", "", "showTop", "showBottom", "b", "(ZZ)V", "onAttachedToWindow", "widthMeasureSpec", "heightMeasureSpec", "onMeasure", "(II)V", "changed", "left", "top", "right", "bottom", "onLayout", "(ZIIII)V", "Landroid/graphics/Canvas;", "canvas", "onDraw", "(Landroid/graphics/Canvas;)V", "dispatchDraw", "j", "Landroid/graphics/Paint;", "debugPaint", "Lcom/afollestad/materialdialogs/internal/main/DialogTitleLayout;", "n", "Lcom/afollestad/materialdialogs/internal/main/DialogTitleLayout;", "getTitleLayout", "()Lcom/afollestad/materialdialogs/internal/main/DialogTitleLayout;", "setTitleLayout", "(Lcom/afollestad/materialdialogs/internal/main/DialogTitleLayout;)V", "titleLayout", "r", "Z", "isButtonsLayoutAChild", "Lcom/afollestad/materialdialogs/internal/button/DialogActionButtonLayout;", "p", "Lcom/afollestad/materialdialogs/internal/button/DialogActionButtonLayout;", "getButtonsLayout", "()Lcom/afollestad/materialdialogs/internal/button/DialogActionButtonLayout;", "setButtonsLayout", "(Lcom/afollestad/materialdialogs/internal/button/DialogActionButtonLayout;)V", "buttonsLayout", "Lv70;", "m", "Lv70;", "getDialog", "()Lv70;", "setDialog", "(Lv70;)V", "dialog", "Lcom/afollestad/materialdialogs/internal/message/DialogContentLayout;", "o", "Lcom/afollestad/materialdialogs/internal/message/DialogContentLayout;", "getContentLayout", "()Lcom/afollestad/materialdialogs/internal/message/DialogContentLayout;", "setContentLayout", "(Lcom/afollestad/materialdialogs/internal/message/DialogContentLayout;)V", "contentLayout", "", "value", "i", "[F", "getCornerRadii", "()[F", "setCornerRadii", "([F)V", "cornerRadii", "s", "I", "windowHeight", "Landroid/graphics/RectF;", "u", "Landroid/graphics/RectF;", "cornerRadiusRect", "h", "getDebugMode", "()Z", "setDebugMode", "(Z)V", "debugMode", "l", "getFrameMarginVerticalLess$core", "()I", "frameMarginVerticalLess", "Landroid/graphics/Path;", "t", "Landroid/graphics/Path;", "cornerRadiusPath", "k", "getFrameMarginVertical$core", "frameMarginVertical", "Lu70;", "q", "Lu70;", "getLayoutMode", "()Lu70;", "setLayoutMode", "(Lu70;)V", "layoutMode", "g", "getMaxHeight", "setMaxHeight", "(I)V", "maxHeight", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "core"}, k = 1, mv = {1, 4, 0})
/* compiled from: DialogLayout.kt */
public final class DialogLayout extends FrameLayout {
    public int g;
    public boolean h;
    public float[] i = new float[0];
    public Paint j;
    public final int k;
    public final int l;
    public v70 m;
    public DialogTitleLayout n;
    public DialogContentLayout o;
    public DialogActionButtonLayout p;
    public u70 q;
    public boolean r;
    public int s;
    public final Path t;
    public final RectF u;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DialogLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        a56.f(context, "context");
        a56.f(this, "$this$dimenPx");
        Context context2 = getContext();
        a56.b(context2, "context");
        this.k = context2.getResources().getDimensionPixelSize(R.dimen.md_dialog_frame_margin_vertical);
        a56.f(this, "$this$dimenPx");
        Context context3 = getContext();
        a56.b(context3, "context");
        this.l = context3.getResources().getDimensionPixelSize(R.dimen.md_dialog_frame_margin_vertical_less);
        this.q = u70.g;
        this.r = true;
        this.s = -1;
        this.t = new Path();
        this.u = new RectF();
    }

    public static void a(DialogLayout dialogLayout, Canvas canvas, int i2, float f, float f2, int i3) {
        if ((i3 & 2) != 0) {
            f = (float) dialogLayout.getMeasuredHeight();
        }
        canvas.drawLine(Utils.FLOAT_EPSILON, f, (float) dialogLayout.getMeasuredWidth(), (i3 & 4) != 0 ? f : f2, dialogLayout.c(i2, 1.0f));
    }

    public static void d(DialogLayout dialogLayout, Canvas canvas, int i2, float f, float f2, int i3) {
        canvas.drawLine(f, Utils.FLOAT_EPSILON, (i3 & 4) != 0 ? f : f2, (float) dialogLayout.getMeasuredHeight(), dialogLayout.c(i2, 1.0f));
    }

    public final void b(boolean z, boolean z2) {
        DialogTitleLayout dialogTitleLayout = this.n;
        if (dialogTitleLayout != null) {
            dialogTitleLayout.setDrawDivider(z);
            DialogActionButtonLayout dialogActionButtonLayout = this.p;
            if (dialogActionButtonLayout != null) {
                dialogActionButtonLayout.setDrawDivider(z2);
                return;
            }
            return;
        }
        a56.l("titleLayout");
        throw null;
    }

    public final Paint c(int i2, float f) {
        if (this.j == null) {
            Paint paint = new Paint();
            paint.setStrokeWidth(w70.m(this, 1));
            paint.setStyle(Paint.Style.FILL);
            paint.setAntiAlias(true);
            this.j = paint;
        }
        Paint paint2 = this.j;
        if (paint2 != null) {
            paint2.setColor(i2);
            setAlpha(f);
            return paint2;
        }
        a56.k();
        throw null;
    }

    public void dispatchDraw(Canvas canvas) {
        a56.f(canvas, "canvas");
        if (!(this.i.length == 0)) {
            canvas.clipPath(this.t);
        }
        super.dispatchDraw(canvas);
    }

    public final DialogActionButtonLayout getButtonsLayout() {
        return this.p;
    }

    public final DialogContentLayout getContentLayout() {
        DialogContentLayout dialogContentLayout = this.o;
        if (dialogContentLayout != null) {
            return dialogContentLayout;
        }
        a56.l("contentLayout");
        throw null;
    }

    public final float[] getCornerRadii() {
        return this.i;
    }

    public final boolean getDebugMode() {
        return this.h;
    }

    public final v70 getDialog() {
        v70 v70 = this.m;
        if (v70 != null) {
            return v70;
        }
        a56.l("dialog");
        throw null;
    }

    public final int getFrameMarginVertical$core() {
        return this.k;
    }

    public final int getFrameMarginVerticalLess$core() {
        return this.l;
    }

    public final u70 getLayoutMode() {
        return this.q;
    }

    public final int getMaxHeight() {
        return this.g;
    }

    public final DialogTitleLayout getTitleLayout() {
        DialogTitleLayout dialogTitleLayout = this.n;
        if (dialogTitleLayout != null) {
            return dialogTitleLayout;
        }
        a56.l("titleLayout");
        throw null;
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Object systemService = getContext().getSystemService("window");
        if (systemService != null) {
            WindowManager windowManager = (WindowManager) systemService;
            a56.f(windowManager, "$this$getWidthAndHeight");
            Point point = new Point();
            windowManager.getDefaultDisplay().getSize(point);
            this.s = ((Number) new Pair(Integer.valueOf(point.x), Integer.valueOf(point.y)).component2()).intValue();
            return;
        }
        throw new TypeCastException("null cannot be cast to non-null type android.view.WindowManager");
    }

    public void onDraw(Canvas canvas) {
        float f;
        a56.f(canvas, "canvas");
        super.onDraw(canvas);
        if (this.h) {
            d(this, canvas, -16776961, w70.m(this, 24), Utils.FLOAT_EPSILON, 4);
            a(this, canvas, -16776961, w70.m(this, 24), Utils.FLOAT_EPSILON, 4);
            d(this, canvas, -16776961, ((float) getMeasuredWidth()) - w70.m(this, 24), Utils.FLOAT_EPSILON, 4);
            DialogTitleLayout dialogTitleLayout = this.n;
            if (dialogTitleLayout != null) {
                if (w70.I(dialogTitleLayout)) {
                    DialogTitleLayout dialogTitleLayout2 = this.n;
                    if (dialogTitleLayout2 != null) {
                        a(this, canvas, -65536, (float) dialogTitleLayout2.getBottom(), Utils.FLOAT_EPSILON, 4);
                    } else {
                        a56.l("titleLayout");
                        throw null;
                    }
                }
                DialogContentLayout dialogContentLayout = this.o;
                if (dialogContentLayout != null) {
                    if (w70.I(dialogContentLayout)) {
                        DialogContentLayout dialogContentLayout2 = this.o;
                        if (dialogContentLayout2 != null) {
                            a(this, canvas, -256, (float) dialogContentLayout2.getTop(), Utils.FLOAT_EPSILON, 4);
                        } else {
                            a56.l("contentLayout");
                            throw null;
                        }
                    }
                    if (w70.Z(this.p)) {
                        if (w70.G(this)) {
                            f = w70.m(this, 8);
                        } else {
                            f = ((float) getMeasuredWidth()) - w70.m(this, 8);
                        }
                        int i2 = -16711681;
                        d(this, canvas, -16711681, f, Utils.FLOAT_EPSILON, 4);
                        DialogActionButtonLayout dialogActionButtonLayout = this.p;
                        float f2 = 0.4f;
                        int i3 = 0;
                        if (dialogActionButtonLayout == null || !dialogActionButtonLayout.getStackButtons$core()) {
                            DialogActionButtonLayout dialogActionButtonLayout2 = this.p;
                            if (dialogActionButtonLayout2 != null) {
                                DialogActionButton[] visibleButtons = dialogActionButtonLayout2.getVisibleButtons();
                                int length = visibleButtons.length;
                                while (i3 < length) {
                                    DialogActionButton dialogActionButton = visibleButtons[i3];
                                    DialogActionButtonLayout dialogActionButtonLayout3 = this.p;
                                    if (dialogActionButtonLayout3 != null) {
                                        float m2 = w70.m(this, 8) + ((float) dialogActionButtonLayout3.getTop()) + ((float) dialogActionButton.getTop());
                                        DialogActionButtonLayout dialogActionButtonLayout4 = this.p;
                                        if (dialogActionButtonLayout4 != null) {
                                            canvas.drawRect(w70.m(this, 4) + ((float) dialogActionButton.getLeft()), m2, ((float) dialogActionButton.getRight()) - w70.m(this, 4), ((float) dialogActionButtonLayout4.getBottom()) - w70.m(this, 8), c(-16711681, 0.4f));
                                            i3++;
                                        } else {
                                            a56.k();
                                            throw null;
                                        }
                                    } else {
                                        a56.k();
                                        throw null;
                                    }
                                }
                                DialogActionButtonLayout dialogActionButtonLayout5 = this.p;
                                if (dialogActionButtonLayout5 != null) {
                                    a(this, canvas, -65281, (float) dialogActionButtonLayout5.getTop(), Utils.FLOAT_EPSILON, 4);
                                    float measuredHeight = ((float) getMeasuredHeight()) - (w70.m(this, 52) - w70.m(this, 8));
                                    a(this, canvas, -65536, measuredHeight, Utils.FLOAT_EPSILON, 4);
                                    a(this, canvas, -65536, ((float) getMeasuredHeight()) - w70.m(this, 8), Utils.FLOAT_EPSILON, 4);
                                    a(this, canvas, -16776961, measuredHeight - w70.m(this, 8), Utils.FLOAT_EPSILON, 4);
                                    return;
                                }
                                a56.k();
                                throw null;
                            }
                            return;
                        }
                        DialogActionButtonLayout dialogActionButtonLayout6 = this.p;
                        if (dialogActionButtonLayout6 != null) {
                            float m3 = w70.m(this, 8) + ((float) dialogActionButtonLayout6.getTop());
                            DialogActionButtonLayout dialogActionButtonLayout7 = this.p;
                            if (dialogActionButtonLayout7 != null) {
                                DialogActionButton[] visibleButtons2 = dialogActionButtonLayout7.getVisibleButtons();
                                int length2 = visibleButtons2.length;
                                float f3 = m3;
                                while (i3 < length2) {
                                    DialogActionButton dialogActionButton2 = visibleButtons2[i3];
                                    float m4 = w70.m(this, 36) + f3;
                                    canvas.drawRect((float) dialogActionButton2.getLeft(), f3, ((float) getMeasuredWidth()) - w70.m(this, 8), m4, c(i2, f2));
                                    f3 = w70.m(this, 16) + m4;
                                    i3++;
                                    f2 = 0.4f;
                                    i2 = -16711681;
                                }
                                DialogActionButtonLayout dialogActionButtonLayout8 = this.p;
                                if (dialogActionButtonLayout8 != null) {
                                    a(this, canvas, -16776961, (float) dialogActionButtonLayout8.getTop(), Utils.FLOAT_EPSILON, 4);
                                    DialogActionButtonLayout dialogActionButtonLayout9 = this.p;
                                    if (dialogActionButtonLayout9 != null) {
                                        a(this, canvas, -65536, w70.m(this, 8) + ((float) dialogActionButtonLayout9.getTop()), Utils.FLOAT_EPSILON, 4);
                                        a(this, canvas, -65536, ((float) getMeasuredHeight()) - w70.m(this, 8), Utils.FLOAT_EPSILON, 4);
                                        return;
                                    }
                                    a56.k();
                                    throw null;
                                }
                                a56.k();
                                throw null;
                            }
                            a56.k();
                            throw null;
                        }
                        a56.k();
                        throw null;
                    }
                    return;
                }
                a56.l("contentLayout");
                throw null;
            }
            a56.l("titleLayout");
            throw null;
        }
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        View findViewById = findViewById(R.id.md_title_layout);
        a56.b(findViewById, "findViewById(R.id.md_title_layout)");
        this.n = (DialogTitleLayout) findViewById;
        View findViewById2 = findViewById(R.id.md_content_layout);
        a56.b(findViewById2, "findViewById(R.id.md_content_layout)");
        this.o = (DialogContentLayout) findViewById2;
        this.p = (DialogActionButtonLayout) findViewById(R.id.md_button_layout);
    }

    public void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        int i6;
        int measuredWidth = getMeasuredWidth();
        DialogTitleLayout dialogTitleLayout = this.n;
        if (dialogTitleLayout != null) {
            int measuredHeight = dialogTitleLayout.getMeasuredHeight();
            DialogTitleLayout dialogTitleLayout2 = this.n;
            if (dialogTitleLayout2 != null) {
                dialogTitleLayout2.layout(0, 0, measuredWidth, measuredHeight);
                if (this.r) {
                    int measuredHeight2 = getMeasuredHeight();
                    DialogActionButtonLayout dialogActionButtonLayout = this.p;
                    i6 = measuredHeight2 - (dialogActionButtonLayout != null ? dialogActionButtonLayout.getMeasuredHeight() : 0);
                    if (w70.Z(this.p)) {
                        int measuredWidth2 = getMeasuredWidth();
                        int measuredHeight3 = getMeasuredHeight();
                        DialogActionButtonLayout dialogActionButtonLayout2 = this.p;
                        if (dialogActionButtonLayout2 != null) {
                            dialogActionButtonLayout2.layout(0, i6, measuredWidth2, measuredHeight3);
                        } else {
                            a56.k();
                            throw null;
                        }
                    }
                } else {
                    i6 = getMeasuredHeight();
                }
                int measuredWidth3 = getMeasuredWidth();
                DialogContentLayout dialogContentLayout = this.o;
                if (dialogContentLayout != null) {
                    dialogContentLayout.layout(0, measuredHeight, measuredWidth3, i6);
                } else {
                    a56.l("contentLayout");
                    throw null;
                }
            } else {
                a56.l("titleLayout");
                throw null;
            }
        } else {
            a56.l("titleLayout");
            throw null;
        }
    }

    public void onMeasure(int i2, int i3) {
        int size = View.MeasureSpec.getSize(i2);
        int size2 = View.MeasureSpec.getSize(i3);
        int i4 = this.g;
        if (1 <= i4 && size2 > i4) {
            size2 = i4;
        }
        DialogTitleLayout dialogTitleLayout = this.n;
        if (dialogTitleLayout != null) {
            boolean z = false;
            dialogTitleLayout.measure(View.MeasureSpec.makeMeasureSpec(size, 1073741824), View.MeasureSpec.makeMeasureSpec(0, 0));
            if (w70.Z(this.p)) {
                DialogActionButtonLayout dialogActionButtonLayout = this.p;
                if (dialogActionButtonLayout != null) {
                    dialogActionButtonLayout.measure(View.MeasureSpec.makeMeasureSpec(size, 1073741824), View.MeasureSpec.makeMeasureSpec(0, 0));
                } else {
                    a56.k();
                    throw null;
                }
            }
            DialogTitleLayout dialogTitleLayout2 = this.n;
            if (dialogTitleLayout2 != null) {
                int measuredHeight = dialogTitleLayout2.getMeasuredHeight();
                DialogActionButtonLayout dialogActionButtonLayout2 = this.p;
                int measuredHeight2 = size2 - (measuredHeight + (dialogActionButtonLayout2 != null ? dialogActionButtonLayout2.getMeasuredHeight() : 0));
                DialogContentLayout dialogContentLayout = this.o;
                if (dialogContentLayout != null) {
                    dialogContentLayout.measure(View.MeasureSpec.makeMeasureSpec(size, 1073741824), View.MeasureSpec.makeMeasureSpec(measuredHeight2, Integer.MIN_VALUE));
                    if (this.q == u70.g) {
                        DialogTitleLayout dialogTitleLayout3 = this.n;
                        if (dialogTitleLayout3 != null) {
                            int measuredHeight3 = dialogTitleLayout3.getMeasuredHeight();
                            DialogContentLayout dialogContentLayout2 = this.o;
                            if (dialogContentLayout2 != null) {
                                int measuredHeight4 = dialogContentLayout2.getMeasuredHeight() + measuredHeight3;
                                DialogActionButtonLayout dialogActionButtonLayout3 = this.p;
                                setMeasuredDimension(size, measuredHeight4 + (dialogActionButtonLayout3 != null ? dialogActionButtonLayout3.getMeasuredHeight() : 0));
                            } else {
                                a56.l("contentLayout");
                                throw null;
                            }
                        } else {
                            a56.l("titleLayout");
                            throw null;
                        }
                    } else {
                        setMeasuredDimension(size, this.s);
                    }
                    if (this.i.length == 0) {
                        z = true;
                    }
                    if (!z) {
                        RectF rectF = this.u;
                        rectF.left = Utils.FLOAT_EPSILON;
                        rectF.top = Utils.FLOAT_EPSILON;
                        rectF.right = (float) getMeasuredWidth();
                        rectF.bottom = (float) getMeasuredHeight();
                        this.t.addRoundRect(this.u, this.i, Path.Direction.CW);
                        return;
                    }
                    return;
                }
                a56.l("contentLayout");
                throw null;
            }
            a56.l("titleLayout");
            throw null;
        }
        a56.l("titleLayout");
        throw null;
    }

    public final void setButtonsLayout(DialogActionButtonLayout dialogActionButtonLayout) {
        this.p = dialogActionButtonLayout;
    }

    public final void setContentLayout(DialogContentLayout dialogContentLayout) {
        a56.f(dialogContentLayout, "<set-?>");
        this.o = dialogContentLayout;
    }

    public final void setCornerRadii(float[] fArr) {
        a56.f(fArr, "value");
        this.i = fArr;
        if (!this.t.isEmpty()) {
            this.t.reset();
        }
        invalidate();
    }

    public final void setDebugMode(boolean z) {
        this.h = z;
        setWillNotDraw(!z);
    }

    public final void setDialog(v70 v70) {
        a56.f(v70, "<set-?>");
        this.m = v70;
    }

    public final void setLayoutMode(u70 u70) {
        a56.f(u70, "<set-?>");
        this.q = u70;
    }

    public final void setMaxHeight(int i2) {
        this.g = i2;
    }

    public final void setTitleLayout(DialogTitleLayout dialogTitleLayout) {
        a56.f(dialogTitleLayout, "<set-?>");
        this.n = dialogTitleLayout;
    }
}
