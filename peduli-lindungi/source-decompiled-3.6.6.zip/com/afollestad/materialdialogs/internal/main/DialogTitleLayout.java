package com.afollestad.materialdialogs.internal.main;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.github.mikephil.charting.utils.Utils;
import com.telkom.tracencare.R;
import kotlin.Metadata;

@Metadata(bv = {1, 0, 3}, d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001B\u001b\u0012\u0006\u00104\u001a\u000203\u0012\n\b\u0002\u00106\u001a\u0004\u0018\u000105¢\u0006\u0004\b7\u00108J\u000f\u0010\u0003\u001a\u00020\u0002H\u0014¢\u0006\u0004\b\u0003\u0010\u0004J\r\u0010\u0006\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u001f\u0010\u000b\u001a\u00020\u00022\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\bH\u0014¢\u0006\u0004\b\u000b\u0010\fJ7\u0010\u0012\u001a\u00020\u00022\u0006\u0010\r\u001a\u00020\u00052\u0006\u0010\u000e\u001a\u00020\b2\u0006\u0010\u000f\u001a\u00020\b2\u0006\u0010\u0010\u001a\u00020\b2\u0006\u0010\u0011\u001a\u00020\bH\u0014¢\u0006\u0004\b\u0012\u0010\u0013J\u0017\u0010\u0016\u001a\u00020\u00022\u0006\u0010\u0015\u001a\u00020\u0014H\u0014¢\u0006\u0004\b\u0016\u0010\u0017R\"\u0010\u001f\u001a\u00020\u00188\u0000@\u0000X.¢\u0006\u0012\n\u0004\b\u0019\u0010\u001a\u001a\u0004\b\u001b\u0010\u001c\"\u0004\b\u001d\u0010\u001eR\u0016\u0010\"\u001a\u00020\b8\u0002@\u0002X\u0004¢\u0006\u0006\n\u0004\b \u0010!R\u0016\u0010$\u001a\u00020\b8\u0002@\u0002X\u0004¢\u0006\u0006\n\u0004\b#\u0010!R\u0016\u0010&\u001a\u00020\b8\u0002@\u0002X\u0004¢\u0006\u0006\n\u0004\b%\u0010!R\u0016\u0010(\u001a\u00020\b8\u0002@\u0002X\u0004¢\u0006\u0006\n\u0004\b'\u0010!R\"\u00100\u001a\u00020)8\u0000@\u0000X.¢\u0006\u0012\n\u0004\b*\u0010+\u001a\u0004\b,\u0010-\"\u0004\b.\u0010/R\u0016\u00102\u001a\u00020\b8\u0002@\u0002X\u0004¢\u0006\u0006\n\u0004\b1\u0010!¨\u00069"}, d2 = {"Lcom/afollestad/materialdialogs/internal/main/DialogTitleLayout;", "Lj80;", "", "onFinishInflate", "()V", "", "b", "()Z", "", "widthMeasureSpec", "heightMeasureSpec", "onMeasure", "(II)V", "changed", "left", "top", "right", "bottom", "onLayout", "(ZIIII)V", "Landroid/graphics/Canvas;", "canvas", "onDraw", "(Landroid/graphics/Canvas;)V", "Landroid/widget/TextView;", "q", "Landroid/widget/TextView;", "getTitleView$core", "()Landroid/widget/TextView;", "setTitleView$core", "(Landroid/widget/TextView;)V", "titleView", "l", "I", "titleMarginBottom", "m", "frameMarginHorizontal", "k", "frameMarginVertical", "o", "iconSize", "Landroid/widget/ImageView;", "p", "Landroid/widget/ImageView;", "getIconView$core", "()Landroid/widget/ImageView;", "setIconView$core", "(Landroid/widget/ImageView;)V", "iconView", "n", "iconMargin", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "core"}, k = 1, mv = {1, 4, 0})
/* compiled from: DialogTitleLayout.kt */
public final class DialogTitleLayout extends j80 {
    public final int k;
    public final int l;
    public final int m;
    public final int n;
    public final int o;
    public ImageView p;
    public TextView q;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DialogTitleLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        a56.f(context, "context");
        a56.f(this, "$this$dimenPx");
        Context context2 = getContext();
        a56.b(context2, "context");
        this.k = context2.getResources().getDimensionPixelSize(R.dimen.md_dialog_frame_margin_vertical);
        a56.f(this, "$this$dimenPx");
        Context context3 = getContext();
        a56.b(context3, "context");
        this.l = context3.getResources().getDimensionPixelSize(R.dimen.md_dialog_title_layout_margin_bottom);
        a56.f(this, "$this$dimenPx");
        Context context4 = getContext();
        a56.b(context4, "context");
        this.m = context4.getResources().getDimensionPixelSize(R.dimen.md_dialog_frame_margin_horizontal);
        a56.f(this, "$this$dimenPx");
        Context context5 = getContext();
        a56.b(context5, "context");
        this.n = context5.getResources().getDimensionPixelSize(R.dimen.md_icon_margin);
        a56.f(this, "$this$dimenPx");
        Context context6 = getContext();
        a56.b(context6, "context");
        this.o = context6.getResources().getDimensionPixelSize(R.dimen.md_icon_size);
    }

    public final boolean b() {
        ImageView imageView = this.p;
        if (imageView != null) {
            a56.f(imageView, "$this$isNotVisible");
            if (!w70.I(imageView)) {
                TextView textView = this.q;
                if (textView != null) {
                    a56.f(textView, "$this$isNotVisible");
                    if (!w70.I(textView)) {
                        return true;
                    }
                } else {
                    a56.l("titleView");
                    throw null;
                }
            }
            return false;
        }
        a56.l("iconView");
        throw null;
    }

    public final ImageView getIconView$core() {
        ImageView imageView = this.p;
        if (imageView != null) {
            return imageView;
        }
        a56.l("iconView");
        throw null;
    }

    public final TextView getTitleView$core() {
        TextView textView = this.q;
        if (textView != null) {
            return textView;
        }
        a56.l("titleView");
        throw null;
    }

    public void onDraw(Canvas canvas) {
        a56.f(canvas, "canvas");
        super.onDraw(canvas);
        if (getDrawDivider()) {
            canvas.drawLine(Utils.FLOAT_EPSILON, ((float) getMeasuredHeight()) - ((float) getDividerHeight()), (float) getMeasuredWidth(), (float) getMeasuredHeight(), a());
        }
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        View findViewById = findViewById(R.id.md_icon_title);
        a56.b(findViewById, "findViewById(R.id.md_icon_title)");
        this.p = (ImageView) findViewById;
        View findViewById2 = findViewById(R.id.md_text_title);
        a56.b(findViewById2, "findViewById(R.id.md_text_title)");
        this.q = (TextView) findViewById2;
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5;
        int i6;
        int i7;
        int i8;
        if (!b()) {
            int i9 = this.k;
            int measuredHeight = getMeasuredHeight() - this.l;
            int i10 = measuredHeight - ((measuredHeight - i9) / 2);
            TextView textView = this.q;
            if (textView != null) {
                int measuredHeight2 = textView.getMeasuredHeight() / 2;
                int i11 = i10 - measuredHeight2;
                int i12 = measuredHeight2 + i10;
                TextView textView2 = this.q;
                if (textView2 != null) {
                    a56.f(textView2, "$this$additionalPaddingForFont");
                    TextPaint paint = textView2.getPaint();
                    a56.b(paint, "paint");
                    Paint.FontMetrics fontMetrics = paint.getFontMetrics();
                    float f = fontMetrics.descent - fontMetrics.ascent;
                    int measuredHeight3 = i12 + (f > ((float) textView2.getMeasuredHeight()) ? (int) (f - ((float) textView2.getMeasuredHeight())) : 0);
                    if (w70.G(this)) {
                        i6 = getMeasuredWidth() - this.m;
                        TextView textView3 = this.q;
                        if (textView3 != null) {
                            i5 = i6 - textView3.getMeasuredWidth();
                        } else {
                            a56.l("titleView");
                            throw null;
                        }
                    } else {
                        i5 = this.m;
                        TextView textView4 = this.q;
                        if (textView4 != null) {
                            i6 = textView4.getMeasuredWidth() + i5;
                        } else {
                            a56.l("titleView");
                            throw null;
                        }
                    }
                    ImageView imageView = this.p;
                    if (imageView != null) {
                        if (w70.I(imageView)) {
                            ImageView imageView2 = this.p;
                            if (imageView2 != null) {
                                int measuredHeight4 = imageView2.getMeasuredHeight() / 2;
                                int i13 = i10 - measuredHeight4;
                                int i14 = i10 + measuredHeight4;
                                if (w70.G(this)) {
                                    ImageView imageView3 = this.p;
                                    if (imageView3 != null) {
                                        i5 = i6 - imageView3.getMeasuredWidth();
                                        i8 = i5 - this.n;
                                        TextView textView5 = this.q;
                                        if (textView5 != null) {
                                            i7 = i8 - textView5.getMeasuredWidth();
                                        } else {
                                            a56.l("titleView");
                                            throw null;
                                        }
                                    } else {
                                        a56.l("iconView");
                                        throw null;
                                    }
                                } else {
                                    ImageView imageView4 = this.p;
                                    if (imageView4 != null) {
                                        i6 = imageView4.getMeasuredWidth() + i5;
                                        int i15 = this.n + i6;
                                        TextView textView6 = this.q;
                                        if (textView6 != null) {
                                            int measuredWidth = textView6.getMeasuredWidth() + i15;
                                            i7 = i15;
                                            i8 = measuredWidth;
                                        } else {
                                            a56.l("titleView");
                                            throw null;
                                        }
                                    } else {
                                        a56.l("iconView");
                                        throw null;
                                    }
                                }
                                ImageView imageView5 = this.p;
                                if (imageView5 != null) {
                                    imageView5.layout(i5, i13, i6, i14);
                                    i6 = i8;
                                    i5 = i7;
                                } else {
                                    a56.l("iconView");
                                    throw null;
                                }
                            } else {
                                a56.l("iconView");
                                throw null;
                            }
                        }
                        TextView textView7 = this.q;
                        if (textView7 != null) {
                            textView7.layout(i5, i11, i6, measuredHeight3);
                        } else {
                            a56.l("titleView");
                            throw null;
                        }
                    } else {
                        a56.l("iconView");
                        throw null;
                    }
                } else {
                    a56.l("titleView");
                    throw null;
                }
            } else {
                a56.l("titleView");
                throw null;
            }
        }
    }

    public void onMeasure(int i, int i2) {
        int i3 = 0;
        if (b()) {
            setMeasuredDimension(0, 0);
            return;
        }
        int size = View.MeasureSpec.getSize(i);
        int i4 = size - (this.m * 2);
        ImageView imageView = this.p;
        if (imageView != null) {
            if (w70.I(imageView)) {
                ImageView imageView2 = this.p;
                if (imageView2 != null) {
                    imageView2.measure(View.MeasureSpec.makeMeasureSpec(this.o, 1073741824), View.MeasureSpec.makeMeasureSpec(this.o, 1073741824));
                    ImageView imageView3 = this.p;
                    if (imageView3 != null) {
                        i4 -= imageView3.getMeasuredWidth() + this.n;
                    } else {
                        a56.l("iconView");
                        throw null;
                    }
                } else {
                    a56.l("iconView");
                    throw null;
                }
            }
            TextView textView = this.q;
            if (textView != null) {
                textView.measure(View.MeasureSpec.makeMeasureSpec(i4, Integer.MIN_VALUE), View.MeasureSpec.makeMeasureSpec(0, 0));
                ImageView imageView4 = this.p;
                if (imageView4 != null) {
                    if (w70.I(imageView4)) {
                        ImageView imageView5 = this.p;
                        if (imageView5 != null) {
                            i3 = imageView5.getMeasuredHeight();
                        } else {
                            a56.l("iconView");
                            throw null;
                        }
                    }
                    TextView textView2 = this.q;
                    if (textView2 != null) {
                        int measuredHeight = textView2.getMeasuredHeight();
                        if (i3 < measuredHeight) {
                            i3 = measuredHeight;
                        }
                        setMeasuredDimension(size, i3 + this.k + this.l);
                        return;
                    }
                    a56.l("titleView");
                    throw null;
                }
                a56.l("iconView");
                throw null;
            }
            a56.l("titleView");
            throw null;
        }
        a56.l("iconView");
        throw null;
    }

    public final void setIconView$core(ImageView imageView) {
        a56.f(imageView, "<set-?>");
        this.p = imageView;
    }

    public final void setTitleView$core(TextView textView) {
        a56.f(textView, "<set-?>");
        this.q = textView;
    }
}
