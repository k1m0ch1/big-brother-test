package com.afollestad.viewpagerdots;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import com.telkom.tracencare.R;
import defpackage.wk;
import kotlin.Metadata;

@Metadata(bv = {1, 0, 3}, d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u001c\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001:\u0001\nB\u001b\u0012\u0006\u0010'\u001a\u00020&\u0012\n\b\u0002\u0010)\u001a\u0004\u0018\u00010(¢\u0006\u0004\b*\u0010+J\u0017\u0010\u0005\u001a\u00020\u00042\b\b\u0001\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0005\u0010\u0006J\u0017\u0010\b\u001a\u00020\u00042\b\b\u0001\u0010\u0007\u001a\u00020\u0002¢\u0006\u0004\b\b\u0010\u0006J\u000f\u0010\n\u001a\u00020\tH\u0002¢\u0006\u0004\b\n\u0010\u000bR\u0016\u0010\u000e\u001a\u00020\t8\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b\f\u0010\rR\u0016\u0010\u0011\u001a\u00020\u00028\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b\u000f\u0010\u0010R\u0016\u0010\u0013\u001a\u00020\u00028\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b\u0012\u0010\u0010R\u0016\u0010\u0015\u001a\u00020\u00028\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b\u0014\u0010\u0010R\u0016\u0010\u0017\u001a\u00020\t8\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b\u0016\u0010\rR\u0016\u0010\u0019\u001a\u00020\u00028\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b\u0018\u0010\u0010R\u0016\u0010\u001b\u001a\u00020\t8\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b\u001a\u0010\rR\u0016\u0010\u001d\u001a\u00020\u00028\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b\u001c\u0010\u0010R\u0016\u0010\u001f\u001a\u00020\u00028\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b\u001e\u0010\u0010R\u0016\u0010!\u001a\u00020\u00028\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b \u0010\u0010R\u0016\u0010#\u001a\u00020\t8\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b\"\u0010\rR\u0016\u0010%\u001a\u00020\u00028\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b$\u0010\u0010¨\u0006,"}, d2 = {"Lcom/afollestad/viewpagerdots/DotsIndicator;", "Landroid/widget/LinearLayout;", "", "tint", "", "setDotTint", "(I)V", "tintRes", "setDotTintRes", "Landroid/animation/Animator;", "a", "()Landroid/animation/Animator;", "i", "Landroid/animation/Animator;", "animatorOut", "n", "I", "animatorResId", "g", "indicatorBackgroundResId", "q", "unselectedBackgroundId", "j", "animatorIn", "r", "dotTint", "k", "immediateAnimatorOut", "o", "animatorReverseResId", "p", "backgroundResId", "m", "lastPosition", "l", "immediateAnimatorIn", "h", "indicatorUnselectedBackgroundResId", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "com.afollestad.viewpagerdots"}, k = 1, mv = {1, 4, 0})
/* compiled from: DotsIndicator.kt */
public final class DotsIndicator extends LinearLayout {
    public int g;
    public int h;
    public Animator i;
    public Animator j;
    public Animator k;
    public Animator l;
    public int m = -1;
    public int n;
    public int o;
    public int p;
    public int q;
    public int r;

    /* compiled from: DotsIndicator.kt */
    public final class a implements Interpolator {
        /* JADX WARN: Incorrect args count in method signature: ()V */
        public a(DotsIndicator dotsIndicator) {
        }

        public float getInterpolation(float f) {
            return Math.abs(1.0f - f);
        }
    }

    /* JADX INFO: finally extract failed */
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DotsIndicator(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        a56.f(context, "context");
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, n80.a);
        try {
            obtainStyledAttributes.getDimensionPixelSize(5, -1);
            obtainStyledAttributes.getDimensionPixelSize(2, -1);
            obtainStyledAttributes.getDimensionPixelSize(3, -1);
            int i2 = obtainStyledAttributes.getInt(9, -1);
            int i3 = obtainStyledAttributes.getInt(8, -1);
            this.n = obtainStyledAttributes.getResourceId(6, R.animator.scale_with_alpha);
            int i4 = 0;
            this.o = obtainStyledAttributes.getResourceId(7, 0);
            int i5 = R.drawable.black_dot;
            int resourceId = obtainStyledAttributes.getResourceId(0, R.drawable.black_dot);
            this.p = resourceId;
            this.q = obtainStyledAttributes.getResourceId(1, resourceId);
            this.r = obtainStyledAttributes.getColor(4, 0);
            obtainStyledAttributes.recycle();
            Resources resources = getResources();
            a56.b(resources, "resources");
            TypedValue.applyDimension(1, (float) 5, resources.getDisplayMetrics());
            Animator loadAnimator = AnimatorInflater.loadAnimator(getContext(), this.n);
            a56.b(loadAnimator, "createAnimatorOut()");
            this.i = loadAnimator;
            Animator loadAnimator2 = AnimatorInflater.loadAnimator(getContext(), this.n);
            a56.b(loadAnimator2, "createAnimatorOut()");
            this.k = loadAnimator2;
            loadAnimator2.setDuration(0);
            this.j = a();
            Animator a2 = a();
            this.l = a2;
            a2.setDuration(0);
            int i6 = this.p;
            this.g = i6 != 0 ? i6 : i5;
            int i7 = this.q;
            this.h = i7 != 0 ? i7 : i6;
            setOrientation(i2 == 1 ? 1 : i4);
            setGravity(i3 < 0 ? 17 : i3);
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    public final Animator a() {
        if (this.o == 0) {
            Animator loadAnimator = AnimatorInflater.loadAnimator(getContext(), this.n);
            a56.b(loadAnimator, "loadAnimator(context, this.animatorResId)");
            loadAnimator.setInterpolator(new a(this));
            return loadAnimator;
        }
        Animator loadAnimator2 = AnimatorInflater.loadAnimator(getContext(), this.o);
        a56.b(loadAnimator2, "loadAnimator(context, this.animatorReverseResId)");
        return loadAnimator2;
    }

    public final void setDotTint(int i2) {
        this.r = i2;
        int childCount = getChildCount();
        int i3 = 0;
        while (i3 < childCount) {
            View childAt = getChildAt(i3);
            int i4 = -1 == i3 ? this.g : this.h;
            Context context = getContext();
            Object obj = wk.a;
            Drawable b = wk.c.b(context, i4);
            int i5 = this.r;
            if (i5 != 0) {
                if (b != null) {
                    a56.f(b, "$receiver");
                    b = ek.s0(b);
                    b.setTint(i5);
                    a56.b(b, "wrapped");
                } else {
                    b = null;
                }
            }
            a56.b(childAt, "indicator");
            childAt.setBackground(b);
            i3++;
        }
    }

    public final void setDotTintRes(int i2) {
        setDotTint(wk.b(getContext(), i2));
    }
}
