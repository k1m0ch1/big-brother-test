package com.airbnb.lottie;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.PathMeasure;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import androidx.appcompat.widget.AppCompatImageView;
import com.github.mikephil.charting.utils.Utils;
import com.telkom.tracencare.R;
import defpackage.a90;
import defpackage.co;
import java.io.ByteArrayInputStream;
import java.io.InterruptedIOException;
import java.lang.ref.WeakReference;
import java.net.ProtocolException;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.net.UnknownServiceException;
import java.nio.channels.ClosedChannelException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import javax.net.ssl.SSLException;

public class LottieAnimationView extends AppCompatImageView {
    public static final String A = LottieAnimationView.class.getSimpleName();
    public static final c90<Throwable> B = new a();
    public final c90<u80> i = new b();
    public final c90<Throwable> j = new c();
    public c90<Throwable> k;
    public int l;
    public final a90 m;
    public boolean n;
    public String o;
    public int p;
    public boolean q;
    public boolean r;
    public boolean s;
    public boolean t;
    public boolean u;
    public l90 v;
    public final Set<e90> w;
    public int x;
    public i90<u80> y;
    public u80 z;

    public class a implements c90<Throwable> {
        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object] */
        @Override // defpackage.c90
        public void onResult(Throwable th) {
            Throwable th2 = th;
            ThreadLocal<PathMeasure> threadLocal = ue0.a;
            if ((th2 instanceof SocketException) || (th2 instanceof ClosedChannelException) || (th2 instanceof InterruptedIOException) || (th2 instanceof ProtocolException) || (th2 instanceof SSLException) || (th2 instanceof UnknownHostException) || (th2 instanceof UnknownServiceException)) {
                qe0.c("Unable to load composition.", th2);
                return;
            }
            throw new IllegalStateException("Unable to parse composition", th2);
        }
    }

    public class b implements c90<u80> {
        public b() {
        }

        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object] */
        @Override // defpackage.c90
        public void onResult(u80 u80) {
            LottieAnimationView.this.setComposition(u80);
        }
    }

    public class c implements c90<Throwable> {
        public c() {
        }

        /* JADX DEBUG: Method arguments types fixed to match base method, original types: [java.lang.Object] */
        @Override // defpackage.c90
        public void onResult(Throwable th) {
            Throwable th2 = th;
            LottieAnimationView lottieAnimationView = LottieAnimationView.this;
            int i = lottieAnimationView.l;
            if (i != 0) {
                lottieAnimationView.setImageResource(i);
            }
            c90<Throwable> c90 = LottieAnimationView.this.k;
            if (c90 == null) {
                String str = LottieAnimationView.A;
                c90 = LottieAnimationView.B;
            }
            c90.onResult(th2);
        }
    }

    public static class d extends View.BaseSavedState {
        public static final Parcelable.Creator<d> CREATOR = new a();
        public String g;
        public int h;
        public float i;
        public boolean j;
        public String k;
        public int l;
        public int m;

        public class a implements Parcelable.Creator<d> {
            /* Return type fixed from 'java.lang.Object' to match base method */
            @Override // android.os.Parcelable.Creator
            public d createFromParcel(Parcel parcel) {
                return new d(parcel, null);
            }

            /* Return type fixed from 'java.lang.Object[]' to match base method */
            @Override // android.os.Parcelable.Creator
            public d[] newArray(int i) {
                return new d[i];
            }
        }

        public d(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeString(this.g);
            parcel.writeFloat(this.i);
            parcel.writeInt(this.j ? 1 : 0);
            parcel.writeString(this.k);
            parcel.writeInt(this.l);
            parcel.writeInt(this.m);
        }

        public d(Parcel parcel, a aVar) {
            super(parcel);
            this.g = parcel.readString();
            this.i = parcel.readFloat();
            this.j = parcel.readInt() != 1 ? false : true;
            this.k = parcel.readString();
            this.l = parcel.readInt();
            this.m = parcel.readInt();
        }
    }

    public LottieAnimationView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        String string;
        boolean z2 = false;
        this.l = 0;
        a90 a90 = new a90();
        this.m = a90;
        this.q = false;
        this.r = false;
        this.s = false;
        this.t = false;
        this.u = true;
        this.v = l90.AUTOMATIC;
        this.w = new HashSet();
        this.x = 0;
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, k90.a, R.attr.lottieAnimationViewStyle, 0);
        this.u = obtainStyledAttributes.getBoolean(1, true);
        boolean hasValue = obtainStyledAttributes.hasValue(9);
        boolean hasValue2 = obtainStyledAttributes.hasValue(5);
        boolean hasValue3 = obtainStyledAttributes.hasValue(15);
        if (!hasValue || !hasValue2) {
            if (hasValue) {
                int resourceId = obtainStyledAttributes.getResourceId(9, 0);
                if (resourceId != 0) {
                    setAnimation(resourceId);
                }
            } else if (hasValue2) {
                String string2 = obtainStyledAttributes.getString(5);
                if (string2 != null) {
                    setAnimation(string2);
                }
            } else if (hasValue3 && (string = obtainStyledAttributes.getString(15)) != null) {
                setAnimationFromUrl(string);
            }
            setFallbackResource(obtainStyledAttributes.getResourceId(4, 0));
            if (obtainStyledAttributes.getBoolean(0, false)) {
                this.s = true;
                this.t = true;
            }
            if (obtainStyledAttributes.getBoolean(7, false)) {
                a90.i.setRepeatCount(-1);
            }
            if (obtainStyledAttributes.hasValue(12)) {
                setRepeatMode(obtainStyledAttributes.getInt(12, 1));
            }
            if (obtainStyledAttributes.hasValue(11)) {
                setRepeatCount(obtainStyledAttributes.getInt(11, -1));
            }
            if (obtainStyledAttributes.hasValue(14)) {
                setSpeed(obtainStyledAttributes.getFloat(14, 1.0f));
            }
            setImageAssetsFolder(obtainStyledAttributes.getString(6));
            setProgress(obtainStyledAttributes.getFloat(8, Utils.FLOAT_EPSILON));
            boolean z3 = obtainStyledAttributes.getBoolean(3, false);
            if (a90.t != z3) {
                a90.t = z3;
                if (a90.h != null) {
                    a90.b();
                }
            }
            if (obtainStyledAttributes.hasValue(2)) {
                a90.a(new eb0("**"), f90.C, new xe0(new m90(obtainStyledAttributes.getColor(2, 0))));
            }
            if (obtainStyledAttributes.hasValue(13)) {
                a90.j = obtainStyledAttributes.getFloat(13, 1.0f);
                a90.v();
            }
            if (obtainStyledAttributes.hasValue(10)) {
                int i2 = obtainStyledAttributes.getInt(10, 0);
                l90.values();
                setRenderMode(l90.values()[i2 >= 3 ? 0 : i2]);
            }
            if (getScaleType() != null) {
                a90.o = getScaleType();
            }
            obtainStyledAttributes.recycle();
            Context context2 = getContext();
            ThreadLocal<PathMeasure> threadLocal = ue0.a;
            Boolean valueOf = Boolean.valueOf(Settings.Global.getFloat(context2.getContentResolver(), "animator_duration_scale", 1.0f) != Utils.FLOAT_EPSILON ? true : z2);
            Objects.requireNonNull(a90);
            a90.k = valueOf.booleanValue();
            d();
            this.n = true;
            return;
        }
        throw new IllegalArgumentException("lottie_rawRes and lottie_fileName cannot be used at the same time. Please use only one at once.");
    }

    private void setCompositionTask(i90<u80> i90) {
        this.z = null;
        this.m.c();
        c();
        i90.b(this.i);
        i90.a(this.j);
        this.y = i90;
    }

    public void buildDrawingCache(boolean z2) {
        this.x++;
        super.buildDrawingCache(z2);
        if (this.x == 1 && getWidth() > 0 && getHeight() > 0 && getLayerType() == 1 && getDrawingCache(z2) == null) {
            setRenderMode(l90.HARDWARE);
        }
        this.x--;
        r80.a("buildDrawingCache");
    }

    public final void c() {
        i90<u80> i90 = this.y;
        if (i90 != null) {
            c90<u80> c90 = this.i;
            synchronized (i90) {
                i90.a.remove(c90);
            }
            i90<u80> i902 = this.y;
            c90<Throwable> c902 = this.j;
            synchronized (i902) {
                i902.b.remove(c902);
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0032, code lost:
        if (r3 != false) goto L_0x0034;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:2:0x000a, code lost:
        if (r0 != 1) goto L_0x000c;
     */
    public final void d() {
        int i2;
        int ordinal = this.v.ordinal();
        int i3 = 2;
        if (ordinal == 0) {
            u80 u80 = this.z;
            boolean z2 = false;
            if ((u80 == null || !u80.n || Build.VERSION.SDK_INT >= 28) && !((u80 != null && u80.o > 4) || (i2 = Build.VERSION.SDK_INT) == 24 || i2 == 25)) {
                z2 = true;
            }
        }
        i3 = 1;
        if (i3 != getLayerType()) {
            setLayerType(i3, null);
        }
    }

    public void e() {
        if (isShown()) {
            this.m.j();
            d();
            return;
        }
        this.q = true;
    }

    public u80 getComposition() {
        return this.z;
    }

    public long getDuration() {
        u80 u80 = this.z;
        if (u80 != null) {
            return (long) u80.b();
        }
        return 0;
    }

    public int getFrame() {
        return (int) this.m.i.l;
    }

    public String getImageAssetsFolder() {
        return this.m.q;
    }

    public float getMaxFrame() {
        return this.m.e();
    }

    public float getMinFrame() {
        return this.m.f();
    }

    public j90 getPerformanceTracker() {
        u80 u80 = this.m.h;
        if (u80 != null) {
            return u80.a;
        }
        return null;
    }

    public float getProgress() {
        return this.m.g();
    }

    public int getRepeatCount() {
        return this.m.h();
    }

    public int getRepeatMode() {
        return this.m.i.getRepeatMode();
    }

    public float getScale() {
        return this.m.j;
    }

    public float getSpeed() {
        return this.m.i.i;
    }

    public void invalidateDrawable(Drawable drawable) {
        Drawable drawable2 = getDrawable();
        a90 a90 = this.m;
        if (drawable2 == a90) {
            super.invalidateDrawable(a90);
        } else {
            super.invalidateDrawable(drawable);
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (!isInEditMode() && (this.t || this.s)) {
            e();
            this.t = false;
            this.s = false;
        }
        if (Build.VERSION.SDK_INT < 23) {
            onVisibilityChanged(this, getVisibility());
        }
    }

    public void onDetachedFromWindow() {
        if (this.m.i()) {
            this.s = false;
            this.r = false;
            this.q = false;
            a90 a90 = this.m;
            a90.m.clear();
            a90.i.cancel();
            d();
            this.s = true;
        }
        super.onDetachedFromWindow();
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof d)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        d dVar = (d) parcelable;
        super.onRestoreInstanceState(dVar.getSuperState());
        String str = dVar.g;
        this.o = str;
        if (!TextUtils.isEmpty(str)) {
            setAnimation(this.o);
        }
        int i2 = dVar.h;
        this.p = i2;
        if (i2 != 0) {
            setAnimation(i2);
        }
        setProgress(dVar.i);
        if (dVar.j) {
            e();
        }
        this.m.q = dVar.k;
        setRepeatMode(dVar.l);
        setRepeatCount(dVar.m);
    }

    public Parcelable onSaveInstanceState() {
        boolean z2;
        d dVar = new d(super.onSaveInstanceState());
        dVar.g = this.o;
        dVar.h = this.p;
        dVar.i = this.m.g();
        if (!this.m.i()) {
            AtomicInteger atomicInteger = co.a;
            if (co.f.b(this) || !this.s) {
                z2 = false;
                dVar.j = z2;
                a90 a90 = this.m;
                dVar.k = a90.q;
                dVar.l = a90.i.getRepeatMode();
                dVar.m = this.m.h();
                return dVar;
            }
        }
        z2 = true;
        dVar.j = z2;
        a90 a902 = this.m;
        dVar.k = a902.q;
        dVar.l = a902.i.getRepeatMode();
        dVar.m = this.m.h();
        return dVar;
    }

    public void onVisibilityChanged(View view, int i2) {
        if (this.n) {
            if (isShown()) {
                if (this.r) {
                    if (isShown()) {
                        this.m.k();
                        d();
                    } else {
                        this.q = false;
                        this.r = true;
                    }
                } else if (this.q) {
                    e();
                }
                this.r = false;
                this.q = false;
            } else if (this.m.i()) {
                this.t = false;
                this.s = false;
                this.r = false;
                this.q = false;
                a90 a90 = this.m;
                a90.m.clear();
                a90.i.j();
                d();
                this.r = true;
            }
        }
    }

    public void setAnimation(int i2) {
        i90<u80> i90;
        i90<u80> i902;
        this.p = i2;
        this.o = null;
        if (isInEditMode()) {
            i90 = new i90<>(new s80(this, i2), true);
        } else {
            if (this.u) {
                Context context = getContext();
                String h = v80.h(context, i2);
                i902 = v80.a(h, new y80(new WeakReference(context), context.getApplicationContext(), i2, h));
            } else {
                Context context2 = getContext();
                Map<String, i90<u80>> map = v80.a;
                i902 = v80.a(null, new y80(new WeakReference(context2), context2.getApplicationContext(), i2, null));
            }
            i90 = i902;
        }
        setCompositionTask(i90);
    }

    @Deprecated
    public void setAnimationFromJson(String str) {
        setCompositionTask(v80.a(null, new z80(new ByteArrayInputStream(str.getBytes()), null)));
    }

    public void setAnimationFromUrl(String str) {
        i90<u80> i90;
        if (this.u) {
            Context context = getContext();
            Map<String, i90<u80>> map = v80.a;
            String r0 = ze0.r0("url_", str);
            i90 = v80.a(r0, new w80(context, str, r0));
        } else {
            i90 = v80.a(null, new w80(getContext(), str, null));
        }
        setCompositionTask(i90);
    }

    public void setApplyingOpacityToLayersEnabled(boolean z2) {
        this.m.y = z2;
    }

    public void setCacheComposition(boolean z2) {
        this.u = z2;
    }

    public void setComposition(u80 u80) {
        this.m.setCallback(this);
        this.z = u80;
        a90 a90 = this.m;
        boolean z2 = false;
        if (a90.h != u80) {
            a90.A = false;
            a90.c();
            a90.h = u80;
            a90.b();
            re0 re0 = a90.i;
            if (re0.p == null) {
                z2 = true;
            }
            re0.p = u80;
            if (z2) {
                re0.l((float) ((int) Math.max(re0.n, u80.k)), (float) ((int) Math.min(re0.o, u80.l)));
            } else {
                re0.l((float) ((int) u80.k), (float) ((int) u80.l));
            }
            float f = re0.l;
            re0.l = Utils.FLOAT_EPSILON;
            re0.k((float) ((int) f));
            re0.c();
            a90.u(a90.i.getAnimatedFraction());
            a90.j = a90.j;
            a90.v();
            a90.v();
            Iterator it = new ArrayList(a90.m).iterator();
            while (it.hasNext()) {
                ((a90.o) it.next()).a(u80);
                it.remove();
            }
            a90.m.clear();
            u80.a.a = a90.w;
            Drawable.Callback callback = a90.getCallback();
            if (callback instanceof ImageView) {
                ImageView imageView = (ImageView) callback;
                imageView.setImageDrawable(null);
                imageView.setImageDrawable(a90);
            }
            z2 = true;
        }
        d();
        if (getDrawable() != this.m || z2) {
            onVisibilityChanged(this, getVisibility());
            requestLayout();
            for (e90 e90 : this.w) {
                e90.a(u80);
            }
        }
    }

    public void setFailureListener(c90<Throwable> c90) {
        this.k = c90;
    }

    public void setFallbackResource(int i2) {
        this.l = i2;
    }

    public void setFontAssetDelegate(o80 o80) {
        ya0 ya0 = this.m.s;
    }

    public void setFrame(int i2) {
        this.m.l(i2);
    }

    public void setImageAssetDelegate(p80 p80) {
        a90 a90 = this.m;
        a90.r = p80;
        za0 za0 = a90.p;
        if (za0 != null) {
            za0.c = p80;
        }
    }

    public void setImageAssetsFolder(String str) {
        this.m.q = str;
    }

    @Override // androidx.appcompat.widget.AppCompatImageView
    public void setImageBitmap(Bitmap bitmap) {
        c();
        super.setImageBitmap(bitmap);
    }

    @Override // androidx.appcompat.widget.AppCompatImageView
    public void setImageDrawable(Drawable drawable) {
        c();
        super.setImageDrawable(drawable);
    }

    @Override // androidx.appcompat.widget.AppCompatImageView
    public void setImageResource(int i2) {
        c();
        super.setImageResource(i2);
    }

    public void setMaxFrame(int i2) {
        this.m.m(i2);
    }

    public void setMaxProgress(float f) {
        this.m.o(f);
    }

    public void setMinAndMaxFrame(String str) {
        this.m.q(str);
    }

    public void setMinFrame(int i2) {
        this.m.r(i2);
    }

    public void setMinProgress(float f) {
        this.m.t(f);
    }

    public void setOutlineMasksAndMattes(boolean z2) {
        a90 a90 = this.m;
        if (a90.x != z2) {
            a90.x = z2;
            qc0 qc0 = a90.u;
            if (qc0 != null) {
                qc0.p(z2);
            }
        }
    }

    public void setPerformanceTrackingEnabled(boolean z2) {
        a90 a90 = this.m;
        a90.w = z2;
        u80 u80 = a90.h;
        if (u80 != null) {
            u80.a.a = z2;
        }
    }

    public void setProgress(float f) {
        this.m.u(f);
    }

    public void setRenderMode(l90 l90) {
        this.v = l90;
        d();
    }

    public void setRepeatCount(int i2) {
        this.m.i.setRepeatCount(i2);
    }

    public void setRepeatMode(int i2) {
        this.m.i.setRepeatMode(i2);
    }

    public void setSafeMode(boolean z2) {
        this.m.l = z2;
    }

    public void setScale(float f) {
        a90 a90 = this.m;
        a90.j = f;
        a90.v();
        if (getDrawable() == this.m) {
            setImageDrawable(null);
            setImageDrawable(this.m);
        }
    }

    public void setScaleType(ImageView.ScaleType scaleType) {
        super.setScaleType(scaleType);
        a90 a90 = this.m;
        if (a90 != null) {
            a90.o = scaleType;
        }
    }

    public void setSpeed(float f) {
        this.m.i.i = f;
    }

    public void setTextDelegate(n90 n90) {
        Objects.requireNonNull(this.m);
    }

    public void setMaxFrame(String str) {
        this.m.n(str);
    }

    public void setMinFrame(String str) {
        this.m.s(str);
    }

    public void setAnimation(String str) {
        i90<u80> i90;
        i90<u80> i902;
        this.o = str;
        this.p = 0;
        if (isInEditMode()) {
            i90 = new i90<>(new t80(this, str), true);
        } else {
            if (this.u) {
                Context context = getContext();
                Map<String, i90<u80>> map = v80.a;
                String r0 = ze0.r0("asset_", str);
                i902 = v80.a(r0, new x80(context.getApplicationContext(), str, r0));
            } else {
                Context context2 = getContext();
                Map<String, i90<u80>> map2 = v80.a;
                i902 = v80.a(null, new x80(context2.getApplicationContext(), str, null));
            }
            i90 = i902;
        }
        setCompositionTask(i90);
    }
}
